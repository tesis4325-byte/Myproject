<?php
// Simple test to check auth API
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "Testing Auth API...\n";

// Test database connection first
try {
    require_once 'config/Database.php';
    $db = Database::getInstance()->getConnection();
    echo "Database connection: SUCCESS\n";
} catch (Exception $e) {
    echo "Database connection: FAILED - " . $e->getMessage() . "\n";
    exit;
}

// Test API call
$url = 'http://localhost/rmdelivery/api/auth.php?action=login';
$data = json_encode([
    'phone' => '09123456789',
    'password' => 'password123',
    'user_type' => 'admin'
]);

$context = stream_context_create([
    'http' => [
        'method' => 'POST',
        'header' => "Content-Type: application/json\r\n",
        'content' => $data
    ]
]);

$result = file_get_contents($url, false, $context);
echo "API Response:\n";
echo $result;
?>
