<?php
// Database Setup Script
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h2>RM Delivery Database Setup</h2>";

try {
    // Connect to MySQL without specifying database
    $pdo = new PDO(
        "mysql:host=localhost;charset=utf8mb4",
        "root",
        "",
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
        ]
    );
    
    echo "<p>✅ Connected to MySQL server</p>";
    
    // Create database if it doesn't exist
    $pdo->exec("CREATE DATABASE IF NOT EXISTS rmdelivery_db");
    echo "<p>✅ Database 'rmdelivery_db' created/verified</p>";
    
    // Use the database
    $pdo->exec("USE rmdelivery_db");
    echo "<p>✅ Using rmdelivery_db database</p>";
    
    // Read and execute schema
    $schemaFile = 'sql/schema.sql';
    if (file_exists($schemaFile)) {
        $schema = file_get_contents($schemaFile);
        
        // Remove USE statement and comments, split by semicolon
        $schema = preg_replace('/USE\s+\w+;/', '', $schema);
        $statements = array_filter(array_map('trim', explode(';', $schema)));
        
        foreach ($statements as $statement) {
            if (!empty($statement) && !preg_match('/^--/', $statement)) {
                try {
                    $pdo->exec($statement);
                } catch (PDOException $e) {
                    // Ignore table exists errors
                    if (strpos($e->getMessage(), 'already exists') === false) {
                        throw $e;
                    }
                }
            }
        }
        echo "<p>✅ Database schema created</p>";
    }
    
    // Read and execute seed data
    $seedFile = 'sql/seed.sql';
    if (file_exists($seedFile)) {
        $seed = file_get_contents($seedFile);
        
        // Remove USE statement and comments, split by semicolon
        $seed = preg_replace('/USE\s+\w+;/', '', $seed);
        $statements = array_filter(array_map('trim', explode(';', $seed)));
        
        foreach ($statements as $statement) {
            if (!empty($statement) && !preg_match('/^--/', $statement)) {
                try {
                    $pdo->exec($statement);
                } catch (PDOException $e) {
                    // Ignore duplicate entry errors
                    if (strpos($e->getMessage(), 'Duplicate entry') === false) {
                        echo "<p>⚠️ Warning: " . $e->getMessage() . "</p>";
                    }
                }
            }
        }
        echo "<p>✅ Sample data inserted</p>";
    }
    
    echo "<h3>✅ Database Setup Complete!</h3>";
    echo "<p><strong>Test Credentials:</strong></p>";
    echo "<ul>";
    echo "<li><strong>Admin:</strong> Phone: 09123456789, Password: password123</li>";
    echo "<li><strong>Rider:</strong> Phone: 09987654321, Password: password123</li>";
    echo "<li><strong>Customer:</strong> Phone: 09111111111, Password: password123</li>";
    echo "</ul>";
    
    echo "<p><a href='admin/index.php'>Go to Admin Login</a> | <a href='rider/index.php'>Go to Rider Login</a></p>";
    
} catch (Exception $e) {
    echo "<p>❌ Error: " . $e->getMessage() . "</p>";
}
?>
