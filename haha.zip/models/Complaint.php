<?php
class Complaint {
    private $conn;
    private $table = 'complaints';

    public function __construct($db) {
        $this->conn = $db;
    }

    public function create($data) {
        try {
            $query = "
                INSERT INTO {$this->table} 
                (customer_id, rider_id, merchant_id, booking_id, type, subject, description, priority, status, created_at) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'open', NOW())
            ";
            
            $stmt = $this->conn->prepare($query);
            $stmt->execute([
                $data['customer_id'] ?? null,
                $data['rider_id'] ?? null,
                $data['merchant_id'] ?? null,
                $data['booking_id'] ?? null,
                $data['type'],
                $data['subject'],
                $data['description'],
                $data['priority'] ?? 'medium'
            ]);
            
            return $this->conn->lastInsertId();
        } catch (Exception $e) {
            throw new Exception("Error creating complaint: " . $e->getMessage());
        }
    }

    public function getById($id) {
        try {
            $query = "
                SELECT c.*, 
                       cu.name as customer_name, cu.phone as customer_phone,
                       r.name as rider_name, r.phone as rider_phone,
                       m.name as merchant_name, m.phone as merchant_phone,
                       b.booking_number, b.service_type
                FROM {$this->table} c
                LEFT JOIN customers cu ON c.customer_id = cu.id
                LEFT JOIN riders r ON c.rider_id = r.id
                LEFT JOIN merchants m ON c.merchant_id = m.id
                LEFT JOIN bookings b ON c.booking_id = b.id
                WHERE c.id = ?
            ";
            
            $stmt = $this->conn->prepare($query);
            $stmt->execute([$id]);
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            throw new Exception("Error fetching complaint: " . $e->getMessage());
        }
    }

    public function getAll($filters = []) {
        try {
            $query = "
                SELECT c.*, 
                       cu.name as customer_name,
                       r.name as rider_name,
                       m.name as merchant_name,
                       b.booking_number
                FROM {$this->table} c
                LEFT JOIN customers cu ON c.customer_id = cu.id
                LEFT JOIN riders r ON c.rider_id = r.id
                LEFT JOIN merchants m ON c.merchant_id = m.id
                LEFT JOIN bookings b ON c.booking_id = b.id
                WHERE 1=1
            ";
            
            $params = [];
            
            if (!empty($filters['status'])) {
                $query .= " AND c.status = ?";
                $params[] = $filters['status'];
            }
            
            if (!empty($filters['type'])) {
                $query .= " AND c.type = ?";
                $params[] = $filters['type'];
            }
            
            if (!empty($filters['priority'])) {
                $query .= " AND c.priority = ?";
                $params[] = $filters['priority'];
            }
            
            if (!empty($filters['customer_id'])) {
                $query .= " AND c.customer_id = ?";
                $params[] = $filters['customer_id'];
            }
            
            if (!empty($filters['rider_id'])) {
                $query .= " AND c.rider_id = ?";
                $params[] = $filters['rider_id'];
            }
            
            if (!empty($filters['merchant_id'])) {
                $query .= " AND c.merchant_id = ?";
                $params[] = $filters['merchant_id'];
            }
            
            if (!empty($filters['start_date'])) {
                $query .= " AND DATE(c.created_at) >= ?";
                $params[] = $filters['start_date'];
            }
            
            if (!empty($filters['end_date'])) {
                $query .= " AND DATE(c.created_at) <= ?";
                $params[] = $filters['end_date'];
            }
            
            $query .= " ORDER BY c.created_at DESC";
            
            if (!empty($filters['limit'])) {
                $query .= " LIMIT ?";
                $params[] = $filters['limit'];
            }
            
            $stmt = $this->conn->prepare($query);
            $stmt->execute($params);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            throw new Exception("Error fetching complaints: " . $e->getMessage());
        }
    }

    public function update($id, $data) {
        try {
            $fields = [];
            $params = [];
            
            $allowedFields = ['status', 'priority', 'assigned_to', 'resolution', 'admin_notes'];
            
            foreach ($allowedFields as $field) {
                if (isset($data[$field])) {
                    $fields[] = "{$field} = ?";
                    $params[] = $data[$field];
                }
            }
            
            if (empty($fields)) {
                return false;
            }
            
            $fields[] = "updated_at = NOW()";
            
            if (isset($data['status']) && $data['status'] === 'resolved') {
                $fields[] = "resolved_at = NOW()";
            }
            
            $query = "UPDATE {$this->table} SET " . implode(', ', $fields) . " WHERE id = ?";
            $params[] = $id;
            
            $stmt = $this->conn->prepare($query);
            return $stmt->execute($params);
        } catch (Exception $e) {
            throw new Exception("Error updating complaint: " . $e->getMessage());
        }
    }

    public function delete($id) {
        try {
            $query = "DELETE FROM {$this->table} WHERE id = ?";
            $stmt = $this->conn->prepare($query);
            return $stmt->execute([$id]);
        } catch (Exception $e) {
            throw new Exception("Error deleting complaint: " . $e->getMessage());
        }
    }

    public function getByBooking($bookingId) {
        try {
            $query = "
                SELECT c.*, 
                       cu.name as customer_name,
                       r.name as rider_name,
                       m.name as merchant_name
                FROM {$this->table} c
                LEFT JOIN customers cu ON c.customer_id = cu.id
                LEFT JOIN riders r ON c.rider_id = r.id
                LEFT JOIN merchants m ON c.merchant_id = m.id
                WHERE c.booking_id = ?
                ORDER BY c.created_at DESC
            ";
            
            $stmt = $this->conn->prepare($query);
            $stmt->execute([$bookingId]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            throw new Exception("Error fetching complaints by booking: " . $e->getMessage());
        }
    }

    public function getByCustomer($customerId, $limit = 10) {
        try {
            $query = "
                SELECT c.*, 
                       r.name as rider_name,
                       m.name as merchant_name,
                       b.booking_number
                FROM {$this->table} c
                LEFT JOIN riders r ON c.rider_id = r.id
                LEFT JOIN merchants m ON c.merchant_id = m.id
                LEFT JOIN bookings b ON c.booking_id = b.id
                WHERE c.customer_id = ?
                ORDER BY c.created_at DESC
                LIMIT ?
            ";
            
            $stmt = $this->conn->prepare($query);
            $stmt->execute([$customerId, $limit]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            throw new Exception("Error fetching customer complaints: " . $e->getMessage());
        }
    }

    public function getByRider($riderId, $limit = 10) {
        try {
            $query = "
                SELECT c.*, 
                       cu.name as customer_name,
                       b.booking_number
                FROM {$this->table} c
                LEFT JOIN customers cu ON c.customer_id = cu.id
                LEFT JOIN bookings b ON c.booking_id = b.id
                WHERE c.rider_id = ?
                ORDER BY c.created_at DESC
                LIMIT ?
            ";
            
            $stmt = $this->conn->prepare($query);
            $stmt->execute([$riderId, $limit]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            throw new Exception("Error fetching rider complaints: " . $e->getMessage());
        }
    }

    public function getByMerchant($merchantId, $limit = 10) {
        try {
            $query = "
                SELECT c.*, 
                       cu.name as customer_name,
                       b.booking_number
                FROM {$this->table} c
                LEFT JOIN customers cu ON c.customer_id = cu.id
                LEFT JOIN bookings b ON c.booking_id = b.id
                WHERE c.merchant_id = ?
                ORDER BY c.created_at DESC
                LIMIT ?
            ";
            
            $stmt = $this->conn->prepare($query);
            $stmt->execute([$merchantId, $limit]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            throw new Exception("Error fetching merchant complaints: " . $e->getMessage());
        }
    }

    public function getStats($period = '30days') {
        try {
            $dateCondition = $this->getDateCondition($period);
            
            $query = "
                SELECT 
                    COUNT(*) as total_complaints,
                    COUNT(CASE WHEN status = 'open' THEN 1 END) as open_complaints,
                    COUNT(CASE WHEN status = 'in_progress' THEN 1 END) as in_progress_complaints,
                    COUNT(CASE WHEN status = 'resolved' THEN 1 END) as resolved_complaints,
                    COUNT(CASE WHEN priority = 'high' THEN 1 END) as high_priority,
                    COUNT(CASE WHEN priority = 'medium' THEN 1 END) as medium_priority,
                    COUNT(CASE WHEN priority = 'low' THEN 1 END) as low_priority,
                    AVG(TIMESTAMPDIFF(HOUR, created_at, resolved_at)) as avg_resolution_time
                FROM {$this->table}
                WHERE {$dateCondition}
            ";
            
            $stmt = $this->conn->prepare($query);
            $stmt->execute();
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            throw new Exception("Error fetching complaint stats: " . $e->getMessage());
        }
    }

    public function getComplaintsByType($period = '30days') {
        try {
            $dateCondition = $this->getDateCondition($period);
            
            $query = "
                SELECT 
                    type,
                    COUNT(*) as count,
                    COUNT(CASE WHEN status = 'resolved' THEN 1 END) as resolved_count
                FROM {$this->table}
                WHERE {$dateCondition}
                GROUP BY type
                ORDER BY count DESC
            ";
            
            $stmt = $this->conn->prepare($query);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            throw new Exception("Error fetching complaints by type: " . $e->getMessage());
        }
    }

    public function assignComplaint($id, $adminId) {
        try {
            $query = "UPDATE {$this->table} SET assigned_to = ?, status = 'in_progress', updated_at = NOW() WHERE id = ?";
            $stmt = $this->conn->prepare($query);
            return $stmt->execute([$adminId, $id]);
        } catch (Exception $e) {
            throw new Exception("Error assigning complaint: " . $e->getMessage());
        }
    }

    public function resolveComplaint($id, $resolution, $adminId) {
        try {
            $query = "
                UPDATE {$this->table} 
                SET status = 'resolved', resolution = ?, assigned_to = ?, resolved_at = NOW(), updated_at = NOW() 
                WHERE id = ?
            ";
            $stmt = $this->conn->prepare($query);
            return $stmt->execute([$resolution, $adminId, $id]);
        } catch (Exception $e) {
            throw new Exception("Error resolving complaint: " . $e->getMessage());
        }
    }

    public function reopenComplaint($id, $reason) {
        try {
            $query = "
                UPDATE {$this->table} 
                SET status = 'open', admin_notes = CONCAT(COALESCE(admin_notes, ''), '\nReopened: ', ?), updated_at = NOW() 
                WHERE id = ?
            ";
            $stmt = $this->conn->prepare($query);
            return $stmt->execute([$reason, $id]);
        } catch (Exception $e) {
            throw new Exception("Error reopening complaint: " . $e->getMessage());
        }
    }

    public function addNote($id, $note, $adminId) {
        try {
            $query = "
                UPDATE {$this->table} 
                SET admin_notes = CONCAT(COALESCE(admin_notes, ''), '\n[', NOW(), ' - Admin ID: ', ?, '] ', ?), updated_at = NOW() 
                WHERE id = ?
            ";
            $stmt = $this->conn->prepare($query);
            return $stmt->execute([$adminId, $note, $id]);
        } catch (Exception $e) {
            throw new Exception("Error adding note to complaint: " . $e->getMessage());
        }
    }

    public function escalateComplaint($id, $newPriority = 'high') {
        try {
            $query = "UPDATE {$this->table} SET priority = ?, updated_at = NOW() WHERE id = ?";
            $stmt = $this->conn->prepare($query);
            return $stmt->execute([$newPriority, $id]);
        } catch (Exception $e) {
            throw new Exception("Error escalating complaint: " . $e->getMessage());
        }
    }

    public function searchComplaints($query, $filters = []) {
        try {
            $sql = "
                SELECT c.*, 
                       cu.name as customer_name,
                       r.name as rider_name,
                       m.name as merchant_name,
                       b.booking_number
                FROM {$this->table} c
                LEFT JOIN customers cu ON c.customer_id = cu.id
                LEFT JOIN riders r ON c.rider_id = r.id
                LEFT JOIN merchants m ON c.merchant_id = m.id
                LEFT JOIN bookings b ON c.booking_id = b.id
                WHERE (c.subject LIKE ? OR c.description LIKE ? OR cu.name LIKE ? OR r.name LIKE ? OR m.name LIKE ?)
            ";
            
            $params = ["%{$query}%", "%{$query}%", "%{$query}%", "%{$query}%", "%{$query}%"];
            
            if (!empty($filters['status'])) {
                $sql .= " AND c.status = ?";
                $params[] = $filters['status'];
            }
            
            if (!empty($filters['type'])) {
                $sql .= " AND c.type = ?";
                $params[] = $filters['type'];
            }
            
            $sql .= " ORDER BY c.created_at DESC";
            
            if (!empty($filters['limit'])) {
                $sql .= " LIMIT ?";
                $params[] = $filters['limit'];
            }
            
            $stmt = $this->conn->prepare($sql);
            $stmt->execute($params);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            throw new Exception("Error searching complaints: " . $e->getMessage());
        }
    }

    public function getComplaintTrends($period = '30days') {
        try {
            $dateCondition = $this->getDateCondition($period);
            
            $query = "
                SELECT 
                    DATE(created_at) as date,
                    COUNT(*) as total_complaints,
                    COUNT(CASE WHEN status = 'resolved' THEN 1 END) as resolved_complaints
                FROM {$this->table}
                WHERE {$dateCondition}
                GROUP BY DATE(created_at)
                ORDER BY date ASC
            ";
            
            $stmt = $this->conn->prepare($query);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            throw new Exception("Error fetching complaint trends: " . $e->getMessage());
        }
    }

    private function getDateCondition($period) {
        switch ($period) {
            case 'today':
                return "DATE(created_at) = CURDATE()";
            case 'yesterday':
                return "DATE(created_at) = DATE_SUB(CURDATE(), INTERVAL 1 DAY)";
            case 'week':
                return "created_at >= DATE_SUB(NOW(), INTERVAL 1 WEEK)";
            case '30days':
                return "created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)";
            case 'month':
                return "MONTH(created_at) = MONTH(NOW()) AND YEAR(created_at) = YEAR(NOW())";
            case 'year':
                return "YEAR(created_at) = YEAR(NOW())";
            default:
                return "1=1";
        }
    }
}
?>
