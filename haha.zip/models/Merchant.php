<?php
require_once __DIR__ . '/../config/Database.php';
require_once __DIR__ . '/../config/AppConfig.php';

class Merchant {
    private $conn;
    private $table_name = "merchants";

    public $id;
    public $name;
    public $slug;
    public $logo;
    public $description;
    public $phone;
    public $email;
    public $address;
    public $lat;
    public $lng;
    public $opening_hours;
    public $is_active;
    public $commission_rate;
    public $service_fee;
    public $rating;
    public $total_orders;
    public $created_at;
    public $updated_at;

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    public function create() {
        $query = "INSERT INTO " . $this->table_name . "
                  SET name = :name, slug = :slug, logo = :logo, description = :description,
                      phone = :phone, email = :email, address = :address, lat = :lat, lng = :lng,
                      opening_hours = :opening_hours, commission_rate = :commission_rate, 
                      service_fee = :service_fee";

        $stmt = $this->conn->prepare($query);

        $stmt->bindParam(':name', $this->name);
        $stmt->bindParam(':slug', $this->slug);
        $stmt->bindParam(':logo', $this->logo);
        $stmt->bindParam(':description', $this->description);
        $stmt->bindParam(':phone', $this->phone);
        $stmt->bindParam(':email', $this->email);
        $stmt->bindParam(':address', $this->address);
        $stmt->bindParam(':lat', $this->lat);
        $stmt->bindParam(':lng', $this->lng);
        $stmt->bindParam(':opening_hours', $this->opening_hours);
        $stmt->bindParam(':commission_rate', $this->commission_rate);
        $stmt->bindParam(':service_fee', $this->service_fee);

        if ($stmt->execute()) {
            $this->id = $this->conn->lastInsertId();
            AppConfig::logActivity(null, 'create_merchant', "New merchant created: {$this->name}");
            return true;
        }
        return false;
    }

    public function update() {
        $query = "UPDATE " . $this->table_name . "
                  SET name = :name, slug = :slug, logo = :logo, description = :description,
                      phone = :phone, email = :email, address = :address, lat = :lat, lng = :lng,
                      opening_hours = :opening_hours, is_active = :is_active, 
                      commission_rate = :commission_rate, service_fee = :service_fee
                  WHERE id = :id";

        $stmt = $this->conn->prepare($query);

        $stmt->bindParam(':name', $this->name);
        $stmt->bindParam(':slug', $this->slug);
        $stmt->bindParam(':logo', $this->logo);
        $stmt->bindParam(':description', $this->description);
        $stmt->bindParam(':phone', $this->phone);
        $stmt->bindParam(':email', $this->email);
        $stmt->bindParam(':address', $this->address);
        $stmt->bindParam(':lat', $this->lat);
        $stmt->bindParam(':lng', $this->lng);
        $stmt->bindParam(':opening_hours', $this->opening_hours);
        $stmt->bindParam(':is_active', $this->is_active);
        $stmt->bindParam(':commission_rate', $this->commission_rate);
        $stmt->bindParam(':service_fee', $this->service_fee);
        $stmt->bindParam(':id', $this->id);

        if ($stmt->execute()) {
            AppConfig::logActivity(null, 'update_merchant', "Merchant updated: {$this->name}");
            return true;
        }
        return false;
    }

    public function getById($id) {
        $query = "SELECT * FROM " . $this->table_name . " WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->execute();

        if ($stmt->rowCount() > 0) {
            $row = $stmt->fetch();
            $this->id = $row['id'];
            $this->name = $row['name'];
            $this->slug = $row['slug'];
            $this->logo = $row['logo'];
            $this->description = $row['description'];
            $this->phone = $row['phone'];
            $this->email = $row['email'];
            $this->address = $row['address'];
            $this->lat = $row['lat'];
            $this->lng = $row['lng'];
            $this->opening_hours = $row['opening_hours'];
            $this->is_active = $row['is_active'];
            $this->commission_rate = $row['commission_rate'];
            $this->service_fee = $row['service_fee'];
            $this->rating = $row['rating'];
            $this->total_orders = $row['total_orders'];
            $this->created_at = $row['created_at'];
            $this->updated_at = $row['updated_at'];
            return true;
        }
        return false;
    }

    public function getBySlug($slug) {
        $query = "SELECT * FROM " . $this->table_name . " WHERE slug = :slug AND is_active = 1";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':slug', $slug);
        $stmt->execute();

        if ($stmt->rowCount() > 0) {
            $row = $stmt->fetch();
            $this->id = $row['id'];
            $this->name = $row['name'];
            $this->slug = $row['slug'];
            $this->logo = $row['logo'];
            $this->description = $row['description'];
            $this->phone = $row['phone'];
            $this->email = $row['email'];
            $this->address = $row['address'];
            $this->lat = $row['lat'];
            $this->lng = $row['lng'];
            $this->opening_hours = $row['opening_hours'];
            $this->is_active = $row['is_active'];
            $this->commission_rate = $row['commission_rate'];
            $this->service_fee = $row['service_fee'];
            $this->rating = $row['rating'];
            $this->total_orders = $row['total_orders'];
            $this->created_at = $row['created_at'];
            $this->updated_at = $row['updated_at'];
            return $row;
        }
        return false;
    }

    public function getAll($active_only = false, $limit = null, $offset = null) {
        $query = "SELECT * FROM " . $this->table_name . " WHERE 1=1";
        
        if ($active_only) {
            $query .= " AND is_active = 1";
        }
        
        $query .= " ORDER BY name ASC";
        
        if ($limit) {
            $query .= " LIMIT :limit";
            if ($offset) {
                $query .= " OFFSET :offset";
            }
        }
        
        $stmt = $this->conn->prepare($query);
        
        if ($limit) {
            $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
            if ($offset) {
                $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
            }
        }
        
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function generateSlug($name) {
        $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $name)));
        $original_slug = $slug;
        $counter = 1;
        
        // Check if slug exists and make it unique
        while ($this->slugExists($slug)) {
            $slug = $original_slug . '-' . $counter;
            $counter++;
        }
        
        return $slug;
    }

    public function slugExists($slug, $exclude_id = null) {
        $query = "SELECT id FROM " . $this->table_name . " WHERE slug = :slug";
        if ($exclude_id) {
            $query .= " AND id != :exclude_id";
        }
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':slug', $slug);
        if ($exclude_id) {
            $stmt->bindParam(':exclude_id', $exclude_id);
        }
        
        $stmt->execute();
        return $stmt->rowCount() > 0;
    }

    public function isOpen($merchant_id = null) {
        if ($merchant_id) {
            $this->getById($merchant_id);
        }
        
        if (!$this->opening_hours) {
            return true; // Always open if no hours specified
        }
        
        $hours = json_decode($this->opening_hours, true);
        $current_day = strtolower(date('l')); // monday, tuesday, etc.
        $current_time = date('H:i');
        
        if (isset($hours[$current_day])) {
            $day_hours = $hours[$current_day];
            if ($day_hours['closed']) {
                return false;
            }
            
            $open_time = $day_hours['open'];
            $close_time = $day_hours['close'];
            
            return ($current_time >= $open_time && $current_time <= $close_time);
        }
        
        return false;
    }

    public function updateRating($new_rating) {
        // Get current rating and total orders
        $query = "SELECT rating, total_orders FROM " . $this->table_name . " WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $this->id);
        $stmt->execute();
        $current = $stmt->fetch();
        
        if ($current) {
            $current_rating = $current['rating'];
            $total_orders = $current['total_orders'];
            
            // Calculate new average rating
            $new_average = (($current_rating * $total_orders) + $new_rating) / ($total_orders + 1);
            
            // Update rating and increment order count
            $update_query = "UPDATE " . $this->table_name . " 
                           SET rating = :rating, total_orders = total_orders + 1 
                           WHERE id = :id";
            $update_stmt = $this->conn->prepare($update_query);
            $update_stmt->bindParam(':rating', $new_average);
            $update_stmt->bindParam(':id', $this->id);
            
            return $update_stmt->execute();
        }
        return false;
    }

    public function getSalesReport($merchant_id, $start_date, $end_date) {
        $query = "SELECT 
                    COUNT(*) as total_orders,
                    COUNT(CASE WHEN status = 'delivered' THEN 1 END) as completed_orders,
                    COUNT(CASE WHEN status = 'cancelled' THEN 1 END) as cancelled_orders,
                    SUM(CASE WHEN status = 'delivered' THEN subtotal ELSE 0 END) as total_sales,
                    SUM(CASE WHEN status = 'delivered' THEN service_fee ELSE 0 END) as total_commission,
                    AVG(CASE WHEN status = 'delivered' AND customer_rating IS NOT NULL THEN customer_rating END) as avg_rating
                  FROM bookings 
                  WHERE merchant_id = :merchant_id 
                  AND created_at BETWEEN :start_date AND :end_date";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':merchant_id', $merchant_id);
        $stmt->bindParam(':start_date', $start_date);
        $stmt->bindParam(':end_date', $end_date);
        $stmt->execute();
        
        return $stmt->fetch();
    }

    public function getTopMerchants($limit = 10, $days = 30) {
        $query = "SELECT m.*, 
                    COUNT(b.id) as recent_orders,
                    SUM(CASE WHEN b.status = 'delivered' THEN b.subtotal ELSE 0 END) as recent_sales
                  FROM " . $this->table_name . " m
                  LEFT JOIN bookings b ON m.id = b.merchant_id 
                    AND b.created_at >= DATE_SUB(NOW(), INTERVAL :days DAY)
                  WHERE m.is_active = 1
                  GROUP BY m.id
                  ORDER BY recent_orders DESC, recent_sales DESC
                  LIMIT :limit";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':days', $days, PDO::PARAM_INT);
        $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt->fetchAll();
    }

    public function delete($id) {
        $query = "DELETE FROM " . $this->table_name . " WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);

        if ($stmt->execute()) {
            AppConfig::logActivity(null, 'delete_merchant', "Merchant deleted: ID {$id}");
            return true;
        }
        return false;
    }

    public function toggleStatus($id) {
        $query = "UPDATE " . $this->table_name . " SET is_active = NOT is_active WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        
        if ($stmt->execute()) {
            AppConfig::logActivity(null, 'toggle_merchant_status', "Merchant status toggled: ID {$id}");
            return true;
        }
        return false;
    }
}
?>
