<?php
require_once __DIR__ . '/../config/Database.php';
require_once __DIR__ . '/../config/AppConfig.php';

class Customer {
    private $conn;
    private $table_name = "customers";

    public $id;
    public $full_name;
    public $phone;
    public $email;
    public $address;
    public $lat;
    public $lng;
    public $is_blocked;
    public $total_orders;
    public $created_at;
    public $updated_at;

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    public function create() {
        $query = "INSERT INTO " . $this->table_name . "
                  SET full_name = :full_name, phone = :phone, email = :email, 
                      address = :address, lat = :lat, lng = :lng";

        $stmt = $this->conn->prepare($query);

        $stmt->bindParam(':full_name', $this->full_name);
        $stmt->bindParam(':phone', $this->phone);
        $stmt->bindParam(':email', $this->email);
        $stmt->bindParam(':address', $this->address);
        $stmt->bindParam(':lat', $this->lat);
        $stmt->bindParam(':lng', $this->lng);

        if ($stmt->execute()) {
            $this->id = $this->conn->lastInsertId();
            return true;
        }
        return false;
    }

    public function getOrCreate($phone, $full_name, $email = null, $address = null, $lat = null, $lng = null) {
        // First try to find existing customer by phone
        $query = "SELECT * FROM " . $this->table_name . " WHERE phone = :phone";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':phone', $phone);
        $stmt->execute();

        if ($stmt->rowCount() > 0) {
            $row = $stmt->fetch();
            $this->id = $row['id'];
            $this->full_name = $row['full_name'];
            $this->phone = $row['phone'];
            $this->email = $row['email'];
            $this->address = $row['address'];
            $this->lat = $row['lat'];
            $this->lng = $row['lng'];
            $this->is_blocked = $row['is_blocked'];
            $this->total_orders = $row['total_orders'];
            $this->created_at = $row['created_at'];
            $this->updated_at = $row['updated_at'];
            
            // Update customer info if provided
            if ($full_name && $full_name !== $this->full_name) {
                $this->full_name = $full_name;
                $this->update();
            }
            
            return $this->id;
        } else {
            // Create new customer
            $this->full_name = $full_name;
            $this->phone = $phone;
            $this->email = $email;
            $this->address = $address;
            $this->lat = $lat;
            $this->lng = $lng;
            
            if ($this->create()) {
                return $this->id;
            }
        }
        return false;
    }

    public function update() {
        $query = "UPDATE " . $this->table_name . "
                  SET full_name = :full_name, phone = :phone, email = :email, 
                      address = :address, lat = :lat, lng = :lng, is_blocked = :is_blocked
                  WHERE id = :id";

        $stmt = $this->conn->prepare($query);

        $stmt->bindParam(':full_name', $this->full_name);
        $stmt->bindParam(':phone', $this->phone);
        $stmt->bindParam(':email', $this->email);
        $stmt->bindParam(':address', $this->address);
        $stmt->bindParam(':lat', $this->lat);
        $stmt->bindParam(':lng', $this->lng);
        $stmt->bindParam(':is_blocked', $this->is_blocked);
        $stmt->bindParam(':id', $this->id);

        return $stmt->execute();
    }

    public function incrementOrderCount() {
        $query = "UPDATE " . $this->table_name . " SET total_orders = total_orders + 1 WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $this->id);
        return $stmt->execute();
    }

    public function getById($id) {
        $query = "SELECT * FROM " . $this->table_name . " WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->execute();

        if ($stmt->rowCount() > 0) {
            $row = $stmt->fetch();
            $this->id = $row['id'];
            $this->full_name = $row['full_name'];
            $this->phone = $row['phone'];
            $this->email = $row['email'];
            $this->address = $row['address'];
            $this->lat = $row['lat'];
            $this->lng = $row['lng'];
            $this->is_blocked = $row['is_blocked'];
            $this->total_orders = $row['total_orders'];
            $this->created_at = $row['created_at'];
            $this->updated_at = $row['updated_at'];
            return true;
        }
        return false;
    }

    public function getAll($limit = null, $offset = null, $search = null, $blocked_only = false) {
        $query = "SELECT * FROM " . $this->table_name . " WHERE 1=1";
        
        if ($search) {
            $query .= " AND (full_name LIKE :search OR phone LIKE :search OR email LIKE :search)";
        }
        
        if ($blocked_only) {
            $query .= " AND is_blocked = 1";
        }
        
        $query .= " ORDER BY created_at DESC";
        
        if ($limit) {
            $query .= " LIMIT :limit";
            if ($offset) {
                $query .= " OFFSET :offset";
            }
        }
        
        $stmt = $this->conn->prepare($query);
        
        if ($search) {
            $search_param = "%{$search}%";
            $stmt->bindParam(':search', $search_param);
        }
        
        if ($limit) {
            $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
            if ($offset) {
                $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
            }
        }
        
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function getOrderHistory($customer_id, $limit = 10) {
        $query = "SELECT b.*, m.name as merchant_name 
                  FROM bookings b 
                  LEFT JOIN merchants m ON b.merchant_id = m.id 
                  WHERE b.customer_id = :customer_id 
                  ORDER BY b.created_at DESC 
                  LIMIT :limit";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':customer_id', $customer_id);
        $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt->fetchAll();
    }

    public function blockCustomer($id, $reason = '') {
        $query = "UPDATE " . $this->table_name . " SET is_blocked = 1 WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        
        if ($stmt->execute()) {
            AppConfig::logActivity(null, 'block_customer', "Customer ID {$id} blocked. Reason: {$reason}");
            return true;
        }
        return false;
    }

    public function unblockCustomer($id) {
        $query = "UPDATE " . $this->table_name . " SET is_blocked = 0 WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        
        if ($stmt->execute()) {
            AppConfig::logActivity(null, 'unblock_customer', "Customer ID {$id} unblocked");
            return true;
        }
        return false;
    }

    public function getTopCustomers($limit = 10) {
        $query = "SELECT c.*, COUNT(b.id) as order_count, SUM(b.total_amount) as total_spent
                  FROM " . $this->table_name . " c
                  LEFT JOIN bookings b ON c.id = b.customer_id
                  WHERE c.is_blocked = 0
                  GROUP BY c.id
                  ORDER BY order_count DESC, total_spent DESC
                  LIMIT :limit";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt->fetchAll();
    }

    public function getTotalCount($search = null, $blocked_only = false) {
        $query = "SELECT COUNT(*) as total FROM " . $this->table_name . " WHERE 1=1";
        
        if ($search) {
            $query .= " AND (full_name LIKE :search OR phone LIKE :search OR email LIKE :search)";
        }
        
        if ($blocked_only) {
            $query .= " AND is_blocked = 1";
        }
        
        $stmt = $this->conn->prepare($query);
        
        if ($search) {
            $search_param = "%{$search}%";
            $stmt->bindParam(':search', $search_param);
        }
        
        $stmt->execute();
        $row = $stmt->fetch();
        return $row['total'];
    }
}
?>
