<?php
class Report {
    private $conn;
    private $table = 'reports';

    public function __construct($db) {
        $this->conn = $db;
    }

    public function getSalesReport($startDate = null, $endDate = null, $filters = []) {
        try {
            $query = "
                SELECT 
                    DATE(b.created_at) as date,
                    COUNT(b.id) as total_orders,
                    SUM(b.total_amount) as total_revenue,
                    SUM(b.delivery_fee) as delivery_fees,
                    SUM(b.total_amount - b.delivery_fee) as merchant_revenue,
                    AVG(b.total_amount) as avg_order_value,
                    COUNT(CASE WHEN b.status = 'completed' THEN 1 END) as completed_orders,
                    COUNT(CASE WHEN b.status = 'cancelled' THEN 1 END) as cancelled_orders,
                    b.service_type,
                    m.name as merchant_name
                FROM bookings b
                LEFT JOIN merchants m ON b.merchant_id = m.id
                WHERE 1=1
            ";

            $params = [];

            if ($startDate) {
                $query .= " AND DATE(b.created_at) >= ?";
                $params[] = $startDate;
            }

            if ($endDate) {
                $query .= " AND DATE(b.created_at) <= ?";
                $params[] = $endDate;
            }

            if (!empty($filters['service_type'])) {
                $query .= " AND b.service_type = ?";
                $params[] = $filters['service_type'];
            }

            if (!empty($filters['merchant_id'])) {
                $query .= " AND b.merchant_id = ?";
                $params[] = $filters['merchant_id'];
            }

            $query .= " GROUP BY DATE(b.created_at), b.service_type, b.merchant_id ORDER BY date DESC";

            $stmt = $this->conn->prepare($query);
            $stmt->execute($params);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            throw new Exception("Error generating sales report: " . $e->getMessage());
        }
    }

    public function getRiderPerformanceReport($riderId = null, $startDate = null, $endDate = null) {
        try {
            $query = "
                SELECT 
                    r.id,
                    r.name,
                    r.phone,
                    COUNT(b.id) as total_deliveries,
                    COUNT(CASE WHEN b.status = 'completed' THEN 1 END) as completed_deliveries,
                    COUNT(CASE WHEN b.status = 'cancelled' THEN 1 END) as cancelled_deliveries,
                    ROUND(AVG(b.rating), 2) as avg_rating,
                    SUM(re.amount) as total_earnings,
                    AVG(TIMESTAMPDIFF(MINUTE, b.pickup_time, b.delivery_time)) as avg_delivery_time,
                    r.acceptance_rate,
                    r.completion_rate,
                    r.total_distance_km
                FROM riders r
                LEFT JOIN bookings b ON r.id = b.rider_id
                LEFT JOIN rider_earnings re ON r.id = re.rider_id
                WHERE r.status = 'active'
            ";

            $params = [];

            if ($riderId) {
                $query .= " AND r.id = ?";
                $params[] = $riderId;
            }

            if ($startDate) {
                $query .= " AND DATE(b.created_at) >= ?";
                $params[] = $startDate;
            }

            if ($endDate) {
                $query .= " AND DATE(b.created_at) <= ?";
                $params[] = $endDate;
            }

            $query .= " GROUP BY r.id ORDER BY total_deliveries DESC";

            $stmt = $this->conn->prepare($query);
            $stmt->execute($params);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            throw new Exception("Error generating rider performance report: " . $e->getMessage());
        }
    }

    public function getMerchantReport($merchantId = null, $startDate = null, $endDate = null) {
        try {
            $query = "
                SELECT 
                    m.id,
                    m.name,
                    m.category,
                    m.status,
                    COUNT(b.id) as total_orders,
                    SUM(b.total_amount - b.delivery_fee) as total_revenue,
                    AVG(b.total_amount - b.delivery_fee) as avg_order_value,
                    COUNT(CASE WHEN b.status = 'completed' THEN 1 END) as completed_orders,
                    COUNT(CASE WHEN b.status = 'cancelled' THEN 1 END) as cancelled_orders,
                    ROUND(AVG(b.rating), 2) as avg_rating,
                    COUNT(DISTINCT b.customer_id) as unique_customers,
                    COUNT(mi.id) as menu_items_count
                FROM merchants m
                LEFT JOIN bookings b ON m.id = b.merchant_id
                LEFT JOIN menu_items mi ON m.id = mi.merchant_id
                WHERE m.status = 'active'
            ";

            $params = [];

            if ($merchantId) {
                $query .= " AND m.id = ?";
                $params[] = $merchantId;
            }

            if ($startDate) {
                $query .= " AND DATE(b.created_at) >= ?";
                $params[] = $startDate;
            }

            if ($endDate) {
                $query .= " AND DATE(b.created_at) <= ?";
                $params[] = $endDate;
            }

            $query .= " GROUP BY m.id ORDER BY total_revenue DESC";

            $stmt = $this->conn->prepare($query);
            $stmt->execute($params);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            throw new Exception("Error generating merchant report: " . $e->getMessage());
        }
    }

    public function getFinancialReport($startDate = null, $endDate = null) {
        try {
            $query = "
                SELECT 
                    DATE(created_at) as date,
                    SUM(total_amount) as gross_revenue,
                    SUM(delivery_fee) as delivery_fees,
                    SUM(total_amount - delivery_fee) as merchant_revenue,
                    COUNT(id) as total_transactions,
                    AVG(total_amount) as avg_transaction_value
                FROM bookings 
                WHERE status IN ('completed', 'delivered')
            ";

            $params = [];

            if ($startDate) {
                $query .= " AND DATE(created_at) >= ?";
                $params[] = $startDate;
            }

            if ($endDate) {
                $query .= " AND DATE(created_at) <= ?";
                $params[] = $endDate;
            }

            $query .= " GROUP BY DATE(created_at) ORDER BY date DESC";

            $stmt = $this->conn->prepare($query);
            $stmt->execute($params);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            throw new Exception("Error generating financial report: " . $e->getMessage());
        }
    }

    public function getCustomerReport($startDate = null, $endDate = null) {
        try {
            $query = "
                SELECT 
                    c.id,
                    c.name,
                    c.phone,
                    c.email,
                    COUNT(b.id) as total_orders,
                    SUM(b.total_amount) as total_spent,
                    AVG(b.total_amount) as avg_order_value,
                    MAX(b.created_at) as last_order_date,
                    c.created_at as first_order_date,
                    c.status,
                    COUNT(CASE WHEN b.status = 'completed' THEN 1 END) as completed_orders
                FROM customers c
                LEFT JOIN bookings b ON c.id = b.customer_id
                WHERE c.status != 'blocked'
            ";

            $params = [];

            if ($startDate) {
                $query .= " AND DATE(b.created_at) >= ?";
                $params[] = $startDate;
            }

            if ($endDate) {
                $query .= " AND DATE(b.created_at) <= ?";
                $params[] = $endDate;
            }

            $query .= " GROUP BY c.id ORDER BY total_spent DESC";

            $stmt = $this->conn->prepare($query);
            $stmt->execute($params);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            throw new Exception("Error generating customer report: " . $e->getMessage());
        }
    }

    public function getDashboardStats($period = 'today') {
        try {
            $dateCondition = $this->getDateCondition($period);
            
            // Total orders
            $stmt = $this->conn->prepare("SELECT COUNT(*) as count FROM bookings WHERE {$dateCondition}");
            $stmt->execute();
            $totalOrders = $stmt->fetch(PDO::FETCH_ASSOC)['count'];

            // Total revenue
            $stmt = $this->conn->prepare("SELECT COALESCE(SUM(total_amount), 0) as revenue FROM bookings WHERE status IN ('completed', 'delivered') AND {$dateCondition}");
            $stmt->execute();
            $totalRevenue = $stmt->fetch(PDO::FETCH_ASSOC)['revenue'];

            // Active riders
            $stmt = $this->conn->prepare("SELECT COUNT(*) as count FROM riders WHERE status = 'active' AND is_online = 1");
            $stmt->execute();
            $activeRiders = $stmt->fetch(PDO::FETCH_ASSOC)['count'];

            // New customers
            $stmt = $this->conn->prepare("SELECT COUNT(*) as count FROM customers WHERE {$dateCondition}");
            $stmt->execute();
            $newCustomers = $stmt->fetch(PDO::FETCH_ASSOC)['count'];

            // Pending orders
            $stmt = $this->conn->prepare("SELECT COUNT(*) as count FROM bookings WHERE status IN ('pending', 'confirmed', 'picked_up')");
            $stmt->execute();
            $pendingOrders = $stmt->fetch(PDO::FETCH_ASSOC)['count'];

            return [
                'total_orders' => $totalOrders,
                'total_revenue' => $totalRevenue,
                'active_riders' => $activeRiders,
                'new_customers' => $newCustomers,
                'pending_orders' => $pendingOrders
            ];
        } catch (Exception $e) {
            throw new Exception("Error fetching dashboard stats: " . $e->getMessage());
        }
    }

    public function getOrderTrends($period = '30days') {
        try {
            $dateCondition = $this->getDateCondition($period);
            
            $query = "
                SELECT 
                    DATE(created_at) as date,
                    COUNT(*) as orders,
                    SUM(total_amount) as revenue
                FROM bookings 
                WHERE {$dateCondition}
                GROUP BY DATE(created_at)
                ORDER BY date ASC
            ";

            $stmt = $this->conn->prepare($query);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            throw new Exception("Error fetching order trends: " . $e->getMessage());
        }
    }

    public function getRevenueTrends($period = '30days') {
        try {
            $dateCondition = $this->getDateCondition($period);
            
            $query = "
                SELECT 
                    DATE(created_at) as date,
                    SUM(total_amount) as total_revenue,
                    SUM(delivery_fee) as delivery_revenue,
                    SUM(total_amount - delivery_fee) as merchant_revenue
                FROM bookings 
                WHERE status IN ('completed', 'delivered') AND {$dateCondition}
                GROUP BY DATE(created_at)
                ORDER BY date ASC
            ";

            $stmt = $this->conn->prepare($query);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            throw new Exception("Error fetching revenue trends: " . $e->getMessage());
        }
    }

    public function getTopPerformers($type = 'riders', $limit = 10, $period = '30days') {
        try {
            $dateCondition = $this->getDateCondition($period);
            
            switch ($type) {
                case 'riders':
                    $query = "
                        SELECT 
                            r.id, r.name, r.phone,
                            COUNT(b.id) as deliveries,
                            SUM(re.amount) as earnings,
                            AVG(b.rating) as avg_rating
                        FROM riders r
                        LEFT JOIN bookings b ON r.id = b.rider_id AND {$dateCondition}
                        LEFT JOIN rider_earnings re ON r.id = re.rider_id
                        WHERE r.status = 'active'
                        GROUP BY r.id
                        ORDER BY deliveries DESC, avg_rating DESC
                        LIMIT ?
                    ";
                    break;
                    
                case 'merchants':
                    $query = "
                        SELECT 
                            m.id, m.name, m.category,
                            COUNT(b.id) as orders,
                            SUM(b.total_amount - b.delivery_fee) as revenue,
                            AVG(b.rating) as avg_rating
                        FROM merchants m
                        LEFT JOIN bookings b ON m.id = b.merchant_id AND {$dateCondition}
                        WHERE m.status = 'active'
                        GROUP BY m.id
                        ORDER BY revenue DESC, avg_rating DESC
                        LIMIT ?
                    ";
                    break;
                    
                case 'customers':
                    $query = "
                        SELECT 
                            c.id, c.name, c.phone,
                            COUNT(b.id) as orders,
                            SUM(b.total_amount) as spent
                        FROM customers c
                        LEFT JOIN bookings b ON c.id = b.customer_id AND {$dateCondition}
                        WHERE c.status = 'active'
                        GROUP BY c.id
                        ORDER BY spent DESC, orders DESC
                        LIMIT ?
                    ";
                    break;
                    
                default:
                    throw new Exception("Invalid performer type");
            }

            $stmt = $this->conn->prepare($query);
            $stmt->execute([$limit]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            throw new Exception("Error fetching top performers: " . $e->getMessage());
        }
    }

    public function getServiceTypeReport($startDate = null, $endDate = null) {
        try {
            $query = "
                SELECT 
                    service_type,
                    COUNT(*) as total_orders,
                    SUM(total_amount) as total_revenue,
                    AVG(total_amount) as avg_order_value,
                    COUNT(CASE WHEN status = 'completed' THEN 1 END) as completed_orders
                FROM bookings
                WHERE 1=1
            ";

            $params = [];

            if ($startDate) {
                $query .= " AND DATE(created_at) >= ?";
                $params[] = $startDate;
            }

            if ($endDate) {
                $query .= " AND DATE(created_at) <= ?";
                $params[] = $endDate;
            }

            $query .= " GROUP BY service_type ORDER BY total_revenue DESC";

            $stmt = $this->conn->prepare($query);
            $stmt->execute($params);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            throw new Exception("Error generating service type report: " . $e->getMessage());
        }
    }

    public function getGeographicReport($startDate = null, $endDate = null) {
        try {
            $query = "
                SELECT 
                    SUBSTRING_INDEX(delivery_address, ',', -1) as area,
                    COUNT(*) as total_orders,
                    SUM(total_amount) as total_revenue,
                    AVG(delivery_time_minutes) as avg_delivery_time
                FROM bookings
                WHERE delivery_address IS NOT NULL
            ";

            $params = [];

            if ($startDate) {
                $query .= " AND DATE(created_at) >= ?";
                $params[] = $startDate;
            }

            if ($endDate) {
                $query .= " AND DATE(created_at) <= ?";
                $params[] = $endDate;
            }

            $query .= " GROUP BY area ORDER BY total_orders DESC";

            $stmt = $this->conn->prepare($query);
            $stmt->execute($params);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            throw new Exception("Error generating geographic report: " . $e->getMessage());
        }
    }

    public function getPayoutReport($riderId = null, $startDate = null, $endDate = null) {
        try {
            $query = "
                SELECT 
                    r.id as rider_id,
                    r.name as rider_name,
                    SUM(re.amount) as total_earnings,
                    COUNT(re.id) as total_deliveries,
                    SUM(CASE WHEN pr.status = 'completed' THEN pr.amount ELSE 0 END) as paid_amount,
                    SUM(CASE WHEN pr.status = 'pending' THEN pr.amount ELSE 0 END) as pending_amount,
                    MAX(pr.created_at) as last_payout_date
                FROM riders r
                LEFT JOIN rider_earnings re ON r.id = re.rider_id
                LEFT JOIN payout_requests pr ON r.id = pr.rider_id
                WHERE r.status = 'active'
            ";

            $params = [];

            if ($riderId) {
                $query .= " AND r.id = ?";
                $params[] = $riderId;
            }

            if ($startDate) {
                $query .= " AND DATE(re.created_at) >= ?";
                $params[] = $startDate;
            }

            if ($endDate) {
                $query .= " AND DATE(re.created_at) <= ?";
                $params[] = $endDate;
            }

            $query .= " GROUP BY r.id ORDER BY total_earnings DESC";

            $stmt = $this->conn->prepare($query);
            $stmt->execute($params);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            throw new Exception("Error generating payout report: " . $e->getMessage());
        }
    }

    public function getComplaintReport($startDate = null, $endDate = null) {
        try {
            $query = "
                SELECT 
                    c.*,
                    cu.name as customer_name,
                    r.name as rider_name,
                    m.name as merchant_name,
                    b.booking_number
                FROM complaints c
                LEFT JOIN customers cu ON c.customer_id = cu.id
                LEFT JOIN riders r ON c.rider_id = r.id
                LEFT JOIN merchants m ON c.merchant_id = m.id
                LEFT JOIN bookings b ON c.booking_id = b.id
                WHERE 1=1
            ";

            $params = [];

            if ($startDate) {
                $query .= " AND DATE(c.created_at) >= ?";
                $params[] = $startDate;
            }

            if ($endDate) {
                $query .= " AND DATE(c.created_at) <= ?";
                $params[] = $endDate;
            }

            $query .= " ORDER BY c.created_at DESC";

            $stmt = $this->conn->prepare($query);
            $stmt->execute($params);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            throw new Exception("Error generating complaint report: " . $e->getMessage());
        }
    }

    private function getDateCondition($period) {
        switch ($period) {
            case 'today':
                return "DATE(created_at) = CURDATE()";
            case 'yesterday':
                return "DATE(created_at) = DATE_SUB(CURDATE(), INTERVAL 1 DAY)";
            case 'week':
                return "created_at >= DATE_SUB(NOW(), INTERVAL 1 WEEK)";
            case '30days':
                return "created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)";
            case 'month':
                return "MONTH(created_at) = MONTH(NOW()) AND YEAR(created_at) = YEAR(NOW())";
            case 'year':
                return "YEAR(created_at) = YEAR(NOW())";
            default:
                return "1=1";
        }
    }

    // Scheduled reports functionality
    public function getScheduledReports() {
        try {
            $query = "SELECT * FROM scheduled_reports ORDER BY created_at DESC";
            $stmt = $this->conn->prepare($query);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            throw new Exception("Error fetching scheduled reports: " . $e->getMessage());
        }
    }

    public function createScheduledReport($data) {
        try {
            $query = "
                INSERT INTO scheduled_reports 
                (name, report_type, frequency, recipients, parameters, next_run, created_at) 
                VALUES (?, ?, ?, ?, ?, ?, NOW())
            ";
            
            $stmt = $this->conn->prepare($query);
            $stmt->execute([
                $data['name'],
                $data['report_type'],
                $data['frequency'],
                json_encode($data['recipients']),
                json_encode($data['parameters'] ?? []),
                $this->calculateNextRun($data['frequency'])
            ]);
            
            return $this->conn->lastInsertId();
        } catch (Exception $e) {
            throw new Exception("Error creating scheduled report: " . $e->getMessage());
        }
    }

    public function updateScheduledReport($id, $data) {
        try {
            $query = "
                UPDATE scheduled_reports 
                SET name = ?, report_type = ?, frequency = ?, recipients = ?, parameters = ?, updated_at = NOW()
                WHERE id = ?
            ";
            
            $stmt = $this->conn->prepare($query);
            return $stmt->execute([
                $data['name'],
                $data['report_type'],
                $data['frequency'],
                json_encode($data['recipients']),
                json_encode($data['parameters'] ?? []),
                $id
            ]);
        } catch (Exception $e) {
            throw new Exception("Error updating scheduled report: " . $e->getMessage());
        }
    }

    public function deleteScheduledReport($id) {
        try {
            $query = "DELETE FROM scheduled_reports WHERE id = ?";
            $stmt = $this->conn->prepare($query);
            return $stmt->execute([$id]);
        } catch (Exception $e) {
            throw new Exception("Error deleting scheduled report: " . $e->getMessage());
        }
    }

    private function calculateNextRun($frequency) {
        switch ($frequency) {
            case 'daily':
                return date('Y-m-d H:i:s', strtotime('+1 day'));
            case 'weekly':
                return date('Y-m-d H:i:s', strtotime('+1 week'));
            case 'monthly':
                return date('Y-m-d H:i:s', strtotime('+1 month'));
            default:
                return date('Y-m-d H:i:s', strtotime('+1 day'));
        }
    }
}
?>
