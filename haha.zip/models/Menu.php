<?php
require_once __DIR__ . '/../config/Database.php';
require_once __DIR__ . '/../config/AppConfig.php';

class Menu {
    private $conn;
    private $category_table = "menu_categories";
    private $item_table = "menu_items";

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    // Category methods
    public function createCategory($merchant_id, $name, $description = '', $sort_order = 0) {
        $query = "INSERT INTO " . $this->category_table . "
                  SET merchant_id = :merchant_id, name = :name, description = :description, sort_order = :sort_order";

        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':merchant_id', $merchant_id);
        $stmt->bindParam(':name', $name);
        $stmt->bindParam(':description', $description);
        $stmt->bindParam(':sort_order', $sort_order);

        if ($stmt->execute()) {
            return $this->conn->lastInsertId();
        }
        return false;
    }

    public function updateCategory($id, $name, $description = '', $sort_order = 0, $is_active = true) {
        $query = "UPDATE " . $this->category_table . "
                  SET name = :name, description = :description, sort_order = :sort_order, is_active = :is_active
                  WHERE id = :id";

        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':name', $name);
        $stmt->bindParam(':description', $description);
        $stmt->bindParam(':sort_order', $sort_order);
        $stmt->bindParam(':is_active', $is_active);
        $stmt->bindParam(':id', $id);

        return $stmt->execute();
    }

    public function getCategories($merchant_id, $active_only = false) {
        $query = "SELECT * FROM " . $this->category_table . " WHERE merchant_id = :merchant_id";
        
        if ($active_only) {
            $query .= " AND is_active = 1";
        }
        
        $query .= " ORDER BY sort_order ASC, name ASC";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':merchant_id', $merchant_id);
        $stmt->execute();
        
        return $stmt->fetchAll();
    }

    public function deleteCategory($id) {
        // First, update all items in this category to have no category
        $update_items = "UPDATE " . $this->item_table . " SET category_id = NULL WHERE category_id = :id";
        $stmt = $this->conn->prepare($update_items);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        
        // Then delete the category
        $query = "DELETE FROM " . $this->category_table . " WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        
        return $stmt->execute();
    }

    // Menu item methods
    public function createItem($merchant_id, $category_id, $name, $description, $price, $image = '', $preparation_time = 15, $sort_order = 0) {
        $query = "INSERT INTO " . $this->item_table . "
                  SET merchant_id = :merchant_id, category_id = :category_id, name = :name, 
                      description = :description, price = :price, image = :image, 
                      preparation_time = :preparation_time, sort_order = :sort_order";

        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':merchant_id', $merchant_id);
        $stmt->bindParam(':category_id', $category_id);
        $stmt->bindParam(':name', $name);
        $stmt->bindParam(':description', $description);
        $stmt->bindParam(':price', $price);
        $stmt->bindParam(':image', $image);
        $stmt->bindParam(':preparation_time', $preparation_time);
        $stmt->bindParam(':sort_order', $sort_order);

        if ($stmt->execute()) {
            return $this->conn->lastInsertId();
        }
        return false;
    }

    public function updateItem($id, $category_id, $name, $description, $price, $image = '', $is_available = true, $preparation_time = 15, $sort_order = 0) {
        $query = "UPDATE " . $this->item_table . "
                  SET category_id = :category_id, name = :name, description = :description, 
                      price = :price, image = :image, is_available = :is_available, 
                      preparation_time = :preparation_time, sort_order = :sort_order
                  WHERE id = :id";

        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':category_id', $category_id);
        $stmt->bindParam(':name', $name);
        $stmt->bindParam(':description', $description);
        $stmt->bindParam(':price', $price);
        $stmt->bindParam(':image', $image);
        $stmt->bindParam(':is_available', $is_available);
        $stmt->bindParam(':preparation_time', $preparation_time);
        $stmt->bindParam(':sort_order', $sort_order);
        $stmt->bindParam(':id', $id);

        return $stmt->execute();
    }

    public function getItems($merchant_id, $category_id = null, $available_only = false) {
        $query = "SELECT i.*, c.name as category_name
                  FROM " . $this->item_table . " i
                  LEFT JOIN " . $this->category_table . " c ON i.category_id = c.id
                  WHERE i.merchant_id = :merchant_id";
        
        if ($category_id) {
            $query .= " AND i.category_id = :category_id";
        }
        
        if ($available_only) {
            $query .= " AND i.is_available = 1";
        }
        
        $query .= " ORDER BY i.sort_order ASC, i.name ASC";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':merchant_id', $merchant_id);
        
        if ($category_id) {
            $stmt->bindParam(':category_id', $category_id);
        }
        
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function getItemById($id) {
        $query = "SELECT i.*, c.name as category_name, m.name as merchant_name
                  FROM " . $this->item_table . " i
                  LEFT JOIN " . $this->category_table . " c ON i.category_id = c.id
                  LEFT JOIN merchants m ON i.merchant_id = m.id
                  WHERE i.id = :id";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        
        return $stmt->fetch();
    }

    public function getFullMenu($merchant_id, $available_only = false) {
        $categories = $this->getCategories($merchant_id, $available_only);
        $menu = [];
        
        foreach ($categories as $category) {
            $category['items'] = $this->getItems($merchant_id, $category['id'], $available_only);
            $menu[] = $category;
        }
        
        // Also get items without category
        $uncategorized_items = $this->getItems($merchant_id, null, $available_only);
        $uncategorized_items = array_filter($uncategorized_items, function($item) {
            return $item['category_id'] === null;
        });
        
        if (!empty($uncategorized_items)) {
            $menu[] = [
                'id' => null,
                'name' => 'Other Items',
                'description' => '',
                'items' => array_values($uncategorized_items)
            ];
        }
        
        return $menu;
    }

    public function toggleItemAvailability($id) {
        $query = "UPDATE " . $this->item_table . " SET is_available = NOT is_available WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        
        return $stmt->execute();
    }

    public function deleteItem($id) {
        $query = "DELETE FROM " . $this->item_table . " WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        
        return $stmt->execute();
    }

    public function searchItems($merchant_id, $search_term) {
        $query = "SELECT i.*, c.name as category_name
                  FROM " . $this->item_table . " i
                  LEFT JOIN " . $this->category_table . " c ON i.category_id = c.id
                  WHERE i.merchant_id = :merchant_id 
                  AND (i.name LIKE :search OR i.description LIKE :search)
                  AND i.is_available = 1
                  ORDER BY i.name ASC";
        
        $stmt = $this->conn->prepare($query);
        $search_param = "%{$search_term}%";
        $stmt->bindParam(':merchant_id', $merchant_id);
        $stmt->bindParam(':search', $search_param);
        $stmt->execute();
        
        return $stmt->fetchAll();
    }

    public function getPopularItems($merchant_id, $limit = 10) {
        $query = "SELECT i.*, c.name as category_name, COUNT(b.id) as order_count
                  FROM " . $this->item_table . " i
                  LEFT JOIN " . $this->category_table . " c ON i.category_id = c.id
                  LEFT JOIN bookings b ON JSON_CONTAINS(b.items, JSON_OBJECT('id', i.id))
                  WHERE i.merchant_id = :merchant_id AND i.is_available = 1
                  GROUP BY i.id
                  ORDER BY order_count DESC, i.name ASC
                  LIMIT :limit";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':merchant_id', $merchant_id);
        $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt->fetchAll();
    }

    public function updateItemImage($id, $image_path) {
        $query = "UPDATE " . $this->item_table . " SET image = :image WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':image', $image_path);
        $stmt->bindParam(':id', $id);
        
        return $stmt->execute();
    }

    public function bulkUpdateAvailability($merchant_id, $available) {
        $query = "UPDATE " . $this->item_table . " SET is_available = :available WHERE merchant_id = :merchant_id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':available', $available, PDO::PARAM_BOOL);
        $stmt->bindParam(':merchant_id', $merchant_id);
        
        return $stmt->execute();
    }

    public function getItemStats($merchant_id, $days = 30) {
        $query = "SELECT 
                    COUNT(DISTINCT i.id) as total_items,
                    COUNT(CASE WHEN i.is_available = 1 THEN 1 END) as available_items,
                    AVG(i.price) as avg_price,
                    MIN(i.price) as min_price,
                    MAX(i.price) as max_price
                  FROM " . $this->item_table . " i
                  WHERE i.merchant_id = :merchant_id";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':merchant_id', $merchant_id);
        $stmt->execute();
        
        return $stmt->fetch();
    }
}
?>
