<?php
require_once __DIR__ . '/../config/Database.php';
require_once __DIR__ . '/../config/AppConfig.php';

class Rider {
    private $conn;
    private $table_name = "riders";

    public $id;
    public $user_id;
    public $license_number;
    public $vehicle_type;
    public $vehicle_plate;
    public $vehicle_model;
    public $is_online;
    public $current_lat;
    public $current_lng;
    public $rating;
    public $total_deliveries;
    public $acceptance_rate;
    public $emergency_contact;
    public $emergency_name;
    public $created_at;
    public $updated_at;

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    public function create() {
        $query = "INSERT INTO " . $this->table_name . "
                  SET user_id = :user_id, license_number = :license_number, 
                      vehicle_type = :vehicle_type, vehicle_plate = :vehicle_plate, 
                      vehicle_model = :vehicle_model, emergency_contact = :emergency_contact, 
                      emergency_name = :emergency_name";

        $stmt = $this->conn->prepare($query);

        $stmt->bindParam(':user_id', $this->user_id);
        $stmt->bindParam(':license_number', $this->license_number);
        $stmt->bindParam(':vehicle_type', $this->vehicle_type);
        $stmt->bindParam(':vehicle_plate', $this->vehicle_plate);
        $stmt->bindParam(':vehicle_model', $this->vehicle_model);
        $stmt->bindParam(':emergency_contact', $this->emergency_contact);
        $stmt->bindParam(':emergency_name', $this->emergency_name);

        if ($stmt->execute()) {
            $this->id = $this->conn->lastInsertId();
            return true;
        }
        return false;
    }

    public function update() {
        $query = "UPDATE " . $this->table_name . "
                  SET license_number = :license_number, vehicle_type = :vehicle_type, 
                      vehicle_plate = :vehicle_plate, vehicle_model = :vehicle_model, 
                      emergency_contact = :emergency_contact, emergency_name = :emergency_name
                  WHERE id = :id";

        $stmt = $this->conn->prepare($query);

        $stmt->bindParam(':license_number', $this->license_number);
        $stmt->bindParam(':vehicle_type', $this->vehicle_type);
        $stmt->bindParam(':vehicle_plate', $this->vehicle_plate);
        $stmt->bindParam(':vehicle_model', $this->vehicle_model);
        $stmt->bindParam(':emergency_contact', $this->emergency_contact);
        $stmt->bindParam(':emergency_name', $this->emergency_name);
        $stmt->bindParam(':id', $this->id);

        return $stmt->execute();
    }

    public function updateLocation($lat, $lng) {
        $query = "UPDATE " . $this->table_name . " SET current_lat = :lat, current_lng = :lng WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':lat', $lat);
        $stmt->bindParam(':lng', $lng);
        $stmt->bindParam(':id', $this->id);
        return $stmt->execute();
    }

    public function setOnlineStatus($is_online) {
        $query = "UPDATE " . $this->table_name . " SET is_online = :is_online WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':is_online', $is_online, PDO::PARAM_BOOL);
        $stmt->bindParam(':id', $this->id);
        
        if ($stmt->execute()) {
            $status = $is_online ? 'online' : 'offline';
            AppConfig::logActivity($this->user_id, 'rider_status_change', "Rider went {$status}");
            return true;
        }
        return false;
    }

    public function getByUserId($user_id) {
        $query = "SELECT r.*, u.full_name, u.phone, u.email, u.status as user_status
                  FROM " . $this->table_name . " r
                  JOIN users u ON r.user_id = u.id
                  WHERE r.user_id = :user_id";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':user_id', $user_id);
        $stmt->execute();

        if ($stmt->rowCount() > 0) {
            $row = $stmt->fetch();
            $this->id = $row['id'];
            $this->user_id = $row['user_id'];
            $this->license_number = $row['license_number'];
            $this->vehicle_type = $row['vehicle_type'];
            $this->vehicle_plate = $row['vehicle_plate'];
            $this->vehicle_model = $row['vehicle_model'];
            $this->is_online = $row['is_online'];
            $this->current_lat = $row['current_lat'];
            $this->current_lng = $row['current_lng'];
            $this->rating = $row['rating'];
            $this->total_deliveries = $row['total_deliveries'];
            $this->acceptance_rate = $row['acceptance_rate'];
            $this->emergency_contact = $row['emergency_contact'];
            $this->emergency_name = $row['emergency_name'];
            $this->created_at = $row['created_at'];
            $this->updated_at = $row['updated_at'];
            return $row;
        }
        return false;
    }

    public function getById($id) {
        $query = "SELECT r.*, u.full_name, u.phone, u.email, u.status as user_status
                  FROM " . $this->table_name . " r
                  JOIN users u ON r.user_id = u.id
                  WHERE r.id = :id";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->execute();

        if ($stmt->rowCount() > 0) {
            return $stmt->fetch();
        }
        return false;
    }

    public function getAll($status = null, $online_only = false) {
        $query = "SELECT r.*, u.full_name, u.phone, u.email, u.status as user_status
                  FROM " . $this->table_name . " r
                  JOIN users u ON r.user_id = u.id
                  WHERE 1=1";
        
        if ($status) {
            $query .= " AND u.status = :status";
        }
        
        if ($online_only) {
            $query .= " AND r.is_online = 1";
        }
        
        $query .= " ORDER BY r.created_at DESC";
        
        $stmt = $this->conn->prepare($query);
        
        if ($status) {
            $stmt->bindParam(':status', $status);
        }
        
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function getAvailableRiders($lat = null, $lng = null, $radius_km = 25) {
        $query = "SELECT r.*, u.full_name, u.phone, u.email";
        
        if ($lat && $lng) {
            // Calculate distance using Haversine formula
            $query .= ", (6371 * acos(cos(radians(:lat)) * cos(radians(r.current_lat)) * 
                      cos(radians(r.current_lng) - radians(:lng)) + 
                      sin(radians(:lat)) * sin(radians(r.current_lat)))) AS distance";
        }
        
        $query .= " FROM " . $this->table_name . " r
                    JOIN users u ON r.user_id = u.id
                    WHERE r.is_online = 1 AND u.status = 'active'
                    AND r.current_lat IS NOT NULL AND r.current_lng IS NOT NULL";
        
        if ($lat && $lng) {
            $query .= " HAVING distance <= :radius";
            $query .= " ORDER BY distance ASC";
        } else {
            $query .= " ORDER BY r.rating DESC, r.acceptance_rate DESC";
        }
        
        $stmt = $this->conn->prepare($query);
        
        if ($lat && $lng) {
            $stmt->bindParam(':lat', $lat);
            $stmt->bindParam(':lng', $lng);
            $stmt->bindParam(':radius', $radius_km);
        }
        
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function updateRating($new_rating) {
        // Get current rating and total deliveries
        $query = "SELECT rating, total_deliveries FROM " . $this->table_name . " WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $this->id);
        $stmt->execute();
        $current = $stmt->fetch();
        
        if ($current) {
            $current_rating = $current['rating'];
            $total_deliveries = $current['total_deliveries'];
            
            // Calculate new average rating
            $new_average = (($current_rating * $total_deliveries) + $new_rating) / ($total_deliveries + 1);
            
            // Update rating and increment delivery count
            $update_query = "UPDATE " . $this->table_name . " 
                           SET rating = :rating, total_deliveries = total_deliveries + 1 
                           WHERE id = :id";
            $update_stmt = $this->conn->prepare($update_query);
            $update_stmt->bindParam(':rating', $new_average);
            $update_stmt->bindParam(':id', $this->id);
            
            return $update_stmt->execute();
        }
        return false;
    }

    public function updateAcceptanceRate($accepted) {
        // This would typically be calculated based on booking acceptance history
        // For now, we'll implement a simple increment/decrement system
        $query = "SELECT acceptance_rate FROM " . $this->table_name . " WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $this->id);
        $stmt->execute();
        $current = $stmt->fetch();
        
        if ($current) {
            $current_rate = $current['acceptance_rate'];
            
            // Simple adjustment - in production, this should be based on actual statistics
            if ($accepted) {
                $new_rate = min(100, $current_rate + 1);
            } else {
                $new_rate = max(0, $current_rate - 2);
            }
            
            $update_query = "UPDATE " . $this->table_name . " SET acceptance_rate = :rate WHERE id = :id";
            $update_stmt = $this->conn->prepare($update_query);
            $update_stmt->bindParam(':rate', $new_rate);
            $update_stmt->bindParam(':id', $this->id);
            
            return $update_stmt->execute();
        }
        return false;
    }

    public function getPerformanceStats($rider_id, $days = 30) {
        $query = "SELECT 
                    COUNT(*) as total_bookings,
                    COUNT(CASE WHEN status = 'delivered' THEN 1 END) as completed_deliveries,
                    AVG(CASE WHEN customer_rating IS NOT NULL THEN customer_rating END) as avg_customer_rating,
                    SUM(CASE WHEN status = 'delivered' THEN total_amount ELSE 0 END) as total_revenue
                  FROM bookings 
                  WHERE rider_id = :rider_id 
                  AND created_at >= DATE_SUB(NOW(), INTERVAL :days DAY)";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':rider_id', $rider_id);
        $stmt->bindParam(':days', $days, PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt->fetch();
    }

    public function getEarnings($rider_id, $start_date = null, $end_date = null) {
        $query = "SELECT 
                    SUM(delivery_fee) as total_delivery_fees,
                    SUM(commission) as total_commission,
                    SUM(bonus) as total_bonus,
                    SUM(total_earning) as total_earnings,
                    COUNT(*) as total_deliveries
                  FROM rider_earnings 
                  WHERE rider_id = :rider_id";
        
        if ($start_date && $end_date) {
            $query .= " AND created_at BETWEEN :start_date AND :end_date";
        }
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':rider_id', $rider_id);
        
        if ($start_date && $end_date) {
            $stmt->bindParam(':start_date', $start_date);
            $stmt->bindParam(':end_date', $end_date);
        }
        
        $stmt->execute();
        return $stmt->fetch();
    }

    public function getActiveBooking($rider_id) {
        $query = "SELECT * FROM bookings 
                  WHERE rider_id = :rider_id 
                  AND status IN ('accepted', 'preparing', 'ready', 'picked_up', 'on_the_way')
                  ORDER BY created_at DESC 
                  LIMIT 1";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':rider_id', $rider_id);
        $stmt->execute();
        
        return $stmt->fetch();
    }

    public function sendPanicAlert($rider_id, $message = '') {
        // Log panic alert
        AppConfig::logActivity($this->user_id, 'panic_alert', "Rider panic alert: {$message}");
        
        // In a real system, this would send notifications to admin and emergency contacts
        // For now, we'll create a notification record
        $query = "INSERT INTO notifications (user_id, type, title, message, data) 
                  VALUES (1, 'emergency', 'RIDER PANIC ALERT', :message, :data)";
        
        $data = json_encode([
            'rider_id' => $rider_id,
            'lat' => $this->current_lat,
            'lng' => $this->current_lng,
            'timestamp' => date('Y-m-d H:i:s')
        ]);
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':message', $message);
        $stmt->bindParam(':data', $data);
        
        return $stmt->execute();
    }
}
?>
