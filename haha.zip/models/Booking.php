<?php
require_once __DIR__ . '/../config/Database.php';
require_once __DIR__ . '/../config/AppConfig.php';

class Booking {
    private $conn;
    private $table_name = "bookings";

    public $id;
    public $booking_number;
    public $customer_id;
    public $rider_id;
    public $merchant_id;
    public $type;
    public $customer_name;
    public $customer_phone;
    public $pickup_address;
    public $pickup_lat;
    public $pickup_lng;
    public $pickup_notes;
    public $delivery_address;
    public $delivery_lat;
    public $delivery_lng;
    public $delivery_notes;
    public $items;
    public $subtotal;
    public $delivery_fee;
    public $service_fee;
    public $total_amount;
    public $payment_method;
    public $payment_status;
    public $status;
    public $accepted_at;
    public $picked_up_at;
    public $delivered_at;
    public $cancelled_at;
    public $delivery_photo;
    public $delivery_signature;
    public $customer_rating;
    public $customer_review;
    public $rider_rating;
    public $rider_review;
    public $created_at;
    public $updated_at;

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    public function create() {
        $this->booking_number = $this->generateBookingNumber();
        
        $query = "INSERT INTO " . $this->table_name . "
                  SET booking_number = :booking_number, customer_id = :customer_id, 
                      merchant_id = :merchant_id, type = :type, customer_name = :customer_name,
                      customer_phone = :customer_phone, pickup_address = :pickup_address,
                      pickup_lat = :pickup_lat, pickup_lng = :pickup_lng, pickup_notes = :pickup_notes,
                      delivery_address = :delivery_address, delivery_lat = :delivery_lat, 
                      delivery_lng = :delivery_lng, delivery_notes = :delivery_notes,
                      items = :items, subtotal = :subtotal, delivery_fee = :delivery_fee,
                      service_fee = :service_fee, total_amount = :total_amount,
                      payment_method = :payment_method";

        $stmt = $this->conn->prepare($query);

        $stmt->bindParam(':booking_number', $this->booking_number);
        $stmt->bindParam(':customer_id', $this->customer_id);
        $stmt->bindParam(':merchant_id', $this->merchant_id);
        $stmt->bindParam(':type', $this->type);
        $stmt->bindParam(':customer_name', $this->customer_name);
        $stmt->bindParam(':customer_phone', $this->customer_phone);
        $stmt->bindParam(':pickup_address', $this->pickup_address);
        $stmt->bindParam(':pickup_lat', $this->pickup_lat);
        $stmt->bindParam(':pickup_lng', $this->pickup_lng);
        $stmt->bindParam(':pickup_notes', $this->pickup_notes);
        $stmt->bindParam(':delivery_address', $this->delivery_address);
        $stmt->bindParam(':delivery_lat', $this->delivery_lat);
        $stmt->bindParam(':delivery_lng', $this->delivery_lng);
        $stmt->bindParam(':delivery_notes', $this->delivery_notes);
        $stmt->bindParam(':items', $this->items);
        $stmt->bindParam(':subtotal', $this->subtotal);
        $stmt->bindParam(':delivery_fee', $this->delivery_fee);
        $stmt->bindParam(':service_fee', $this->service_fee);
        $stmt->bindParam(':total_amount', $this->total_amount);
        $stmt->bindParam(':payment_method', $this->payment_method);

        if ($stmt->execute()) {
            $this->id = $this->conn->lastInsertId();
            $this->logStatusChange('pending', 'New booking created');
            return true;
        }
        return false;
    }

    private function generateBookingNumber() {
        $prefix = 'RM';
        $date = date('Ymd');
        $random = str_pad(mt_rand(1, 9999), 4, '0', STR_PAD_LEFT);
        return $prefix . $date . $random;
    }

    public function updateStatus($new_status, $notes = '', $user_id = null) {
        $old_status = $this->status;
        
        $query = "UPDATE " . $this->table_name . " SET status = :status";
        
        // Update timestamp based on status
        switch ($new_status) {
            case 'accepted':
                $query .= ", accepted_at = NOW()";
                break;
            case 'picked_up':
                $query .= ", picked_up_at = NOW()";
                break;
            case 'delivered':
                $query .= ", delivered_at = NOW()";
                break;
            case 'cancelled':
                $query .= ", cancelled_at = NOW()";
                break;
        }
        
        $query .= " WHERE id = :id";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':status', $new_status);
        $stmt->bindParam(':id', $this->id);

        if ($stmt->execute()) {
            $this->status = $new_status;
            $this->logStatusChange($new_status, $notes, $user_id);
            
            // Update rider earnings when delivered
            if ($new_status === 'delivered' && $this->rider_id) {
                $this->createRiderEarning();
            }
            
            return true;
        }
        return false;
    }

    public function assignRider($rider_id, $user_id = null) {
        $query = "UPDATE " . $this->table_name . " SET rider_id = :rider_id WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':rider_id', $rider_id);
        $stmt->bindParam(':id', $this->id);

        if ($stmt->execute()) {
            $this->rider_id = $rider_id;
            $this->logStatusChange($this->status, "Rider assigned: ID {$rider_id}", $user_id);
            return true;
        }
        return false;
    }

    public function updateDeliveryProof($photo_path, $signature_data) {
        $query = "UPDATE " . $this->table_name . " 
                  SET delivery_photo = :photo, delivery_signature = :signature 
                  WHERE id = :id";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':photo', $photo_path);
        $stmt->bindParam(':signature', $signature_data);
        $stmt->bindParam(':id', $this->id);

        return $stmt->execute();
    }

    public function addCustomerRating($rating, $review = '') {
        $query = "UPDATE " . $this->table_name . " 
                  SET customer_rating = :rating, customer_review = :review 
                  WHERE id = :id";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':rating', $rating);
        $stmt->bindParam(':review', $review);
        $stmt->bindParam(':id', $this->id);

        if ($stmt->execute()) {
            // Update rider rating
            if ($this->rider_id) {
                require_once __DIR__ . '/Rider.php';
                $rider = new Rider();
                $rider->id = $this->rider_id;
                $rider->updateRating($rating);
            }
            
            // Update merchant rating if applicable
            if ($this->merchant_id) {
                require_once __DIR__ . '/Merchant.php';
                $merchant = new Merchant();
                $merchant->id = $this->merchant_id;
                $merchant->updateRating($rating);
            }
            
            return true;
        }
        return false;
    }

    public function addRiderRating($rating, $review = '') {
        $query = "UPDATE " . $this->table_name . " 
                  SET rider_rating = :rating, rider_review = :review 
                  WHERE id = :id";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':rating', $rating);
        $stmt->bindParam(':review', $review);
        $stmt->bindParam(':id', $this->id);

        return $stmt->execute();
    }

    private function logStatusChange($status, $notes = '', $user_id = null) {
        $query = "INSERT INTO booking_status_history 
                  (booking_id, status, notes, created_by) 
                  VALUES (:booking_id, :status, :notes, :created_by)";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':booking_id', $this->id);
        $stmt->bindParam(':status', $status);
        $stmt->bindParam(':notes', $notes);
        $stmt->bindParam(':created_by', $user_id);
        
        $stmt->execute();
    }

    private function createRiderEarning() {
        $commission = $this->delivery_fee * (AppConfig::RIDER_COMMISSION_PERCENTAGE);
        $total_earning = $commission;
        
        $query = "INSERT INTO rider_earnings 
                  (rider_id, booking_id, delivery_fee, commission, total_earning) 
                  VALUES (:rider_id, :booking_id, :delivery_fee, :commission, :total_earning)";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':rider_id', $this->rider_id);
        $stmt->bindParam(':booking_id', $this->id);
        $stmt->bindParam(':delivery_fee', $this->delivery_fee);
        $stmt->bindParam(':commission', $commission);
        $stmt->bindParam(':total_earning', $total_earning);
        
        $stmt->execute();
    }

    public function getById($id) {
        $query = "SELECT b.*, c.full_name as customer_full_name, c.email as customer_email,
                         r.id as rider_info_id, u.full_name as rider_name, u.phone as rider_phone,
                         m.name as merchant_name, m.address as merchant_address
                  FROM " . $this->table_name . " b
                  LEFT JOIN customers c ON b.customer_id = c.id
                  LEFT JOIN riders r ON b.rider_id = r.id
                  LEFT JOIN users u ON r.user_id = u.id
                  LEFT JOIN merchants m ON b.merchant_id = m.id
                  WHERE b.id = :id";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->execute();

        if ($stmt->rowCount() > 0) {
            return $stmt->fetch();
        }
        return false;
    }

    public function getByBookingNumber($booking_number) {
        $query = "SELECT * FROM " . $this->table_name . " WHERE booking_number = :booking_number";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':booking_number', $booking_number);
        $stmt->execute();

        if ($stmt->rowCount() > 0) {
            return $stmt->fetch();
        }
        return false;
    }

    public function getAll($status = null, $type = null, $rider_id = null, $merchant_id = null, $limit = null, $offset = null) {
        $query = "SELECT b.*, c.full_name as customer_full_name, 
                         u.full_name as rider_name, m.name as merchant_name
                  FROM " . $this->table_name . " b
                  LEFT JOIN customers c ON b.customer_id = c.id
                  LEFT JOIN riders r ON b.rider_id = r.id
                  LEFT JOIN users u ON r.user_id = u.id
                  LEFT JOIN merchants m ON b.merchant_id = m.id
                  WHERE 1=1";
        
        if ($status) {
            if (is_array($status)) {
                $placeholders = str_repeat('?,', count($status) - 1) . '?';
                $query .= " AND b.status IN ($placeholders)";
            } else {
                $query .= " AND b.status = :status";
            }
        }
        
        if ($type) $query .= " AND b.type = :type";
        if ($rider_id) $query .= " AND b.rider_id = :rider_id";
        if ($merchant_id) $query .= " AND b.merchant_id = :merchant_id";
        
        $query .= " ORDER BY b.created_at DESC";
        
        if ($limit) {
            $query .= " LIMIT :limit";
            if ($offset) {
                $query .= " OFFSET :offset";
            }
        }
        
        $stmt = $this->conn->prepare($query);
        
        if ($status && !is_array($status)) $stmt->bindParam(':status', $status);
        if ($type) $stmt->bindParam(':type', $type);
        if ($rider_id) $stmt->bindParam(':rider_id', $rider_id);
        if ($merchant_id) $stmt->bindParam(':merchant_id', $merchant_id);
        
        if ($limit) {
            $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
            if ($offset) {
                $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
            }
        }
        
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function getStatusHistory($booking_id) {
        $query = "SELECT bsh.*, u.full_name as created_by_name
                  FROM booking_status_history bsh
                  LEFT JOIN users u ON bsh.created_by = u.id
                  WHERE bsh.booking_id = :booking_id
                  ORDER BY bsh.created_at ASC";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':booking_id', $booking_id);
        $stmt->execute();
        
        return $stmt->fetchAll();
    }

    public function getDashboardStats($days = 30) {
        $query = "SELECT 
                    COUNT(*) as total_bookings,
                    COUNT(CASE WHEN status = 'delivered' THEN 1 END) as completed_bookings,
                    COUNT(CASE WHEN status IN ('pending', 'accepted', 'preparing', 'ready', 'picked_up', 'on_the_way') THEN 1 END) as ongoing_bookings,
                    COUNT(CASE WHEN status = 'cancelled' THEN 1 END) as cancelled_bookings,
                    SUM(CASE WHEN status = 'delivered' THEN total_amount ELSE 0 END) as total_revenue,
                    AVG(CASE WHEN status = 'delivered' AND customer_rating IS NOT NULL THEN customer_rating END) as avg_rating
                  FROM " . $this->table_name . " 
                  WHERE created_at >= DATE_SUB(NOW(), INTERVAL :days DAY)";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':days', $days, PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt->fetch();
    }

    public function getTodayStats() {
        $query = "SELECT 
                    COUNT(*) as today_bookings,
                    COUNT(CASE WHEN status = 'delivered' THEN 1 END) as today_completed,
                    SUM(CASE WHEN status = 'delivered' THEN total_amount ELSE 0 END) as today_revenue
                  FROM " . $this->table_name . " 
                  WHERE DATE(created_at) = CURDATE()";
        
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        
        return $stmt->fetch();
    }

    public function calculateDeliveryFee($pickup_lat, $pickup_lng, $delivery_lat, $delivery_lng) {
        // Calculate distance using Haversine formula
        $earth_radius = 6371; // km
        
        $lat_diff = deg2rad($delivery_lat - $pickup_lat);
        $lng_diff = deg2rad($delivery_lng - $pickup_lng);
        
        $a = sin($lat_diff/2) * sin($lat_diff/2) + 
             cos(deg2rad($pickup_lat)) * cos(deg2rad($delivery_lat)) * 
             sin($lng_diff/2) * sin($lng_diff/2);
        
        $c = 2 * atan2(sqrt($a), sqrt(1-$a));
        $distance = $earth_radius * $c;
        
        // Calculate fee
        $base_fee = AppConfig::DELIVERY_FEE_BASE;
        $per_km_fee = AppConfig::DELIVERY_FEE_PER_KM;
        
        $total_fee = $base_fee + ($distance * $per_km_fee);
        
        return [
            'distance' => round($distance, 2),
            'fee' => round($total_fee, 2)
        ];
    }

    public function getAvailableForAssignment() {
        $query = "SELECT b.*, c.full_name as customer_name, m.name as merchant_name
                  FROM " . $this->table_name . " b
                  LEFT JOIN customers c ON b.customer_id = c.id
                  LEFT JOIN merchants m ON b.merchant_id = m.id
                  WHERE b.rider_id IS NULL AND b.status = 'pending'
                  ORDER BY b.created_at ASC";
        
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        
        return $stmt->fetchAll();
    }

    public function autoAssignRider() {
        if (!$this->pickup_lat || !$this->pickup_lng) {
            return false;
        }
        
        require_once __DIR__ . '/Rider.php';
        $rider_model = new Rider();
        $available_riders = $rider_model->getAvailableRiders($this->pickup_lat, $this->pickup_lng);
        
        if (!empty($available_riders)) {
            $nearest_rider = $available_riders[0];
            return $this->assignRider($nearest_rider['id']);
        }
        
        return false;
    }
}
?>
