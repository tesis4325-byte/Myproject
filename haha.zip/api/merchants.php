<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

require_once '../config/Database.php';

class MerchantsAPI {
    private $db;
    
    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }

    private function slugify($text) {
        $text = preg_replace('~[^\pL\d]+~u', '-', $text);
        $text = trim($text, '-');
        // Try transliterator (intl), then iconv, else fallback
        if (function_exists('transliterator_transliterate')) {
            $text = transliterator_transliterate('Any-Latin; Latin-ASCII; [^A-Za-z0-9_-] remove; Lower()', $text);
        } elseif (function_exists('iconv')) {
            $converted = @iconv('UTF-8', 'ASCII//TRANSLIT', $text);
            if ($converted !== false) { $text = $converted; }
            $text = strtolower($text);
        } else {
            $text = strtolower($text);
        }
        $text = preg_replace('~[^-a-z0-9]+~', '', $text);
        if (empty($text)) { return 'n-a'; }
        return $text;
    }
    
    public function handleRequest() {
        $method = $_SERVER['REQUEST_METHOD'];
        $action = $_GET['action'] ?? '';
        
        try {
            switch ($method) {
                case 'GET':
                    $this->handleGet($action);
                    break;
                case 'POST':
                    $this->handlePost($action);
                    break;
                case 'PUT':
                    $this->handlePut($action);
                    break;
                case 'DELETE':
                    $this->handleDelete($action);
                    break;
                default:
                    $this->sendError('Method not allowed', 405);
            }
        } catch (Exception $e) {
            $this->sendError($e->getMessage(), 500);
        }
    }
    
    private function handleGet($action) {
        switch ($action) {
            case 'list':
                $this->getMerchants();
                break;
            case 'stats':
                $this->getMerchantStats();
                break;
            case 'details':
                $this->getMerchantDetails();
                break;
            case 'menu_items':
                $this->getMerchantMenuItems();
                break;
            case 'orders':
                $this->getMerchantOrders();
                break;
            case 'nearby':
                $this->getNearbyMerchants();
                break;
            case 'categories':
                $this->getMerchantCategories();
                break;
            case 'export':
                $this->exportMerchants();
                break;
            default:
                $this->sendError('Invalid action', 400);
        }
    }
    
    private function handlePost($action) {
        $contentType = $_SERVER['CONTENT_TYPE'] ?? ($_SERVER['HTTP_CONTENT_TYPE'] ?? '');
        $input = [];
        $isMultipart = stripos($contentType, 'multipart/form-data') !== false || !empty($_FILES);
        if ($isMultipart) {
            $input = $_POST ?: [];
            // Diagnostics: if Content-Type says multipart but PHP gave us no files, likely post_max_size exceeded or file_uploads disabled
            if (stripos($contentType, 'multipart/form-data') !== false && empty($_FILES)) {
                $cl = $_SERVER['CONTENT_LENGTH'] ?? 'unknown';
                $pms = ini_get('post_max_size');
                $umf = ini_get('upload_max_filesize');
                $fup = ini_get('file_uploads');
                $this->logActivity("POST diagnostics: multipart with empty \\$_FILES; Content-Length={$cl}, post_max_size={$pms}, upload_max_filesize={$umf}, file_uploads={$fup}");
            }
        } else {
            $raw = file_get_contents('php://input');
            $input = json_decode($raw, true) ?: [];
        }
        $this->logActivity("POST action={$action} isMultipart=" . ($isMultipart ? '1' : '0'));
        
        switch ($action) {
            case 'create':
                $this->createMerchant($input);
                break;
            case 'delete':
                // Allow delete via POST for environments that block DELETE
                $this->deleteMerchant();
                break;
            case 'bulk_action':
                $this->bulkAction($input);
                break;
            default:
                $this->sendError('Invalid action', 400);
        }
    }
    
    private function handlePut($action) {
        $input = json_decode(file_get_contents('php://input'), true);
        
        switch ($action) {
            case 'update':
                $this->updateMerchant($input);
                break;
            case 'update_status':
                $this->updateMerchantStatus($input);
                break;
            case 'update_hours':
                $this->updateOperatingHours($input);
                break;
            default:
                $this->sendError('Invalid action', 400);
        }
    }
    
    private function handleDelete($action) {
        switch ($action) {
            case 'delete':
                $this->deleteMerchant();
                break;
            default:
                $this->sendError('Invalid action', 400);
        }
    }
    
    private function getMerchants() {
        $page = (int)($_GET['page'] ?? 1);
        $limit = (int)($_GET['limit'] ?? 20);
        $search = $_GET['search'] ?? '';
        $status = $_GET['status'] ?? '';
        // category and city columns do not exist in schema; ignore filters safely
        $sortBy = $_GET['sort_by'] ?? 'created_at';
        $sortOrder = strtoupper($_GET['sort_order'] ?? 'DESC');
        // Whitelist allowed sort fields to prevent SQL injection and ambiguity
        $allowedSorts = [
            'created_at' => 'm.created_at',
            'name' => 'm.name',
            'total_revenue' => 'total_revenue',
            'avg_rating' => 'avg_rating',
            'delivered_orders' => 'delivered_orders',
            'monthly_orders' => 'monthly_orders',
            'monthly_revenue' => 'monthly_revenue',
            'menu_items_count' => 'menu_items_count',
            'last_order_date' => 'last_order_date'
        ];
        $sortColumn = $allowedSorts[$sortBy] ?? 'm.created_at';
        $sortOrder = ($sortOrder === 'ASC') ? 'ASC' : 'DESC';
        
        $offset = ($page - 1) * $limit;
        
        // Build query
        $whereConditions = [];
        $params = [];
        
        if (!empty($search)) {
            $whereConditions[] = "(name LIKE ? OR address LIKE ? OR phone LIKE ?)";
            $searchTerm = "%{$search}%";
            $params[] = $searchTerm;
            $params[] = $searchTerm;
            $params[] = $searchTerm;
        }
        
        if (!empty($status)) {
            if ($status === 'active') {
                $whereConditions[] = "is_active = 1";
            } elseif ($status === 'inactive') {
                $whereConditions[] = "is_active = 0";
            } // pending/suspended not tracked; ignore
        }
        
        $whereClause = !empty($whereConditions) ? 'WHERE ' . implode(' AND ', $whereConditions) : '';
        
        // Get total count
        $countQuery = "SELECT COUNT(*) as total FROM merchants {$whereClause}";
        $countStmt = $this->db->prepare($countQuery);
        $countStmt->execute($params);
        $total = $countStmt->fetch(PDO::FETCH_ASSOC)['total'];
        
        // Get merchants with order stats
        $query = "
            SELECT 
                m.id,
                m.name,
                m.slug,
                m.logo,
                m.description,
                m.phone,
                m.email,
                m.address,
                m.lat,
                m.lng,
                m.is_active,
                CASE WHEN m.is_active = 1 THEN 'active' ELSE 'inactive' END AS status,
                '' AS category,
                m.rating,
                m.total_orders,
                COALESCE(COUNT(DISTINCT CASE WHEN b.status = 'delivered' THEN b.id END), 0) AS delivered_orders,
                COALESCE(SUM(CASE WHEN b.status = 'delivered' THEN b.total_amount ELSE 0 END), 0) AS total_revenue,
                COALESCE(AVG(CASE WHEN b.status = 'delivered' AND b.customer_rating IS NOT NULL THEN b.customer_rating END), m.rating) AS avg_rating,
                COALESCE(COUNT(CASE WHEN b.status = 'delivered' AND b.customer_rating IS NOT NULL THEN 1 END), 0) AS total_reviews,
                COALESCE(COUNT(DISTINCT CASE WHEN MONTH(b.created_at) = MONTH(CURRENT_DATE()) AND YEAR(b.created_at) = YEAR(CURRENT_DATE()) AND b.status = 'delivered' THEN b.id END), 0) AS monthly_orders,
                COALESCE(SUM(CASE WHEN MONTH(b.created_at) = MONTH(CURRENT_DATE()) AND YEAR(b.created_at) = YEAR(CURRENT_DATE()) AND b.status = 'delivered' THEN b.total_amount ELSE 0 END), 0) AS monthly_revenue,
                COALESCE(COUNT(DISTINCT CASE WHEN mi.is_available = 1 THEN mi.id END), 0) AS menu_items_count,
                MAX(b.created_at) AS last_order_date
            FROM merchants m
            LEFT JOIN bookings b ON m.id = b.merchant_id
            LEFT JOIN menu_items mi ON m.id = mi.merchant_id
            {$whereClause}
            GROUP BY m.id
            ORDER BY {$sortColumn} {$sortOrder}
            LIMIT {$limit} OFFSET {$offset}
        ";
        
        $stmt = $this->db->prepare($query);
        $stmt->execute($params);
        $merchants = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $this->sendSuccess([
            'merchants' => $merchants,
            'pagination' => [
                'page' => $page,
                'limit' => $limit,
                'total' => (int)$total,
                'pages' => ceil($total / $limit)
            ]
        ]);
    }
    
    private function getMerchantStats() {
        $query = "
            SELECT 
                COUNT(*) as total_merchants,
                COUNT(CASE WHEN is_active = 1 THEN 1 END) as active_merchants,
                COUNT(CASE WHEN is_active = 0 THEN 1 END) as inactive_merchants,
                0 as pending_merchants
            FROM merchants
        ";
        
        $stmt = $this->db->prepare($query);
        $stmt->execute();
        $stats = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // Get revenue stats
        $revenueQuery = "
            SELECT 
                COUNT(DISTINCT b.merchant_id) as merchants_with_orders,
                COALESCE(SUM(CASE WHEN DATE(b.created_at) = CURDATE() AND b.status = 'delivered' THEN b.total_amount ELSE 0 END), 0) as revenue_today,
                COALESCE(SUM(CASE WHEN DATE(b.created_at) >= DATE_SUB(CURDATE(), INTERVAL 7 DAY) AND b.status = 'delivered' THEN b.total_amount ELSE 0 END), 0) as revenue_week,
                COALESCE(SUM(CASE WHEN DATE(b.created_at) >= DATE_SUB(CURDATE(), INTERVAL 30 DAY) AND b.status = 'delivered' THEN b.total_amount ELSE 0 END), 0) as revenue_month,
                AVG(merchant_revenue.avg_order_value) as avg_order_value,
                COALESCE(SUM(CASE WHEN b.status = 'delivered' THEN b.total_amount ELSE 0 END), 0) as total_revenue
            FROM bookings b
            LEFT JOIN (
                SELECT merchant_id, AVG(total_amount) as avg_order_value
                FROM bookings 
                WHERE status = 'delivered'
                GROUP BY merchant_id
            ) merchant_revenue ON b.merchant_id = merchant_revenue.merchant_id
            WHERE b.status = 'delivered'
        ";
        
        $revenueStmt = $this->db->prepare($revenueQuery);
        $revenueStmt->execute();
        $revenueStats = $revenueStmt->fetch(PDO::FETCH_ASSOC);
        
        $this->sendSuccess(array_merge($stats, $revenueStats));
    }
    
    private function getMerchantDetails() {
        $merchantId = $_GET['merchant_id'] ?? '';
        
        if (empty($merchantId)) {
            $this->sendError('Merchant ID is required', 400);
            return;
        }
        
        // Get merchant details (align with schema: delivered status, customer_rating, is_available)
        $merchantQuery = "
            SELECT m.*,
                   COUNT(DISTINCT b.id) as total_orders,
                   COUNT(DISTINCT CASE WHEN b.status = 'delivered' THEN b.id END) as completed_orders,
                   COALESCE(SUM(CASE WHEN b.status = 'delivered' THEN b.total_amount ELSE 0 END), 0) as total_revenue,
                   COALESCE(AVG(CASE WHEN b.status = 'delivered' AND b.customer_rating IS NOT NULL THEN b.customer_rating END), m.rating) as avg_rating,
                   COUNT(DISTINCT CASE WHEN mi.is_available = 1 THEN mi.id END) as menu_items_count,
                   MAX(b.created_at) as last_order_date
            FROM merchants m
            LEFT JOIN bookings b ON m.id = b.merchant_id
            LEFT JOIN menu_items mi ON m.id = mi.merchant_id
            WHERE m.id = ?
            GROUP BY m.id
        ";
        
        $stmt = $this->db->prepare($merchantQuery);
        $stmt->execute([$merchantId]);
        $merchant = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$merchant) {
            $this->sendError('Merchant not found', 404);
            return;
        }
        
        // Get recent orders
        $ordersQuery = "
            SELECT b.*, c.full_name as customer_name, u.full_name as rider_name
            FROM bookings b
            LEFT JOIN customers c ON b.customer_id = c.id
            LEFT JOIN riders r ON b.rider_id = r.id
            LEFT JOIN users u ON r.user_id = u.id
            WHERE b.merchant_id = ?
            ORDER BY b.created_at DESC
            LIMIT 10
        ";
        
        $ordersStmt = $this->db->prepare($ordersQuery);
        $ordersStmt->execute([$merchantId]);
        $recentOrders = $ordersStmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Get popular menu items (booking_items table doesn't exist; return latest available items)
        $popularQuery = "
            SELECT mi.*
            FROM menu_items mi
            WHERE mi.merchant_id = ? AND mi.is_available = 1
            ORDER BY mi.created_at DESC, mi.name ASC
            LIMIT 5
        ";
        
        $popularStmt = $this->db->prepare($popularQuery);
        $popularStmt->execute([$merchantId]);
        $popularItems = $popularStmt->fetchAll(PDO::FETCH_ASSOC);
        
        $this->sendSuccess([
            'merchant' => $merchant,
            'recent_orders' => $recentOrders,
            'popular_items' => $popularItems
        ]);
    }
    
    private function getMerchantMenuItems() {
        $merchantId = $_GET['merchant_id'] ?? '';
        $category = $_GET['category'] ?? '';
        $status = $_GET['status'] ?? 'active';
        
        if (empty($merchantId)) {
            $this->sendError('Merchant ID is required', 400);
            return;
        }
        
        $whereConditions = ['merchant_id = ?'];
        $params = [$merchantId];
        
        if (!empty($category)) {
            $whereConditions[] = "category = ?";
            $params[] = $category;
        }
        
        if (!empty($status)) {
            $whereConditions[] = "status = ?";
            $params[] = $status;
        }
        
        $whereClause = 'WHERE ' . implode(' AND ', $whereConditions);
        
        $query = "
            SELECT mi.*, COUNT(bi.id) as order_count
            FROM menu_items mi
            LEFT JOIN booking_items bi ON mi.id = bi.menu_item_id
            {$whereClause}
            GROUP BY mi.id
            ORDER BY mi.category, mi.name
        ";
        
        $stmt = $this->db->prepare($query);
        $stmt->execute($params);
        $menuItems = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Group by category
        $groupedItems = [];
        foreach ($menuItems as $item) {
            $category = $item['category'] ?? 'Other';
            if (!isset($groupedItems[$category])) {
                $groupedItems[$category] = [];
            }
            $groupedItems[$category][] = $item;
        }
        
        $this->sendSuccess([
            'menu_items' => $menuItems,
            'grouped_items' => $groupedItems
        ]);
    }
    
    private function getMerchantOrders() {
        $merchantId = $_GET['merchant_id'] ?? '';
        $page = (int)($_GET['page'] ?? 1);
        $limit = (int)($_GET['limit'] ?? 20);
        $status = $_GET['status'] ?? '';
        
        if (empty($merchantId)) {
            $this->sendError('Merchant ID is required', 400);
            return;
        }
        
        $offset = ($page - 1) * $limit;
        $whereConditions = ['merchant_id = ?'];
        $params = [$merchantId];
        
        if (!empty($status)) {
            $whereConditions[] = "status = ?";
            $params[] = $status;
        }
        
        $whereClause = 'WHERE ' . implode(' AND ', $whereConditions);
        
        // Get total count
        $countQuery = "SELECT COUNT(*) as total FROM bookings {$whereClause}";
        $countStmt = $this->db->prepare($countQuery);
        $countStmt->execute($params);
        $total = $countStmt->fetch(PDO::FETCH_ASSOC)['total'];
        
        // Get orders
        $query = "
            SELECT b.*, c.full_name as customer_name, c.phone as customer_phone,
                   u.full_name as rider_name, u.phone as rider_phone
            FROM bookings b
            LEFT JOIN customers c ON b.customer_id = c.id
            LEFT JOIN riders r ON b.rider_id = r.id
            LEFT JOIN users u ON r.user_id = u.id
            {$whereClause}
            ORDER BY b.created_at DESC
            LIMIT {$limit} OFFSET {$offset}
        ";
        
        $stmt = $this->db->prepare($query);
        $stmt->execute($params);
        $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $this->sendSuccess([
            'orders' => $orders,
            'pagination' => [
                'page' => $page,
                'limit' => $limit,
                'total' => (int)$total,
                'pages' => ceil($total / $limit)
            ]
        ]);
    }
    
    private function getNearbyMerchants() {
        $latitude = $_GET['latitude'] ?? '';
        $longitude = $_GET['longitude'] ?? '';
        $radius = (float)($_GET['radius'] ?? 10); // km
        $category = $_GET['category'] ?? '';
        $limit = (int)($_GET['limit'] ?? 20);
        
        if (empty($latitude) || empty($longitude)) {
            $this->sendError('Latitude and longitude are required', 400);
            return;
        }
        
        $whereConditions = ["status = 'active'"];
        $params = [];
        
        if (!empty($category)) {
            $whereConditions[] = "category = ?";
            $params[] = $category;
        }
        
        $whereClause = 'WHERE ' . implode(' AND ', $whereConditions);
        
        // Calculate distance using Haversine formula
        $query = "
            SELECT m.*, 
                   COUNT(DISTINCT mi.id) as menu_items_count,
                   COALESCE(AVG(b.rating), 0) as avg_rating,
                   COUNT(DISTINCT CASE WHEN b.status = 'completed' THEN b.id END) as completed_orders,
                   (6371 * acos(cos(radians(?)) * cos(radians(latitude)) * cos(radians(longitude) - radians(?)) + sin(radians(?)) * sin(radians(latitude)))) AS distance
            FROM merchants m
            LEFT JOIN menu_items mi ON m.id = mi.merchant_id AND mi.status = 'active'
            LEFT JOIN bookings b ON m.id = b.merchant_id AND b.status = 'completed'
            {$whereClause}
            GROUP BY m.id
            HAVING distance <= ?
            ORDER BY distance ASC, avg_rating DESC
            LIMIT {$limit}
        ";
        
        $allParams = array_merge([$latitude, $longitude, $latitude], $params, [$radius]);
        $stmt = $this->db->prepare($query);
        $stmt->execute($allParams);
        $merchants = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $this->sendSuccess(['merchants' => $merchants]);
    }
    
    private function getMerchantCategories() {
        $query = "
            SELECT category, COUNT(*) as count
            FROM merchants 
            WHERE status = 'active' AND category IS NOT NULL
            GROUP BY category
            ORDER BY count DESC, category ASC
        ";
        
        $stmt = $this->db->prepare($query);
        $stmt->execute();
        $categories = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $this->sendSuccess(['categories' => $categories]);
    }
    
    private function createMerchant($data) {
        $this->logActivity('createMerchant:start');
        // Fallback to $_POST if JSON parsing was empty but form-data was used
        if (empty($data) && !empty($_POST)) {
            $data = $_POST;
        }
        $requiredFields = ['name', 'phone', 'address'];
        foreach ($requiredFields as $field) {
            if (!isset($data[$field]) || empty($data[$field])) {
                $this->sendError("Field {$field} is required", 400);
                $this->logActivity('createMerchant:error missing ' . $field);
                return;
            }
        }
        
        // Check if phone already exists
        $checkStmt = $this->db->prepare("SELECT id FROM merchants WHERE phone = ?");
        $checkStmt->execute([$data['phone']]);
        if ($checkStmt->fetch()) {
            $this->sendError('Phone number already exists', 409);
            $this->logActivity('createMerchant:error phone exists');
            return;
        }

        // Handle logo upload if provided via multipart/form-data
        if (isset($_FILES['logo'])) {
            $err = $_FILES['logo']['error'] ?? null;
            $this->logActivity('createMerchant:logo upload present err=' . var_export($err, true) . ' name=' . ($_FILES['logo']['name'] ?? '')); 
            if ($err === UPLOAD_ERR_OK && !empty($_FILES['logo']['tmp_name'])) {
                $uploadDir = dirname(__DIR__) . '/admin/assets/images';
                if (!is_dir($uploadDir)) {
                    if (!@mkdir($uploadDir, 0775, true)) {
                        $this->logActivity('createMerchant:error mkdir failed for ' . $uploadDir);
                    }
                }
                $originalName = $_FILES['logo']['name'];
                $tmpPath = $_FILES['logo']['tmp_name'];
                $ext = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));
                $allowed = ['jpg','jpeg','png','gif','webp'];
                if (!in_array($ext, $allowed)) {
                    $this->sendError('Invalid logo file type', 400);
                    $this->logActivity('createMerchant:error invalid logo type ' . $ext);
                    return;
                }
                $slugBase = !empty($data['slug']) ? $data['slug'] : $this->slugify($data['name']);
                $fileName = $slugBase . '-' . time() . '.' . $ext;
                $destPath = $uploadDir . '/' . $fileName;
                if (!@move_uploaded_file($tmpPath, $destPath)) {
                    $this->sendError('Failed to save uploaded logo', 500);
                    $this->logActivity('createMerchant:error move_uploaded_file failed tmp=' . $tmpPath . ' dest=' . $destPath);
                    return;
                }
                // Store web path used by frontend (with leading slash)
                $data['logo'] = '/admin/assets/images/' . $fileName;
                $this->logActivity('createMerchant:logo saved ' . $data['logo']);
            } elseif ($err !== null && $err !== UPLOAD_ERR_NO_FILE) {
                // Map common errors
                $errMap = [
                    UPLOAD_ERR_INI_SIZE => 'Exceeded upload_max_filesize',
                    UPLOAD_ERR_FORM_SIZE => 'Exceeded MAX_FILE_SIZE',
                    UPLOAD_ERR_PARTIAL => 'Partial upload',
                    UPLOAD_ERR_NO_TMP_DIR => 'Missing temp folder',
                    UPLOAD_ERR_CANT_WRITE => 'Failed to write file to disk',
                    UPLOAD_ERR_EXTENSION => 'PHP extension stopped the file upload'
                ];
                $msg = $errMap[$err] ?? ('Upload error code ' . $err);
                $this->logActivity('createMerchant:logo upload error - ' . $msg);
                // Continue without blocking create if logo upload fails
            } else {
                $this->logActivity('createMerchant:logo not provided or empty');
            }
        } else {
            $this->logActivity('createMerchant:$_FILES has no logo key');
        }
        
        // Prepare columns aligned with schema
        $fields = ['name', 'slug', 'phone', 'email', 'address', 'description', 'lat', 'lng', 'opening_hours', 'is_active', 'commission_rate', 'service_fee', 'created_at', 'updated_at'];
        $slug = !empty($data['slug']) ? $data['slug'] : $this->slugify($data['name']);
        $values = [
            $data['name'],
            $slug,
            $data['phone'],
            $data['email'] ?? null,
            $data['address'],
            $data['description'] ?? null,
            $data['lat'] ?? null,
            $data['lng'] ?? null,
            isset($data['opening_hours']) ? (is_string($data['opening_hours']) ? $data['opening_hours'] : json_encode($data['opening_hours'])) : null,
            isset($data['is_active']) ? (int)$data['is_active'] : 1,
            isset($data['commission_rate']) ? (float)$data['commission_rate'] : 5.00,
            isset($data['service_fee']) ? (float)$data['service_fee'] : 0.00,
            date('Y-m-d H:i:s'),
            date('Y-m-d H:i:s')
        ];

        // Optional: logo (either URL in JSON or uploaded file path handled above)
        if (!empty($data['logo'])) {
            $fields[] = 'logo';
            $values[] = $data['logo'];
        }

        $placeholders = str_repeat('?,', count($values) - 1) . '?';
        $query = "INSERT INTO merchants (" . implode(',', $fields) . ") VALUES ({$placeholders})";
        
        $stmt = $this->db->prepare($query);
        if ($stmt->execute($values)) {
            $merchantId = $this->db->lastInsertId();
            $this->logActivity('createMerchant:success id=' . $merchantId);
            $this->sendSuccess(['merchant_id' => $merchantId], 'Merchant created successfully');
        } else {
            $this->logActivity('createMerchant:error insert failed');
            $this->sendError('Failed to create merchant', 500);
        }
    }

    private function logActivity($message) {
        $logFile = dirname(__DIR__) . '/logs/activity.log';
        $date = date('Y-m-d H:i:s');
        @file_put_contents($logFile, "[$date] MerchantsAPI: {$message}\n", FILE_APPEND);
    }
    
    private function updateMerchant($data) {
        if (!isset($data['merchant_id'])) {
            $this->sendError('Merchant ID is required', 400);
            return;
        }
        
        $merchantId = $data['merchant_id'];
        $updateFields = [];
        $values = [];
        
        $allowedFields = [
            'name', 'slug', 'logo', 'phone', 'email', 'address', 'description',
            'lat', 'lng', 'opening_hours', 'is_active', 'commission_rate', 'service_fee'
        ];
        
        foreach ($allowedFields as $field) {
            if (isset($data[$field])) {
                $updateFields[] = "{$field} = ?";
                $values[] = $data[$field];
            }
        }
        
        if (empty($updateFields)) {
            $this->sendError('No fields to update', 400);
            return;
        }
        
        $updateFields[] = "updated_at = ?";
        $values[] = date('Y-m-d H:i:s');
        $values[] = $merchantId;
        
        $query = "UPDATE merchants SET " . implode(', ', $updateFields) . " WHERE id = ?";
        $stmt = $this->db->prepare($query);
        
        if ($stmt->execute($values)) {
            $this->sendSuccess([], 'Merchant updated successfully');
        } else {
            $this->sendError('Failed to update merchant', 500);
        }
    }
    
    private function updateMerchantStatus($data) {
        if (!isset($data['merchant_id']) || !isset($data['status'])) {
            $this->sendError('Merchant ID and status are required', 400);
            return;
        }
        $merchantId = $data['merchant_id'];
        $status = $data['status'];
        $isActive = ($status === 'active') ? 1 : 0; // map other statuses to inactive
        $stmt = $this->db->prepare("UPDATE merchants SET is_active = ?, updated_at = ? WHERE id = ?");
        if ($stmt->execute([$isActive, date('Y-m-d H:i:s'), $merchantId])) {
            $this->sendSuccess([], 'Merchant status updated successfully');
        } else {
            $this->sendError('Failed to update merchant status', 500);
        }
    }
    
    private function updateOperatingHours($data) {
        if (!isset($data['merchant_id']) || !isset($data['opening_hours'])) {
            $this->sendError('Merchant ID and opening hours are required', 400);
            return;
        }
        
        $merchantId = $data['merchant_id'];
        $openingHours = json_encode($data['opening_hours']);
        $isOpen = $data['is_open'] ?? null;
        
        $updateFields = ['opening_hours = ?', 'updated_at = ?'];
        $params = [$openingHours, date('Y-m-d H:i:s')];
        
        if ($isOpen !== null) {
            $updateFields[] = 'is_open = ?';
            $params[] = $isOpen;
        }
        
        $params[] = $merchantId;
        
        $query = "UPDATE merchants SET " . implode(', ', $updateFields) . " WHERE id = ?";
        $stmt = $this->db->prepare($query);
        
        if ($stmt->execute($params)) {
            $this->sendSuccess([], 'Operating hours updated successfully');
        } else {
            $this->sendError('Failed to update operating hours', 500);
        }
    }
    
    private function deleteMerchant() {
        $merchantId = $_GET['merchant_id'] ?? ($_POST['merchant_id'] ?? '');
        $this->logActivity('deleteMerchant:start id=' . ($merchantId ?: '')); 
        
        if (empty($merchantId)) {
            $this->sendError('Merchant ID is required', 400);
            $this->logActivity('deleteMerchant:error missing merchant_id');
            return;
        }
        
        // Check if merchant has orders
        $checkStmt = $this->db->prepare("SELECT COUNT(*) as order_count FROM bookings WHERE merchant_id = ?");
        $checkStmt->execute([$merchantId]);
        $orderCount = $checkStmt->fetch(PDO::FETCH_ASSOC)['order_count'];
        
        if ($orderCount > 0) {
            // Soft delete - deactivate
            $stmt = $this->db->prepare("UPDATE merchants SET is_active = 0, updated_at = ? WHERE id = ?");
            $stmt->execute([date('Y-m-d H:i:s'), $merchantId]);
        } else {
            // Hard delete if no orders
            $stmt = $this->db->prepare("DELETE FROM merchants WHERE id = ?");
            $stmt->execute([$merchantId]);
        }
        
        $this->sendSuccess([], 'Merchant deleted successfully');
        $this->logActivity('deleteMerchant:success id=' . $merchantId);
    }
    
    private function bulkAction($data) {
        if (!isset($data['action']) || !isset($data['merchant_ids'])) {
            $this->sendError('Action and merchant IDs are required', 400);
            return;
        }
        
        $action = $data['action'];
        $merchantIds = $data['merchant_ids'];
        
        if (empty($merchantIds)) {
            $this->sendError('No merchants selected', 400);
            return;
        }
        
        $placeholders = str_repeat('?,', count($merchantIds) - 1) . '?';
        
        switch ($action) {
            case 'activate':
                $query = "UPDATE merchants SET is_active = 1, updated_at = ? WHERE id IN ({$placeholders})";
                $params = array_merge([date('Y-m-d H:i:s')], $merchantIds);
                break;
            case 'deactivate':
            case 'suspend':
            case 'delete':
                $query = "UPDATE merchants SET is_active = 0, updated_at = ? WHERE id IN ({$placeholders})";
                $params = array_merge([date('Y-m-d H:i:s')], $merchantIds);
                break;
            default:
                $this->sendError('Invalid bulk action', 400);
                return;
        }
        
        $stmt = $this->db->prepare($query);
        if ($stmt->execute($params)) {
            $affectedRows = $stmt->rowCount();
            $this->sendSuccess(['affected_rows' => $affectedRows], "Bulk action completed on {$affectedRows} merchants");
        } else {
            $this->sendError('Failed to perform bulk action', 500);
        }
    }
    
    private function exportMerchants() {
        $format = $_GET['format'] ?? 'csv';
        $status = $_GET['status'] ?? '';
        $category = $_GET['category'] ?? '';
        
        $whereConditions = [];
        $params = [];
        
        if (!empty($status)) {
            $whereConditions[] = "status = ?";
            $params[] = $status;
        }
        
        if (!empty($category)) {
            $whereConditions[] = "category = ?";
            $params[] = $category;
        }
        
        $whereClause = !empty($whereConditions) ? 'WHERE ' . implode(' AND ', $whereConditions) : '';
        
        $query = "
            SELECT m.*, 
                   COUNT(DISTINCT b.id) as total_orders,
                   COALESCE(SUM(CASE WHEN b.status = 'completed' THEN b.total_amount ELSE 0 END), 0) as total_revenue
            FROM merchants m
            LEFT JOIN bookings b ON m.id = b.merchant_id
            {$whereClause}
            GROUP BY m.id
            ORDER BY m.created_at DESC
        ";
        
        $stmt = $this->db->prepare($query);
        $stmt->execute($params);
        $merchants = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        if ($format === 'csv') {
            header('Content-Type: text/csv');
            header('Content-Disposition: attachment; filename="merchants_' . date('Y-m-d') . '.csv"');
            
            $output = fopen('php://output', 'w');
            
            // CSV headers
            fputcsv($output, ['ID', 'Name', 'Phone', 'Email', 'Address', 'Category', 'Status', 'Total Orders', 'Total Revenue', 'Created At']);
            
            foreach ($merchants as $merchant) {
                fputcsv($output, [
                    $merchant['id'],
                    $merchant['name'],
                    $merchant['phone'],
                    $merchant['email'],
                    $merchant['address'],
                    $merchant['category'],
                    $merchant['status'],
                    $merchant['total_orders'],
                    $merchant['total_revenue'],
                    $merchant['created_at']
                ]);
            }
            
            fclose($output);
        } else {
            $this->sendSuccess(['merchants' => $merchants]);
        }
    }
    
    private function sendSuccess($data = [], $message = 'Success') {
        echo json_encode([
            'success' => true,
            'message' => $message,
            'data' => $data
        ]);
    }
    
    private function sendError($message, $code = 400) {
        http_response_code($code);
        echo json_encode([
            'success' => false,
            'message' => $message,
            'error_code' => $code
        ]);
    }
}

$api = new MerchantsAPI();
$api->handleRequest();
?>
