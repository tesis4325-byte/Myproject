<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

require_once '../config/Database.php';

class BookingsAPI {
    private $db;
    
    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }
    
    public function handleRequest() {
        $method = $_SERVER['REQUEST_METHOD'];
        $action = $_GET['action'] ?? '';
        
        try {
            switch ($method) {
                case 'GET':
                    $this->handleGet($action);
                    break;
                case 'POST':
                    $this->handlePost($action);
                    break;
                case 'PUT':
                    $this->handlePut($action);
                    break;
                case 'DELETE':
                    $this->handleDelete($action);
                    break;
                default:
                    $this->sendError('Method not allowed', 405);
            }
        } catch (Exception $e) {
            $this->sendError($e->getMessage(), 500);
        }
    }
    
    private function handleGet($action) {
        switch ($action) {
            case 'list':
                $this->getBookings();
                break;
            case 'stats':
                $this->getBookingStats();
                break;
            case 'details':
                $this->getBookingDetails();
                break;
            case 'track':
                $this->trackBooking();
                break;
            case 'export':
                $this->exportBookings();
                break;
            default:
                $this->sendError('Invalid action', 400);
        }
    }
    
    private function handlePost($action) {
        $input = json_decode(file_get_contents('php://input'), true);
        // Default to create when action is not provided for POST requests
        if (empty($action)) {
            $action = 'create';
        }
        
        switch ($action) {
            case 'create':
                $this->createBooking($input);
                break;
            case 'assign_rider':
                $this->assignRider($input);
                break;
            case 'bulk_action':
                $this->bulkAction($input);
                break;
            case 'submit_rating':
                $this->submitCustomerRating($input);
                break;
            default:
                $this->sendError('Invalid action', 400);
        }
    }
    
    private function handlePut($action) {
        $input = json_decode(file_get_contents('php://input'), true);
        
        switch ($action) {
            case 'update':
                $this->updateBooking($input);
                break;
            case 'update_status':
                $this->updateBookingStatus($input);
                break;
            default:
                $this->sendError('Invalid action', 400);
        }
    }
    
    private function handleDelete($action) {
        switch ($action) {
            case 'cancel':
                $this->cancelBooking();
                break;
            default:
                $this->sendError('Invalid action', 400);
        }
    }
    
    private function getBookings() {
        $page = (int)($_GET['page'] ?? 1);
        $limit = (int)($_GET['limit'] ?? 20);
        $search = $_GET['search'] ?? '';
        $status = $_GET['status'] ?? '';
        $dateFrom = $_GET['date_from'] ?? '';
        $dateTo = $_GET['date_to'] ?? '';
        $riderId = $_GET['rider_id'] ?? '';
        $customerId = $_GET['customer_id'] ?? '';
        $sortBy = $_GET['sort_by'] ?? 'created_at';
        $sortOrder = $_GET['sort_order'] ?? 'DESC';
        
        $offset = ($page - 1) * $limit;
        
        // Build query
        $whereConditions = [];
        $params = [];
        
        if (!empty($search)) {
            $whereConditions[] = "(b.id LIKE ? OR c.full_name LIKE ? OR m.name LIKE ?)";
            $searchTerm = "%{$search}%";
            $params[] = $searchTerm;
            $params[] = $searchTerm;
            $params[] = $searchTerm;
        }
        
        if (!empty($status)) {
            $whereConditions[] = "b.status = ?";
            $params[] = $status;
        }
        
        if (!empty($dateFrom)) {
            $whereConditions[] = "DATE(b.created_at) >= ?";
            $params[] = $dateFrom;
        }
        
        if (!empty($dateTo)) {
            $whereConditions[] = "DATE(b.created_at) <= ?";
            $params[] = $dateTo;
        }
        
        if (!empty($riderId)) {
            $whereConditions[] = "b.rider_id = ?";
            $params[] = $riderId;
        }
        
        if (!empty($customerId)) {
            $whereConditions[] = "b.customer_id = ?";
            $params[] = $customerId;
        }
        
        $whereClause = !empty($whereConditions) ? 'WHERE ' . implode(' AND ', $whereConditions) : '';
        
        // Get total count
        $countQuery = "
            SELECT COUNT(*) as total 
            FROM bookings b
            LEFT JOIN customers c ON b.customer_id = c.id
            LEFT JOIN merchants m ON b.merchant_id = m.id
            {$whereClause}
        ";
        $countStmt = $this->db->prepare($countQuery);
        $countStmt->execute($params);
        $total = $countStmt->fetch(PDO::FETCH_ASSOC)['total'];
        
        // Get bookings
        $query = "
            SELECT b.*, 
                   b.type AS service_type,
                   c.full_name as customer_name, c.phone as customer_phone,
                   m.name as merchant_name, m.address as merchant_address,
                   u.full_name as rider_name, u.phone as rider_phone
            FROM bookings b
            LEFT JOIN customers c ON b.customer_id = c.id
            LEFT JOIN merchants m ON b.merchant_id = m.id
            LEFT JOIN riders r ON b.rider_id = r.id
            LEFT JOIN users u ON r.user_id = u.id
            {$whereClause}
            ORDER BY {$sortBy} {$sortOrder}
            LIMIT {$limit} OFFSET {$offset}
        ";
        
        $stmt = $this->db->prepare($query);
        $stmt->execute($params);
        $bookings = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $this->sendSuccess([
            'bookings' => $bookings,
            'pagination' => [
                'page' => $page,
                'limit' => $limit,
                'total' => (int)$total,
                'pages' => ceil($total / $limit)
            ]
        ]);
    }
    
    private function getBookingStats() {
        $query = "
            SELECT 
                COUNT(*) as total_bookings,
                COUNT(CASE WHEN status = 'pending' THEN 1 END) as pending_orders,
                COUNT(CASE WHEN status IN ('assigned','picked_up','on_the_way') THEN 1 END) as in_transit_orders,
                COUNT(CASE WHEN status IN ('delivered','completed') AND DATE(created_at) = CURDATE() THEN 1 END) as completed_today,
                COUNT(CASE WHEN status = 'cancelled' THEN 1 END) as cancelled_bookings,
                COUNT(CASE WHEN DATE(created_at) = CURDATE() THEN 1 END) as today_bookings,
                COALESCE(SUM(total_amount), 0) as total_revenue,
                COALESCE(SUM(CASE WHEN DATE(created_at) = CURDATE() THEN total_amount ELSE 0 END), 0) as today_revenue,
                AVG(CASE WHEN status IN ('delivered','completed') THEN rider_rating END) as avg_rating
            FROM bookings
        ";
        
        $stmt = $this->db->prepare($query);
        $stmt->execute();
        $stats = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // Backward-compatible aliases often used elsewhere
        $stats['pending_bookings'] = $stats['pending_orders'];
        $stats['in_transit_bookings'] = $stats['in_transit_orders'];
        $stats['completed_bookings'] = $stats['completed_today'];
        
        $this->sendSuccess($stats);
    }
    
    private function getBookingDetails() {
        $bookingId = $_GET['booking_id'] ?? '';
        
        if (empty($bookingId)) {
            $this->sendError('Booking ID is required', 400);
            return;
        }
        
        $query = "
            SELECT b.*, 
                   c.full_name as customer_name, c.phone as customer_phone, c.email as customer_email,
                   m.name as merchant_name, m.address as merchant_address, m.phone as merchant_phone,
                   u.full_name as rider_name, u.phone as rider_phone, r.vehicle_type
            FROM bookings b
            LEFT JOIN customers c ON b.customer_id = c.id
            LEFT JOIN merchants m ON b.merchant_id = m.id
            LEFT JOIN riders r ON b.rider_id = r.id
            LEFT JOIN users u ON r.user_id = u.id
            WHERE b.id = ?
        ";
        
        $stmt = $this->db->prepare($query);
        $stmt->execute([$bookingId]);
        $booking = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$booking) {
            $this->sendError('Booking not found', 404);
            return;
        }
        
        // Get booking items if table exists (graceful fallback if not)
        $items = [];
        try {
            $itemsQuery = "SELECT * FROM booking_items WHERE booking_id = ?";
            $itemsStmt = $this->db->prepare($itemsQuery);
            $itemsStmt->execute([$bookingId]);
            $items = $itemsStmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            // Table may not exist in current schema; ignore and return empty items
            @file_put_contents(__DIR__ . '/../logs/error.log', "[".date('Y-m-d H:i:s')."] WARN [BOOKING] [DETAILS] booking_items fetch skipped: " . $e->getMessage() . "\n", FILE_APPEND);
        }
        
        $this->sendSuccess([
            'booking' => $booking,
            'items' => $items
        ]);
    }

    private function trackBooking() {
        $bookingNumber = $_GET['booking_number'] ?? '';
        if (empty($bookingNumber)) {
            $this->sendError('Booking number is required', 400);
            return;
        }
        $query = "
            SELECT b.*, 
                   c.full_name as customer_name, c.phone as customer_phone,
                   m.name as merchant_name, m.phone as merchant_phone,
                   u.full_name as rider_name, u.phone as rider_phone
            FROM bookings b
            LEFT JOIN customers c ON b.customer_id = c.id
            LEFT JOIN merchants m ON b.merchant_id = m.id
            LEFT JOIN riders r ON b.rider_id = r.id
            LEFT JOIN users u ON r.user_id = u.id
            WHERE b.booking_number = ?
        ";
        $stmt = $this->db->prepare($query);
        $stmt->execute([$bookingNumber]);
        $booking = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$booking) {
            $this->sendError('Booking not found', 404);
            return;
        }
        $this->sendSuccess(['booking' => $booking]);
    }

    private function submitCustomerRating($data) {
        // rating for delivered bookings, by booking_number or booking_id
        $bookingNumber = $data['booking_number'] ?? null;
        $bookingId = $data['booking_id'] ?? null;
        $rating = isset($data['rating']) ? (int)$data['rating'] : null;
        $review = $data['review'] ?? null;
        if ((!$bookingNumber && !$bookingId) || !$rating || $rating < 1 || $rating > 5) {
            $this->sendError('booking_number or booking_id and rating (1-5) are required', 400);
            return;
        }
        // resolve booking id by booking_number
        if (!$bookingId) {
            $stmt = $this->db->prepare("SELECT id, status FROM bookings WHERE booking_number = ? LIMIT 1");
            $stmt->execute([$bookingNumber]);
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            if (!$row) {
                $this->sendError('Booking not found', 404);
                return;
            }
            $bookingId = (int)$row['id'];
            $status = $row['status'];
        } else {
            $stmt = $this->db->prepare("SELECT status FROM bookings WHERE id = ? LIMIT 1");
            $stmt->execute([$bookingId]);
            $statusRow = $stmt->fetch(PDO::FETCH_ASSOC);
            if (!$statusRow) {
                $this->sendError('Booking not found', 404);
                return;
            }
            $status = $statusRow['status'];
        }
        // allow rating when delivered (or completed legacy)
        if (!in_array($status, ['delivered', 'completed'])) {
            $this->sendError('You can rate only after delivery is completed', 400);
            return;
        }
        $upd = $this->db->prepare("UPDATE bookings SET customer_rating = ?, customer_review = ?, updated_at = ? WHERE id = ?");
        $ok = $upd->execute([$rating, $review, date('Y-m-d H:i:s'), $bookingId]);
        if ($ok) {
            // Recalculate rider's average rating based on all rated bookings
            $ridStmt = $this->db->prepare("SELECT rider_id FROM bookings WHERE id = ? LIMIT 1");
            $ridStmt->execute([$bookingId]);
            $ridRow = $ridStmt->fetch(PDO::FETCH_ASSOC);
            if ($ridRow && !empty($ridRow['rider_id'])) {
                $riderId = (int)$ridRow['rider_id'];
                $avgStmt = $this->db->prepare("SELECT AVG(customer_rating) AS avg_rating FROM bookings WHERE rider_id = ? AND customer_rating IS NOT NULL");
                $avgStmt->execute([$riderId]);
                $avg = $avgStmt->fetch(PDO::FETCH_ASSOC);
                $avgRating = $avg && isset($avg['avg_rating']) ? (float)$avg['avg_rating'] : null;
                if ($avgRating !== null) {
                    $upR = $this->db->prepare("UPDATE riders SET rating = ?, updated_at = ? WHERE id = ?");
                    $upR->execute([number_format($avgRating, 2, '.', ''), date('Y-m-d H:i:s'), $riderId]);
                }
            }
            $this->sendSuccess([], 'Thank you for your feedback!');
        } else {
            $this->sendError('Failed to submit rating', 500);
        }
    }
    
    private function createBooking($data) {
        // Accept flexible payloads from the public booking forms
        // 1) Resolve or create customer
        $customerId = $data['customer_id'] ?? null;
        if (!$customerId) {
            $customerName = $data['customer_name'] ?? ($data['name'] ?? null);
            $customerPhone = $data['customer_phone'] ?? ($data['phone'] ?? null);
            if ($customerPhone) {
                // Try to find existing customer by phone
                $findStmt = $this->db->prepare("SELECT id FROM customers WHERE phone = ? LIMIT 1");
                $findStmt->execute([$customerPhone]);
                $existing = $findStmt->fetch(PDO::FETCH_ASSOC);
                if ($existing && isset($existing['id'])) {
                    $customerId = (int)$existing['id'];
                } else {
                    // Create a new customer record
                    $insStmt = $this->db->prepare("INSERT INTO customers (full_name, phone, address, created_at) VALUES (?, ?, ?, ?)");
                    $insStmt->execute([
                        $customerName ?: 'Guest',
                        $customerPhone,
                        $data['delivery_address'] ?? ($data['address'] ?? ''),
                        date('Y-m-d H:i:s')
                    ]);
                    $customerId = (int)$this->db->lastInsertId();
                }
            }
        }
        if (!$customerId) {
            $this->sendError('Customer information is required', 400);
            return;
        }

        // 2) Determine merchant and addresses based on type
        $type = $data['type'] ?? '';
        // Normalize to match DB ENUM ('pay_bills' not 'bill_payment')
        if ($type === 'bill_payment') {
            $type = 'pay_bills';
        }
        $merchantId = $data['merchant_id'] ?? null;
        $pickupAddress = $data['pickup_address'] ?? '';
        $deliveryAddress = $data['delivery_address'] ?? '';
        $deliveryNotes = $data['delivery_notes'] ?? ($data['special_instructions'] ?? null);
        // Capture customer basic details for denormalized columns
        $customerName = $customerName ?? ($data['customer_name'] ?? ($data['name'] ?? 'Guest'));
        $customerPhone = $customerPhone ?? ($data['customer_phone'] ?? ($data['phone'] ?? ''));

        if (empty($deliveryAddress)) {
            $this->sendError('Delivery address is required', 400);
            return;
        }

        // Validate merchant requirements and existence to satisfy FK
        if ($type === 'food_delivery') {
            if (empty($merchantId)) {
                $this->sendError('Merchant is required for food delivery', 400);
                return;
            }
            // Ensure merchant exists
            $mStmt = $this->db->prepare("SELECT id FROM merchants WHERE id = ? LIMIT 1");
            $mStmt->execute([$merchantId]);
            $m = $mStmt->fetch(PDO::FETCH_ASSOC);
            if (!$m) {
                $this->sendError('Invalid merchant selected. Please choose an available restaurant.', 400);
                return;
            }
        } else {
            // For non-food types, merchant is optional; normalize falsy values to NULL
            if (empty($merchantId)) {
                $merchantId = null;
            }
        }
        if ($type === 'pickup_deliver' && empty($pickupAddress)) {
            $this->sendError('Pickup address is required for pickup & deliver', 400);
            return;
        }

        // 3) Compute amounts
        $baseAmount = 0.0;
        if (isset($data['subtotal'])) {
            $baseAmount = (float)$data['subtotal'];
        } elseif (isset($data['amount'])) { // e.g., bill payments
            $baseAmount = (float)$data['amount'];
        } elseif (isset($data['items']) && is_array($data['items'])) {
            foreach ($data['items'] as $it) {
                if (isset($it['total_price'])) {
                    $baseAmount += (float)$it['total_price'];
                } elseif (isset($it['price'], $it['quantity'])) {
                    $baseAmount += ((float)$it['price']) * ((int)$it['quantity']);
                } elseif (isset($it['amount'])) {
                    $baseAmount += (float)$it['amount'];
                }
            }
        }
        $deliveryFee = isset($data['delivery_fee']) ? (float)$data['delivery_fee'] : 50.00;
        $totalAmount = $baseAmount + $deliveryFee;
        $serviceFee = isset($data['service_fee']) ? (float)$data['service_fee'] : 0.00;
        $paymentMethod = $data['payment_method'] ?? 'cod';
        $subtotal = $baseAmount;
        $itemsJson = null;
        if (isset($data['items']) && is_array($data['items'])) {
            $itemsJson = json_encode($data['items']);
        }
        // Default coordinates if not provided (schema requires NOT NULL)
        $deliveryLat = isset($data['delivery_lat']) ? (float)$data['delivery_lat'] : 0.0;
        $deliveryLng = isset($data['delivery_lng']) ? (float)$data['delivery_lng'] : 0.0;

        // 4) Build insert (include schema-required fields)
        $bookingNumber = 'RM' . date('ymdHis') . rand(100, 999);
        $fields = [
            'booking_number', 'customer_id', 'merchant_id', 'type',
            'customer_name', 'customer_phone',
            'pickup_address', 'delivery_address', 'delivery_lat', 'delivery_lng',
            'items', 'subtotal', 'delivery_fee', 'service_fee', 'total_amount',
            'payment_method', 'status', 'created_at'
        ];
        $values = [
            $bookingNumber,
            $customerId,
            $merchantId, // may be null
            $type,
            $customerName,
            $customerPhone,
            $pickupAddress,
            $deliveryAddress,
            $deliveryLat,
            $deliveryLng,
            $itemsJson,
            $subtotal,
            $deliveryFee,
            $serviceFee,
            $totalAmount,
            $paymentMethod,
            'pending',
            date('Y-m-d H:i:s')
        ];

        // Optional fields
        $optionalFields = [
            'pickup_latitude', 'pickup_longitude', 'delivery_latitude', 'delivery_longitude',
            'priority', 'estimated_delivery_time'
        ];
        foreach ($optionalFields as $field) {
            if (isset($data[$field])) {
                $fields[] = $field;
                $values[] = $data[$field];
            }
        }
        if (!empty($deliveryNotes)) {
            $fields[] = 'delivery_notes';
            $values[] = $deliveryNotes;
        }

        // Quote identifiers to avoid reserved word conflicts (e.g., `type`)
        $quotedFields = array_map(function($f){ return "`" . $f . "`"; }, $fields);
        $placeholders = str_repeat('?,', count($values) - 1) . '?';
        $query = "INSERT INTO `bookings` (" . implode(',', $quotedFields) . ") VALUES ({$placeholders})";

        try {
            $stmt = $this->db->prepare($query);
            $ok = $stmt->execute($values);
        } catch (PDOException $e) {
            // Log details to file for debugging
            @file_put_contents(__DIR__ . '/../logs/error.log', "[".date('Y-m-d H:i:s')."] ERROR [BOOKING] [CREATE] - " . $e->getMessage() . "\n", FILE_APPEND);
            return $this->sendError('Failed to create booking: ' . $e->getMessage(), 500);
        }

        if ($ok) {
            $bookingId = $this->db->lastInsertId();
            // Activity log for traceability
            @file_put_contents(__DIR__ . '/../logs/activity.log', "[".date('Y-m-d H:i:s')."] BOOKING CREATE booking_id={$bookingId} number={$bookingNumber} type={$type} customer_id={$customerId} merchant_id=".($merchantId ?? 'NULL')." total={$totalAmount}\n", FILE_APPEND);
            $this->sendSuccess([
                'booking_id' => (int)$bookingId,
                'booking_number' => $bookingNumber,
                'total_amount' => (float)$totalAmount
            ], 'Booking created successfully');
        } else {
            @file_put_contents(__DIR__ . '/../logs/error.log', "[".date('Y-m-d H:i:s')."] ERROR [BOOKING] [CREATE] - Unknown failure executing insert\n", FILE_APPEND);
            $this->sendError('Failed to create booking', 500);
        }
    }
    
    private function insertBookingItems($bookingId, $items) {
        $stmt = $this->db->prepare("
            INSERT INTO booking_items (booking_id, menu_item_id, item_name, quantity, price, total_price)
            VALUES (?, ?, ?, ?, ?, ?)
        ");
        
        foreach ($items as $item) {
            $stmt->execute([
                $bookingId,
                $item['menu_item_id'] ?? null,
                $item['item_name'],
                $item['quantity'],
                $item['price'],
                $item['quantity'] * $item['price']
            ]);
        }
    }
    
    private function updateBooking($data) {
        if (!isset($data['booking_id'])) {
            $this->sendError('Booking ID is required', 400);
            return;
        }
        
        $bookingId = $data['booking_id'];
        $updateFields = [];
        $values = [];
        
        $allowedFields = [
            'pickup_address', 'delivery_address', 'special_instructions', 
            'priority', 'estimated_delivery_time'
        ];
        
        foreach ($allowedFields as $field) {
            if (isset($data[$field])) {
                $updateFields[] = "{$field} = ?";
                $values[] = $data[$field];
            }
        }
        
        if (empty($updateFields)) {
            $this->sendError('No fields to update', 400);
            return;
        }
        
        $updateFields[] = "updated_at = ?";
        $values[] = date('Y-m-d H:i:s');
        $values[] = $bookingId;
        
        $query = "UPDATE bookings SET " . implode(', ', $updateFields) . " WHERE id = ?";
        $stmt = $this->db->prepare($query);
        
        if ($stmt->execute($values)) {
            $this->sendSuccess([], 'Booking updated successfully');
        } else {
            $this->sendError('Failed to update booking', 500);
        }
    }
    
    private function updateBookingStatus($data) {
        if (!isset($data['booking_id']) || !isset($data['status'])) {
            $this->sendError('Booking ID and status are required', 400);
            return;
        }
        
        $bookingId = $data['booking_id'];
        $status = $data['status'];
        $allowedStatuses = ['pending', 'assigned', 'picked_up', 'in_transit', 'delivered', 'completed', 'cancelled'];
        
        if (!in_array($status, $allowedStatuses)) {
            $this->sendError('Invalid status', 400);
            return;
        }
        
        $updateFields = ['status = ?', 'updated_at = ?'];
        $params = [$status, date('Y-m-d H:i:s')];
        
        // Add timestamp fields based on status
        switch ($status) {
            case 'assigned':
                $updateFields[] = 'assigned_at = ?';
                $params[] = date('Y-m-d H:i:s');
                break;
            case 'picked_up':
                $updateFields[] = 'picked_up_at = ?';
                $params[] = date('Y-m-d H:i:s');
                break;
            case 'delivered':
                $updateFields[] = 'delivered_at = ?';
                $params[] = date('Y-m-d H:i:s');
                break;
            case 'completed':
                $updateFields[] = 'completed_at = ?';
                $params[] = date('Y-m-d H:i:s');
                if (isset($data['rating'])) {
                    $updateFields[] = 'rating = ?';
                    $params[] = $data['rating'];
                }
                break;
            case 'cancelled':
                $updateFields[] = 'cancelled_at = ?';
                $params[] = date('Y-m-d H:i:s');
                break;
        }
        
        $params[] = $bookingId;
        
        $query = "UPDATE bookings SET " . implode(', ', $updateFields) . " WHERE id = ?";
        $stmt = $this->db->prepare($query);
        
        if ($stmt->execute($params)) {
            $this->sendSuccess([], 'Booking status updated successfully');
        } else {
            $this->sendError('Failed to update booking status', 500);
        }
    }
    
    private function assignRider($data) {
        if (!isset($data['booking_id']) || !isset($data['rider_id'])) {
            $this->sendError('Booking ID and Rider ID are required', 400);
            return;
        }
        
        $bookingId = $data['booking_id'];
        $riderId = $data['rider_id'];
        
        // Check if booking exists and is pending
        $checkStmt = $this->db->prepare("SELECT * FROM bookings WHERE id = ? AND status = 'pending'");
        $checkStmt->execute([$bookingId]);
        $booking = $checkStmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$booking) {
            $this->sendError('Booking not found or not available for assignment', 404);
            return;
        }
        
        // Check if rider exists and is available
        $riderStmt = $this->db->prepare("SELECT * FROM riders WHERE id = ? AND status = 'active' AND is_available = 1");
        $riderStmt->execute([$riderId]);
        $rider = $riderStmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$rider) {
            $this->sendError('Rider not found or not available', 404);
            return;
        }
        
        // Assign rider to booking
        $updateStmt = $this->db->prepare("
            UPDATE bookings 
            SET rider_id = ?, status = 'assigned', assigned_at = ?, updated_at = ?
            WHERE id = ?
        ");
        
        $now = date('Y-m-d H:i:s');
        if ($updateStmt->execute([$riderId, $now, $now, $bookingId])) {
            // Update rider status
            $riderUpdateStmt = $this->db->prepare("UPDATE riders SET status = 'busy', updated_at = ? WHERE id = ?");
            $riderUpdateStmt->execute([$now, $riderId]);
            
            $this->sendSuccess([], 'Rider assigned successfully');
        } else {
            $this->sendError('Failed to assign rider', 500);
        }
    }
    
    private function cancelBooking() {
        $bookingId = $_GET['booking_id'] ?? '';
        $reason = $_GET['reason'] ?? 'Cancelled by admin';
        
        if (empty($bookingId)) {
            $this->sendError('Booking ID is required', 400);
            return;
        }
        
        $stmt = $this->db->prepare("\n            UPDATE bookings \n            SET status = 'cancelled', cancelled_at = ?, updated_at = ?\n            WHERE id = ? AND status NOT IN ('completed', 'cancelled')\n        ");
        
        $now = date('Y-m-d H:i:s');
        if ($stmt->execute([$now, $now, $bookingId])) {
            $affectedRows = $stmt->rowCount();
            if ($affectedRows > 0) {
                $this->sendSuccess([], 'Booking cancelled successfully');
            } else {
                $this->sendError('Booking not found or cannot be cancelled', 404);
            }
        } else {
            $this->sendError('Failed to cancel booking', 500);
        }
    }
    
    private function bulkAction($data) {
        if (!isset($data['action']) || !isset($data['booking_ids'])) {
            $this->sendError('Action and booking IDs are required', 400);
            return;
        }
        
        $action = $data['action'];
        $bookingIds = $data['booking_ids'];
        
        if (empty($bookingIds)) {
            $this->sendError('No bookings selected', 400);
            return;
        }
        
        $placeholders = str_repeat('?,', count($bookingIds) - 1) . '?';
        $now = date('Y-m-d H:i:s');
        
        switch ($action) {
            case 'cancel':
                $query = "UPDATE bookings SET status = 'cancelled', cancelled_at = ?, updated_at = ? WHERE id IN ({$placeholders}) AND status NOT IN ('completed', 'cancelled')";
                $params = array_merge([$now, $now], $bookingIds);
                break;
            case 'mark_completed':
                $query = "UPDATE bookings SET status = 'completed', completed_at = ?, updated_at = ? WHERE id IN ({$placeholders})";
                $params = array_merge([$now, $now], $bookingIds);
                break;
            default:
                $this->sendError('Invalid bulk action', 400);
                return;
        }
        
        $stmt = $this->db->prepare($query);
        if ($stmt->execute($params)) {
            $affectedRows = $stmt->rowCount();
            $this->sendSuccess(['affected_rows' => $affectedRows], "Bulk action completed on {$affectedRows} bookings");
        } else {
            $this->sendError('Failed to perform bulk action', 500);
        }
    }
    
    private function exportBookings() {
        $format = $_GET['format'] ?? 'csv';
        $status = $_GET['status'] ?? '';
        $dateFrom = $_GET['date_from'] ?? '';
        $dateTo = $_GET['date_to'] ?? '';
        
        $whereConditions = [];
        $params = [];
        
        if (!empty($status)) {
            $whereConditions[] = "b.status = ?";
            $params[] = $status;
        }
        
        if (!empty($dateFrom)) {
            $whereConditions[] = "DATE(b.created_at) >= ?";
            $params[] = $dateFrom;
        }
        
        if (!empty($dateTo)) {
            $whereConditions[] = "DATE(b.created_at) <= ?";
            $params[] = $dateTo;
        }
        
        $whereClause = !empty($whereConditions) ? 'WHERE ' . implode(' AND ', $whereConditions) : '';
        
        $query = "
            SELECT b.id, b.status, b.total_amount, b.delivery_fee, b.created_at,
                   c.full_name as customer_name, c.phone as customer_phone,
                   m.name as merchant_name,
                   u.full_name as rider_name
            FROM bookings b
            LEFT JOIN customers c ON b.customer_id = c.id
            LEFT JOIN merchants m ON b.merchant_id = m.id
            LEFT JOIN riders r ON b.rider_id = r.id
            LEFT JOIN users u ON r.user_id = u.id
            {$whereClause}
            ORDER BY b.created_at DESC
        ";
        
        $stmt = $this->db->prepare($query);
        $stmt->execute($params);
        $bookings = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        if ($format === 'csv') {
            header('Content-Type: text/csv');
            header('Content-Disposition: attachment; filename="bookings_' . date('Y-m-d') . '.csv"');
            
            $output = fopen('php://output', 'w');
            
            // CSV headers
            fputcsv($output, ['ID', 'Status', 'Customer', 'Customer Phone', 'Merchant', 'Rider', 'Total Amount', 'Delivery Fee', 'Created At']);
            
            foreach ($bookings as $booking) {
                fputcsv($output, [
                    $booking['id'],
                    $booking['status'],
                    $booking['customer_name'],
                    $booking['customer_phone'],
                    $booking['merchant_name'],
                    $booking['rider_name'],
                    $booking['total_amount'],
                    $booking['delivery_fee'],
                    $booking['created_at']
                ]);
            }
            
            fclose($output);
        } else {
            $this->sendSuccess(['bookings' => $bookings]);
        }
    }
    
    private function sendSuccess($data = [], $message = 'Success') {
        echo json_encode([
            'success' => true,
            'message' => $message,
            'data' => $data
        ]);
    }
    
    private function sendError($message, $code = 400) {
        http_response_code($code);
        echo json_encode([
            'success' => false,
            'message' => $message,
            'error_code' => $code
        ]);
    }
}

$api = new BookingsAPI();
$api->handleRequest();
?>
