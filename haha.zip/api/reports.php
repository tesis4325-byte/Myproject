<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

require_once '../config/Database.php';

class ReportsAPI {
    private $db;
    
    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }

    // Map admin GET calls like action=generate&category=sales&type=daily_sales&date_range=this_month
    private function generateReportFromGet() {
        $category = $_GET['category'] ?? 'sales';
        $type = $_GET['type'] ?? '';
        $dateRange = $_GET['date_range'] ?? 'this_month';
        $startDate = $_GET['start_date'] ?? null;
        $endDate = $_GET['end_date'] ?? null;

        [$from, $to, $prevFrom, $prevTo] = $this->resolveDateRange($dateRange, $startDate, $endDate);

        switch ($category) {
            case 'sales':
                $this->sendSuccess($this->buildSalesSummary($from, $to, $prevFrom, $prevTo));
                return;
            case 'financial':
                // Minimal placeholder aligned fields to avoid UI break
                $this->sendSuccess(['stats' => [
                    'total_payouts' => 0,
                    'total_commissions' => 0,
                    'pending_payouts' => 0,
                    'profit_margin' => 0
                ]]);
                return;
            case 'performance':
                $this->sendSuccess(['stats' => [
                    'avg_delivery_time' => 0,
                    'success_rate' => 0,
                    'avg_rating' => 0,
                    'active_riders' => 0
                ]]);
                return;
            case 'customer':
                $this->sendSuccess(['stats' => [
                    'total_customers' => 0,
                    'new_customers' => 0,
                    'repeat_rate' => 0,
                    'satisfaction_score' => 0
                ]]);
                return;
            default:
                $this->sendError('Unsupported report category', 400);
        }
    }

    private function exportReportFromGet() {
        $format = $_GET['format'] ?? 'csv';
        $category = $_GET['category'] ?? 'sales';
        $filename = $category . '_report_' . date('Y-m-d') . '.' . $format;
        $this->sendSuccess([
            'download_url' => '/downloads/' . $filename,
            'filename' => $filename,
            'format' => $format
        ], 'Report generated successfully');
    }

    private function resolveDateRange($dateRange, $startDate = null, $endDate = null) {
        $today = new DateTime('today');
        $from = clone $today; $to = clone $today;
        switch ($dateRange) {
            case 'today':
                // already set to today
                break;
            case 'yesterday':
                $from->modify('-1 day');
                $to->modify('-1 day');
                break;
            case 'this_week':
                $from->modify('monday this week');
                break;
            case 'last_week':
                $from->modify('monday last week');
                $to->modify('sunday last week');
                break;
            case 'this_month':
                $from = new DateTime(date('Y-m-01'));
                break;
            case 'last_month':
                $from = new DateTime(date('Y-m-01', strtotime('first day of last month')));
                $to = new DateTime(date('Y-m-t', strtotime('last day of last month')));
                break;
            case 'this_year':
                $from = new DateTime(date('Y-01-01'));
                break;
            case 'custom':
                if ($startDate) $from = new DateTime($startDate);
                if ($endDate) $to = new DateTime($endDate);
                break;
            default:
                // Fallback: last 30 days
                $from = new DateTime(date('Y-m-d', strtotime('-30 days')));
                $to = new DateTime(date('Y-m-d'));
        }
        $fromStr = $from->format('Y-m-d');
        $toStr = $to->format('Y-m-d');

        // Previous period for growth
        $fromDiff = (new DateTime($fromStr))->diff(new DateTime($toStr))->days + 1;
        $prevTo = (new DateTime($fromStr))->modify('-1 day');
        $prevFrom = (clone $prevTo)->modify('-' . ($fromDiff - 1) . ' days');
        return [$fromStr, $toStr, $prevFrom->format('Y-m-d'), $prevTo->format('Y-m-d')];
    }

    private function buildSalesSummary($from, $to, $prevFrom, $prevTo) {
        // Current period
        $summaryQuery = "
            SELECT 
                COUNT(*) as total_orders,
                COUNT(CASE WHEN status = 'delivered' THEN 1 END) as completed_orders,
                COALESCE(SUM(CASE WHEN status = 'delivered' THEN total_amount ELSE 0 END), 0) as total_revenue,
                COALESCE(AVG(CASE WHEN status = 'delivered' THEN total_amount END), 0) as avg_order_value
            FROM bookings
            WHERE DATE(created_at) BETWEEN ? AND ?
        ";
        $stmt = $this->db->prepare($summaryQuery);
        $stmt->execute([$from, $to]);
        $current = $stmt->fetch(PDO::FETCH_ASSOC) ?: [
            'total_orders' => 0,
            'completed_orders' => 0,
            'total_revenue' => 0,
            'avg_order_value' => 0,
        ];

        // Previous period revenue
        $prevQuery = "
            SELECT COALESCE(SUM(CASE WHEN status = 'delivered' THEN total_amount ELSE 0 END), 0) as total_revenue
            FROM bookings WHERE DATE(created_at) BETWEEN ? AND ?
        ";
        $pstmt = $this->db->prepare($prevQuery);
        $pstmt->execute([$prevFrom, $prevTo]);
        $prev = $pstmt->fetch(PDO::FETCH_ASSOC);
        $prevRevenue = (float)($prev['total_revenue'] ?? 0);
        $currRevenue = (float)($current['total_revenue'] ?? 0);
        $growthRate = $prevRevenue > 0 ? round((($currRevenue - $prevRevenue) / $prevRevenue) * 100, 2) : 0.0;

        // Top merchants by revenue
        $topQuery = "
            SELECT m.name as name,
                   COUNT(b.id) as orders,
                   COALESCE(SUM(CASE WHEN b.status = 'delivered' THEN b.total_amount ELSE 0 END), 0) as revenue
            FROM merchants m
            LEFT JOIN bookings b ON m.id = b.merchant_id AND DATE(b.created_at) BETWEEN ? AND ?
            GROUP BY m.id
            ORDER BY revenue DESC
            LIMIT 5
        ";
        $tstmt = $this->db->prepare($topQuery);
        $tstmt->execute([$from, $to]);
        $top = $tstmt->fetchAll(PDO::FETCH_ASSOC);
        // Add growth placeholder per merchant (0)
        $top = array_map(function($row){ $row['growth'] = 0; return $row; }, $top);

        return [
            'stats' => [
                'total_orders' => (int)$current['total_orders'],
                'avg_order_value' => (float)$current['avg_order_value'],
                'total_revenue' => (float)$current['total_revenue'],
                'growth_rate' => $growthRate
            ],
            'top_merchants' => $top,
            'period' => ['from' => $from, 'to' => $to]
        ];
    }
    
    public function handleRequest() {
        $method = $_SERVER['REQUEST_METHOD'];
        $action = $_GET['action'] ?? '';
        
        try {
            switch ($method) {
                case 'GET':
                    $this->handleGet($action);
                    break;
                case 'POST':
                    $this->handlePost($action);
                    break;
                default:
                    $this->sendError('Method not allowed', 405);
            }
        } catch (Exception $e) {
            $this->sendError($e->getMessage(), 500);
        }
    }
    
    private function handleGet($action) {
        switch ($action) {
            case 'generate':
                $this->generateReportFromGet();
                break;
            case 'export':
                $this->exportReportFromGet();
                break;
            case 'dashboard_overview':
                $this->getDashboardOverview();
                break;
            case 'sales_report':
                $this->getSalesReport();
                break;
            case 'delivery_report':
                $this->getDeliveryReport();
                break;
            case 'rider_performance':
                $this->getRiderPerformance();
                break;
            case 'merchant_performance':
                $this->getMerchantPerformance();
                break;
            case 'customer_analytics':
                $this->getCustomerAnalytics();
                break;
            case 'revenue_trends':
                $this->getRevenueTrends();
                break;
            case 'order_trends':
                $this->getOrderTrends();
                break;
            case 'top_performers':
                $this->getTopPerformers();
                break;
            case 'geographic_data':
                $this->getGeographicData();
                break;
            case 'popular_items':
                $this->getPopularItemsReport();
                break;
            case 'complaints_summary':
                $this->getComplaintsSummary();
                break;
            case 'financial_summary':
                $this->getFinancialSummary();
                break;
            default:
                $this->sendError('Invalid action', 400);
        }
    }
    
    private function handlePost($action) {
        $input = json_decode(file_get_contents('php://input'), true);
        
        switch ($action) {
            case 'generate_custom_report':
                $this->generateCustomReport($input);
                break;
            case 'export_report':
                $this->exportReport($input);
                break;
            default:
                $this->sendError('Invalid action', 400);
        }
    }
    
    private function getDashboardOverview() {
        $dateFrom = $_GET['date_from'] ?? date('Y-m-d', strtotime('-30 days'));
        $dateTo = $_GET['date_to'] ?? date('Y-m-d');
        
        // Overall stats
        $overviewQuery = "
            SELECT 
                COUNT(DISTINCT b.id) as total_orders,
                COUNT(DISTINCT CASE WHEN b.status = 'delivered' THEN b.id END) as completed_orders,
                COUNT(DISTINCT b.customer_id) as active_customers,
                COUNT(DISTINCT b.rider_id) as active_riders,
                COUNT(DISTINCT b.merchant_id) as active_merchants,
                COALESCE(SUM(CASE WHEN b.status = 'delivered' THEN b.total_amount ELSE 0 END), 0) as total_revenue,
                COALESCE(AVG(CASE WHEN b.status = 'delivered' THEN b.rider_rating END), 0) as avg_rating,
                COALESCE(AVG(CASE WHEN b.status = 'delivered' AND b.picked_up_at IS NOT NULL AND b.delivered_at IS NOT NULL THEN TIMESTAMPDIFF(MINUTE, b.picked_up_at, b.delivered_at) END), 0) as avg_delivery_time
            FROM bookings b
            WHERE DATE(b.created_at) BETWEEN ? AND ?
        ";
        
        $stmt = $this->db->prepare($overviewQuery);
        $stmt->execute([$dateFrom, $dateTo]);
        $overview = $stmt->fetch(PDO::FETCH_ASSOC);

        // New customers within period
        try {
            $ncStmt = $this->db->prepare("SELECT COUNT(*) AS new_customers FROM customers WHERE DATE(created_at) BETWEEN ? AND ?");
            $ncStmt->execute([$dateFrom, $dateTo]);
            $nc = $ncStmt->fetch(PDO::FETCH_ASSOC);
            $overview['new_customers'] = (int)($nc['new_customers'] ?? 0);
        } catch (Exception $e) {
            $overview['new_customers'] = 0;
        }

        // Online riders now
        try {
            $orow = $this->db->query("SELECT COUNT(*) AS online_riders FROM riders WHERE is_online = 1")->fetch(PDO::FETCH_ASSOC);
            $overview['online_riders'] = (int)($orow['online_riders'] ?? 0);
        } catch (Exception $e) {
            $overview['online_riders'] = (int)($overview['active_riders'] ?? 0);
        }

        // Compute growth vs. previous equal-length period
        try {
            $fromDt = new DateTime($dateFrom);
            $toDt = new DateTime($dateTo);
            $days = $fromDt->diff($toDt)->days + 1; // inclusive
            $prevTo = (clone $fromDt)->modify('-1 day');
            $prevFrom = (clone $prevTo)->modify('-' . ($days - 1) . ' days');

            // Previous totals
            $prevQuery = "
                SELECT 
                    COUNT(*) AS total_orders,
                    COALESCE(SUM(CASE WHEN status = 'delivered' THEN total_amount ELSE 0 END), 0) AS total_revenue
                FROM bookings
                WHERE DATE(created_at) BETWEEN ? AND ?
            ";
            $pstmt = $this->db->prepare($prevQuery);
            $pstmt->execute([$prevFrom->format('Y-m-d'), $prevTo->format('Y-m-d')]);
            $prev = $pstmt->fetch(PDO::FETCH_ASSOC) ?: ['total_orders' => 0, 'total_revenue' => 0];

            $currOrders = (int)($overview['total_orders'] ?? 0);
            $prevOrders = (int)($prev['total_orders'] ?? 0);
            $currRevenue = (float)($overview['total_revenue'] ?? 0);
            $prevRevenue = (float)($prev['total_revenue'] ?? 0);

            $overview['orders_growth_rate'] = $prevOrders > 0 ? round((($currOrders - $prevOrders) / $prevOrders) * 100, 2) : 0.0;
            $overview['revenue_growth_rate'] = $prevRevenue > 0 ? round((($currRevenue - $prevRevenue) / $prevRevenue) * 100, 2) : 0.0;
        } catch (Exception $e) {
            $overview['orders_growth_rate'] = 0.0;
            $overview['revenue_growth_rate'] = 0.0;
        }
        
        // Daily trends for the period
        $trendsQuery = "
            SELECT 
                DATE(created_at) as date,
                COUNT(*) as orders,
                COUNT(CASE WHEN status = 'delivered' THEN 1 END) as completed,
                COALESCE(SUM(CASE WHEN status = 'delivered' THEN total_amount ELSE 0 END), 0) as revenue
            FROM bookings
            WHERE DATE(created_at) BETWEEN ? AND ?
            GROUP BY DATE(created_at)
            ORDER BY date ASC
        ";
        
        $trendsStmt = $this->db->prepare($trendsQuery);
        $trendsStmt->execute([$dateFrom, $dateTo]);
        $trends = $trendsStmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Top performing metrics
        $topMetricsQuery = "
            SELECT 
                'merchants' as type,
                m.name as name,
                COUNT(b.id) as orders,
                COALESCE(SUM(CASE WHEN b.status = 'delivered' THEN b.total_amount ELSE 0 END), 0) as revenue
            FROM merchants m
            LEFT JOIN bookings b ON m.id = b.merchant_id AND DATE(b.created_at) BETWEEN ? AND ?
            GROUP BY m.id
            ORDER BY revenue DESC
            LIMIT 5
        ";
        
        $topStmt = $this->db->prepare($topMetricsQuery);
        $topStmt->execute([$dateFrom, $dateTo]);
        $topMerchants = $topStmt->fetchAll(PDO::FETCH_ASSOC);

        // Service distribution within the selected period
        $serviceDistQuery = "
            SELECT 
                type AS service_type,
                COUNT(*) AS orders,
                COALESCE(SUM(CASE WHEN status = 'delivered' THEN total_amount ELSE 0 END), 0) AS revenue
            FROM bookings
            WHERE DATE(created_at) BETWEEN ? AND ?
            GROUP BY type
        ";
        $svcStmt = $this->db->prepare($serviceDistQuery);
        $svcStmt->execute([$dateFrom, $dateTo]);
        $serviceDistribution = $svcStmt->fetchAll(PDO::FETCH_ASSOC);

        // Recent orders (latest 8)
        $recentQuery = "
            SELECT 
                id,
                booking_number,
                customer_name,
                type AS service_type,
                total_amount,
                status,
                created_at
            FROM bookings
            ORDER BY created_at DESC
            LIMIT 8
        ";
        $recentStmt = $this->db->prepare($recentQuery);
        $recentStmt->execute();
        $recentOrders = $recentStmt->fetchAll(PDO::FETCH_ASSOC);

        // Counts for quick actions
        $pendingOrders = 0;
        $openComplaints = 0;
        try {
            $pendingRow = $this->db->query("SELECT COUNT(*) AS cnt FROM bookings WHERE status = 'pending'")->fetch(PDO::FETCH_ASSOC);
            $pendingOrders = (int)($pendingRow['cnt'] ?? 0);
        } catch (Exception $e) { /* ignore */ }
        try {
            $complaintsRow = $this->db->query("SELECT COUNT(*) AS cnt FROM complaints WHERE status IN ('pending','investigating')")->fetch(PDO::FETCH_ASSOC);
            $openComplaints = (int)($complaintsRow['cnt'] ?? 0);
        } catch (Exception $e) { /* ignore */ }
        
        $this->sendSuccess([
            'overview' => $overview,
            'trends' => $trends,
            'top_merchants' => $topMerchants,
            'service_distribution' => $serviceDistribution,
            'recent_orders' => $recentOrders,
            'pending_orders' => $pendingOrders,
            'open_complaints' => $openComplaints,
            'period' => ['from' => $dateFrom, 'to' => $dateTo]
        ]);
    }
    
    private function getSalesReport() {
        $dateFrom = $_GET['date_from'] ?? date('Y-m-d', strtotime('-30 days'));
        $dateTo = $_GET['date_to'] ?? date('Y-m-d');
        $groupBy = $_GET['group_by'] ?? 'day'; // day, week, month
        
        $dateFormat = match($groupBy) {
            'week' => "DATE_FORMAT(created_at, '%Y-%u')",
            'month' => "DATE_FORMAT(created_at, '%Y-%m')",
            default => "DATE(created_at)"
        };
        
        $salesQuery = "
            SELECT 
                {$dateFormat} as period,
                COUNT(*) as total_orders,
                COUNT(CASE WHEN status = 'completed' THEN 1 END) as completed_orders,
                COUNT(CASE WHEN status = 'cancelled' THEN 1 END) as cancelled_orders,
                COALESCE(SUM(CASE WHEN status = 'completed' THEN total_amount ELSE 0 END), 0) as revenue,
                COALESCE(SUM(CASE WHEN status = 'completed' THEN delivery_fee ELSE 0 END), 0) as delivery_fees,
                COALESCE(AVG(CASE WHEN status = 'completed' THEN total_amount END), 0) as avg_order_value
            FROM bookings
            WHERE DATE(created_at) BETWEEN ? AND ?
            GROUP BY period
            ORDER BY period ASC
        ";
        
        $stmt = $this->db->prepare($salesQuery);
        $stmt->execute([$dateFrom, $dateTo]);
        $salesData = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Sales by category
        $categoryQuery = "
            SELECT 
                mi.category,
                COUNT(bi.id) as items_sold,
                SUM(bi.quantity) as total_quantity,
                SUM(bi.total_price) as category_revenue
            FROM booking_items bi
            LEFT JOIN menu_items mi ON bi.menu_item_id = mi.id
            LEFT JOIN bookings b ON bi.booking_id = b.id
            WHERE DATE(b.created_at) BETWEEN ? AND ? AND b.status = 'completed'
            GROUP BY mi.category
            ORDER BY category_revenue DESC
        ";
        
        $categoryStmt = $this->db->prepare($categoryQuery);
        $categoryStmt->execute([$dateFrom, $dateTo]);
        $categoryData = $categoryStmt->fetchAll(PDO::FETCH_ASSOC);
        
        $this->sendSuccess([
            'sales_data' => $salesData,
            'category_data' => $categoryData,
            'period' => ['from' => $dateFrom, 'to' => $dateTo],
            'group_by' => $groupBy
        ]);
    }
    
    private function getDeliveryReport() {
        $dateFrom = $_GET['date_from'] ?? date('Y-m-d', strtotime('-30 days'));
        $dateTo = $_GET['date_to'] ?? date('Y-m-d');
        
        $deliveryQuery = "
            SELECT 
                COUNT(*) as total_deliveries,
                COUNT(CASE WHEN status = 'completed' THEN 1 END) as completed_deliveries,
                COUNT(CASE WHEN status = 'cancelled' THEN 1 END) as cancelled_deliveries,
                COALESCE(AVG(CASE WHEN status = 'completed' THEN delivery_time END), 0) as avg_delivery_time,
                COALESCE(AVG(CASE WHEN status = 'completed' THEN delivery_distance END), 0) as avg_delivery_distance,
                COALESCE(AVG(CASE WHEN status = 'completed' THEN rating END), 0) as avg_rating
            FROM bookings
            WHERE DATE(created_at) BETWEEN ? AND ?
        ";
        
        $stmt = $this->db->prepare($deliveryQuery);
        $stmt->execute([$dateFrom, $dateTo]);
        $deliveryStats = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // Delivery time distribution
        $timeDistributionQuery = "
            SELECT 
                CASE 
                    WHEN delivery_time <= 30 THEN '0-30 min'
                    WHEN delivery_time <= 60 THEN '31-60 min'
                    WHEN delivery_time <= 90 THEN '61-90 min'
                    ELSE '90+ min'
                END as time_range,
                COUNT(*) as count
            FROM bookings
            WHERE DATE(created_at) BETWEEN ? AND ? AND status = 'completed' AND delivery_time IS NOT NULL
            GROUP BY time_range
            ORDER BY MIN(delivery_time)
        ";
        
        $timeStmt = $this->db->prepare($timeDistributionQuery);
        $timeStmt->execute([$dateFrom, $dateTo]);
        $timeDistribution = $timeStmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Peak hours analysis
        $peakHoursQuery = "
            SELECT 
                HOUR(created_at) as hour,
                COUNT(*) as orders
            FROM bookings
            WHERE DATE(created_at) BETWEEN ? AND ?
            GROUP BY HOUR(created_at)
            ORDER BY hour
        ";
        
        $peakStmt = $this->db->prepare($peakHoursQuery);
        $peakStmt->execute([$dateFrom, $dateTo]);
        $peakHours = $peakStmt->fetchAll(PDO::FETCH_ASSOC);
        
        $this->sendSuccess([
            'delivery_stats' => $deliveryStats,
            'time_distribution' => $timeDistribution,
            'peak_hours' => $peakHours,
            'period' => ['from' => $dateFrom, 'to' => $dateTo]
        ]);
    }
    
    private function getRiderPerformance() {
        $dateFrom = $_GET['date_from'] ?? date('Y-m-d', strtotime('-30 days'));
        $dateTo = $_GET['date_to'] ?? date('Y-m-d');
        $limit = (int)($_GET['limit'] ?? 20);
        
        $riderQuery = "
            SELECT 
                r.id, r.name, r.phone, r.vehicle_type,
                COUNT(b.id) as total_deliveries,
                COUNT(CASE WHEN b.status = 'completed' THEN 1 END) as completed_deliveries,
                COALESCE(SUM(CASE WHEN b.status = 'completed' THEN b.delivery_fee ELSE 0 END), 0) as total_earnings,
                COALESCE(AVG(CASE WHEN b.status = 'completed' THEN b.rating END), 0) as avg_rating,
                COALESCE(AVG(CASE WHEN b.status = 'completed' THEN b.delivery_time END), 0) as avg_delivery_time,
                COALESCE(SUM(CASE WHEN b.status = 'completed' THEN b.delivery_distance ELSE 0 END), 0) as total_distance
            FROM riders r
            LEFT JOIN bookings b ON r.id = b.rider_id AND DATE(b.created_at) BETWEEN ? AND ?
            GROUP BY r.id
            ORDER BY completed_deliveries DESC, avg_rating DESC
            LIMIT {$limit}
        ";
        
        $stmt = $this->db->prepare($riderQuery);
        $stmt->execute([$dateFrom, $dateTo]);
        $riderPerformance = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $this->sendSuccess([
            'rider_performance' => $riderPerformance,
            'period' => ['from' => $dateFrom, 'to' => $dateTo]
        ]);
    }
    
    private function getMerchantPerformance() {
        $dateFrom = $_GET['date_from'] ?? date('Y-m-d', strtotime('-30 days'));
        $dateTo = $_GET['date_to'] ?? date('Y-m-d');
        $limit = (int)($_GET['limit'] ?? 20);
        
        $merchantQuery = "
            SELECT 
                m.id, m.name, m.category, m.phone,
                COUNT(b.id) as total_orders,
                COUNT(CASE WHEN b.status = 'completed' THEN 1 END) as completed_orders,
                COALESCE(SUM(CASE WHEN b.status = 'completed' THEN b.total_amount ELSE 0 END), 0) as total_revenue,
                COALESCE(AVG(CASE WHEN b.status = 'completed' THEN b.rating END), 0) as avg_rating,
                COALESCE(AVG(CASE WHEN b.status = 'completed' THEN b.total_amount END), 0) as avg_order_value,
                COUNT(DISTINCT b.customer_id) as unique_customers
            FROM merchants m
            LEFT JOIN bookings b ON m.id = b.merchant_id AND DATE(b.created_at) BETWEEN ? AND ?
            GROUP BY m.id
            ORDER BY total_revenue DESC, completed_orders DESC
            LIMIT {$limit}
        ";
        
        $stmt = $this->db->prepare($merchantQuery);
        $stmt->execute([$dateFrom, $dateTo]);
        $merchantPerformance = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $this->sendSuccess([
            'merchant_performance' => $merchantPerformance,
            'period' => ['from' => $dateFrom, 'to' => $dateTo]
        ]);
    }
    
    private function getCustomerAnalytics() {
        $dateFrom = $_GET['date_from'] ?? date('Y-m-d', strtotime('-30 days'));
        $dateTo = $_GET['date_to'] ?? date('Y-m-d');
        
        $customerQuery = "
            SELECT 
                COUNT(DISTINCT c.id) as total_customers,
                COUNT(DISTINCT CASE WHEN b.id IS NOT NULL THEN c.id END) as active_customers,
                COUNT(DISTINCT CASE WHEN DATE(c.created_at) BETWEEN ? AND ? THEN c.id END) as new_customers,
                COALESCE(AVG(customer_stats.order_count), 0) as avg_orders_per_customer,
                COALESCE(AVG(customer_stats.total_spent), 0) as avg_spent_per_customer
            FROM customers c
            LEFT JOIN bookings b ON c.id = b.customer_id AND DATE(b.created_at) BETWEEN ? AND ?
            LEFT JOIN (
                SELECT 
                    customer_id,
                    COUNT(*) as order_count,
                    SUM(CASE WHEN status = 'completed' THEN total_amount ELSE 0 END) as total_spent
                FROM bookings 
                WHERE DATE(created_at) BETWEEN ? AND ?
                GROUP BY customer_id
            ) customer_stats ON c.id = customer_stats.customer_id
        ";
        
        $stmt = $this->db->prepare($customerQuery);
        $stmt->execute([$dateFrom, $dateTo, $dateFrom, $dateTo, $dateFrom, $dateTo]);
        $customerAnalytics = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // Customer segmentation
        $segmentationQuery = "
            SELECT 
                CASE 
                    WHEN customer_stats.order_count >= 10 THEN 'Frequent'
                    WHEN customer_stats.order_count >= 5 THEN 'Regular'
                    WHEN customer_stats.order_count >= 2 THEN 'Occasional'
                    ELSE 'New'
                END as segment,
                COUNT(*) as customer_count,
                AVG(customer_stats.total_spent) as avg_spent
            FROM (
                SELECT 
                    customer_id,
                    COUNT(*) as order_count,
                    SUM(CASE WHEN status = 'completed' THEN total_amount ELSE 0 END) as total_spent
                FROM bookings 
                WHERE DATE(created_at) BETWEEN ? AND ?
                GROUP BY customer_id
            ) customer_stats
            GROUP BY segment
            ORDER BY avg_spent DESC
        ";
        
        $segmentStmt = $this->db->prepare($segmentationQuery);
        $segmentStmt->execute([$dateFrom, $dateTo]);
        $segmentation = $segmentStmt->fetchAll(PDO::FETCH_ASSOC);
        
        $this->sendSuccess([
            'customer_analytics' => $customerAnalytics,
            'segmentation' => $segmentation,
            'period' => ['from' => $dateFrom, 'to' => $dateTo]
        ]);
    }
    
    private function getRevenueTrends() {
        $dateFrom = $_GET['date_from'] ?? date('Y-m-d', strtotime('-90 days'));
        $dateTo = $_GET['date_to'] ?? date('Y-m-d');
        $groupBy = $_GET['group_by'] ?? 'day';
        
        $dateFormat = match($groupBy) {
            'week' => "YEARWEEK(created_at)",
            'month' => "DATE_FORMAT(created_at, '%Y-%m')",
            default => "DATE(created_at)"
        };
        
        $revenueQuery = "
            SELECT 
                {$dateFormat} as period,
                COALESCE(SUM(CASE WHEN status = 'delivered' THEN total_amount ELSE 0 END), 0) as total_revenue,
                COALESCE(SUM(CASE WHEN status = 'delivered' THEN delivery_fee ELSE 0 END), 0) as delivery_revenue,
                COUNT(CASE WHEN status = 'delivered' THEN 1 END) as completed_orders,
                COALESCE(AVG(CASE WHEN status = 'delivered' THEN total_amount END), 0) as avg_order_value
            FROM bookings
            WHERE DATE(created_at) BETWEEN ? AND ?
            GROUP BY period
            ORDER BY period ASC
        ";
        
        $stmt = $this->db->prepare($revenueQuery);
        $stmt->execute([$dateFrom, $dateTo]);
        $revenueTrends = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $this->sendSuccess([
            'revenue_trends' => $revenueTrends,
            'period' => ['from' => $dateFrom, 'to' => $dateTo],
            'group_by' => $groupBy
        ]);
    }
    
    private function getOrderTrends() {
        $dateFrom = $_GET['date_from'] ?? date('Y-m-d', strtotime('-30 days'));
        $dateTo = $_GET['date_to'] ?? date('Y-m-d');
        
        $orderTrendsQuery = "
            SELECT 
                DATE(created_at) as date,
                COUNT(*) as total_orders,
                COUNT(CASE WHEN status = 'delivered' THEN 1 END) as completed,
                COUNT(CASE WHEN status = 'cancelled' THEN 1 END) as cancelled,
                COUNT(CASE WHEN status = 'pending' THEN 1 END) as pending
            FROM bookings
            WHERE DATE(created_at) BETWEEN ? AND ?
            GROUP BY DATE(created_at)
            ORDER BY date ASC
        ";
        
        $stmt = $this->db->prepare($orderTrendsQuery);
        $stmt->execute([$dateFrom, $dateTo]);
        $orderTrends = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $this->sendSuccess([
            'order_trends' => $orderTrends,
            'period' => ['from' => $dateFrom, 'to' => $dateTo]
        ]);
    }

    private function getTopPerformers() {
        try {
            $type = $_GET['type'] ?? 'riders'; // riders | merchants | customers
            $dateFrom = $_GET['date_from'] ?? date('Y-m-d', strtotime('-30 days'));
            $dateTo = $_GET['date_to'] ?? date('Y-m-d');
            $limit = (int)($_GET['limit'] ?? 5);

            if ($limit < 1) { $limit = 5; }
            if ($limit > 50) { $limit = 50; }

            switch ($type) {
            case 'riders':
                $query = "
                    SELECT 
                        r.id,
                        u.full_name AS name,
                        u.phone AS subtitle,
                        COUNT(CASE WHEN b.status = 'delivered' THEN 1 END) AS completed_deliveries,
                        COALESCE(SUM(CASE WHEN b.status = 'delivered' THEN b.delivery_fee ELSE 0 END), 0) AS earnings,
                        COUNT(CASE WHEN b.status = 'delivered' AND b.rider_rating IS NOT NULL THEN 1 END) AS ratings_count,
                        COALESCE(AVG(CASE WHEN b.status = 'delivered' AND b.rider_rating IS NOT NULL THEN b.rider_rating END), 0) AS avg_rating
                    FROM riders r
                    INNER JOIN users u ON u.id = r.user_id
                    LEFT JOIN bookings b ON r.id = b.rider_id AND DATE(b.created_at) BETWEEN ? AND ?
                    GROUP BY r.id, u.full_name, u.phone
                    ORDER BY completed_deliveries DESC, avg_rating DESC
                    LIMIT {$limit}
                ";
                $stmt = $this->db->prepare($query);
                $stmt->execute([$dateFrom, $dateTo]);
                $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
                $items = array_map(function($r){
                    return [
                        'name' => $r['name'] ?? 'Unknown',
                        'subtitle' => $r['subtitle'] ?? '',
                        'metric_label' => 'Deliveries',
                        'metric_value' => (int)($r['completed_deliveries'] ?? 0),
                        'secondary' => ((int)($r['ratings_count'] ?? 0) > 0)
                            ? ('★ ' . number_format((float)($r['avg_rating'] ?? 0), 2) . ' (' . (int)$r['ratings_count'] . ')')
                            : ''
                    ];
                }, $rows);
                break;
            case 'merchants':
                $query = "
                    SELECT 
                        m.id,
                        m.name AS name,
                        COALESCE(m.phone, '') AS subtitle,
                        COUNT(CASE WHEN b.status = 'delivered' THEN 1 END) AS orders,
                        COALESCE(SUM(CASE WHEN b.status = 'delivered' THEN b.total_amount ELSE 0 END), 0) AS revenue
                    FROM merchants m
                    LEFT JOIN bookings b ON m.id = b.merchant_id AND DATE(b.created_at) BETWEEN ? AND ?
                    GROUP BY m.id, m.name, m.phone
                    ORDER BY revenue DESC, orders DESC
                    LIMIT {$limit}
                ";
                $stmt = $this->db->prepare($query);
                $stmt->execute([$dateFrom, $dateTo]);
                $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
                $items = array_map(function($r){
                    return [
                        'name' => $r['name'] ?? 'Unknown',
                        'subtitle' => $r['subtitle'] ?? '',
                        'metric_label' => 'Revenue',
                        'metric_value' => (float)($r['revenue'] ?? 0),
                        'secondary' => (int)($r['orders'] ?? 0) . ' orders'
                    ];
                }, $rows);
                break;
            case 'customers':
                $query = "
                    SELECT 
                        c.id,
                        COALESCE(c.full_name, CONCAT('Customer #', c.id)) AS name,
                        COALESCE(NULLIF(c.email, ''), c.phone) AS subtitle,
                        COUNT(CASE WHEN b.status = 'delivered' THEN 1 END) AS orders,
                        COALESCE(SUM(CASE WHEN b.status = 'delivered' THEN b.total_amount ELSE 0 END), 0) AS total_spent
                    FROM customers c
                    LEFT JOIN bookings b ON c.id = b.customer_id AND DATE(b.created_at) BETWEEN ? AND ?
                    GROUP BY c.id, c.full_name, c.email, c.phone
                    ORDER BY total_spent DESC, orders DESC
                    LIMIT {$limit}
                ";
                $stmt = $this->db->prepare($query);
                $stmt->execute([$dateFrom, $dateTo]);
                $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
                $items = array_map(function($r){
                    return [
                        'name' => $r['name'] ?? 'Unknown',
                        'subtitle' => $r['subtitle'] ?? '',
                        'metric_label' => 'Spent',
                        'metric_value' => (float)($r['total_spent'] ?? 0),
                        'secondary' => (int)($r['orders'] ?? 0) . ' orders'
                    ];
                }, $rows);
                break;
            default:
                return $this->sendError('Unsupported type', 400);
            }

            $this->sendSuccess([
                'items' => $items,
                'period' => ['from' => $dateFrom, 'to' => $dateTo],
                'type' => $type
            ]);
        } catch (Throwable $e) {
            error_log('[TopPerformers] ' . $e->getMessage());
            return $this->sendError('Top performers query failed: ' . $e->getMessage(), 500);
        }
    }
    
    private function getGeographicData() {
        $dateFrom = $_GET['date_from'] ?? date('Y-m-d', strtotime('-30 days'));
        $dateTo = $_GET['date_to'] ?? date('Y-m-d');
        
        // Orders by city/area
        $geoQuery = "
            SELECT 
                COALESCE(m.city, 'Unknown') as city,
                COUNT(b.id) as order_count,
                COALESCE(SUM(CASE WHEN b.status = 'completed' THEN b.total_amount ELSE 0 END), 0) as revenue
            FROM bookings b
            LEFT JOIN merchants m ON b.merchant_id = m.id
            WHERE DATE(b.created_at) BETWEEN ? AND ?
            GROUP BY city
            ORDER BY order_count DESC
            LIMIT 20
        ";
        
        $stmt = $this->db->prepare($geoQuery);
        $stmt->execute([$dateFrom, $dateTo]);
        $geoData = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $this->sendSuccess([
            'geographic_data' => $geoData,
            'period' => ['from' => $dateFrom, 'to' => $dateTo]
        ]);
    }
    
    private function getPopularItemsReport() {
        $dateFrom = $_GET['date_from'] ?? date('Y-m-d', strtotime('-30 days'));
        $dateTo = $_GET['date_to'] ?? date('Y-m-d');
        $limit = (int)($_GET['limit'] ?? 20);
        
        $popularQuery = "
            SELECT 
                mi.name as item_name,
                mi.category,
                m.name as merchant_name,
                COUNT(bi.id) as order_count,
                SUM(bi.quantity) as total_quantity,
                SUM(bi.total_price) as total_revenue,
                AVG(bi.price) as avg_price
            FROM booking_items bi
            LEFT JOIN menu_items mi ON bi.menu_item_id = mi.id
            LEFT JOIN merchants m ON mi.merchant_id = m.id
            LEFT JOIN bookings b ON bi.booking_id = b.id
            WHERE DATE(b.created_at) BETWEEN ? AND ? AND b.status = 'completed'
            GROUP BY bi.menu_item_id
            ORDER BY total_quantity DESC
            LIMIT {$limit}
        ";
        
        $stmt = $this->db->prepare($popularQuery);
        $stmt->execute([$dateFrom, $dateTo]);
        $popularItems = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $this->sendSuccess([
            'popular_items' => $popularItems,
            'period' => ['from' => $dateFrom, 'to' => $dateTo]
        ]);
    }
    
    private function getComplaintsSummary() {
        $dateFrom = $_GET['date_from'] ?? date('Y-m-d', strtotime('-30 days'));
        $dateTo = $_GET['date_to'] ?? date('Y-m-d');
        
        $complaintsQuery = "
            SELECT 
                COUNT(*) as total_complaints,
                COUNT(CASE WHEN status = 'resolved' THEN 1 END) as resolved_complaints,
                COUNT(CASE WHEN status = 'pending' THEN 1 END) as pending_complaints,
                COUNT(CASE WHEN priority = 'high' THEN 1 END) as high_priority,
                AVG(CASE WHEN status = 'resolved' THEN DATEDIFF(resolved_at, created_at) END) as avg_resolution_days
            FROM complaints
            WHERE DATE(created_at) BETWEEN ? AND ?
        ";
        
        $stmt = $this->db->prepare($complaintsQuery);
        $stmt->execute([$dateFrom, $dateTo]);
        $complaintsSummary = $stmt->fetch(PDO::FETCH_ASSOC);
        
        $this->sendSuccess([
            'complaints_summary' => $complaintsSummary,
            'period' => ['from' => $dateFrom, 'to' => $dateTo]
        ]);
    }
    
    private function getFinancialSummary() {
        $dateFrom = $_GET['date_from'] ?? date('Y-m-d', strtotime('-30 days'));
        $dateTo = $_GET['date_to'] ?? date('Y-m-d');
        
        $financialQuery = "
            SELECT 
                COALESCE(SUM(CASE WHEN status = 'completed' THEN total_amount ELSE 0 END), 0) as gross_revenue,
                COALESCE(SUM(CASE WHEN status = 'completed' THEN delivery_fee ELSE 0 END), 0) as delivery_fees,
                COUNT(CASE WHEN status = 'completed' THEN 1 END) as completed_transactions,
                COUNT(CASE WHEN status = 'cancelled' THEN 1 END) as cancelled_transactions,
                COALESCE(AVG(CASE WHEN status = 'completed' THEN total_amount END), 0) as avg_transaction_value
            FROM bookings
            WHERE DATE(created_at) BETWEEN ? AND ?
        ";
        
        $stmt = $this->db->prepare($financialQuery);
        $stmt->execute([$dateFrom, $dateTo]);
        $financialSummary = $stmt->fetch(PDO::FETCH_ASSOC);
        
        $this->sendSuccess([
            'financial_summary' => $financialSummary,
            'period' => ['from' => $dateFrom, 'to' => $dateTo]
        ]);
    }
    
    private function generateCustomReport($data) {
        $reportType = $data['report_type'] ?? '';
        $dateFrom = $data['date_from'] ?? date('Y-m-d', strtotime('-30 days'));
        $dateTo = $data['date_to'] ?? date('Y-m-d');
        $filters = $data['filters'] ?? [];
        
        switch ($reportType) {
            case 'sales':
                $this->getSalesReport();
                break;
            case 'delivery':
                $this->getDeliveryReport();
                break;
            case 'rider_performance':
                $this->getRiderPerformance();
                break;
            case 'merchant_performance':
                $this->getMerchantPerformance();
                break;
            default:
                $this->sendError('Invalid report type', 400);
        }
    }
    
    private function exportReport($data) {
        $reportType = $data['report_type'] ?? '';
        $format = $data['format'] ?? 'csv';
        $dateFrom = $data['date_from'] ?? date('Y-m-d', strtotime('-30 days'));
        $dateTo = $data['date_to'] ?? date('Y-m-d');
        
        // This would generate and return downloadable report
        // For now, just return success with download URL
        $filename = $reportType . '_report_' . date('Y-m-d') . '.' . $format;
        
        $this->sendSuccess([
            'download_url' => '/downloads/' . $filename,
            'filename' => $filename,
            'format' => $format
        ], 'Report generated successfully');
    }
    
    private function sendSuccess($data = [], $message = 'Success') {
        echo json_encode([
            'success' => true,
            'message' => $message,
            'data' => $data
        ]);
    }
    
    private function sendError($message, $code = 400) {
        http_response_code($code);
        echo json_encode([
            'success' => false,
            'message' => $message,
            'error_code' => $code
        ]);
    }
}

$api = new ReportsAPI();
$api->handleRequest();
?>
