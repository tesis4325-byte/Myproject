<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

require_once '../config/Database.php';

class MenusAPI {
    private $db;
    
    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }

    private function seedDefaultCategories($data) {
        if (!isset($data['merchant_id']) || empty($data['merchant_id'])) {
            $this->sendError('Merchant ID is required', 400);
            return;
        }
        $merchantId = (int)$data['merchant_id'];
        $defaults = $data['categories'] ?? [
            'Drinks','Rice Meals','Noodles','Desserts','Appetizers','Breakfast','Burgers','Pizza',
            'Chicken','Pork','Beef','Seafood','Vegetables','Soup','Sandwiches','Pasta','Beverages',
            'Snacks','Silog Meals','Combo Meals','Extras','Sauces','Others'
        ];

        // Fetch existing names
        $stmt = $this->db->prepare('SELECT name FROM menu_categories WHERE merchant_id = ?');
        $stmt->execute([$merchantId]);
        $existing = array_map(function($r){ return strtolower($r['name']); }, $stmt->fetchAll(PDO::FETCH_ASSOC));

        $inserted = 0;
        $ins = $this->db->prepare('INSERT INTO menu_categories (merchant_id, name, is_active, created_at) VALUES (?, ?, 1, ?)');
        $now = date('Y-m-d H:i:s');
        foreach ($defaults as $name) {
            if (!in_array(strtolower($name), $existing, true)) {
                $ok = $ins->execute([$merchantId, $name, $now]);
                if ($ok) { $inserted++; }
            }
        }

        $this->sendSuccess(['inserted' => $inserted], $inserted > 0 ? 'Categories seeded' : 'No new categories added');
    }
    
    public function handleRequest() {
        $method = $_SERVER['REQUEST_METHOD'];
        $action = $_GET['action'] ?? '';
        
        try {
            switch ($method) {
                case 'GET':
                    $this->handleGet($action);
                    break;
                case 'POST':
                    $this->handlePost($action);
                    break;
                case 'PUT':
                    $this->handlePut($action);
                    break;
                case 'DELETE':
                    $this->handleDelete($action);
                    break;
                default:
                    $this->sendError('Method not allowed', 405);
            }
        } catch (Exception $e) {
            $this->sendError($e->getMessage(), 500);
        }
    }
    
    private function handleGet($action) {
        switch ($action) {
            case 'list':
                $this->getMenuItems();
                break;
            case 'stats':
                $this->getMenuStats();
                break;
            case 'by_merchant':
                $this->getMenuByMerchant();
                break;
            case 'categories':
                $this->getMenuCategories();
                break;
            case 'popular':
                $this->getPopularItems();
                break;
            case 'search':
                $this->searchMenuItems();
                break;
            default:
                $this->sendError('Invalid action', 400);
        }
    }
    
    private function handlePost($action) {
        $input = json_decode(file_get_contents('php://input'), true);
        
        switch ($action) {
            case 'create':
                $this->createMenuItem($input);
                break;
            case 'bulk_action':
                $this->bulkAction($input);
                break;
            case 'seed_default_categories':
                $this->seedDefaultCategories($input);
                break;
            default:
                $this->sendError('Invalid action', 400);
        }
    }
    
    private function handlePut($action) {
        $input = json_decode(file_get_contents('php://input'), true);
        
        switch ($action) {
            case 'update':
                $this->updateMenuItem($input);
                break;
            case 'update_status':
                $this->updateMenuItemStatus($input);
                break;
            case 'update_availability':
                $this->updateAvailability($input);
                break;
            default:
                $this->sendError('Invalid action', 400);
        }
    }
    
    private function handleDelete($action) {
        switch ($action) {
            case 'delete':
                $this->deleteMenuItem();
                break;
            default:
                $this->sendError('Invalid action', 400);
        }
    }
    
    private function getMenuItems() {
        $page = (int)($_GET['page'] ?? 1);
        $limit = (int)($_GET['limit'] ?? 20);
        $search = $_GET['search'] ?? '';
        $merchantId = $_GET['merchant_id'] ?? '';
        // Support both category and category_id
        $category = $_GET['category'] ?? ($_GET['category_id'] ?? '');
        $status = $_GET['status'] ?? '';
        $minPrice = isset($_GET['min_price']) ? (float)$_GET['min_price'] : null;
        $maxPrice = isset($_GET['max_price']) ? (float)$_GET['max_price'] : null;
        
        $offset = ($page - 1) * $limit;
        $whereConditions = [];
        $params = [];
        
        if (!empty($search)) {
            $whereConditions[] = "(mi.name LIKE ? OR mi.description LIKE ?)";
            $searchTerm = "%{$search}%";
            $params[] = $searchTerm;
            $params[] = $searchTerm;
        }
        
        if (!empty($merchantId)) {
            $whereConditions[] = "mi.merchant_id = ?";
            $params[] = $merchantId;
        }
        
        $joinCategory = false;
        if (!empty($category)) {
            $joinCategory = true;
            if (is_numeric($category)) {
                $whereConditions[] = "mi.category_id = ?";
                $params[] = (int)$category;
            } else {
                $whereConditions[] = "mc.name = ?";
                $params[] = $category;
            }
        }
        
        if (!empty($status)) {
            if ($status === 'active' || $status === 'available') {
                $whereConditions[] = "mi.is_available = 1";
            } elseif ($status === 'inactive' || $status === 'unavailable') {
                $whereConditions[] = "mi.is_available = 0";
            }
        }

        if ($minPrice !== null) {
            $whereConditions[] = "mi.price >= ?";
            $params[] = $minPrice;
        }
        if ($maxPrice !== null) {
            $whereConditions[] = "mi.price <= ?";
            $params[] = $maxPrice;
        }
        
        $whereClause = !empty($whereConditions) ? 'WHERE ' . implode(' AND ', $whereConditions) : '';
        
        $categoryJoinSql = $joinCategory ? " LEFT JOIN menu_categories mc ON mi.category_id = mc.id " : "";
        $countQuery = "SELECT COUNT(*) as total FROM menu_items mi {$categoryJoinSql} {$whereClause}";
        $countStmt = $this->db->prepare($countQuery);
        $countStmt->execute($params);
        $total = $countStmt->fetch(PDO::FETCH_ASSOC)['total'];
        
        $query = "
            SELECT mi.*, m.name as merchant_name, COALESCE(mc.name, 'Uncategorized') AS category_name,
                   CASE WHEN mi.is_available = 1 THEN 'available' ELSE 'unavailable' END AS status
            FROM menu_items mi
            LEFT JOIN merchants m ON mi.merchant_id = m.id
            LEFT JOIN menu_categories mc ON mi.category_id = mc.id
            {$whereClause}
            ORDER BY mi.created_at DESC
            LIMIT {$limit} OFFSET {$offset}
        ";
        
        $stmt = $this->db->prepare($query);
        $stmt->execute($params);
        $menuItems = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Compute order counts from bookings JSON items
        $idIndex = [];
        $itemIds = [];
        foreach ($menuItems as $idx => $mi) {
            $idIndex[(int)$mi['id']] = $idx;
            $itemIds[] = (int)$mi['id'];
            // defaults
            $menuItems[$idx]['total_orders'] = 0;
            $menuItems[$idx]['monthly_orders'] = 0;
        }

        if (!empty($itemIds)) {
            $bookingWhere = ["type = 'food_delivery'"]; // count only food orders
            $bookingParams = [];
            if (!empty($merchantId)) { $bookingWhere[] = 'merchant_id = ?'; $bookingParams[] = $merchantId; }
            // Exclude cancelled
            $bookingWhere[] = "status <> 'cancelled'";
            $bw = 'WHERE ' . implode(' AND ', $bookingWhere);

            $bq = "SELECT id, items, created_at FROM bookings {$bw}";
            $bstmt = $this->db->prepare($bq);
            $bstmt->execute($bookingParams);
            $bookings = $bstmt->fetchAll(PDO::FETCH_ASSOC);

            $now = new DateTime();
            $currentMonth = (int)$now->format('n');
            $currentYear = (int)$now->format('Y');

            foreach ($bookings as $b) {
                $created = new DateTime($b['created_at']);
                $isCurrentMonth = ((int)$created->format('n') === $currentMonth) && ((int)$created->format('Y') === $currentYear);
                $itemsJson = $b['items'];
                if (!$itemsJson) continue;
                $items = json_decode($itemsJson, true);
                if (!is_array($items)) continue;
                foreach ($items as $it) {
                    if (!isset($it['id'])) continue;
                    $iid = (int)$it['id'];
                    $qty = isset($it['quantity']) ? (int)$it['quantity'] : 1;
                    if (isset($idIndex[$iid])) {
                        $idx = $idIndex[$iid];
                        $menuItems[$idx]['total_orders'] += max(1, $qty);
                        if ($isCurrentMonth) {
                            $menuItems[$idx]['monthly_orders'] += max(1, $qty);
                        }
                    }
                }
            }
        }

        $this->sendSuccess([
            'items' => $menuItems,
            'pagination' => [
                'page' => $page,
                'limit' => $limit,
                'total' => (int)$total,
                'pages' => ceil($total / $limit)
            ]
        ]);
    }
    
    private function getMenuStats() {
        $query = "
            SELECT 
                (SELECT COUNT(*) FROM menu_items) as total_items,
                (SELECT COUNT(*) FROM menu_items WHERE is_available = 1) as available_items,
                (SELECT COUNT(*) FROM menu_categories WHERE is_active = 1) as total_categories,
                (SELECT AVG(price) FROM menu_items) as avg_price,
                (SELECT MIN(price) FROM menu_items) as min_price,
                (SELECT MAX(price) FROM menu_items) as max_price
        ";
        
        $stmt = $this->db->prepare($query);
        $stmt->execute();
        $stats = $stmt->fetch(PDO::FETCH_ASSOC);
        
        $this->sendSuccess($stats);
    }
    
    private function getMenuByMerchant() {
        $merchantId = $_GET['merchant_id'] ?? '';
        
        if (empty($merchantId)) {
            $this->sendError('Merchant ID is required', 400);
            return;
        }
        
        $query = "
            SELECT mi.*, mc.name AS category
            FROM menu_items mi
            LEFT JOIN menu_categories mc ON mi.category_id = mc.id
            WHERE mi.merchant_id = ? AND mi.is_available = 1
            ORDER BY mc.name, mi.name
        ";
        
        $stmt = $this->db->prepare($query);
        $stmt->execute([$merchantId]);
        $menuItems = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $groupedItems = [];
        foreach ($menuItems as $item) {
            $category = $item['category'] ?? 'Other';
            if (!isset($groupedItems[$category])) {
                $groupedItems[$category] = [];
            }
            $groupedItems[$category][] = $item;
        }
        
        $this->sendSuccess([
            'menu_items' => $menuItems,
            'grouped_items' => $groupedItems
        ]);
    }
    
    private function getMenuCategories() {
        $merchantId = $_GET['merchant_id'] ?? '';
        
        $whereConditions = ["mc.is_active = 1"];
        $params = [];
        
        if (!empty($merchantId)) {
            $whereConditions[] = "mc.merchant_id = ?";
            $params[] = $merchantId;
        }
        
        $whereClause = 'WHERE ' . implode(' AND ', $whereConditions);
        
        $query = "
            SELECT mc.id, mc.name AS name, COUNT(mi.id) as count
            FROM menu_categories mc
            LEFT JOIN menu_items mi ON mi.category_id = mc.id
            {$whereClause}
            GROUP BY mc.id, mc.name
            ORDER BY count DESC
        ";
        
        $stmt = $this->db->prepare($query);
        $stmt->execute($params);
        $categories = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Return array directly as data for UI expectations
        $this->sendSuccess($categories);
    }
    
    private function getPopularItems() {
        $limit = (int)($_GET['limit'] ?? 10);
        
        $query = "
            SELECT mi.*, m.name as merchant_name, mc.name AS category
            FROM menu_items mi
            LEFT JOIN merchants m ON mi.merchant_id = m.id
            LEFT JOIN menu_categories mc ON mi.category_id = mc.id
            WHERE mi.is_available = 1
            ORDER BY mi.created_at DESC
            LIMIT {$limit}
        ";
        
        $stmt = $this->db->prepare($query);
        $stmt->execute();
        $popularItems = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $this->sendSuccess(['popular_items' => $popularItems]);
    }
    
    private function searchMenuItems() {
        $query = $_GET['q'] ?? '';
        $limit = (int)($_GET['limit'] ?? 20);
        
        if (empty($query)) {
            $this->sendError('Search query is required', 400);
            return;
        }
        
        $searchTerm = "%{$query}%";
        
        $searchQuery = "
            SELECT mi.*, m.name as merchant_name
            FROM menu_items mi
            LEFT JOIN merchants m ON mi.merchant_id = m.id
            WHERE mi.is_available = 1
            AND (mi.name LIKE ? OR mi.description LIKE ?)
            ORDER BY mi.name ASC
            LIMIT {$limit}
        ";
        
        $stmt = $this->db->prepare($searchQuery);
        $stmt->execute([$searchTerm, $searchTerm]);
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $this->sendSuccess([
            'results' => $results,
            'query' => $query
        ]);
    }
    
    private function createMenuItem($data) {
        $requiredFields = ['merchant_id', 'name', 'price'];
        foreach ($requiredFields as $field) {
            if (!isset($data[$field]) || empty($data[$field])) {
                $this->sendError("Field {$field} is required", 400);
                return;
            }
        }
        
        $fields = ['merchant_id', 'name', 'price', 'is_available', 'created_at'];
        $values = [$data['merchant_id'], $data['name'], $data['price'], 1, date('Y-m-d H:i:s')];
        
        $optionalFields = ['description', 'image', 'preparation_time'];
        foreach ($optionalFields as $field) {
            if (!empty($data[$field])) {
                $fields[] = $field;
                $values[] = $data[$field];
            }
        }
        if (!empty($data['category_id'])) {
            $fields[] = 'category_id';
            $values[] = (int)$data['category_id'];
        }
        
        $placeholders = str_repeat('?,', count($values) - 1) . '?';
        $query = "INSERT INTO menu_items (" . implode(',', $fields) . ") VALUES ({$placeholders})";
        
        $stmt = $this->db->prepare($query);
        if ($stmt->execute($values)) {
            $itemId = $this->db->lastInsertId();
            $this->sendSuccess(['item_id' => $itemId], 'Menu item created successfully');
        } else {
            $this->sendError('Failed to create menu item', 500);
        }
    }
    
    private function updateMenuItem($data) {
        if (!isset($data['item_id'])) {
            $this->sendError('Menu item ID is required', 400);
            return;
        }
        
        $itemId = $data['item_id'];
        $updateFields = [];
        $values = [];
        
        $allowedFields = ['name', 'description', 'price', 'image', 'preparation_time', 'category_id'];
        
        foreach ($allowedFields as $field) {
            if (isset($data[$field])) {
                $updateFields[] = "{$field} = ?";
                $values[] = $data[$field];
            }
        }
        
        if (empty($updateFields)) {
            $this->sendError('No fields to update', 400);
            return;
        }
        
        $updateFields[] = "updated_at = ?";
        $values[] = date('Y-m-d H:i:s');
        $values[] = $itemId;
        
        $query = "UPDATE menu_items SET " . implode(', ', $updateFields) . " WHERE id = ?";
        $stmt = $this->db->prepare($query);
        
        if ($stmt->execute($values)) {
            $this->sendSuccess([], 'Menu item updated successfully');
        } else {
            $this->sendError('Failed to update menu item', 500);
        }
    }
    
    private function updateMenuItemStatus($data) {
        if (!isset($data['item_id']) || !isset($data['status'])) {
            $this->sendError('Menu item ID and status are required', 400);
            return;
        }
        
        $itemId = $data['item_id'];
        $status = $data['status'];
        
        $isAvailable = ($status === 'active') ? 1 : 0;
        $stmt = $this->db->prepare("UPDATE menu_items SET is_available = ?, updated_at = ? WHERE id = ?");
        
        if ($stmt->execute([$isAvailable, date('Y-m-d H:i:s'), $itemId])) {
            $this->sendSuccess([], 'Menu item status updated successfully');
        } else {
            $this->sendError('Failed to update menu item status', 500);
        }
    }
    
    private function updateAvailability($data) {
        if (!isset($data['item_id']) || !isset($data['is_available'])) {
            $this->sendError('Menu item ID and availability are required', 400);
            return;
        }
        
        $itemId = $data['item_id'];
        $isAvailable = $data['is_available'] ? 1 : 0;
        
        $stmt = $this->db->prepare("UPDATE menu_items SET is_available = ?, updated_at = ? WHERE id = ?");
        
        if ($stmt->execute([$isAvailable, date('Y-m-d H:i:s'), $itemId])) {
            $this->sendSuccess(['is_available' => (bool)$isAvailable], 'Availability updated successfully');
        } else {
            $this->sendError('Failed to update availability', 500);
        }
    }
    
    private function deleteMenuItem() {
        $itemId = $_GET['item_id'] ?? '';
        
        if (empty($itemId)) {
            $this->sendError('Menu item ID is required', 400);
            return;
        }
        
        // No booking_items table; perform soft delete by marking unavailable
        $stmt = $this->db->prepare("UPDATE menu_items SET is_available = 0, updated_at = ? WHERE id = ?");
        $stmt->execute([date('Y-m-d H:i:s'), $itemId]);
        
        $this->sendSuccess([], 'Menu item deleted successfully');
    }
    
    private function bulkAction($data) {
        if (!isset($data['action']) || !isset($data['item_ids'])) {
            $this->sendError('Action and item IDs are required', 400);
            return;
        }
        
        $action = $data['action'];
        $itemIds = $data['item_ids'];
        
        if (empty($itemIds)) {
            $this->sendError('No items selected', 400);
            return;
        }
        
        $placeholders = str_repeat('?,', count($itemIds) - 1) . '?';
        
        switch ($action) {
            case 'activate':
                $query = "UPDATE menu_items SET is_available = 1, updated_at = ? WHERE id IN ({$placeholders})";
                $params = array_merge([date('Y-m-d H:i:s')], $itemIds);
                break;
            case 'deactivate':
                $query = "UPDATE menu_items SET is_available = 0, updated_at = ? WHERE id IN ({$placeholders})";
                $params = array_merge([date('Y-m-d H:i:s')], $itemIds);
                break;
            default:
                $this->sendError('Invalid bulk action', 400);
                return;
        }
        
        $stmt = $this->db->prepare($query);
        if ($stmt->execute($params)) {
            $affectedRows = $stmt->rowCount();
            $this->sendSuccess(['affected_rows' => $affectedRows], "Bulk action completed on {$affectedRows} items");
        } else {
            $this->sendError('Failed to perform bulk action', 500);
        }
    }
    
    private function sendSuccess($data = [], $message = 'Success') {
        echo json_encode([
            'success' => true,
            'message' => $message,
            'data' => $data
        ]);
    }
    
    private function sendError($message, $code = 400) {
        http_response_code($code);
        echo json_encode([
            'success' => false,
            'message' => $message,
            'error_code' => $code
        ]);
    }
}

$api = new MenusAPI();
$api->handleRequest();
?>
