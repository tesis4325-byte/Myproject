<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

require_once '../config/Database.php';

class ComplaintsAPI {
    private $db;

    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }

    public function handleRequest() {
        $method = $_SERVER['REQUEST_METHOD'];
        $action = $_GET['action'] ?? '';
        try {
            switch ($method) {
                case 'GET':
                    $this->handleGet($action);
                    break;
                default:
                    $this->sendError('Method not allowed', 405);
            }
        } catch (Exception $e) {
            $this->sendError($e->getMessage(), 500);
        }
    }

    private function handleGet($action) {
        switch ($action) {
            case 'stats':
                $this->getStats();
                break;
            case 'list':
                $this->getComplaintsList();
                break;
            case 'export':
                $this->exportComplaints();
                break;
            default:
                $this->sendError('Invalid action', 404);
        }
    }

    private function getStats() {
        // Totals by status
        $sql = "SELECT 
                    COUNT(*) AS total,
                    SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) AS pending_cnt,
                    SUM(CASE WHEN status = 'resolved' THEN 1 ELSE 0 END) AS resolved_cnt
                FROM complaints";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC) ?: ['total'=>0,'pending_cnt'=>0,'resolved_cnt'=>0];

        // Average resolution time (hours) for resolved complaints
        $avgSql = "SELECT AVG(TIMESTAMPDIFF(HOUR, created_at, resolved_at)) AS avg_hours
                   FROM complaints
                   WHERE status = 'resolved' AND resolved_at IS NOT NULL";
        $avgStmt = $this->db->prepare($avgSql);
        $avgStmt->execute();
        $avg = $avgStmt->fetch(PDO::FETCH_ASSOC);
        $avgHours = $avg && $avg['avg_hours'] !== null ? (float)$avg['avg_hours'] : 0.0;

        $this->sendSuccess([
            'total_complaints' => (int)$row['total'],
            'pending_complaints' => (int)$row['pending_cnt'],
            'resolved_complaints' => (int)$row['resolved_cnt'],
            'avg_resolution_time' => round($avgHours, 1)
        ]);
    }

    private function getComplaintsList() {
        $status = $_GET['status'] ?? '';
        $priority = $_GET['priority'] ?? '';
        $category = $_GET['category'] ?? '';
        $search = $_GET['search'] ?? '';

        $conditions = [];
        $params = [];

        if ($status) { $conditions[] = 'c.status = ?'; $params[] = $status; }
        if ($priority) { $conditions[] = 'c.priority = ?'; $params[] = $priority; }
        if ($category) {
            // Map UI categories to DB enum values
            $map = [
                'delivery' => 'delivery_issue',
                'food_quality' => 'food_quality',
                'rider_behavior' => 'rider_behavior',
                'payment' => 'payment_issue',
                'app_bug' => 'other',
                'other' => 'other'
            ];
            $dbCat = $map[$category] ?? $category;
            $conditions[] = 'c.type = ?';
            $params[] = $dbCat;
        }
        if ($search) {
            $conditions[] = '(c.subject LIKE ? OR c.description LIKE ? OR c.customer_name LIKE ? OR c.customer_phone LIKE ?)';
            $term = "%{$search}%";
            array_push($params, $term, $term, $term, $term);
        }

        $where = $conditions ? ('WHERE ' . implode(' AND ', $conditions)) : '';

        $sql = "SELECT 
                    c.id,
                    c.type,
                    c.subject,
                    c.description,
                    c.customer_name,
                    c.customer_phone,
                    c.priority,
                    c.status,
                    c.assigned_to,
                    c.created_at,
                    u.full_name AS assigned_to_name
                FROM complaints c
                LEFT JOIN users u ON c.assigned_to = u.id
                {$where}
                ORDER BY c.created_at DESC";
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $results = array_map(function($r) {
            // Map DB type to UI category values
            $typeMap = [
                'delivery_issue' => 'delivery',
                'food_quality' => 'food_quality',
                'rider_behavior' => 'rider_behavior',
                'payment_issue' => 'payment',
                'other' => 'other'
            ];
            return [
                'id' => (int)$r['id'],
                'subject' => $r['subject'],
                'description' => $r['description'],
                'customer_name' => $r['customer_name'],
                'customer_phone' => $r['customer_phone'],
                'category' => $typeMap[$r['type']] ?? $r['type'],
                'priority' => $r['priority'],
                'status' => $r['status'],
                'assigned_to' => $r['assigned_to'] !== null ? (int)$r['assigned_to'] : null,
                'assigned_to_name' => $r['assigned_to_name'] ?? null,
                'created_at' => $r['created_at']
            ];
        }, $rows);

        $this->sendSuccess(['complaints' => $results]);
    }

    private function exportComplaints() {
        $filename = 'complaints_export_' . date('Y-m-d') . '.csv';
        $this->sendSuccess([
            'download_url' => '/downloads/' . $filename,
            'filename' => $filename,
            'format' => 'csv'
        ], 'Export ready');
    }

    private function sendSuccess($data = [], $message = 'Success') {
        echo json_encode([
            'success' => true,
            'message' => $message,
            'data' => $data
        ]);
    }

    private function sendError($message, $code = 400) {
        http_response_code($code);
        echo json_encode([
            'success' => false,
            'message' => $message,
            'error_code' => $code
        ]);
    }
}

$api = new ComplaintsAPI();
$api->handleRequest();
