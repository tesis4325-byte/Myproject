<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Access-Control-Allow-Credentials: true');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

require_once '../config/Database.php';

class AuthAPI {
    private $db;
    
    private function logActivity($message) {
        $dir = dirname(__DIR__) . DIRECTORY_SEPARATOR . 'logs';
        if (!is_dir($dir)) {
            @mkdir($dir, 0777, true);
        }
        $file = $dir . DIRECTORY_SEPARATOR . 'activity.log';
        $timestamp = date('Y-m-d H:i:s');
        @file_put_contents($file, "[$timestamp] AUTH: " . $message . PHP_EOL, FILE_APPEND);
    }
    
    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }
    
    public function handleRequest() {
        $method = $_SERVER['REQUEST_METHOD'];
        $action = $_GET['action'] ?? '';
        
        try {
            switch ($method) {
                case 'GET':
                    $this->handleGet($action);
                    break;
                case 'POST':
                    $this->handlePost($action);
                    break;
                default:
                    $this->sendError('Method not allowed', 405);
            }
        } catch (Exception $e) {
            $this->sendError($e->getMessage(), 500);
        }
    }
    
    private function handleGet($action) {
        switch ($action) {
            case 'check_session':
                $this->checkSession();
                break;
            case 'logout':
                $this->logout();
                break;
            default:
                $this->sendError('Invalid action', 400);
        }
    }
    
    private function handlePost($action) {
        $input = json_decode(file_get_contents('php://input'), true);
        
        switch ($action) {
            case 'login':
                $this->login($input);
                break;
            case 'register':
                $this->register($input);
                break;
            case 'forgot_password':
                $this->forgotPassword($input);
                break;
            case 'reset_password':
                $this->resetPassword($input);
                break;
            default:
                $this->sendError('Invalid action', 400);
        }
    }
    
    private function login($data) {
        if (!isset($data['phone']) || !isset($data['password'])) {
            $this->sendError('Phone and password are required', 400);
            return;
        }
        
        $identifier = isset($data['phone']) ? trim($data['phone']) : '';
        $password = isset($data['password']) ? (string)$data['password'] : '';
        $userType = strtolower(trim($data['user_type'] ?? 'customer'));
        
        // Start session first
        session_start();
        
        try {
            $this->logActivity("Login attempt: identifier='{$identifier}', userType='{$userType}'");
            // For admin and rider, check users table with role
            if ($userType === 'admin' || $userType === 'rider') {
                // Fetch by identifier first (username/phone/email), then validate role
                $stmt = $this->db->prepare("SELECT * FROM users WHERE (username = ? OR phone = ? OR email = ?) AND LOWER(status) = 'active' LIMIT 1");
                $stmt->execute([$identifier, $identifier, $identifier]);
                $user = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if (!$user) {
                    $this->logActivity("No user found for identifier='{$identifier}'");
                    $this->sendError('Invalid credentials: user not found for provided identifier', 401);
                    return;
                }
                
                $role = strtolower($user['role'] ?? '');
                $allowed = ($userType === 'admin') ? in_array($role, ['admin','super_admin'], true) : ($role === 'rider');
                if (!$allowed) {
                    $this->logActivity("Role mismatch for user id={$user['id']}, role='{$role}', portal='{$userType}'");
                    $this->sendError('Invalid credentials: role not allowed for this portal', 401);
                    return;
                }
                
                if (!password_verify($password, $user['password'])) {
                    $this->logActivity("Password mismatch for user id={$user['id']}");
                    $this->sendError('Invalid credentials: incorrect password', 401);
                    return;
                }
                
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_type'] = $userType;
                $_SESSION['role'] = $role; // needed by admin/templates/header.php
                $_SESSION['name'] = $user['full_name'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['phone'] = $user['phone'];
                $_SESSION['email'] = $user['email'];
                
                $this->logActivity("Login success for user id={$user['id']}, role='{$role}'");
                $this->sendSuccess([
                    'user' => [
                        'id' => $user['id'],
                        'name' => $user['full_name'],
                        'phone' => $user['phone'],
                        'email' => $user['email'],
                        'user_type' => $userType
                    ]
                ], 'Login successful');
                
            } else {
                // For customers and merchants, use separate tables
                $table = $this->getUserTable($userType);
                
                $stmt = $this->db->prepare("SELECT * FROM {$table} WHERE phone = ? AND status = 'active'");
                $stmt->execute([$phone]);
                $user = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if (!$user) {
                    $this->sendError('Invalid credentials: user not found', 401);
                    return;
                }
                if (!password_verify($password, $user['password'])) {
                    $this->sendError('Invalid credentials: incorrect password', 401);
                    return;
                }
                
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_type'] = $userType;
                $_SESSION['name'] = $user['name'] ?? $user['full_name'];
                $_SESSION['phone'] = $user['phone'];
                $_SESSION['email'] = $user['email'] ?? '';
                
                $this->sendSuccess([
                    'user' => [
                        'id' => $user['id'],
                        'name' => $user['name'] ?? $user['full_name'],
                        'phone' => $user['phone'],
                        'email' => $user['email'] ?? '',
                        'user_type' => $userType
                    ]
                ], 'Login successful');
            }
        } catch (PDOException $e) {
            $this->sendError('Login failed: ' . $e->getMessage(), 500);
        }
    }
    
    private function register($data) {
        $requiredFields = ['name', 'phone', 'password', 'user_type'];
        foreach ($requiredFields as $field) {
            if (!isset($data[$field]) || empty($data[$field])) {
                $this->sendError("Field {$field} is required", 400);
                return;
            }
        }
        
        $name = $data['name'];
        $phone = $data['phone'];
        $password = password_hash($data['password'], PASSWORD_DEFAULT);
        $userType = $data['user_type'];
        $email = $data['email'] ?? '';
        
        $table = $this->getUserTable($userType);
        
        // Check if phone already exists
        $checkStmt = $this->db->prepare("SELECT id FROM {$table} WHERE phone = ?");
        $checkStmt->execute([$phone]);
        if ($checkStmt->fetch()) {
            $this->sendError('Phone number already registered', 409);
            return;
        }
        
        // Insert new user
        $fields = ['name', 'phone', 'password', 'status', 'created_at'];
        $values = [$name, $phone, $password, 'active', date('Y-m-d H:i:s')];
        
        if (!empty($email)) {
            $fields[] = 'email';
            $values[] = $email;
        }
        
        $placeholders = str_repeat('?,', count($values) - 1) . '?';
        $insertStmt = $this->db->prepare("INSERT INTO {$table} (" . implode(',', $fields) . ") VALUES ({$placeholders})");
        
        if ($insertStmt->execute($values)) {
            $userId = $this->db->lastInsertId();
            
            $this->sendSuccess([
                'user' => [
                    'id' => $userId,
                    'name' => $name,
                    'phone' => $phone,
                    'email' => $email,
                    'user_type' => $userType
                ]
            ], 'Registration successful');
        } else {
            $this->sendError('Registration failed', 500);
        }
    }
    
    private function forgotPassword($data) {
        if (!isset($data['phone'])) {
            $this->sendError('Phone number is required', 400);
            return;
        }
        
        $phone = $data['phone'];
        $userType = $data['user_type'] ?? 'customer';
        $table = $this->getUserTable($userType);
        
        $stmt = $this->db->prepare("SELECT id, name, email FROM {$table} WHERE phone = ? AND status = 'active'");
        $stmt->execute([$phone]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$user) {
            $this->sendError('Phone number not found', 404);
            return;
        }
        
        // Generate reset token
        $resetToken = bin2hex(random_bytes(32));
        $resetExpiry = date('Y-m-d H:i:s', strtotime('+1 hour'));
        
        $updateStmt = $this->db->prepare("UPDATE {$table} SET reset_token = ?, reset_token_expiry = ? WHERE id = ?");
        $updateStmt->execute([$resetToken, $resetExpiry, $user['id']]);
        
        // In a real application, you would send SMS or email here
        // For now, we'll just return success
        
        $this->sendSuccess([
            'reset_token' => $resetToken // Remove this in production
        ], 'Password reset instructions sent');
    }
    
    private function resetPassword($data) {
        $requiredFields = ['reset_token', 'new_password', 'user_type'];
        foreach ($requiredFields as $field) {
            if (!isset($data[$field])) {
                $this->sendError("Field {$field} is required", 400);
                return;
            }
        }
        
        $resetToken = $data['reset_token'];
        $newPassword = password_hash($data['new_password'], PASSWORD_DEFAULT);
        $userType = $data['user_type'];
        $table = $this->getUserTable($userType);
        
        $stmt = $this->db->prepare("SELECT id FROM {$table} WHERE reset_token = ? AND reset_token_expiry > NOW()");
        $stmt->execute([$resetToken]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$user) {
            $this->sendError('Invalid or expired reset token', 400);
            return;
        }
        
        // Update password and clear reset token
        $updateStmt = $this->db->prepare("UPDATE {$table} SET password = ?, reset_token = NULL, reset_token_expiry = NULL WHERE id = ?");
        $updateStmt->execute([$newPassword, $user['id']]);
        
        $this->sendSuccess([], 'Password reset successful');
    }
    
    private function checkSession() {
        session_start();
        
        if (isset($_SESSION['user_id'])) {
            $this->sendSuccess([
                'authenticated' => true,
                'user' => [
                    'id' => $_SESSION['user_id'],
                    'name' => $_SESSION['name'],
                    'phone' => $_SESSION['phone'],
                    'email' => $_SESSION['email'],
                    'user_type' => $_SESSION['user_type']
                ]
            ]);
        } else {
            $this->sendSuccess(['authenticated' => false]);
        }
    }
    
    private function logout() {
        session_start();
        
        // Capture user type BEFORE destroying the session for proper redirect
        $userType = $_SESSION['user_type'] ?? 'customer';

        // Clear remember me cookie if exists
        if (isset($_COOKIE['remember_token'])) {
            setcookie('remember_token', '', time() - 3600, '/');
        }
        
        // Destroy session
        session_destroy();
        
        // Redirect based on user type or return JSON
        if (isset($_GET['redirect'])) {
            switch ($userType) {
                case 'admin':
                    header('Location: ../admin/index.php');
                    break;
                case 'rider':
                    header('Location: ../rider/index.php');
                    break;
                default:
                    header('Location: ../public/index.php');
            }
            exit();
        } else {
            $this->sendSuccess([], 'Logout successful');
        }
    }
    
    private function getUserTable($userType) {
        switch ($userType) {
            case 'admin':
                return 'users';
            case 'rider':
                return 'riders';
            case 'merchant':
                return 'merchants';
            case 'customer':
            default:
                return 'customers';
        }
    }
    
    private function sendSuccess($data = [], $message = 'Success') {
        echo json_encode([
            'success' => true,
            'message' => $message,
            'data' => $data
        ]);
    }
    
    private function sendError($message, $code = 400) {
        http_response_code($code);
        echo json_encode([
            'success' => false,
            'message' => $message,
            'error_code' => $code
        ]);
    }
}

$api = new AuthAPI();
$api->handleRequest();
?>
