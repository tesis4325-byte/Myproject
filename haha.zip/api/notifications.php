<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

session_start();

require_once '../config/Database.php';

class NotificationsAPI {
    private $db;
    private $user_id;

    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
        $this->user_id = $_SESSION['user_id'] ?? null;
    }

    public function handleRequest() {
        if (!$this->user_id) {
            return $this->sendError('Unauthorized', 401);
        }

        $method = $_SERVER['REQUEST_METHOD'];
        $action = $_GET['action'] ?? 'list';

        try {
            switch ($action) {
                case 'list':
                    return $this->listNotifications();
                case 'count_unread':
                    return $this->countUnread();
                case 'mark_all_read':
                    if ($method !== 'POST') return $this->sendError('Method not allowed', 405);
                    return $this->markAllRead();
                case 'mark_read':
                    if ($method !== 'POST') return $this->sendError('Method not allowed', 405);
                    return $this->markRead();
                default:
                    return $this->sendError('Invalid action', 404);
            }
        } catch (Exception $e) {
            return $this->sendError($e->getMessage(), 500);
        }
    }

    private function listNotifications() {
        $limit = isset($_GET['limit']) ? max(1, min(50, (int)$_GET['limit'])) : 10;
        $stmt = $this->db->prepare("SELECT id, type, title, message, data, is_read, created_at FROM notifications WHERE user_id = :uid ORDER BY created_at DESC LIMIT :lim");
        $stmt->bindValue(':uid', $this->user_id, PDO::PARAM_INT);
        $stmt->bindValue(':lim', $limit, PDO::PARAM_INT);
        $stmt->execute();
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $countStmt = $this->db->prepare("SELECT COUNT(*) AS c FROM notifications WHERE user_id = :uid AND is_read = 0");
        $countStmt->execute([':uid' => $this->user_id]);
        $unread = (int)($countStmt->fetch(PDO::FETCH_ASSOC)['c'] ?? 0);

        return $this->sendSuccess([
            'items' => $rows,
            'unread_count' => $unread
        ]);
    }

    private function countUnread() {
        $stmt = $this->db->prepare("SELECT COUNT(*) AS c FROM notifications WHERE user_id = :uid AND is_read = 0");
        $stmt->execute([':uid' => $this->user_id]);
        $unread = (int)($stmt->fetch(PDO::FETCH_ASSOC)['c'] ?? 0);
        return $this->sendSuccess(['unread_count' => $unread]);
    }

    private function markAllRead() {
        $stmt = $this->db->prepare("UPDATE notifications SET is_read = 1 WHERE user_id = :uid AND is_read = 0");
        $stmt->execute([':uid' => $this->user_id]);
        return $this->sendSuccess([], 'All notifications marked as read');
    }

    private function markRead() {
        $input = $_POST;
        if (empty($input)) {
            $raw = file_get_contents('php://input');
            $decoded = json_decode($raw, true);
            if (is_array($decoded)) { $input = $decoded; }
        }
        $id = isset($input['id']) ? (int)$input['id'] : 0;
        if ($id <= 0) return $this->sendError('Invalid notification id', 400);
        $stmt = $this->db->prepare("UPDATE notifications SET is_read = 1 WHERE id = :id AND user_id = :uid");
        $stmt->execute([':id' => $id, ':uid' => $this->user_id]);
        return $this->sendSuccess([], 'Notification marked as read');
    }

    private function sendSuccess($data = [], $message = 'Success') {
        echo json_encode([
            'success' => true,
            'message' => $message,
            'data' => $data
        ]);
        return true;
    }

    private function sendError($message, $code = 400) {
        http_response_code($code);
        echo json_encode([
            'success' => false,
            'message' => $message,
            'error_code' => $code
        ]);
        return false;
    }
}

$api = new NotificationsAPI();
$api->handleRequest();
