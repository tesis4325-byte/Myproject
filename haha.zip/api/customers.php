<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

require_once '../config/Database.php';

class CustomersAPI {
    private $db;
    
    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }
    
    public function handleRequest() {
        $method = $_SERVER['REQUEST_METHOD'];
        $action = $_GET['action'] ?? '';
        
        try {
            switch ($method) {
                case 'GET':
                    $this->handleGet($action);
                    break;
                case 'POST':
                    $this->handlePost($action);
                    break;
                case 'PUT':
                    $this->handlePut($action);
                    break;
                case 'DELETE':
                    $this->handleDelete($action);
                    break;
                default:
                    $this->sendError('Method not allowed', 405);
            }
        } catch (Exception $e) {
            $this->sendError($e->getMessage(), 500);
        }
    }
    
    private function handleGet($action) {
        switch ($action) {
            case 'list':
                $this->getCustomers();
                break;
            case 'stats':
                $this->getCustomerStats();
                break;
            case 'get':
                $this->getSingleCustomer();
                break;
            case 'details':
                $this->getCustomerDetails();
                break;
            case 'orders':
                $this->getCustomerOrders();
                break;
            case 'export':
                $this->exportCustomers();
                break;
            default:
                $this->sendError('Invalid action', 400);
        }
    }
    
    private function handlePost($action) {
        $input = json_decode(file_get_contents('php://input'), true);
        
        switch ($action) {
            case 'create':
                $this->createCustomer($input);
                break;
            case 'activate':
                $this->setCustomerBlocked($input, false);
                break;
            case 'suspend':
                $this->setCustomerBlocked($input, true);
                break;
            case 'delete':
                $this->deleteCustomerByPost($input);
                break;
            case 'bulk_action':
                $this->bulkAction($input);
                break;
            default:
                $this->sendError('Invalid action', 400);
        }
    }
    
    private function handlePut($action) {
        $input = json_decode(file_get_contents('php://input'), true);
        
        switch ($action) {
            case 'update':
                $this->updateCustomer($input);
                break;
            default:
                $this->sendError('Invalid action', 400);
        }
    }
    
    private function handleDelete($action) {
        switch ($action) {
            case 'delete':
                $this->deleteCustomer();
                break;
            default:
                $this->sendError('Invalid action', 400);
        }
    }
    
    private function getCustomers() {
        $page = (int)($_GET['page'] ?? 1);
        $limit = (int)($_GET['limit'] ?? 20);
        $search = $_GET['search'] ?? '';
        $status = $_GET['status'] ?? '';
        $type = $_GET['type'] ?? '';
        $dateFrom = $_GET['date_from'] ?? '';
        $dateTo = $_GET['date_to'] ?? '';
        $sortBy = $_GET['sort_by'] ?? 'created_at';
        $sortOrder = $_GET['sort_order'] ?? 'DESC';
        
        $offset = ($page - 1) * $limit;
        
        // Build query
        $whereConditions = [];
        $params = [];
        
        if (!empty($search)) {
            $whereConditions[] = "(full_name LIKE ? OR phone LIKE ? OR email LIKE ?)";
            $searchTerm = "%{$search}%";
            $params[] = $searchTerm;
            $params[] = $searchTerm;
            $params[] = $searchTerm;
        }
        
        if (!empty($status)) {
            // Map UI status to is_blocked flag
            if ($status === 'active') {
                $whereConditions[] = "is_blocked = 0";
            } elseif ($status === 'suspended') {
                $whereConditions[] = "is_blocked = 1";
            } // 'inactive' not tracked for customers
        }
        
        // customer_type not stored in schema; ignore filter safely
        
        if (!empty($dateFrom)) {
            $whereConditions[] = "DATE(created_at) >= ?";
            $params[] = $dateFrom;
        }
        
        if (!empty($dateTo)) {
            $whereConditions[] = "DATE(created_at) <= ?";
            $params[] = $dateTo;
        }
        
        $whereClause = !empty($whereConditions) ? 'WHERE ' . implode(' AND ', $whereConditions) : '';
        
        // Get total count
        $countQuery = "SELECT COUNT(*) as total FROM customers {$whereClause}";
        $countStmt = $this->db->prepare($countQuery);
        $countStmt->execute($params);
        $total = $countStmt->fetch(PDO::FETCH_ASSOC)['total'];
        
        // Get customers with order counts
        $query = "
            SELECT 
                c.id,
                c.full_name AS name,
                c.phone,
                c.email,
                c.address,
                c.created_at,
                c.updated_at,
                CASE WHEN c.is_blocked = 1 THEN 'suspended' ELSE 'active' END AS status,
                'regular' AS customer_type,
                NULL AS avatar,
                COUNT(DISTINCT b.id) as total_orders,
                COALESCE(SUM(b.total_amount), 0) as total_spent,
                MAX(b.created_at) as last_order_date
            FROM customers c
            LEFT JOIN bookings b ON c.id = b.customer_id
            {$whereClause}
            GROUP BY c.id
            ORDER BY {$sortBy} {$sortOrder}
            LIMIT {$limit} OFFSET {$offset}
        ";
        
        $stmt = $this->db->prepare($query);
        $stmt->execute($params);
        $customers = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $this->sendSuccess([
            'customers' => $customers,
            'pagination' => [
                'page' => $page,
                'limit' => $limit,
                'total' => (int)$total,
                'pages' => ceil($total / $limit)
            ]
        ]);
    }
    
    private function getCustomerStats() {
        // Base customer counts with schema-compatible fields
        $query = "
            SELECT 
                COUNT(*) as total_customers,
                COUNT(CASE WHEN is_blocked = 0 THEN 1 END) as active_customers,
                COUNT(CASE WHEN is_blocked = 1 THEN 1 END) as suspended_customers,
                COUNT(CASE WHEN DATE(created_at) >= DATE_SUB(CURDATE(), INTERVAL 30 DAY) THEN 1 END) as new_customers
            FROM customers
        ";
        $stmt = $this->db->prepare($query);
        $stmt->execute();
        $stats = $stmt->fetch(PDO::FETCH_ASSOC);

        // VIP customers: customers whose lifetime spend exceeds a threshold
        $vipQuery = "
            SELECT COUNT(*) as vip_customers FROM (
                SELECT customer_id, COALESCE(SUM(total_amount),0) as total_spent
                FROM bookings
                GROUP BY customer_id
                HAVING total_spent >= 5000
            ) t
        ";
        $vipStmt = $this->db->prepare($vipQuery);
        $vipStmt->execute();
        $vip = $vipStmt->fetch(PDO::FETCH_ASSOC);

        $this->sendSuccess(array_merge($stats ?: [], $vip ?: []));
    }

    private function getSingleCustomer() {
        $id = $_GET['id'] ?? '';
        if (empty($id)) {
            $this->sendError('Customer ID is required', 400);
            return;
        }
        $query = "
            SELECT 
                c.id,
                c.full_name AS name,
                c.phone,
                c.email,
                c.address,
                c.created_at,
                c.updated_at,
                CASE WHEN c.is_blocked = 1 THEN 'suspended' ELSE 'active' END AS status,
                'regular' AS customer_type,
                NULL AS avatar,
                COALESCE(order_stats.total_orders,0) AS total_orders,
                COALESCE(order_stats.total_spent,0) AS total_spent,
                order_stats.last_order_date
            FROM customers c
            LEFT JOIN (
                SELECT customer_id, COUNT(*) AS total_orders, SUM(total_amount) AS total_spent, MAX(created_at) AS last_order_date
                FROM bookings
                GROUP BY customer_id
            ) order_stats ON order_stats.customer_id = c.id
            WHERE c.id = ?
        ";
        $stmt = $this->db->prepare($query);
        $stmt->execute([$id]);
        $customer = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$customer) {
            $this->sendError('Customer not found', 404);
            return;
        }
        $this->sendSuccess($customer);
    }
    
    private function getCustomerDetails() {
        $customerId = $_GET['customer_id'] ?? '';
        
        if (empty($customerId)) {
            $this->sendError('Customer ID is required', 400);
            return;
        }
        
        // Get customer details
        $customerQuery = "
            SELECT 
                c.full_name AS name,
                c.phone,
                c.email,
                c.address,
                c.created_at,
                c.updated_at,
                CASE WHEN c.is_blocked = 1 THEN 'suspended' ELSE 'active' END AS status,
                'regular' AS customer_type,
                NULL AS avatar,
                COUNT(DISTINCT b.id) as total_orders,
                COALESCE(SUM(b.total_amount), 0) as total_spent,
                MAX(b.created_at) as last_order_date
            FROM customers c
            LEFT JOIN bookings b ON c.id = b.customer_id
            WHERE c.id = ?
            GROUP BY c.id
        ";
        
        $stmt = $this->db->prepare($customerQuery);
        $stmt->execute([$customerId]);
        $customer = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$customer) {
            $this->sendError('Customer not found', 404);
            return;
        }
        
        // Get recent orders
        $ordersQuery = "
            SELECT b.*, m.name as merchant_name, u.full_name as rider_name
            FROM bookings b
            LEFT JOIN merchants m ON b.merchant_id = m.id
            LEFT JOIN riders r ON b.rider_id = r.id
            LEFT JOIN users u ON r.user_id = u.id
            WHERE b.customer_id = ?
            ORDER BY b.created_at DESC
            LIMIT 10
        ";
        
        $ordersStmt = $this->db->prepare($ordersQuery);
        $ordersStmt->execute([$customerId]);
        $recentOrders = $ordersStmt->fetchAll(PDO::FETCH_ASSOC);
        
        $this->sendSuccess([
            'customer' => $customer,
            'recent_orders' => $recentOrders
        ]);
    }
    
    private function getCustomerOrders() {
        $customerId = $_GET['customer_id'] ?? '';
        $page = (int)($_GET['page'] ?? 1);
        $limit = (int)($_GET['limit'] ?? 10);
        
        if (empty($customerId)) {
            $this->sendError('Customer ID is required', 400);
            return;
        }
        
        $offset = ($page - 1) * $limit;
        
        // Get total count
        $countQuery = "SELECT COUNT(*) as total FROM bookings WHERE customer_id = ?";
        $countStmt = $this->db->prepare($countQuery);
        $countStmt->execute([$customerId]);
        $total = $countStmt->fetch(PDO::FETCH_ASSOC)['total'];
        
        // Get orders
        $query = "
            SELECT b.*, m.name as merchant_name, u.full_name as rider_name
            FROM bookings b
            LEFT JOIN merchants m ON b.merchant_id = m.id
            LEFT JOIN riders r ON b.rider_id = r.id
            LEFT JOIN users u ON r.user_id = u.id
            WHERE b.customer_id = ?
            ORDER BY b.created_at DESC
            LIMIT {$limit} OFFSET {$offset}
        ";
        
        $stmt = $this->db->prepare($query);
        $stmt->execute([$customerId]);
        $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $this->sendSuccess([
            'orders' => $orders,
            'pagination' => [
                'page' => $page,
                'limit' => $limit,
                'total' => (int)$total,
                'pages' => ceil($total / $limit)
            ]
        ]);
    }
    
    private function createCustomer($data) {
        $requiredFields = ['name', 'phone'];
        foreach ($requiredFields as $field) {
            if (!isset($data[$field]) || empty($data[$field])) {
                $this->sendError("Field {$field} is required", 400);
                return;
            }
        }
        
        // Check if phone already exists
        $checkStmt = $this->db->prepare("SELECT id FROM customers WHERE phone = ?");
        $checkStmt->execute([$data['phone']]);
        if ($checkStmt->fetch()) {
            $this->sendError('Phone number already exists', 409);
            return;
        }
        
        $fields = ['full_name', 'phone', 'created_at'];
        $values = [$data['name'], $data['phone'], date('Y-m-d H:i:s')];
        
        if (!empty($data['email'])) {
            $fields[] = 'email';
            $values[] = $data['email'];
        }
        
        if (!empty($data['address'])) {
            $fields[] = 'address';
            $values[] = $data['address'];
        }
        
        // customer_type not stored; ignore
        
        // password not stored for customers
        
        $placeholders = str_repeat('?,', count($values) - 1) . '?';
        $query = "INSERT INTO customers (" . implode(',', $fields) . ") VALUES ({$placeholders})";
        
        $stmt = $this->db->prepare($query);
        if ($stmt->execute($values)) {
            $customerId = $this->db->lastInsertId();
            $this->sendSuccess(['customer_id' => $customerId], 'Customer created successfully');
        } else {
            $this->sendError('Failed to create customer', 500);
        }
    }
    
    private function updateCustomer($data) {
        if (!isset($data['customer_id'])) {
            $this->sendError('Customer ID is required', 400);
            return;
        }
        
        $customerId = $data['customer_id'];
        $updateFields = [];
        $values = [];
        
        $allowedFields = ['full_name', 'phone', 'email', 'address'];
        
        foreach ($allowedFields as $field) {
            if (isset($data[$field])) {
                $updateFields[] = "{$field} = ?";
                $values[] = $data[$field];
            }
        }
        
        if (empty($updateFields)) {
            $this->sendError('No fields to update', 400);
            return;
        }
        
        $updateFields[] = "updated_at = ?";
        $values[] = date('Y-m-d H:i:s');
        $values[] = $customerId;
        
        $query = "UPDATE customers SET " . implode(', ', $updateFields) . " WHERE id = ?";
        $stmt = $this->db->prepare($query);
        
        if ($stmt->execute($values)) {
            $this->sendSuccess([], 'Customer updated successfully');
        } else {
            $this->sendError('Failed to update customer', 500);
        }
    }
    
    private function deleteCustomer() {
        $customerId = $_GET['customer_id'] ?? '';
        
        if (empty($customerId)) {
            $this->sendError('Customer ID is required', 400);
            return;
        }
        
        // Check if customer has orders
        $checkStmt = $this->db->prepare("SELECT COUNT(*) as order_count FROM bookings WHERE customer_id = ?");
        $checkStmt->execute([$customerId]);
        $orderCount = $checkStmt->fetch(PDO::FETCH_ASSOC)['order_count'];
        
        if ($orderCount > 0) {
            // Soft delete - block customer
            $stmt = $this->db->prepare("UPDATE customers SET is_blocked = 1, updated_at = ? WHERE id = ?");
            $stmt->execute([date('Y-m-d H:i:s'), $customerId]);
        } else {
            // Hard delete if no orders
            $stmt = $this->db->prepare("DELETE FROM customers WHERE id = ?");
            $stmt->execute([$customerId]);
        }
        
        $this->sendSuccess([], 'Customer deleted successfully');
    }

    private function deleteCustomerByPost($input) {
        if (!isset($input['customer_id'])) {
            $this->sendError('Customer ID is required', 400);
            return;
        }
        // Reuse delete logic but with provided ID
        $_GET['customer_id'] = $input['customer_id'];
        $this->deleteCustomer();
    }

    private function setCustomerBlocked($input, $blocked) {
        if (!isset($input['customer_id'])) {
            $this->sendError('Customer ID is required', 400);
            return;
        }
        $stmt = $this->db->prepare("UPDATE customers SET is_blocked = ?, updated_at = ? WHERE id = ?");
        if ($stmt->execute([$blocked ? 1 : 0, date('Y-m-d H:i:s'), $input['customer_id']])) {
            $this->sendSuccess([], $blocked ? 'Customer suspended successfully' : 'Customer activated successfully');
        } else {
            $this->sendError('Failed to update customer status', 500);
        }
    }
    
    private function bulkAction($data) {
        if (!isset($data['action']) || !isset($data['customer_ids'])) {
            $this->sendError('Action and customer IDs are required', 400);
            return;
        }
        
        $action = $data['action'];
        $customerIds = $data['customer_ids'];
        
        if (empty($customerIds)) {
            $this->sendError('No customers selected', 400);
            return;
        }
        
        $placeholders = str_repeat('?,', count($customerIds) - 1) . '?';
        
        switch ($action) {
            case 'activate':
                $query = "UPDATE customers SET status = 'active', updated_at = ? WHERE id IN ({$placeholders})";
                $params = array_merge([date('Y-m-d H:i:s')], $customerIds);
                break;
            case 'suspend':
                $query = "UPDATE customers SET status = 'suspended', updated_at = ? WHERE id IN ({$placeholders})";
                $params = array_merge([date('Y-m-d H:i:s')], $customerIds);
                break;
            case 'delete':
                $query = "UPDATE customers SET status = 'deleted', updated_at = ? WHERE id IN ({$placeholders})";
                $params = array_merge([date('Y-m-d H:i:s')], $customerIds);
                break;
            default:
                $this->sendError('Invalid bulk action', 400);
                return;
        }
        
        $stmt = $this->db->prepare($query);
        if ($stmt->execute($params)) {
            $affectedRows = $stmt->rowCount();
            $this->sendSuccess(['affected_rows' => $affectedRows], "Bulk action completed on {$affectedRows} customers");
        } else {
            $this->sendError('Failed to perform bulk action', 500);
        }
    }
    
    private function exportCustomers() {
        $format = $_GET['format'] ?? 'csv';
        
        // Get customers with filters
        $search = $_GET['search'] ?? '';
        $status = $_GET['status'] ?? '';
        $type = $_GET['type'] ?? '';
        
        $whereConditions = [];
        $params = [];
        
        if (!empty($search)) {
            $whereConditions[] = "(full_name LIKE ? OR phone LIKE ? OR email LIKE ?)";
            $searchTerm = "%{$search}%";
            $params[] = $searchTerm;
            $params[] = $searchTerm;
            $params[] = $searchTerm;
        }
        
        if (!empty($status)) {
            if ($status === 'active') {
                $whereConditions[] = "is_blocked = 0";
            } elseif ($status === 'suspended') {
                $whereConditions[] = "is_blocked = 1";
            }
        }
        
        // customer_type not stored in schema; ignore filter safely
        
        $whereClause = !empty($whereConditions) ? 'WHERE ' . implode(' AND ', $whereConditions) : '';
        
        $query = "
            SELECT 
                c.id,
                c.full_name AS name,
                c.phone,
                c.email,
                c.address,
                c.created_at,
                CASE WHEN c.is_blocked = 1 THEN 'suspended' ELSE 'active' END AS status,
                'regular' AS customer_type,
                NULL AS avatar,
                COUNT(DISTINCT b.id) as total_orders,
                COALESCE(SUM(b.total_amount), 0) as total_spent
            FROM customers c
            LEFT JOIN bookings b ON c.id = b.customer_id
            {$whereClause}
            GROUP BY c.id
            ORDER BY c.created_at DESC
        ";
        
        $stmt = $this->db->prepare($query);
        $stmt->execute($params);
        $customers = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        if ($format === 'csv') {
            header('Content-Type: text/csv');
            header('Content-Disposition: attachment; filename="customers_' . date('Y-m-d') . '.csv"');
            
            $output = fopen('php://output', 'w');
            
            // CSV headers
            fputcsv($output, ['ID', 'Name', 'Phone', 'Email', 'Address', 'Type', 'Status', 'Total Orders', 'Total Spent', 'Created At']);
            
            foreach ($customers as $customer) {
                fputcsv($output, [
                    $customer['id'],
                    $customer['name'],
                    $customer['phone'],
                    $customer['email'],
                    $customer['address'],
                    $customer['customer_type'],
                    $customer['status'],
                    $customer['total_orders'],
                    $customer['total_spent'],
                    $customer['created_at']
                ]);
            }
            
            fclose($output);
        } else {
            $this->sendSuccess(['customers' => $customers]);
        }
    }
    
    private function sendSuccess($data = [], $message = 'Success') {
        echo json_encode([
            'success' => true,
            'message' => $message,
            'data' => $data
        ]);
    }
    
    private function sendError($message, $code = 400) {
        http_response_code($code);
        echo json_encode([
            'success' => false,
            'message' => $message,
            'error_code' => $code
        ]);
    }
}

$api = new CustomersAPI();
$api->handleRequest();
?>
