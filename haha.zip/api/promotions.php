<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

require_once '../config/Database.php';

class PromotionsAPI {
    private $db;

    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }

    public function handleRequest() {
        $method = $_SERVER['REQUEST_METHOD'];
        $action = $_GET['action'] ?? '';

        try {
            switch ($method) {
                case 'GET':
                    $this->handleGet($action);
                    break;
                case 'POST':
                    $this->handlePost($action);
                    break;
                case 'PUT':
                    $this->handlePut($action);
                    break;
                case 'DELETE':
                    $this->handleDelete($action);
                    break;
                default:
                    $this->sendError('Method not allowed', 405);
            }
        } catch (Exception $e) {
            $this->sendError($e->getMessage(), 500);
        }
    }

    private function handleGet($action) {
        switch ($action) {
            case 'stats':
                $this->getStats();
                break;
            case 'list':
                $this->getPromotionsList();
                break;
            case 'export':
                $this->exportPromotions();
                break;
            default:
                $this->sendError('Invalid action', 404);
        }
    }

    private function getStats() {
        // Total promotions = promotions + banners
        $totalPromotions = 0;
        $activePromotions = 0;
        $totalVouchersUsed = 0;
        $totalSavings = 0.0; // Placeholder; requires per-use data to compute accurately

        // Promotions (vouchers)
        $promoSql = "SELECT 
                        COUNT(*) AS total,
                        SUM(CASE WHEN is_active = 1 AND CURDATE() BETWEEN start_date AND end_date THEN 1 ELSE 0 END) AS active,
                        COALESCE(SUM(used_count),0) AS used
                     FROM promotions";
        $stmt = $this->db->prepare($promoSql);
        $stmt->execute();
        $p = $stmt->fetch(PDO::FETCH_ASSOC) ?: ['total'=>0,'active'=>0,'used'=>0];

        // Banners
        $bannerSql = "SELECT 
                        COUNT(*) AS total,
                        SUM(CASE WHEN is_active = 1 AND (start_date IS NULL OR CURDATE() >= start_date) AND (end_date IS NULL OR CURDATE() <= end_date) THEN 1 ELSE 0 END) AS active
                      FROM banners";
        $bstmt = $this->db->prepare($bannerSql);
        $bstmt->execute();
        $b = $bstmt->fetch(PDO::FETCH_ASSOC) ?: ['total'=>0,'active'=>0];

        $totalPromotions = (int)$p['total'] + (int)$b['total'];
        $activePromotions = (int)$p['active'] + (int)$b['active'];
        $totalVouchersUsed = (int)$p['used'];

        $this->sendSuccess([
            'total_promotions' => $totalPromotions,
            'active_promotions' => $activePromotions,
            'total_vouchers' => $totalVouchersUsed,
            'total_savings' => (float)$totalSavings
        ]);
    }

    private function getPromotionsList() {
        $type = $_GET['type'] ?? 'all'; // all | banner | voucher | announcement
        $status = $_GET['status'] ?? '';
        $search = $_GET['search'] ?? '';
        $startDate = $_GET['start_date'] ?? '';
        $endDate = $_GET['end_date'] ?? '';

        $results = [];

        // Helper to compute status string
        $computeStatus = function($isActive, $startDate, $endDate) {
            $today = new DateTime('today');
            $start = $startDate ? new DateTime($startDate) : null;
            $end = $endDate ? new DateTime($endDate) : null;
            if (!$isActive) return 'inactive';
            if ($start && $today < $start) return 'scheduled';
            if ($end && $today > $end) return 'expired';
            return 'active';
        };

        // Vouchers from promotions table
        if ($type === 'all' || $type === 'voucher') {
            $conditions = [];
            $params = [];
            if ($search) { $conditions[] = '(title LIKE ? OR code LIKE ? OR description LIKE ?)'; $term = "%{$search}%"; $params[] = $term; $params[] = $term; $params[] = $term; }
            if ($startDate) { $conditions[] = 'end_date >= ?'; $params[] = $startDate; }
            if ($endDate) { $conditions[] = 'start_date <= ?'; $params[] = $endDate; }
            $where = $conditions ? ('WHERE ' . implode(' AND ', $conditions)) : '';
            $sql = "SELECT id, code, title, description, type, value, min_order_amount, max_discount, usage_limit, used_count, start_date, end_date, is_active FROM promotions {$where} ORDER BY created_at DESC";
            $stmt = $this->db->prepare($sql);
            $stmt->execute($params);
            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
            foreach ($rows as $r) {
                $rowStatus = $computeStatus((int)$r['is_active'] === 1, $r['start_date'], $r['end_date']);
                if ($status && $rowStatus !== $status) continue;
                $results[] = [
                    'id' => (int)$r['id'],
                    'title' => $r['title'],
                    'description' => $r['description'],
                    'image' => null,
                    'type' => 'voucher',
                    'voucher_type' => $r['type'],
                    'code' => $r['code'],
                    'value' => isset($r['value']) ? (float)$r['value'] : null,
                    'status' => $rowStatus,
                    'start_date' => $r['start_date'],
                    'end_date' => $r['end_date'],
                    'usage_count' => (int)$r['used_count'],
                    'usage_limit' => $r['usage_limit'] !== null ? (int)$r['usage_limit'] : null,
                    'total_savings' => 0.0
                ];
            }
        }

        // Banners from banners table
        if ($type === 'all' || $type === 'banner') {
            $conditions = [];
            $params = [];
            if ($search) { $conditions[] = '(title LIKE ? OR link LIKE ?)'; $term = "%{$search}%"; $params[] = $term; $params[] = $term; }
            if ($startDate) { $conditions[] = '(end_date IS NULL OR end_date >= ?)'; $params[] = $startDate; }
            if ($endDate) { $conditions[] = '(start_date IS NULL OR start_date <= ?)'; $params[] = $endDate; }
            $where = $conditions ? ('WHERE ' . implode(' AND ', $conditions)) : '';
            $sql = "SELECT id, title, image, link, sort_order, is_active, start_date, end_date, created_at FROM banners {$where} ORDER BY sort_order ASC, created_at DESC";
            $stmt = $this->db->prepare($sql);
            $stmt->execute($params);
            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
            foreach ($rows as $r) {
                $rowStatus = $computeStatus((int)$r['is_active'] === 1, $r['start_date'], $r['end_date']);
                if ($status && $rowStatus !== $status) continue;
                $results[] = [
                    'id' => (int)$r['id'],
                    'title' => $r['title'],
                    'description' => $r['link'] ?? '',
                    'image' => $r['image'],
                    'type' => 'banner',
                    'status' => $rowStatus,
                    'start_date' => $r['start_date'],
                    'end_date' => $r['end_date'],
                    'usage_count' => 0,
                    'usage_limit' => null,
                    'total_savings' => 0.0
                ];
            }
        }

        // Announcements - no dedicated table, return empty list for now
        if ($type === 'announcement') {
            // No-op; keep empty
        }

        // Sort by start_date desc then title
        usort($results, function($a, $b) {
            $ad = $a['start_date'] ?? '';
            $bd = $b['start_date'] ?? '';
            if ($ad == $bd) return strcmp($a['title'], $b['title']);
            return strcmp($bd, $ad);
        });

        $this->sendSuccess([
            'promotions' => $results
        ]);
    }

    private function exportPromotions() {
        $filename = 'promotions_export_' . date('Y-m-d') . '.csv';
        $this->sendSuccess([
            'download_url' => '/downloads/' . $filename,
            'filename' => $filename,
            'format' => 'csv'
        ], 'Export ready');
    }

    // --- Mutations ---
    private function handlePost($action) {
        switch ($action) {
            case 'create':
                $this->createItem();
                break;
            default:
                $this->sendError('Invalid action', 404);
        }
    }

    private function handlePut($action) {
        switch ($action) {
            case 'update':
                $this->updateItem();
                break;
            case 'toggle_status':
                $this->toggleStatus();
                break;
            default:
                $this->sendError('Invalid action', 404);
        }
    }

    private function handleDelete($action) {
        switch ($action) {
            case 'delete':
                $this->deleteItem();
                break;
            default:
                $this->sendError('Invalid action', 404);
        }
    }

    private function getJsonInput() {
        $raw = file_get_contents('php://input');
        $data = json_decode($raw, true);
        return is_array($data) ? $data : [];
    }

    private function createItem() {
        $data = $this->getJsonInput();
        $kind = $data['kind'] ?? 'voucher'; // voucher | banner

        if ($kind === 'voucher') {
            $required = ['code','title','type','value','start_date','end_date'];
            foreach ($required as $f) {
                if (!isset($data[$f]) || $data[$f] === '') {
                    $this->sendError("Field {$f} is required", 400);
                    return;
                }
            }
            $sql = "INSERT INTO promotions (code, title, description, type, value, min_order_amount, max_discount, usage_limit, start_date, end_date, is_active) VALUES (?,?,?,?,?,?,?,?,?,?,?)";
            $stmt = $this->db->prepare($sql);
            $ok = $stmt->execute([
                $data['code'],
                $data['title'],
                $data['description'] ?? null,
                $data['type'],
                $data['value'],
                $data['min_order_amount'] ?? 0,
                $data['max_discount'] ?? null,
                $data['usage_limit'] ?? null,
                $data['start_date'],
                $data['end_date'],
                isset($data['is_active']) ? (int)!!$data['is_active'] : 1
            ]);
            if ($ok) { $this->sendSuccess(['id' => (int)$this->db->lastInsertId()], 'Promotion created'); } else { $this->sendError('Failed to create promotion', 500); }
            return;
        }

        if ($kind === 'banner') {
            $required = ['title','image'];
            foreach ($required as $f) {
                if (!isset($data[$f]) || $data[$f] === '') {
                    $this->sendError("Field {$f} is required", 400);
                    return;
                }
            }
            $sql = "INSERT INTO banners (title, image, link, sort_order, is_active, start_date, end_date) VALUES (?,?,?,?,?,?,?)";
            $stmt = $this->db->prepare($sql);
            $ok = $stmt->execute([
                $data['title'],
                $data['image'],
                $data['link'] ?? null,
                $data['sort_order'] ?? 0,
                isset($data['is_active']) ? (int)!!$data['is_active'] : 1,
                $data['start_date'] ?? null,
                $data['end_date'] ?? null
            ]);
            if ($ok) { $this->sendSuccess(['id' => (int)$this->db->lastInsertId()], 'Banner created'); } else { $this->sendError('Failed to create banner', 500); }
            return;
        }

        $this->sendError('Invalid kind', 400);
    }

    private function updateItem() {
        $data = $this->getJsonInput();
        $kind = $data['kind'] ?? 'voucher';
        $id = $data['id'] ?? null;
        if (!$id) { $this->sendError('ID is required', 400); return; }

        if ($kind === 'voucher') {
            $allowed = ['code','title','description','type','value','min_order_amount','max_discount','usage_limit','start_date','end_date','is_active'];
            $fields = [];
            $values = [];
            foreach ($allowed as $f) {
                if (array_key_exists($f, $data)) { $fields[] = "$f = ?"; $values[] = $data[$f]; }
            }
            if (empty($fields)) { $this->sendError('No fields to update', 400); return; }
            $values[] = $id;
            $sql = "UPDATE promotions SET " . implode(', ', $fields) . " WHERE id = ?";
            $stmt = $this->db->prepare($sql);
            if ($stmt->execute($values)) { $this->sendSuccess([], 'Promotion updated'); } else { $this->sendError('Failed to update promotion', 500); }
            return;
        }

        if ($kind === 'banner') {
            $allowed = ['title','image','link','sort_order','is_active','start_date','end_date'];
            $fields = [];
            $values = [];
            foreach ($allowed as $f) {
                if (array_key_exists($f, $data)) { $fields[] = "$f = ?"; $values[] = $data[$f]; }
            }
            if (empty($fields)) { $this->sendError('No fields to update', 400); return; }
            $values[] = $id;
            $sql = "UPDATE banners SET " . implode(', ', $fields) . " WHERE id = ?";
            $stmt = $this->db->prepare($sql);
            if ($stmt->execute($values)) { $this->sendSuccess([], 'Banner updated'); } else { $this->sendError('Failed to update banner', 500); }
            return;
        }

        $this->sendError('Invalid kind', 400);
    }

    private function toggleStatus() {
        $data = $this->getJsonInput();
        $kind = $data['kind'] ?? 'voucher';
        $id = $data['id'] ?? null;
        $status = $data['status'] ?? null; // active | inactive
        if (!$id || !in_array($status, ['active','inactive'])) { $this->sendError('ID and valid status are required', 400); return; }
        $isActive = $status === 'active' ? 1 : 0;

        if ($kind === 'voucher') {
            $stmt = $this->db->prepare('UPDATE promotions SET is_active = ? WHERE id = ?');
            if ($stmt->execute([$isActive, $id])) { $this->sendSuccess(['status'=>$status], 'Promotion status updated'); } else { $this->sendError('Failed to update status', 500); }
            return;
        }
        if ($kind === 'banner') {
            $stmt = $this->db->prepare('UPDATE banners SET is_active = ? WHERE id = ?');
            if ($stmt->execute([$isActive, $id])) { $this->sendSuccess(['status'=>$status], 'Banner status updated'); } else { $this->sendError('Failed to update status', 500); }
            return;
        }
        $this->sendError('Invalid kind', 400);
    }

    private function deleteItem() {
        $data = $this->getJsonInput();
        $kind = $data['kind'] ?? 'voucher';
        $id = $data['id'] ?? null;
        if (!$id) { $this->sendError('ID is required', 400); return; }
        if ($kind === 'voucher') {
            $stmt = $this->db->prepare('DELETE FROM promotions WHERE id = ?');
            if ($stmt->execute([$id])) { $this->sendSuccess([], 'Promotion deleted'); } else { $this->sendError('Failed to delete promotion', 500); }
            return;
        }
        if ($kind === 'banner') {
            $stmt = $this->db->prepare('DELETE FROM banners WHERE id = ?');
            if ($stmt->execute([$id])) { $this->sendSuccess([], 'Banner deleted'); } else { $this->sendError('Failed to delete banner', 500); }
            return;
        }
        $this->sendError('Invalid kind', 400);
    }

    private function sendSuccess($data = [], $message = 'Success') {
        echo json_encode([
            'success' => true,
            'message' => $message,
            'data' => $data
        ]);
    }

    private function sendError($message, $code = 400) {
        http_response_code($code);
        echo json_encode([
            'success' => false,
            'message' => $message,
            'error_code' => $code
        ]);
    }
}

$api = new PromotionsAPI();
$api->handleRequest();
