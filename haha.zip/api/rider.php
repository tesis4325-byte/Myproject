<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Access-Control-Allow-Credentials: true');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

require_once __DIR__ . '/../config/Database.php';
require_once __DIR__ . '/../models/Booking.php';

class RiderAPI {
    private $db;

    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }

    public function handleRequest() {
        $method = $_SERVER['REQUEST_METHOD'];
        $action = $_GET['action'] ?? '';

        try {
            if ($method === 'GET') {
                switch ($action) {
                    case 'stats':
                        $this->getStats();
                        break;
                    case 'current_booking':
                        $this->getCurrentBooking();
                        break;
                    case 'available_bookings':
                        $this->getAvailableBookings();
                        break;
                    default:
                        $this->sendError('Invalid action', 400);
                }
            } elseif ($method === 'POST') {
                $input = json_decode(file_get_contents('php://input'), true) ?? [];
                switch ($action) {
                    case 'update_location':
                        $this->updateLocation($input);
                        break;
                    case 'accept_booking':
                        $this->acceptBooking($input);
                        break;
                    case 'update_booking_status':
                        $this->updateBookingStatus($input);
                        break;
                    case 'sync_data':
                        $this->sendSuccess([], 'Synced');
                        break;
                    default:
                        $this->sendError('Invalid action', 400);
                }
            } else {
                $this->sendError('Method not allowed', 405);
            }
        } catch (Exception $e) {
            $this->sendError($e->getMessage(), 500);
        }
    }

    private function resolveRiderByUserId($user_id) {
        // riders.user_id -> users.id
        $stmt = $this->db->prepare("SELECT * FROM riders WHERE user_id = ? LIMIT 1");
        $stmt->execute([$user_id]);
        return $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    private function getStats() {
        $user_id = intval($_GET['rider_id'] ?? 0);
        if (!$user_id) return $this->sendError('rider_id is required', 400);

        $rider = $this->resolveRiderByUserId($user_id);
        if (!$rider) return $this->sendError('Rider not found', 404);

        // Today range
        $todayStart = date('Y-m-d 00:00:00');
        $todayEnd = date('Y-m-d 23:59:59');

        // Total and pending deliveries (for this rider)
        $q1 = $this->db->prepare("SELECT 
            COUNT(*) AS total_deliveries,
            COUNT(CASE WHEN status IN ('accepted','picked_up','on_the_way') THEN 1 END) AS pending_deliveries,
            COUNT(CASE WHEN status = 'delivered' THEN 1 END) AS completed_deliveries
            FROM bookings WHERE rider_id = ?");
        $q1->execute([$rider['id']]);
        $agg = $q1->fetch(PDO::FETCH_ASSOC) ?: ['total_deliveries'=>0,'pending_deliveries'=>0,'completed_deliveries'=>0];

        // Earnings today
        $q2 = $this->db->prepare("SELECT COALESCE(SUM(total_earning),0) AS earnings_today FROM rider_earnings WHERE rider_id = ? AND DATE(created_at) = CURDATE()");
        $q2->execute([$rider['id']]);
        $earnRow = $q2->fetch(PDO::FETCH_ASSOC);

        // Earnings week (Mon..Sun)
        $q3 = $this->db->prepare("SELECT COALESCE(SUM(total_earning),0) AS earnings_week FROM rider_earnings WHERE rider_id = ? AND YEARWEEK(created_at,1) = YEARWEEK(CURDATE(),1)");
        $q3->execute([$rider['id']]);
        $weekRow = $q3->fetch(PDO::FETCH_ASSOC);

        $data = [
            'total_deliveries' => (int)$agg['total_deliveries'],
            'pending_deliveries' => (int)$agg['pending_deliveries'],
            'completed_deliveries' => (int)$agg['completed_deliveries'],
            'rating' => isset($rider['rating']) ? (float)$rider['rating'] : 5.0,
            'distance_today' => 0.0, // Not tracked; placeholder
            'earnings_today' => (float)($earnRow['earnings_today'] ?? 0),
            'earnings_week' => (float)($weekRow['earnings_week'] ?? 0),
        ];

        $this->sendSuccess($data);
    }

    private function getCurrentBooking() {
        $user_id = intval($_GET['rider_id'] ?? 0);
        if (!$user_id) return $this->sendError('rider_id is required', 400);
        $rider = $this->resolveRiderByUserId($user_id);
        if (!$rider) return $this->sendError('Rider not found', 404);

        $stmt = $this->db->prepare("SELECT * FROM bookings WHERE rider_id = ? AND status IN ('accepted','picked_up','on_the_way') ORDER BY updated_at DESC LIMIT 1");
        $stmt->execute([$rider['id']]);
        $booking = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$booking) return $this->sendSuccess(null, 'No current booking');

        $distance = $this->computeDistanceKm($booking['pickup_lat'], $booking['pickup_lng'], $booking['delivery_lat'], $booking['delivery_lng']);

        $data = [
            'id' => (int)$booking['id'],
            'customer_name' => $booking['customer_name'],
            'customer_phone' => $booking['customer_phone'],
            'delivery_address' => $booking['delivery_address'],
            'total_amount' => (float)$booking['total_amount'],
            'status' => $booking['status'],
            'distance' => $distance,
        ];
        $this->sendSuccess($data);
    }

    private function getAvailableBookings() {
        $user_id = intval($_GET['rider_id'] ?? 0);
        if (!$user_id) return $this->sendError('rider_id is required', 400);
        $rider = $this->resolveRiderByUserId($user_id);
        if (!$rider) return $this->sendError('Rider not found', 404);

        $rLat = $rider['current_lat'];
        $rLng = $rider['current_lng'];

        $stmt = $this->db->prepare("SELECT id, customer_name, pickup_address, pickup_lat, pickup_lng, delivery_address, delivery_lat, delivery_lng, total_amount
            FROM bookings WHERE rider_id IS NULL AND status = 'pending' ORDER BY created_at ASC LIMIT 20");
        $stmt->execute();
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];

        $list = [];
        foreach ($rows as $b) {
            $distance = null;
            if (!empty($rLat) && !empty($rLng) && !empty($b['pickup_lat']) && !empty($b['pickup_lng'])) {
                $distance = $this->computeDistanceKm($rLat, $rLng, $b['pickup_lat'], $b['pickup_lng']);
            } elseif (!empty($b['delivery_lat']) && !empty($b['delivery_lng']) && !empty($b['pickup_lat']) && !empty($b['pickup_lng'])) {
                $distance = $this->computeDistanceKm($b['pickup_lat'], $b['pickup_lng'], $b['delivery_lat'], $b['delivery_lng']);
            }
            $list[] = [
                'id' => (int)$b['id'],
                'customer_name' => $b['customer_name'],
                'pickup_address' => $b['pickup_address'],
                'delivery_address' => $b['delivery_address'],
                'total_amount' => (float)$b['total_amount'],
                'distance' => $distance !== null ? round($distance, 2) : 0.0,
            ];
        }

        $this->sendSuccess($list);
    }

    private function updateLocation($input) {
        $user_id = intval($input['rider_id'] ?? ($_GET['rider_id'] ?? 0));
        if (!$user_id) {
            // Fallback to session if available
            if (session_status() !== PHP_SESSION_ACTIVE) {
                @session_start();
            }
            $user_id = intval($_SESSION['user_id'] ?? 0);
        }
        $lat = isset($input['latitude']) ? (float)$input['latitude'] : null;
        $lng = isset($input['longitude']) ? (float)$input['longitude'] : null;
        if (!$user_id || $lat === null || $lng === null) {
            return $this->sendError('rider_id, latitude and longitude are required', 400);
        }

        $rider = $this->resolveRiderByUserId($user_id);
        if (!$rider) return $this->sendError('Rider not found', 404);

        $stmt = $this->db->prepare("UPDATE riders SET current_lat = ?, current_lng = ?, is_online = 1, updated_at = NOW() WHERE id = ?");
        $stmt->execute([$lat, $lng, $rider['id']]);

        $this->sendSuccess(['updated' => true]);
    }

    private function acceptBooking($input) {
        $user_id = intval($input['rider_id'] ?? 0);
        $booking_id = intval($input['booking_id'] ?? 0);
        if (!$user_id || !$booking_id) return $this->sendError('rider_id and booking_id are required', 400);

        $rider = $this->resolveRiderByUserId($user_id);
        if (!$rider) return $this->sendError('Rider not found', 404);

        // Ensure booking is still available
        $stmt = $this->db->prepare("SELECT * FROM bookings WHERE id = ? AND rider_id IS NULL AND status = 'pending' LIMIT 1");
        $stmt->execute([$booking_id]);
        $b = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$b) return $this->sendError('Booking not available', 409);

        // Assign rider and mark accepted
        $booking = new Booking();
        $booking->id = $booking_id;
        $booking->status = $b['status'];
        if (!$booking->assignRider($rider['id'], $user_id)) {
            return $this->sendError('Failed to assign rider', 500);
        }
        if (!$booking->updateStatus('accepted', 'Rider accepted booking', $user_id)) {
            return $this->sendError('Failed to update status', 500);
        }

        $this->sendSuccess(['accepted' => true], 'Booking accepted');
    }

    private function updateBookingStatus($input) {
        $user_id = intval($input['rider_id'] ?? 0);
        $booking_id = intval($input['booking_id'] ?? 0);
        $status = $input['status'] ?? '';
        if (!$user_id || !$booking_id || !$status) return $this->sendError('rider_id, booking_id and status are required', 400);

        $rider = $this->resolveRiderByUserId($user_id);
        if (!$rider) return $this->sendError('Rider not found', 404);

        // Verify booking belongs to rider
        $stmt = $this->db->prepare("SELECT * FROM bookings WHERE id = ? AND rider_id = ? LIMIT 1");
        $stmt->execute([$booking_id, $rider['id']]);
        $b = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$b) return $this->sendError('Booking not found for rider', 404);

        $booking = new Booking();
        $booking->id = $booking_id;
        $booking->rider_id = $rider['id'];
        $booking->delivery_fee = (float)$b['delivery_fee'];
        if (!$booking->updateStatus($status, 'Rider updated status', $user_id)) {
            return $this->sendError('Failed to update status', 500);
        }

        $this->sendSuccess(['updated' => true], 'Status updated');
    }

    private function computeDistanceKm($lat1, $lng1, $lat2, $lng2) {
        if ($lat1 === null || $lng1 === null || $lat2 === null || $lng2 === null) return 0.0;
        $earth_radius = 6371; // km
        $dLat = deg2rad($lat2 - $lat1);
        $dLon = deg2rad($lng2 - $lng1);
        $a = sin($dLat/2) * sin($dLat/2) + cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * sin($dLon/2) * sin($dLon/2);
        $c = 2 * atan2(sqrt($a), sqrt(1-$a));
        return $earth_radius * $c;
    }

    private function sendSuccess($data = [], $message = 'Success') {
        echo json_encode([
            'success' => true,
            'message' => $message,
            'data' => $data
        ]);
    }

    private function sendError($message, $code = 400) {
        http_response_code($code);
        echo json_encode([
            'success' => false,
            'message' => $message,
            'error_code' => $code
        ]);
    }
}

$api = new RiderAPI();
$api->handleRequest();
