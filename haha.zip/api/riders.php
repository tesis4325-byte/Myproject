<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

require_once '../config/Database.php';

class RidersAPI {
    private $db;
    
    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }

    // Resolve a provided identifier (which may be a users.id) to the actual riders.id
    private function resolveRiderId($rawId) {
        if ($rawId === null) return null;
        $id = (int)$rawId;
        // Try as riders.id
        $stmt = $this->db->prepare("SELECT id FROM riders WHERE id = ? LIMIT 1");
        $stmt->execute([$id]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($row && isset($row['id'])) {
            return (int)$row['id'];
        }
        // Try mapping from users.id
        $stmt2 = $this->db->prepare("SELECT id FROM riders WHERE user_id = ? LIMIT 1");
        $stmt2->execute([$id]);
        $row2 = $stmt2->fetch(PDO::FETCH_ASSOC);
        if ($row2 && isset($row2['id'])) {
            return (int)$row2['id'];
        }
        return null;
    }
    
    public function handleRequest() {
        $method = $_SERVER['REQUEST_METHOD'];
        $action = $_GET['action'] ?? '';
        
        try {
            switch ($method) {
                case 'GET':
                    $this->handleGet($action);
                    break;
                case 'POST':
                    $this->handlePost($action);
                    break;
                case 'PUT':
                    $this->handlePut($action);
                    break;
                case 'DELETE':
                    $this->handleDelete($action);
                    break;
                default:
                    $this->sendError('Method not allowed', 405);
            }
        } catch (Exception $e) {
            $this->sendError($e->getMessage(), 500);
        }
    }
    
    private function handleGet($action) {
        switch ($action) {
            case 'list':
                $this->getRiders();
                break;
            case 'stats':
                $this->getRiderStats();
                break;
            case 'dashboard_stats':
                $this->getDashboardStats();
                break;
            case 'bookings':
                $this->getRiderBookings();
                break;
            case 'history':
                $this->getRiderHistory();
                break;
            case 'profile':
                $this->getRiderProfile();
                break;
            case 'panic_alerts':
                $this->getPanicAlerts();
                break;
            case 'available_bookings':
                $this->getAvailableBookings();
                break;
            case 'current_delivery':
                $this->getCurrentDelivery();
                break;
            default:
                $this->sendError('Invalid action', 400);
        }
    }
    
    private function handlePost($action) {
        $input = json_decode(file_get_contents('php://input'), true);
        
        switch ($action) {
            case 'accept_booking':
                $this->acceptBooking($input);
                break;
            case 'update_location':
                $this->updateLocation($input);
                break;
            case 'update_status':
                // Alias to PUT update_booking_status to match frontend calls
                $this->updateBookingStatus($input);
                break;
            case 'send_panic_alert':
                $this->sendPanicAlert($input);
                break;
            case 'upload_profile_image':
                $this->uploadProfileImage();
                break;
            default:
                $this->sendError('Invalid action', 400);
        }
    }
    
    private function handlePut($action) {
        $input = json_decode(file_get_contents('php://input'), true);
        
        switch ($action) {
            case 'update_profile':
                $this->updateProfile($input);
                break;
            case 'update_personal_info':
                $this->updatePersonalInfo($input);
                break;
            case 'change_password':
                $this->changePassword($input);
                break;
            case 'update_booking_status':
                $this->updateBookingStatus($input);
                break;
            case 'toggle_availability':
                $this->toggleAvailability($input);
                break;
            default:
                $this->sendError('Invalid action', 400);
        }
    }

    private function changePassword($data) {
        session_start();
        $userId = $_SESSION['user_id'] ?? null;
        if (!$userId) {
            $this->sendError('Rider not authenticated', 401);
            return;
        }

        $current = $data['current_password'] ?? '';
        $new = $data['new_password'] ?? '';
        if (!$current || !$new) {
            $this->sendError('Current and new password are required', 400);
            return;
        }
        if (strlen($new) < 6) {
            $this->sendError('New password must be at least 6 characters', 400);
            return;
        }

        // Fetch current password hash
        $stmt = $this->db->prepare('SELECT password FROM users WHERE id = ? LIMIT 1');
        $stmt->execute([$userId]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$user || empty($user['password'])) {
            $this->sendError('User not found', 404);
            return;
        }

        if (!password_verify($current, $user['password'])) {
            $this->sendError('Current password is incorrect', 400);
            return;
        }

        $newHash = password_hash($new, PASSWORD_BCRYPT);
        $upd = $this->db->prepare('UPDATE users SET password = ?, updated_at = NOW() WHERE id = ?');
        if ($upd->execute([$newHash, $userId])) {
            $this->sendSuccess([], 'Password updated successfully');
        } else {
            $this->sendError('Failed to update password', 500);
        }
    }

    private function updatePersonalInfo($data) {
        session_start();
        $userId = $_SESSION['user_id'] ?? null;
        if (!$userId) {
            $this->sendError('Rider not authenticated', 401);
            return;
        }

        $firstName = trim($data['first_name'] ?? '');
        $lastName  = trim($data['last_name'] ?? '');
        $email     = trim($data['email'] ?? '');
        $phone     = trim($data['phone'] ?? '');

        if ($firstName === '' && $lastName === '' && $email === '' && $phone === '') {
            $this->sendError('No fields to update', 400);
            return;
        }

        $fullName = trim($firstName . ' ' . $lastName);

        $fields = [];
        $params = [];
        if ($fullName !== '') { $fields[] = 'full_name = ?'; $params[] = $fullName; }
        if ($email !== '')    { $fields[] = 'email = ?';     $params[] = $email; }
        if ($phone !== '')    { $fields[] = 'phone = ?';     $params[] = $phone; }

        if (empty($fields)) {
            $this->sendError('No fields to update', 400);
            return;
        }

        $params[] = $userId;
        $sql = 'UPDATE users SET ' . implode(', ', $fields) . ', updated_at = NOW() WHERE id = ?';
        $stmt = $this->db->prepare($sql);
        if ($stmt->execute($params)) {
            $this->sendSuccess(['full_name' => $fullName, 'email' => $email, 'phone' => $phone], 'Personal info updated');
        } else {
            $this->sendError('Failed to update personal info', 500);
        }
    }
    
    private function handleDelete($action) {
        $this->sendError('Invalid action', 400);
    }
    
    private function getRiders() {
        $page = (int)($_GET['page'] ?? 1);
        $limit = (int)($_GET['limit'] ?? 20);
        $search = $_GET['search'] ?? '';
        $status = $_GET['status'] ?? '';
        $offset = ($page - 1) * $limit;
        
        $whereConditions = [];
        $params = [];
        
        if (!empty($search)) {
            $whereConditions[] = "(u.full_name LIKE ? OR u.phone LIKE ? OR r.vehicle_type LIKE ? OR r.vehicle_plate LIKE ?)";
            $searchTerm = "%{$search}%";
            $params[] = $searchTerm;
            $params[] = $searchTerm;
            $params[] = $searchTerm;
            $params[] = $searchTerm;
        }
        
        if (!empty($status)) {
            // Map UI status filters to conditions
            if ($status === 'online') {
                $whereConditions[] = "r.is_online = 1";
            } elseif ($status === 'offline') {
                $whereConditions[] = "r.is_online = 0 AND u.status <> 'inactive'";
            } elseif ($status === 'inactive') {
                $whereConditions[] = "u.status = 'inactive'";
            } elseif ($status === 'busy') {
                $whereConditions[] = "r.is_online = 1 AND EXISTS (SELECT 1 FROM bookings b2 WHERE b2.rider_id = r.id AND b2.status IN ('accepted','picked_up','on_the_way'))";
            }
        }
        
        $whereClause = !empty($whereConditions) ? 'WHERE ' . implode(' AND ', $whereConditions) : '';
        
        $countQuery = "SELECT COUNT(*) as total FROM riders r LEFT JOIN users u ON r.user_id = u.id {$whereClause}";
        $countStmt = $this->db->prepare($countQuery);
        $countStmt->execute($params);
        $total = $countStmt->fetch(PDO::FETCH_ASSOC)['total'];
        
        $query = "
            SELECT 
                r.id,
                u.full_name AS name,
                u.phone,
                u.email,
                r.vehicle_type,
                r.vehicle_plate,
                r.rating,
                0 AS total_reviews,
                CASE 
                    WHEN r.is_online = 1 AND EXISTS (SELECT 1 FROM bookings b2 WHERE b2.rider_id = r.id AND b2.status IN ('accepted','picked_up','on_the_way')) THEN 'busy'
                    WHEN r.is_online = 1 THEN 'online'
                    WHEN u.status = 'inactive' THEN 'inactive'
                    ELSE 'offline'
                END AS status,
                COUNT(DISTINCT b.id) AS total_deliveries,
                COALESCE(SUM(CASE WHEN MONTH(b.created_at) = MONTH(CURRENT_DATE()) AND YEAR(b.created_at) = YEAR(CURRENT_DATE()) THEN 1 ELSE 0 END), 0) AS monthly_deliveries
            FROM riders r
            LEFT JOIN users u ON r.user_id = u.id
            LEFT JOIN bookings b ON r.id = b.rider_id
            {$whereClause}
            GROUP BY r.id
            ORDER BY r.created_at DESC
            LIMIT {$limit} OFFSET {$offset}
        ";
        
        $stmt = $this->db->prepare($query);
        $stmt->execute($params);
        $riders = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $this->sendSuccess([
            'riders' => $riders,
            'pagination' => [
                'page' => $page,
                'limit' => $limit,
                'total' => (int)$total,
                'pages' => ceil($total / $limit)
            ]
        ]);
    }
    
    private function getRiderStats() {
        // Admin/overview stats about riders
        $baseQuery = "SELECT COUNT(*) as total_riders, AVG(rating) as avg_rating, SUM(CASE WHEN is_online = 1 THEN 1 ELSE 0 END) as online_riders FROM riders";
        $stmt = $this->db->prepare($baseQuery);
        $stmt->execute();
        $stats = $stmt->fetch(PDO::FETCH_ASSOC) ?: ['total_riders' => 0, 'avg_rating' => 0, 'online_riders' => 0];

        $busyQuery = "SELECT COUNT(DISTINCT r.id) AS busy_riders
                      FROM riders r
                      JOIN bookings b ON b.rider_id = r.id
                      WHERE b.status IN ('accepted','picked_up','on_the_way')";
        $busyStmt = $this->db->prepare($busyQuery);
        $busyStmt->execute();
        $busy = $busyStmt->fetch(PDO::FETCH_ASSOC) ?: ['busy_riders' => 0];

        $stats['busy_riders'] = (int)$busy['busy_riders'];
        $this->sendSuccess($stats);
    }

    private function getDashboardStats() {
        session_start();
        $userId = $_SESSION['user_id'] ?? null;
        if (!$userId) {
            $this->sendError('Rider not authenticated', 401);
            return;
        }
        $riderId = $this->resolveRiderId($userId);
        if (!$riderId) {
            $this->sendError('Rider profile not found', 404);
            return;
        }

        $statsQuery = "
            SELECT 
                COALESCE(SUM(CASE WHEN DATE(b.created_at) = CURDATE() THEN 1 ELSE 0 END),0) AS deliveries_today,
                COALESCE(SUM(CASE WHEN b.status = 'delivered' THEN 1 ELSE 0 END),0) AS total_deliveries,
                COALESCE(SUM(CASE WHEN DATE(b.created_at) = CURDATE() AND b.status = 'delivered' THEN b.delivery_fee ELSE 0 END),0) AS earnings_today,
                COALESCE(SUM(CASE WHEN b.status = 'delivered' THEN b.delivery_fee ELSE 0 END),0) AS total_earnings,
                r.is_online, r.rating
            FROM riders r
            LEFT JOIN bookings b ON r.id = b.rider_id
            WHERE r.id = ?
            GROUP BY r.id, r.is_online, r.rating
        ";

        $stmt = $this->db->prepare($statsQuery);
        $stmt->execute([$riderId]);
        $stats = $stmt->fetch(PDO::FETCH_ASSOC) ?: [];
        // Coerce to numeric types for frontend formatting
        $stats['deliveries_today'] = isset($stats['deliveries_today']) ? (int)$stats['deliveries_today'] : 0;
        $stats['total_deliveries'] = isset($stats['total_deliveries']) ? (int)$stats['total_deliveries'] : 0;
        $stats['earnings_today'] = isset($stats['earnings_today']) ? (float)$stats['earnings_today'] : 0.0;
        $stats['total_earnings'] = isset($stats['total_earnings']) ? (float)$stats['total_earnings'] : 0.0;
        $stats['rating'] = isset($stats['rating']) ? (float)$stats['rating'] : 5.0;
        // Provide defaults used by UI
        $stats['pending_deliveries'] = isset($stats['pending_deliveries']) ? (int)$stats['pending_deliveries'] : 0;
        $stats['distance_today'] = isset($stats['distance_today']) ? (float)$stats['distance_today'] : 0.0;
        $stats['earnings_week'] = isset($stats['earnings_week']) ? (float)$stats['earnings_week'] : 0.0;
        $this->sendSuccess($stats);
    }

    private function getAvailableBookings() {
        $query = "
            SELECT b.*, c.full_name as customer_name, c.phone as customer_phone, 
                   m.name as merchant_name, m.address as merchant_address
            FROM bookings b
            LEFT JOIN customers c ON b.customer_id = c.id
            LEFT JOIN merchants m ON b.merchant_id = m.id
            WHERE b.status = 'pending' AND b.rider_id IS NULL
            ORDER BY b.created_at ASC
            LIMIT 20
        ";
        $stmt = $this->db->prepare($query);
        $stmt->execute();
        $bookings = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $this->sendSuccess(['bookings' => $bookings]);
    }

    private function getRiderBookings() {
        // Resolve rider id (supports users.id or riders.id)
        $rawRiderId = $_GET['rider_id'] ?? null;
        $riderId = $this->resolveRiderId($rawRiderId);
        if (!$riderId) {
            // Try from session as fallback
            session_start();
            $userId = $_SESSION['user_id'] ?? null;
            $riderId = $this->resolveRiderId($userId);
            if (!$riderId) {
                $this->sendError('Rider not authenticated', 401);
                return;
            }
        }

        $status = $_GET['status'] ?? 'all';
        $sort = $_GET['sort'] ?? 'created_at';

        // Map UI status to DB status
        $statusMap = [
            'assigned' => 'accepted',
            'in_transit' => 'picked_up',
        ];
        $dbStatus = $statusMap[$status] ?? $status;

        $validSort = ['created_at', 'amount', 'distance', 'priority'];
        if (!in_array($sort, $validSort, true)) { $sort = 'created_at'; }
        // Map sort to actual columns
        $sortColMap = [
            'created_at' => 'b.created_at',
            'amount' => 'b.total_amount',
            'distance' => 'b.distance',
            'priority' => 'b.priority'
        ];
        $orderBy = $sortColMap[$sort] . ' DESC';

        $where = 'WHERE b.rider_id = ?';
        $params = [$riderId];
        if ($dbStatus !== 'all') {
            $where .= ' AND b.status = ?';
            $params[] = $dbStatus;
        }

        $sql = "
            SELECT b.*, 
                   c.full_name AS customer_name, c.phone AS customer_phone,
                   m.name AS merchant_name, m.address AS merchant_address
            FROM bookings b
            LEFT JOIN customers c ON b.customer_id = c.id
            LEFT JOIN merchants m ON b.merchant_id = m.id
            $where
            ORDER BY $orderBy
            LIMIT 100
        ";
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $this->sendSuccess(['bookings' => $rows]);
    }

    private function getRiderHistory() {
        // Resolve rider id (supports users.id or riders.id). Allow session fallback.
        $rawRiderId = $_GET['rider_id'] ?? null;
        $riderId = $this->resolveRiderId($rawRiderId);
        if (!$riderId) {
            session_start();
            $userId = $_SESSION['user_id'] ?? null;
            $riderId = $this->resolveRiderId($userId);
            if (!$riderId) {
                $this->sendError('Rider not authenticated', 401);
                return;
            }
        }

        // Date range filters (optional)
        $dateFrom = $_GET['date_from'] ?? null; // format: YYYY-MM-DD
        $dateTo   = $_GET['date_to'] ?? null;   // format: YYYY-MM-DD
        $status   = $_GET['status'] ?? 'all';   // optional filter

        $where = ['b.rider_id = ?'];
        $params = [$riderId];

        if ($status !== 'all') {
            // Support delivered/cancelled filtering
            $allowed = ['delivered','cancelled'];
            if (in_array($status, $allowed, true)) {
                $where[] = 'b.status = ?';
                $params[] = $status;
            }
        }

        // Apply date range on the completion/updated/created date, in that order of preference
        $dateExpr = "DATE(COALESCE(b.delivered_at, b.updated_at, b.created_at))";
        if ($dateFrom) {
            $where[] = "$dateExpr >= ?";
            $params[] = $dateFrom;
        }
        if ($dateTo) {
            $where[] = "$dateExpr <= ?";
            $params[] = $dateTo;
        }

        $whereSql = 'WHERE ' . implode(' AND ', $where);

        // Fetch deliveries for the rider within range
        $sql = "
            SELECT 
                b.id, b.status, b.total_amount, b.delivery_fee, b.rider_rating AS rating,
                b.created_at, b.updated_at, b.delivered_at AS completed_at,
                b.pickup_address, b.delivery_address,
                c.full_name AS customer_name, c.phone AS customer_phone
            FROM bookings b
            LEFT JOIN customers c ON b.customer_id = c.id
            $whereSql
            ORDER BY COALESCE(b.delivered_at, b.updated_at, b.created_at) DESC
            LIMIT 500
        ";
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];

        // Compute stats
        $statsSql = "
            SELECT 
                COALESCE(SUM(CASE WHEN b.status = 'delivered' THEN 1 ELSE 0 END),0) AS total_deliveries,
                COALESCE(SUM(CASE WHEN b.status = 'delivered' THEN b.delivery_fee ELSE 0 END),0) AS total_earnings
            FROM bookings b
            $whereSql
        ";
        $statsStmt = $this->db->prepare($statsSql);
        $statsStmt->execute($params);
        $stats = $statsStmt->fetch(PDO::FETCH_ASSOC) ?: [
            'total_deliveries' => 0,
            'total_earnings' => 0
        ];
        // Distance not tracked in schema; default to 0
        $stats['total_distance'] = 0;

        // Average rating from riders table as a stable metric
        $rateStmt = $this->db->prepare('SELECT COALESCE(rating, 5.0) AS avg_rating FROM riders WHERE id = ? LIMIT 1');
        $rateStmt->execute([$riderId]);
        $rateRow = $rateStmt->fetch(PDO::FETCH_ASSOC) ?: ['avg_rating' => 5.0];
        $stats['avg_rating'] = (float)$rateRow['avg_rating'];

        // Group deliveries by date string that frontend can flatten
        $grouped = [];
        foreach ($rows as $r) {
            $d = $r['completed_at'] ?: $r['created_at'];
            $key = substr($d, 0, 10); // YYYY-MM-DD
            if (!isset($grouped[$key])) $grouped[$key] = [];
            // Cast numeric fields for frontend
            $r['total_amount'] = isset($r['total_amount']) ? (float)$r['total_amount'] : 0.0;
            $r['delivery_fee'] = isset($r['delivery_fee']) ? (float)$r['delivery_fee'] : 0.0;
            // Distance not present; provide 0 for UI
            $r['distance'] = isset($r['distance']) ? (float)$r['distance'] : 0.0;
            $r['rating'] = isset($r['rating']) ? (float)$r['rating'] : null;
            $grouped[$key][] = $r;
        }

        // Coerce stats
        $stats['total_deliveries'] = (int)$stats['total_deliveries'];
        $stats['total_earnings'] = (float)$stats['total_earnings'];
        $stats['total_distance'] = (float)$stats['total_distance'];

        $this->sendSuccess([
            'stats' => $stats,
            'deliveries' => $grouped,
        ]);
    }

    private function getCurrentDelivery() {
        session_start();
        $userId = $_SESSION['user_id'] ?? null;
        if (!$userId) {
            $this->sendError('Rider not authenticated', 401);
            return;
        }
        $riderId = $this->resolveRiderId($userId);
        if (!$riderId) {
            $this->sendError('Rider profile not found', 404);
            return;
        }

        $query = "
            SELECT b.*, c.full_name as customer_name, c.phone as customer_phone, 
                   m.name as merchant_name, m.address as merchant_address
            FROM bookings b
            LEFT JOIN customers c ON b.customer_id = c.id
            LEFT JOIN merchants m ON b.merchant_id = m.id
            WHERE b.rider_id = ? AND b.status IN ('accepted','picked_up','on_the_way')
            ORDER BY b.updated_at DESC
            LIMIT 1
        ";
        $stmt = $this->db->prepare($query);
        $stmt->execute([$riderId]);
        $delivery = $stmt->fetch(PDO::FETCH_ASSOC);
        $this->sendSuccess(['delivery' => $delivery]);
    }

    private function acceptBooking($data) {
        session_start();
        $userId = $_SESSION['user_id'] ?? null;
        if (!$userId) {
            $this->sendError('Rider not authenticated', 401);
            return;
        }
        $riderId = $this->resolveRiderId($userId);
        if (!$riderId) {
            $this->sendError('Rider profile not found', 404);
            return;
        }

        if (!isset($data['booking_id'])) {
            $this->sendError('Booking ID is required', 400);
            return;
        }
        $bookingId = (int)$data['booking_id'];

        $checkStmt = $this->db->prepare("SELECT * FROM bookings WHERE id = ? AND status = 'pending' AND rider_id IS NULL");
        $checkStmt->execute([$bookingId]);
        $booking = $checkStmt->fetch(PDO::FETCH_ASSOC);
        if (!$booking) {
            $this->sendError('Booking not available', 400);
            return;
        }

        $updateStmt = $this->db->prepare("UPDATE bookings SET rider_id = ?, status = 'accepted', accepted_at = NOW(), updated_at = NOW() WHERE id = ?");
        if ($updateStmt->execute([$riderId, $bookingId])) {
            // Ensure rider is marked online
            $ru = $this->db->prepare("UPDATE riders SET is_online = 1, updated_at = NOW() WHERE id = ?");
            $ru->execute([$riderId]);
            $this->sendSuccess([], 'Booking accepted successfully');
        } else {
            $this->sendError('Failed to accept booking', 500);
        }
    }

    private function updateLocation($data) {
        session_start();
        $userId = $_SESSION['user_id'] ?? null;
        if (!$userId) {
            $this->sendError('Rider not authenticated', 401);
            return;
        }
        $riderId = $this->resolveRiderId($userId);
        if (!$riderId) {
            $this->sendError('Rider profile not found', 404);
            return;
        }
        if (!isset($data['latitude']) || !isset($data['longitude'])) {
            $this->sendError('Latitude and longitude are required', 400);
            return;
        }
        $stmt = $this->db->prepare("UPDATE riders SET current_lat = ?, current_lng = ?, updated_at = NOW() WHERE id = ?");
        if ($stmt->execute([$data['latitude'], $data['longitude'], $riderId])) {
            $this->sendSuccess([], 'Location updated successfully');
        } else {
            $this->sendError('Failed to update location', 500);
        }
    }

    private function updateBookingStatus($data) {
        session_start();
        $userId = $_SESSION['user_id'] ?? null;
        if (!$userId) {
            $this->sendError('Rider not authenticated', 401);
            return;
        }
        $riderId = $this->resolveRiderId($userId);
        if (!$riderId) {
            $this->sendError('Rider profile not found', 404);
            return;
        }
        if (!isset($data['booking_id']) || !isset($data['status'])) {
            $this->sendError('Booking ID and status are required', 400);
            return;
        }
        $bookingId = (int)$data['booking_id'];
        $status = $data['status'];
        $allowed = ['picked_up','on_the_way','delivered'];
        if (!in_array($status, $allowed, true)) {
            $this->sendError('Invalid status', 400);
            return;
        }

        $updateFields = [];
        $params = [];
        switch ($status) {
            case 'picked_up':
                $updateFields[] = 'status = ?';
                $params[] = 'picked_up';
                $updateFields[] = 'picked_up_at = NOW()';
                break;
            case 'on_the_way':
                $updateFields[] = 'status = ?';
                $params[] = 'on_the_way';
                break;
            case 'delivered':
                $updateFields[] = 'status = ?';
                $params[] = 'delivered';
                $updateFields[] = 'delivered_at = NOW()';
                break;
        }
        $updateFields[] = 'updated_at = NOW()';
        $params[] = $bookingId;

        $sql = 'UPDATE bookings SET ' . implode(', ', $updateFields) . ' WHERE id = ?';
        $stmt = $this->db->prepare($sql);
        if ($stmt->execute($params)) {
            $this->sendSuccess([], 'Booking status updated successfully');
        } else {
            $this->sendError('Failed to update booking status', 500);
        }
    }

    private function toggleAvailability($data) {
        session_start();
        $userId = $_SESSION['user_id'] ?? null;
        if (!$userId) {
            $this->sendError('Rider not authenticated', 401);
            return;
        }
        $riderId = $this->resolveRiderId($userId);
        if (!$riderId) {
            $this->sendError('Rider profile not found', 404);
            return;
        }
        $isAvailable = $data['is_available'] ?? null;
        if ($isAvailable === null) {
            $this->sendError('Availability status is required', 400);
            return;
        }
        $stmt = $this->db->prepare('UPDATE riders SET is_online = ?, updated_at = NOW() WHERE id = ?');
        if ($stmt->execute([$isAvailable ? 1 : 0, $riderId])) {
            $this->sendSuccess(['is_online' => (bool)$isAvailable], 'Availability updated successfully');
        } else {
            $this->sendError('Failed to update availability', 500);
        }
    }

    private function getRiderProfile() {
        session_start();
        $userId = $_SESSION['user_id'] ?? null;
        if (!$userId) {
            $this->sendError('Rider not authenticated', 401);
            return;
        }
        $query = "
            SELECT 
                r.id AS rider_id,
                r.user_id,
                u.full_name,
                u.phone,
                u.email,
                r.license_number,
                r.vehicle_type,
                r.vehicle_plate,
                r.vehicle_model,
                r.is_online,
                r.current_lat,
                r.current_lng,
                r.rating,
                r.total_deliveries,
                r.acceptance_rate,
                r.emergency_contact,
                r.emergency_name,
                r.created_at,
                r.updated_at
            FROM riders r
            INNER JOIN users u ON r.user_id = u.id
            WHERE u.id = ?
            LIMIT 1
        ";
        $stmt = $this->db->prepare($query);
        $stmt->execute([$userId]);
        $profile = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$profile) {
            $this->sendError('Rider not found', 404);
            return;
        }
        $this->sendSuccess(['rider' => $profile]);
    }

    private function sendSuccess($data = [], $message = 'Success') {
        echo json_encode([
            'success' => true,
            'message' => $message,
            'data' => $data
        ]);
    }

    private function sendError($message, $code = 400) {
        http_response_code($code);
        echo json_encode([
            'success' => false,
            'message' => $message,
            'error_code' => $code
        ]);
    }
}

$api = new RidersAPI();
$api->handleRequest();
?>
