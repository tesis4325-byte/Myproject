<?php
// Simple geocoding proxy to Nominatim with server-side User-Agent
require_once __DIR__ . '/../config/Database.php'; // ensure autoload/env; DB not used but keeps consistency
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

$action = $_GET['action'] ?? '';

function send_json($ok, $data = null, $message = '') {
    echo json_encode(['success' => $ok, 'data' => $data, 'message' => $message]);
    exit;
}

function http_get_json($url, $params) {
    $full = $url . (strpos($url, '?') !== false ? '&' : '?') . http_build_query($params);
    $ch = curl_init($full);
    $headers = [
        'Accept: application/json',
        // Identify your application per Nominatim usage policy
        'User-Agent: RMDelivery/1.0 (+https://example.com; admin@yourdomain.local)'
    ];
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_CONNECTTIMEOUT => 5,
        CURLOPT_TIMEOUT => 10,
        CURLOPT_HTTPHEADER => $headers,
    ]);
    $res = curl_exec($ch);
    if ($res === false) {
        $err = curl_error($ch);
        curl_close($ch);
        throw new Exception('HTTP request failed: ' . $err);
    }
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($code >= 400) {
        throw new Exception('Upstream error code: ' . $code);
    }
    $json = json_decode($res, true);
    if ($json === null) {
        throw new Exception('Invalid JSON from upstream');
    }
    return $json;
}

try {
    switch ($action) {
        case 'reverse':
            $lat = isset($_GET['lat']) ? floatval($_GET['lat']) : null;
            $lng = isset($_GET['lng']) ? floatval($_GET['lng']) : null;
            if ($lat === null || $lng === null) {
                send_json(false, null, 'lat and lng required');
            }
            $json = http_get_json('https://nominatim.openstreetmap.org/reverse', [
                'format' => 'json',
                'lat' => $lat,
                'lon' => $lng
            ]);
            $address = $json['display_name'] ?? '';
            if (!$address) {
                send_json(false, null, 'Address not found for coordinates');
            }
            send_json(true, [
                'address' => $address,
                'details' => $json['address'] ?? new stdClass()
            ]);
            break;
        case 'search':
            $q = trim($_GET['q'] ?? '');
            if ($q === '') {
                send_json(false, null, 'q required');
            }
            $json = http_get_json('https://nominatim.openstreetmap.org/search', [
                'format' => 'json',
                'q' => $q,
                'countrycodes' => 'ph',
                'limit' => 5
            ]);
            $results = [];
            foreach ($json as $r) {
                $results[] = [
                    'lat' => isset($r['lat']) ? floatval($r['lat']) : null,
                    'lng' => isset($r['lon']) ? floatval($r['lon']) : null,
                    'display_name' => $r['display_name'] ?? '',
                    'address' => $r['display_name'] ?? ''
                ];
            }
            if (empty($results)) {
                send_json(false, [], 'Address not found');
            }
            send_json(true, ['results' => $results]);
            break;
        default:
            send_json(false, null, 'Invalid action');
    }
} catch (Exception $e) {
    send_json(false, null, $e->getMessage());
}
