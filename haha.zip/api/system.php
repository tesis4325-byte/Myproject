<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

require_once '../config/Database.php';

class SystemAPI {
    private $db;

    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }

    public function handleRequest() {
        $method = $_SERVER['REQUEST_METHOD'];
        $action = $_GET['action'] ?? '';
        try {
            if ($method !== 'GET') {
                return $this->sendError('Method not allowed', 405);
            }
            switch ($action) {
                case 'users':
                    return $this->getUsers();
                case 'security_settings':
                    return $this->getSecuritySettings();
                case 'system_settings':
                    return $this->getSystemSettings();
                case 'logs':
                    return $this->getLogs();
                case 'export_logs':
                    return $this->exportLogs();
                default:
                    return $this->sendError('Invalid action', 404);
            }
        } catch (Exception $e) {
            return $this->sendError($e->getMessage(), 500);
        }
    }

    private function getUsers() {
        // Basic list of users; UI filters by role client-side
        $sql = "SELECT id, username, email, role, status, created_at FROM users ORDER BY created_at DESC";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Map DB roles to UI roles for color coding
        $roleMap = [
            'super_admin' => 'admin',
            'admin' => 'admin',
            'finance' => 'manager',
            'dispatcher' => 'support',
            'rider' => 'support'
        ];

        $users = array_map(function($r) use ($roleMap) {
            $uiRole = $roleMap[$r['role']] ?? $r['role'];
            return [
                'id' => (int)$r['id'],
                'name' => $r['username'],
                'email' => $r['email'],
                'role' => $uiRole,
                'status' => $r['status'],
                'last_login' => null
            ];
        }, $rows);

        return $this->sendSuccess($users);
    }

    private function getSecuritySettings() {
        // Pull from system_settings if available; otherwise defaults
        $settings = $this->getSettings([ 
            'min_password_length' => 8,
            'require_uppercase' => true,
            'require_numbers' => true,
            'require_special_chars' => false,
            'session_timeout' => 30,
            'max_login_attempts' => 5,
            'lockout_duration' => 15,
            'enable_2fa' => false,
            'force_2fa' => false
        ]);
        return $this->sendSuccess($settings);
    }

    private function getSystemSettings() {
        $settings = $this->getSettings([
            'system_name' => 'RM Delivery System',
            'admin_email' => '',
            'timezone' => 'Asia/Manila',
            'email_notifications' => true,
            'sms_notifications' => false,
            'push_notifications' => true,
            'maintenance_mode' => false,
            'maintenance_message' => ''
        ]);
        return $this->sendSuccess($settings);
    }

    private function getSettings(array $defaults) {
        // system_settings table: setting_key, setting_value
        $sql = "SELECT setting_key, setting_value FROM system_settings";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $map = [];
        foreach ($rows as $r) {
            $map[$r['setting_key']] = $r['setting_value'];
        }
        // Build final settings with type coercion from strings
        $result = $defaults;
        foreach ($defaults as $k => $v) {
            if (array_key_exists($k, $map)) {
                $raw = $map[$k];
                if (is_bool($v)) {
                    $result[$k] = in_array(strtolower((string)$raw), ['1','true','yes','on'], true);
                } elseif (is_int($v)) {
                    $result[$k] = (int)$raw;
                } elseif (is_float($v)) {
                    $result[$k] = (float)$raw;
                } else {
                    $result[$k] = $raw;
                }
            }
        }
        return $result;
    }

    private function getLogs() {
        // Return recent activity logs from activity_logs table
        $sql = "SELECT id, user_id, action, table_name, created_at FROM activity_logs ORDER BY created_at DESC LIMIT 50";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $logs = array_map(function($r) {
            return [
                'type' => 'activity',
                'message' => ($r['action'] ?: 'activity') . ($r['table_name'] ? (' on ' . $r['table_name']) : ''),
                'details' => 'User ID: ' . ($r['user_id'] ?? 'N/A'),
                'created_at' => $r['created_at']
            ];
        }, $rows);

        return $this->sendSuccess($logs);
    }

    private function exportLogs() {
        $filename = 'system_logs_' . date('Y-m-d') . '.csv';
        return $this->sendSuccess([
            'download_url' => '/downloads/' . $filename,
            'filename' => $filename,
            'format' => 'csv'
        ], 'Export ready');
    }

    private function sendSuccess($data = [], $message = 'Success') {
        echo json_encode([
            'success' => true,
            'message' => $message,
            'data' => $data
        ]);
        return true;
    }

    private function sendError($message, $code = 400) {
        http_response_code($code);
        echo json_encode([
            'success' => false,
            'message' => $message,
            'error_code' => $code
        ]);
        return false;
    }
}

$api = new SystemAPI();
$api->handleRequest();
