<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

require_once '../config/Database.php';

class UploadsAPI {
    private $db;
    private $uploadDir;
    private $allowedTypes;
    private $maxFileSize;
    
    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
        $this->uploadDir = '../uploads/';
        $this->allowedTypes = [
            'image/jpeg', 'image/jpg', 'image/png', 'image/gif',
            'application/pdf', 'application/msword', 
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
        ];
        $this->maxFileSize = 5 * 1024 * 1024; // 5MB
        
        // Create upload directory if it doesn't exist
        if (!file_exists($this->uploadDir)) {
            mkdir($this->uploadDir, 0755, true);
        }
        
        // Create subdirectories
        $subdirs = ['profiles', 'documents', 'menus', 'merchants'];
        foreach ($subdirs as $subdir) {
            $path = $this->uploadDir . $subdir . '/';
            if (!file_exists($path)) {
                mkdir($path, 0755, true);
            }
        }
    }
    
    public function handleRequest() {
        $method = $_SERVER['REQUEST_METHOD'];
        $action = $_GET['action'] ?? '';
        
        try {
            switch ($method) {
                case 'POST':
                    $this->handlePost($action);
                    break;
                default:
                    $this->sendError('Method not allowed', 405);
            }
        } catch (Exception $e) {
            $this->sendError($e->getMessage(), 500);
        }
    }
    
    private function handlePost($action) {
        switch ($action) {
            case 'profile_image':
                $this->uploadProfileImage();
                break;
            case 'document':
                $this->uploadDocument();
                break;
            case 'menu_image':
                $this->uploadMenuImage();
                break;
            case 'merchant_image':
                $this->uploadMerchantImage();
                break;
            default:
                $this->sendError('Invalid action', 400);
        }
    }
    
    private function uploadProfileImage() {
        session_start();
        $userId = $_SESSION['user_id'] ?? null;
        $userType = $_SESSION['user_type'] ?? 'customer';
        
        if (!$userId) {
            $this->sendError('User not authenticated', 401);
            return;
        }
        
        if (!isset($_FILES['profile_image'])) {
            $this->sendError('No file uploaded', 400);
            return;
        }
        
        $file = $_FILES['profile_image'];
        
        // Validate file
        $validation = $this->validateFile($file, ['image/jpeg', 'image/jpg', 'image/png']);
        if (!$validation['valid']) {
            $this->sendError($validation['error'], 400);
            return;
        }
        
        // Generate unique filename
        $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
        $filename = $userType . '_' . $userId . '_' . time() . '.' . $extension;
        $uploadPath = $this->uploadDir . 'profiles/' . $filename;
        
        if (move_uploaded_file($file['tmp_name'], $uploadPath)) {
            // Update user profile with image path
            $table = $this->getUserTable($userType);
            $imagePath = 'uploads/profiles/' . $filename;
            
            $stmt = $this->db->prepare("UPDATE {$table} SET profile_image = ?, updated_at = NOW() WHERE id = ?");
            $stmt->execute([$imagePath, $userId]);
            
            $this->sendSuccess([
                'filename' => $filename,
                'path' => $imagePath,
                'url' => '../' . $imagePath
            ], 'Profile image uploaded successfully');
        } else {
            $this->sendError('Failed to upload file', 500);
        }
    }
    
    private function uploadDocument() {
        session_start();
        $userId = $_SESSION['user_id'] ?? null;
        $userType = $_SESSION['user_type'] ?? 'customer';
        
        if (!$userId) {
            $this->sendError('User not authenticated', 401);
            return;
        }
        
        if (!isset($_FILES['document'])) {
            $this->sendError('No file uploaded', 400);
            return;
        }
        
        $file = $_FILES['document'];
        $documentType = $_POST['document_type'] ?? 'general';
        
        // Validate file
        $validation = $this->validateFile($file);
        if (!$validation['valid']) {
            $this->sendError($validation['error'], 400);
            return;
        }
        
        // Generate unique filename
        $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
        $filename = $userType . '_' . $userId . '_' . $documentType . '_' . time() . '.' . $extension;
        $uploadPath = $this->uploadDir . 'documents/' . $filename;
        
        if (move_uploaded_file($file['tmp_name'], $uploadPath)) {
            // Save document record
            $documentPath = 'uploads/documents/' . $filename;
            
            $stmt = $this->db->prepare("
                INSERT INTO user_documents (user_id, user_type, document_type, filename, file_path, original_name, file_size, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, NOW())
            ");
            
            $stmt->execute([
                $userId,
                $userType,
                $documentType,
                $filename,
                $documentPath,
                $file['name'],
                $file['size']
            ]);
            
            $documentId = $this->db->lastInsertId();
            
            $this->sendSuccess([
                'document_id' => $documentId,
                'filename' => $filename,
                'path' => $documentPath,
                'url' => '../' . $documentPath,
                'document_type' => $documentType
            ], 'Document uploaded successfully');
        } else {
            $this->sendError('Failed to upload file', 500);
        }
    }
    
    private function uploadMenuImage() {
        session_start();
        $userId = $_SESSION['user_id'] ?? null;
        
        if (!$userId) {
            $this->sendError('User not authenticated', 401);
            return;
        }
        
        if (!isset($_FILES['menu_image'])) {
            $this->sendError('No file uploaded', 400);
            return;
        }
        
        $file = $_FILES['menu_image'];
        $menuId = $_POST['menu_id'] ?? null;
        
        // Validate file
        $validation = $this->validateFile($file, ['image/jpeg', 'image/jpg', 'image/png']);
        if (!$validation['valid']) {
            $this->sendError($validation['error'], 400);
            return;
        }
        
        // Generate unique filename
        $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
        $filename = 'menu_' . ($menuId ?? 'new') . '_' . time() . '.' . $extension;
        $uploadPath = $this->uploadDir . 'menus/' . $filename;
        
        if (move_uploaded_file($file['tmp_name'], $uploadPath)) {
            $imagePath = 'uploads/menus/' . $filename;
            
            // Update menu item if menu_id provided
            if ($menuId) {
                $stmt = $this->db->prepare("UPDATE menu_items SET image = ?, updated_at = NOW() WHERE id = ?");
                $stmt->execute([$imagePath, $menuId]);
            }
            
            $this->sendSuccess([
                'filename' => $filename,
                'path' => $imagePath,
                'url' => '../' . $imagePath
            ], 'Menu image uploaded successfully');
        } else {
            $this->sendError('Failed to upload file', 500);
        }
    }
    
    private function uploadMerchantImage() {
        session_start();
        $userId = $_SESSION['user_id'] ?? null;
        
        if (!$userId) {
            $this->sendError('User not authenticated', 401);
            return;
        }
        
        if (!isset($_FILES['merchant_image'])) {
            $this->sendError('No file uploaded', 400);
            return;
        }
        
        $file = $_FILES['merchant_image'];
        $merchantId = $_POST['merchant_id'] ?? null;
        
        // Validate file
        $validation = $this->validateFile($file, ['image/jpeg', 'image/jpg', 'image/png']);
        if (!$validation['valid']) {
            $this->sendError($validation['error'], 400);
            return;
        }
        
        // Generate unique filename
        $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
        $filename = 'merchant_' . ($merchantId ?? 'new') . '_' . time() . '.' . $extension;
        $uploadPath = $this->uploadDir . 'merchants/' . $filename;
        
        if (move_uploaded_file($file['tmp_name'], $uploadPath)) {
            $imagePath = 'uploads/merchants/' . $filename;
            
            // Update merchant if merchant_id provided
            if ($merchantId) {
                $stmt = $this->db->prepare("UPDATE merchants SET image = ?, updated_at = NOW() WHERE id = ?");
                $stmt->execute([$imagePath, $merchantId]);
            }
            
            $this->sendSuccess([
                'filename' => $filename,
                'path' => $imagePath,
                'url' => '../' . $imagePath
            ], 'Merchant image uploaded successfully');
        } else {
            $this->sendError('Failed to upload file', 500);
        }
    }
    
    private function validateFile($file, $allowedTypes = null) {
        if ($file['error'] !== UPLOAD_ERR_OK) {
            return ['valid' => false, 'error' => 'File upload error: ' . $file['error']];
        }
        
        if ($file['size'] > $this->maxFileSize) {
            return ['valid' => false, 'error' => 'File size exceeds maximum allowed size (5MB)'];
        }
        
        $allowedTypes = $allowedTypes ?? $this->allowedTypes;
        
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mimeType = finfo_file($finfo, $file['tmp_name']);
        finfo_close($finfo);
        
        if (!in_array($mimeType, $allowedTypes)) {
            return ['valid' => false, 'error' => 'File type not allowed'];
        }
        
        // Additional security checks
        $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $allowedExtensions = ['jpg', 'jpeg', 'png', 'gif', 'pdf', 'doc', 'docx'];
        
        if (!in_array($extension, $allowedExtensions)) {
            return ['valid' => false, 'error' => 'File extension not allowed'];
        }
        
        return ['valid' => true];
    }
    
    private function getUserTable($userType) {
        switch ($userType) {
            case 'admin':
                return 'users';
            case 'rider':
                return 'riders';
            case 'merchant':
                return 'merchants';
            case 'customer':
            default:
                return 'customers';
        }
    }
    
    private function sendSuccess($data = [], $message = 'Success') {
        echo json_encode([
            'success' => true,
            'message' => $message,
            'data' => $data
        ]);
    }
    
    private function sendError($message, $code = 400) {
        http_response_code($code);
        echo json_encode([
            'success' => false,
            'message' => $message,
            'error_code' => $code
        ]);
    }
}

$api = new UploadsAPI();
$api->handleRequest();
?>
