<?php
// public/track.php - Customer order tracking and rating page
session_start();
$bookingNumber = $_GET['booking'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Track Order - RM Delivery</title>
  <link rel="stylesheet" href="assets/css/style.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
  <style>
    body { font-family: system-ui, -apple-system, Segoe UI, Roboto, Arial, sans-serif; background: #f7f8fa; margin: 0; }
    .wrapper { max-width: 900px; margin: 24px auto; padding: 0 16px; }
    .card { background: #fff; border-radius: 12px; box-shadow: 0 4px 14px rgba(0,0,0,0.06); padding: 20px; margin-bottom: 16px; }
    .title { font-size: 20px; font-weight: 700; margin: 0 0 12px; }
    .track-form { display: flex; gap: 8px; }
    .track-form input { flex: 1; padding: 12px 14px; border: 1px solid #e4e6eb; border-radius: 10px; font-size: 16px; }
    .track-form button { padding: 12px 16px; border: 0; background: #2563eb; color:#fff; border-radius: 10px; cursor: pointer; font-weight: 600; }
    .grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 12px; }
    .row { display: flex; align-items: center; justify-content: space-between; padding: 10px 0; border-bottom: 1px dashed #eee; }
    .row:last-child { border-bottom: 0; }
    .label { color: #64748b; }
    .value { font-weight: 600; }
    .status-steps { display: flex; flex-wrap: wrap; gap: 10px; }
    .chip { padding: 8px 10px; border-radius: 999px; background: #f1f5f9; color:#334155; font-size: 14px; }
    .chip.active { background: #dcfce7; color:#166534; }
    .muted { color: #64748b; }
    .rating { display: flex; gap: 6px; font-size: 24px; color: #eab308; cursor: pointer; }
    .rating .star { color: #cbd5e1; }
    .rating .star.active { color: #eab308; }
    .success { color: #166534; background: #dcfce7; border: 1px solid #86efac; padding: 10px; border-radius: 8px; margin-top: 8px; display:none; }
    .error { color: #991b1b; background: #fee2e2; border: 1px solid #fecaca; padding: 10px; border-radius: 8px; margin-top: 8px; display:none; }
  </style>
</head>
<body>
  <div class="wrapper">
    <div class="card">
      <h2 class="title"><i class="fa fa-location-dot"></i> Track Your Order</h2>
      <form class="track-form" onsubmit="event.preventDefault(); doTrack();">
        <input type="text" id="bookingNumber" placeholder="Enter Booking Number (e.g., RM250828133709489)" value="<?php echo htmlspecialchars($bookingNumber); ?>" required />
        <button type="submit">Track</button>
      </form>
      <div id="trackError" class="error"></div>
    </div>

    <div id="result" style="display:none">
      <div class="card">
        <h3 class="title">Order Summary</h3>
        <div class="grid">
          <div class="row"><span class="label">Booking Number</span><span class="value" id="tNumber">-</span></div>
          <div class="row"><span class="label">Status</span><span class="value" id="tStatus">-</span></div>
          <div class="row"><span class="label">Restaurant</span><span class="value" id="tMerchant">-</span></div>
          <div class="row"><span class="label">Amount</span><span class="value" id="tAmount">-</span></div>
          <div class="row"><span class="label">Customer</span><span class="value" id="tCustomer">-</span></div>
          <div class="row"><span class="label">Phone</span><span class="value" id="tPhone">-</span></div>
          <div class="row"><span class="label">Delivery Address</span><span class="value" id="tAddress">-</span></div>
        </div>
        <div style="margin-top:12px">
          <div class="status-steps">
            <span class="chip" id="s_pending">Pending</span>
            <span class="chip" id="s_accepted">Accepted</span>
            <span class="chip" id="s_preparing">Preparing</span>
            <span class="chip" id="s_ready">Ready</span>
            <span class="chip" id="s_picked_up">Picked Up</span>
            <span class="chip" id="s_on_the_way">On The Way</span>
            <span class="chip" id="s_delivered">Delivered</span>
          </div>
          <p class="muted" style="margin-top:8px">Status updates automatically every 30s.</p>
        </div>
      </div>

      <div class="card" id="riderCard" style="display:none">
        <h3 class="title"><i class="fa fa-motorcycle"></i> Your Rider</h3>
        <div class="grid">
          <div class="row"><span class="label">Name</span><span class="value" id="riderName">-</span></div>
          <div class="row"><span class="label">Phone</span><span class="value" id="riderPhone">-</span></div>
        </div>
      </div>

      <div class="card" id="ratingCard" style="display:none">
        <h3 class="title"><i class="fa fa-star"></i> Rate Your Delivery</h3>
        <div class="rating" id="ratingStars">
          <i class="fa fa-star star" data-v="1"></i>
          <i class="fa fa-star star" data-v="2"></i>
          <i class="fa fa-star star" data-v="3"></i>
          <i class="fa fa-star star" data-v="4"></i>
          <i class="fa fa-star star" data-v="5"></i>
        </div>
        <textarea id="reviewText" rows="3" style="width:100%;margin-top:10px;padding:10px;border:1px solid #e4e6eb;border-radius:8px" placeholder="Share your feedback (optional)"></textarea>
        <button id="btnSubmitRating" style="margin-top:10px;padding:10px 14px;border:0;border-radius:10px;background:#16a34a;color:#fff;font-weight:600;cursor:pointer">Submit Rating</button>
        <div id="ratingOk" class="success">Thank you for your feedback!</div>
        <div id="ratingErr" class="error"></div>
      </div>
    </div>
  </div>

<script>
  let currentBookingNumber = '<?php echo htmlspecialchars($bookingNumber); ?>';
  let refreshTimer = null;
  let ratingValue = 0;

  document.addEventListener('DOMContentLoaded', () => {
    bindRating();
    if (currentBookingNumber) {
      doTrack();
    }
  });

  function bindRating() {
    const stars = document.querySelectorAll('#ratingStars .star');
    stars.forEach(star => {
      star.addEventListener('mouseover', () => paintStars(star.dataset.v));
      star.addEventListener('mouseleave', () => paintStars(ratingValue));
      star.addEventListener('click', () => { ratingValue = parseInt(star.dataset.v); paintStars(ratingValue); });
    });
    document.getElementById('btnSubmitRating').addEventListener('click', submitRating);
  }

  function paintStars(v) {
    const stars = document.querySelectorAll('#ratingStars .star');
    stars.forEach(star => star.classList.toggle('active', parseInt(star.dataset.v) <= v));
  }

  async function doTrack() {
    const bnInput = document.getElementById('bookingNumber');
    const bn = (bnInput.value || '').trim();
    if (!bn) return;
    currentBookingNumber = bn;
    try {
      const res = await fetch(`../api/bookings.php?action=track&booking_number=${encodeURIComponent(bn)}`);
      const json = await res.json();
      if (!json.success) throw new Error(json.message || 'Failed to track');
      renderResult(json.data.booking);
      // auto refresh
      if (refreshTimer) clearInterval(refreshTimer);
      refreshTimer = setInterval(() => doTrack(), 30000);
      document.getElementById('trackError').style.display = 'none';
    } catch (e) {
      const el = document.getElementById('trackError');
      el.textContent = e.message;
      el.style.display = 'block';
    }
  }

  function renderResult(b) {
    document.getElementById('result').style.display = 'block';
    document.getElementById('tNumber').textContent = b.booking_number;
    document.getElementById('tStatus').textContent = b.status;
    document.getElementById('tMerchant').textContent = b.merchant_name || '—';
    document.getElementById('tAmount').textContent = '₱' + Number(b.total_amount || 0).toFixed(2);
    document.getElementById('tCustomer').textContent = b.customer_name;
    document.getElementById('tPhone').textContent = b.customer_phone;
    document.getElementById('tAddress').textContent = b.delivery_address;

    // highlight steps
    const steps = ['pending','accepted','preparing','ready','picked_up','on_the_way','delivered'];
    steps.forEach(s => document.getElementById('s_'+s).classList.toggle('active', s === b.status));

    // rider info visible once rider is set and status beyond accepted
    const riderVisible = !!b.rider_id && ['accepted','picked_up','on_the_way','delivered'].includes(b.status);
    document.getElementById('riderCard').style.display = riderVisible ? 'block' : 'none';
    if (riderVisible) {
      document.getElementById('riderName').textContent = b.rider_name || 'Assigned Rider';
      document.getElementById('riderPhone').textContent = b.rider_phone || '—';
    }

    // rating allowed when delivered and not yet rated
    const canRate = b.status === 'delivered' && (!b.customer_rating || Number(b.customer_rating) <= 0);
    document.getElementById('ratingCard').style.display = canRate ? 'block' : 'none';
  }

  async function submitRating() {
    const err = document.getElementById('ratingErr');
    const ok = document.getElementById('ratingOk');
    err.style.display = 'none';
    ok.style.display = 'none';
    if (!ratingValue) {
      err.textContent = 'Please select a star rating';
      err.style.display = 'block';
      return;
    }
    try {
      const res = await fetch('../api/bookings.php?action=submit_rating', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ booking_number: currentBookingNumber, rating: ratingValue, review: document.getElementById('reviewText').value })
      });
      const json = await res.json();
      if (!json.success) throw new Error(json.message || 'Failed to submit rating');
      ok.style.display = 'block';
      // refresh status to hide rating card after submission
      setTimeout(() => doTrack(), 600);
    } catch (e) {
      err.textContent = e.message;
      err.style.display = 'block';
    }
  }
</script>
</body>
</html>
