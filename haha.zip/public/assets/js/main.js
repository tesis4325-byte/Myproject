// RM Delivery - Main JavaScript Functions
class RMDelivery {
    constructor() {
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.initializeComponents();
    }

    setupEventListeners() {
        // Modal close events
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('modal')) {
                this.closeModal();
            }
        });

        // Escape key to close modal
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                this.closeModal();
            }
        });

        // Form submissions
        document.addEventListener('submit', (e) => {
            if (e.target.classList.contains('booking-form')) {
                e.preventDefault();
                this.handleBookingSubmission(e.target);
            }
        });

        // Mobile menu toggle
        const toggleBtn = document.querySelector('.menu-toggle');
        const primaryNav = document.getElementById('primary-nav');
        if (toggleBtn && primaryNav) {
            toggleBtn.addEventListener('click', () => {
                const willOpen = !primaryNav.classList.contains('open');
                primaryNav.classList.toggle('open');
                toggleBtn.setAttribute('aria-expanded', String(willOpen));
            });

            // Close menu when a link is tapped
            primaryNav.addEventListener('click', (e) => {
                const a = e.target.closest('a');
                if (a && primaryNav.classList.contains('open')) {
                    primaryNav.classList.remove('open');
                    toggleBtn.setAttribute('aria-expanded', 'false');
                }
            });

            // Reset on resize (desktop)
            window.addEventListener('resize', () => {
                if (window.innerWidth > 768 && primaryNav.classList.contains('open')) {
                    primaryNav.classList.remove('open');
                    toggleBtn.setAttribute('aria-expanded', 'false');
                }
            });
        }

        // Collapsible section toggles (e.g., Services grid)
        document.querySelectorAll('.section-toggle').forEach(btn => {
            const targetSel = btn.getAttribute('data-target');
            const target = targetSel ? document.querySelector(targetSel) : null;
            if (!target) return;

            const setState = (open) => {
                target.classList.toggle('open', open);
                btn.setAttribute('aria-expanded', String(open));
                const icon = btn.querySelector('i');
                if (icon) icon.className = `fas ${open ? 'fa-chevron-up' : 'fa-chevron-down'}`;
                btn.lastChild && (btn.lastChild.nodeType === Node.TEXT_NODE) && (btn.lastChild.textContent = ` ${open ? 'Hide Services' : 'Show Services'}`);
                if (btn.lastChild && btn.lastChild.nodeType !== Node.TEXT_NODE) {
                    btn.appendChild(document.createTextNode(` ${open ? 'Hide Services' : 'Show Services'}`));
                }
            };

            // Initialize respecting existing state in HTML
            const init = () => {
                const htmlWantsOpen = target.classList.contains('open') || btn.getAttribute('aria-expanded') === 'true';
                const fallback = window.innerWidth > 768; // desktop open
                setState(htmlWantsOpen || fallback);
            };
            init();

            btn.addEventListener('click', () => {
                const willOpen = !target.classList.contains('open');
                setState(willOpen);
            });

            window.addEventListener('resize', () => {
                // Keep desktop expanded
                if (window.innerWidth > 768 && !target.classList.contains('open')) {
                    setState(true);
                }
            });
        });
    }

    initializeComponents() {
        // Initialize any components that need setup
        this.initializeAnimations();
    }

    initializeAnimations() {
        // Intersection Observer for fade-in animations
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.style.opacity = '1';
                    entry.target.style.transform = 'translateY(0)';
                }
            });
        }, observerOptions);

        // Observe all service cards
        document.querySelectorAll('.service-card').forEach(card => {
            card.style.opacity = '0';
            card.style.transform = 'translateY(30px)';
            card.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
            observer.observe(card);
        });
    }

    openService(serviceType) {
        const modal = document.getElementById('serviceModal');
        const modalTitle = document.getElementById('modalTitle');
        const modalBody = document.getElementById('modalBody');

        let title = '';
        let content = '';

        switch (serviceType) {
            case 'food':
                title = 'Food Delivery';
                content = this.getFoodDeliveryForm();
                break;
            case 'pickup':
                title = 'Pickup & Deliver';
                content = this.getPickupDeliveryForm();
                break;
            case 'bills':
                title = 'Pay Bills';
                content = this.getBillPaymentForm();
                break;
            case 'custom':
                title = 'Custom Request';
                content = this.getCustomRequestForm();
                break;
        }

        modalTitle.textContent = title;
        modalBody.innerHTML = content;
        modal.classList.add('show');
        document.body.style.overflow = 'hidden';

        // Initialize form components
        this.initializeFormComponents();
    }

    closeModal() {
        const modal = document.getElementById('serviceModal');
        modal.classList.remove('show');
        document.body.style.overflow = '';
    }

    getFoodDeliveryForm() {
        return `
            <form class="booking-form" data-type="food_delivery">
                <div class="form-group">
                    <label class="form-label">Select Restaurant</label>
                    <select class="form-control form-select" name="merchant_id" required>
                        <option value="">Choose a restaurant...</option>
                        <option value="1">Jollibee</option>
                        <option value="2">McDonald's</option>
                        <option value="3">KFC</option>
                        <option value="4">Pizza Hut</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Your Name</label>
                    <input type="text" class="form-control" name="customer_name" required>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Phone Number</label>
                    <input type="tel" class="form-control" name="customer_phone" required>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Delivery Address</label>
                    <textarea class="form-control" name="delivery_address" rows="3" required></textarea>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Special Instructions</label>
                    <textarea class="form-control" name="delivery_notes" rows="2" placeholder="Any special delivery instructions..."></textarea>
                </div>
                
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" onclick="rmDelivery.closeModal()">Cancel</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-shopping-cart"></i> Continue to Menu
                    </button>
                </div>
            </form>
        `;
    }

    getPickupDeliveryForm() {
        return `
            <form class="booking-form" data-type="pickup_deliver">
                <div class="form-group">
                    <label class="form-label">Your Name</label>
                    <input type="text" class="form-control" name="customer_name" required>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Phone Number</label>
                    <input type="tel" class="form-control" name="customer_phone" required>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Pickup Address</label>
                    <textarea class="form-control" name="pickup_address" rows="3" required></textarea>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Delivery Address</label>
                    <textarea class="form-control" name="delivery_address" rows="3" required></textarea>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Item Description</label>
                    <textarea class="form-control" name="item_description" rows="3" placeholder="Describe what needs to be picked up and delivered..." required></textarea>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Special Instructions</label>
                    <textarea class="form-control" name="delivery_notes" rows="2" placeholder="Any special handling or delivery instructions..."></textarea>
                </div>
                
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" onclick="rmDelivery.closeModal()">Cancel</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-shipping-fast"></i> Book Pickup
                    </button>
                </div>
            </form>
        `;
    }

    getBillPaymentForm() {
        return `
            <form class="booking-form" data-type="pay_bills">
                <div class="form-group">
                    <label class="form-label">Your Name</label>
                    <input type="text" class="form-control" name="customer_name" required>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Phone Number</label>
                    <input type="tel" class="form-control" name="customer_phone" required>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Bill Type</label>
                    <select class="form-control form-select" name="bill_type" required>
                        <option value="">Select bill type...</option>
                        <option value="electricity">Electricity</option>
                        <option value="water">Water</option>
                        <option value="internet">Internet</option>
                        <option value="cable">Cable TV</option>
                        <option value="phone">Phone</option>
                        <option value="other">Other</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Account Number</label>
                    <input type="text" class="form-control" name="account_number" required>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Amount to Pay</label>
                    <input type="number" class="form-control" name="amount" step="0.01" min="1" required>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Delivery Address</label>
                    <textarea class="form-control" name="delivery_address" rows="3" required></textarea>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Upload Bill (Optional)</label>
                    <input type="file" class="form-control" name="bill_image" accept="image/*">
                    <small class="text-muted">Upload a photo of your bill for reference</small>
                </div>
                
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" onclick="rmDelivery.closeModal()">Cancel</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-file-invoice-dollar"></i> Process Payment
                    </button>
                </div>
            </form>
        `;
    }

    getCustomRequestForm() {
        return `
            <form class="booking-form" data-type="custom_request">
                <div class="form-group">
                    <label class="form-label">Your Name</label>
                    <input type="text" class="form-control" name="customer_name" required>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Phone Number</label>
                    <input type="tel" class="form-control" name="customer_phone" required>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Request Description</label>
                    <textarea class="form-control" name="request_description" rows="4" placeholder="Describe your custom request in detail..." required></textarea>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Pickup Location (if applicable)</label>
                    <textarea class="form-control" name="pickup_address" rows="2" placeholder="Where should we pick up items?"></textarea>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Delivery Address</label>
                    <textarea class="form-control" name="delivery_address" rows="3" required></textarea>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Estimated Budget</label>
                    <input type="number" class="form-control" name="estimated_budget" step="0.01" min="1" placeholder="Your estimated budget for this request">
                </div>
                
                <div class="form-group">
                    <label class="form-label">Preferred Time</label>
                    <select class="form-control form-select" name="preferred_time">
                        <option value="">Any time</option>
                        <option value="morning">Morning (8AM - 12PM)</option>
                        <option value="afternoon">Afternoon (12PM - 5PM)</option>
                        <option value="evening">Evening (5PM - 8PM)</option>
                    </select>
                </div>
                
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" onclick="rmDelivery.closeModal()">Cancel</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-concierge-bell"></i> Submit Request
                    </button>
                </div>
            </form>
        `;
    }

    initializeFormComponents() {
        // Add any form-specific initialization here
        const fileInputs = document.querySelectorAll('input[type="file"]');
        fileInputs.forEach(input => {
            input.addEventListener('change', this.handleFileUpload);
        });
    }

    handleFileUpload(event) {
        const file = event.target.files[0];
        if (file) {
            // Validate file size (5MB max)
            if (file.size > 5 * 1024 * 1024) {
                Swal.fire({
                    icon: 'error',
                    title: 'File Too Large',
                    text: 'Please select a file smaller than 5MB'
                });
                event.target.value = '';
                return;
            }

            // Validate file type
            const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif'];
            if (!allowedTypes.includes(file.type)) {
                Swal.fire({
                    icon: 'error',
                    title: 'Invalid File Type',
                    text: 'Please select a valid image file (JPG, PNG, GIF)'
                });
                event.target.value = '';
                return;
            }
        }
    }

    async handleBookingSubmission(form) {
        const formData = new FormData(form);
        const bookingType = form.dataset.type;

        // Show loading
        Swal.fire({
            title: 'Processing...',
            text: 'Creating your booking',
            allowOutsideClick: false,
            showConfirmButton: false,
            willOpen: () => {
                Swal.showLoading();
            }
        });

        try {
            // Prepare booking data
            const bookingData = {
                type: bookingType,
                customer_name: formData.get('customer_name'),
                customer_phone: formData.get('customer_phone'),
                delivery_address: formData.get('delivery_address'),
                delivery_notes: formData.get('delivery_notes'),
                payment_method: 'cod'
            };

            // Add type-specific data
            switch (bookingType) {
                case 'food_delivery':
                    bookingData.merchant_id = formData.get('merchant_id');
                    break;
                case 'pickup_deliver':
                    bookingData.pickup_address = formData.get('pickup_address');
                    bookingData.items = [{
                        description: formData.get('item_description'),
                        quantity: 1
                    }];
                    break;
                case 'pay_bills':
                    bookingData.items = [{
                        type: 'bill_payment',
                        bill_type: formData.get('bill_type'),
                        account_number: formData.get('account_number'),
                        amount: parseFloat(formData.get('amount'))
                    }];
                    bookingData.subtotal = parseFloat(formData.get('amount'));
                    break;
                case 'custom_request':
                    bookingData.pickup_address = formData.get('pickup_address');
                    bookingData.items = [{
                        description: formData.get('request_description'),
                        estimated_budget: parseFloat(formData.get('estimated_budget') || 0),
                        preferred_time: formData.get('preferred_time')
                    }];
                    break;
            }

            // Submit booking
            const response = await fetch('/rmdelivery/api/bookings.php?action=create', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(bookingData)
            });

            const result = await response.json();

            if (result.success) {
                const data = result.data || {};
                const bookingId = data.booking_id || result.booking_id || data.booking_number || result.booking_number || 'N/A';
                const totalAmount = data.total_amount || result.total_amount || 0;
                Swal.fire({
                    icon: 'success',
                    title: 'Booking Created!',
                    html: `
                        <p>Your booking has been created successfully.</p>
                        <p><strong>Booking Number:</strong> ${bookingId}</p>
                        <p><strong>Total Amount:</strong> ₱${totalAmount}</p>
                        <p>You will receive a call from our rider shortly.</p>
                    `,
                    confirmButtonText: 'OK'
                }).then(() => {
                    this.closeModal();
                });
            } else {
                throw new Error(result.message || 'Booking creation failed');
            }

        } catch (error) {
            console.error('Booking error:', error);
            Swal.fire({
                icon: 'error',
                title: 'Booking Failed',
                text: error.message || 'Something went wrong. Please try again.'
            });
        }
    }

    // Utility functions
    formatCurrency(amount) {
        return new Intl.NumberFormat('en-PH', {
            style: 'currency',
            currency: 'PHP'
        }).format(amount);
    }

    formatDate(date) {
        return new Intl.DateTimeFormat('en-PH', {
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        }).format(new Date(date));
    }

    showNotification(message, type = 'info') {
        const toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3000,
            timerProgressBar: true,
            didOpen: (toast) => {
                toast.addEventListener('mouseenter', Swal.stopTimer);
                toast.addEventListener('mouseleave', Swal.resumeTimer);
            }
        });

        toast.fire({
            icon: type,
            title: message
        });
    }
}

// Global functions for backward compatibility
function openService(serviceType) {
    rmDelivery.openService(serviceType);
}

function closeModal() {
    rmDelivery.closeModal();
}

// Initialize the application
const rmDelivery = new RMDelivery();

// Export for module usage
if (typeof module !== 'undefined' && module.exports) {
    module.exports = RMDelivery;
}
