// RM Delivery - OpenStreetMap Integration (Customer Side)
class MapManager {
    constructor() {
        this.map = null;
        this.markers = [];
        this.currentLocationMarker = null;
        this.routeControl = null;
        // Center of the Philippines
        this.mindanaoCenter = [12.8797, 121.7740];
        this.defaultZoom = 6;
        this.init();
    }

    init() {
        // Load Leaflet CSS and JS if not already loaded
        this.loadLeafletResources();
    }

    loadLeafletResources() {
        // Check if Leaflet is already loaded
        if (typeof L !== 'undefined') {
            return;
        }

        // Load Leaflet CSS
        const leafletCSS = document.createElement('link');
        leafletCSS.rel = 'stylesheet';
        leafletCSS.href = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css';
        leafletCSS.integrity = 'sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY=';
        leafletCSS.crossOrigin = '';
        document.head.appendChild(leafletCSS);

        // Load Leaflet JS
        const leafletJS = document.createElement('script');
        leafletJS.src = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js';
        leafletJS.integrity = 'sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo=';
        leafletJS.crossOrigin = '';
        document.head.appendChild(leafletJS);

        // Load routing plugin
        const routingCSS = document.createElement('link');
        routingCSS.rel = 'stylesheet';
        routingCSS.href = 'https://unpkg.com/leaflet-routing-machine@3.2.12/dist/leaflet-routing-machine.css';
        document.head.appendChild(routingCSS);

        const routingJS = document.createElement('script');
        routingJS.src = 'https://unpkg.com/leaflet-routing-machine@3.2.12/dist/leaflet-routing-machine.js';
        document.head.appendChild(routingJS);
    }

    initializeMap(containerId, options = {}) {
        const defaultOptions = {
            center: this.mindanaoCenter,
            zoom: this.defaultZoom,
            zoomControl: true,
            scrollWheelZoom: true
        };

        const mapOptions = { ...defaultOptions, ...options };

        // Wait for Leaflet to load
        const initMap = () => {
            if (typeof L === 'undefined') {
                setTimeout(initMap, 100);
                return;
            }

            this.map = L.map(containerId, {
                center: mapOptions.center,
                zoom: mapOptions.zoom,
                zoomControl: mapOptions.zoomControl,
                scrollWheelZoom: mapOptions.scrollWheelZoom
            });

            // Add OpenStreetMap tiles
            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
                maxZoom: 19
            }).addTo(this.map);

            // Add click event listener
            this.map.on('click', (e) => {
                if (options.onMapClick) {
                    options.onMapClick(e.latlng);
                }
            });

            // Get user's current location if requested
            if (options.getCurrentLocation) {
                this.getCurrentLocation();
            }
        };

        initMap();
        return this.map;
    }

    getCurrentLocation() {
        if (!navigator.geolocation) {
            alerts.warning('Geolocation Not Supported', 'Your browser does not support geolocation.');
            return;
        }

        navigator.geolocation.getCurrentPosition(
            (position) => {
                const lat = position.coords.latitude;
                const lng = position.coords.longitude;
                // Accept locations anywhere in the Philippines (or abroad) without restriction
                this.setCurrentLocation(lat, lng);
                this.map.setView([lat, lng], 15);
            },
            (error) => {
                let message = 'Unable to get your current location.';
                switch (error.code) {
                    case error.PERMISSION_DENIED:
                        message = 'Location access denied. Please enable location services.';
                        break;
                    case error.POSITION_UNAVAILABLE:
                        message = 'Location information is unavailable.';
                        break;
                    case error.TIMEOUT:
                        message = 'Location request timed out.';
                        break;
                }
                alerts.warning('Location Error', message);
            },
            {
                enableHighAccuracy: true,
                timeout: 10000,
                maximumAge: 300000
            }
        );
    }

    setCurrentLocation(lat, lng) {
        if (this.currentLocationMarker) {
            this.map.removeLayer(this.currentLocationMarker);
        }

        const currentLocationIcon = L.divIcon({
            className: 'current-location-marker',
            html: '<div class="current-location-dot"></div>',
            iconSize: [20, 20],
            iconAnchor: [10, 10]
        });

        this.currentLocationMarker = L.marker([lat, lng], { icon: currentLocationIcon })
            .addTo(this.map)
            .bindPopup('Your Current Location')
            .openPopup();

        return this.currentLocationMarker;
    }

    addMarker(lat, lng, options = {}) {
        const defaultOptions = {
            draggable: false,
            popup: null,
            icon: null
        };

        const markerOptions = { ...defaultOptions, ...options };
        
        let marker;
        if (markerOptions.icon) {
            marker = L.marker([lat, lng], { 
                draggable: markerOptions.draggable,
                icon: markerOptions.icon 
            });
        } else {
            marker = L.marker([lat, lng], { 
                draggable: markerOptions.draggable 
            });
        }

        marker.addTo(this.map);

        if (markerOptions.popup) {
            marker.bindPopup(markerOptions.popup);
        }

        if (markerOptions.draggable) {
            marker.on('dragend', (e) => {
                const position = e.target.getLatLng();
                if (markerOptions.onDragEnd) {
                    markerOptions.onDragEnd(position);
                }
            });
        }

        this.markers.push(marker);
        return marker;
    }

    removeMarker(marker) {
        if (marker) {
            this.map.removeLayer(marker);
            const index = this.markers.indexOf(marker);
            if (index > -1) {
                this.markers.splice(index, 1);
            }
        }
    }

    clearMarkers() {
        this.markers.forEach(marker => {
            this.map.removeLayer(marker);
        });
        this.markers = [];
    }

    createCustomIcon(type) {
        const icons = {
            pickup: {
                html: '<i class="fas fa-map-marker-alt" style="color: #0EA5E9;"></i>',
                className: 'custom-marker pickup-marker'
            },
            delivery: {
                html: '<i class="fas fa-home" style="color: #10B981;"></i>',
                className: 'custom-marker delivery-marker'
            },
            rider: {
                html: '<i class="fas fa-motorcycle" style="color: #F59E0B;"></i>',
                className: 'custom-marker rider-marker'
            },
            restaurant: {
                html: '<i class="fas fa-utensils" style="color: #EF4444;"></i>',
                className: 'custom-marker restaurant-marker'
            }
        };

        const iconConfig = icons[type] || icons.pickup;
        
        return L.divIcon({
            className: iconConfig.className,
            html: iconConfig.html,
            iconSize: [30, 30],
            iconAnchor: [15, 30],
            popupAnchor: [0, -30]
        });
    }

    showRoute(startLat, startLng, endLat, endLng) {
        if (this.routeControl) {
            this.map.removeControl(this.routeControl);
        }

        // Wait for routing plugin to load
        const showRouting = () => {
            if (typeof L.Routing === 'undefined') {
                setTimeout(showRouting, 100);
                return;
            }

            this.routeControl = L.Routing.control({
                waypoints: [
                    L.latLng(startLat, startLng),
                    L.latLng(endLat, endLng)
                ],
                routeWhileDragging: false,
                addWaypoints: false,
                createMarker: function() { return null; }, // Don't create default markers
                lineOptions: {
                    styles: [{
                        color: '#0EA5E9',
                        weight: 5,
                        opacity: 0.8
                    }]
                }
            }).addTo(this.map);

            // Fit map to route bounds
            this.routeControl.on('routesfound', (e) => {
                const routes = e.routes;
                if (routes.length > 0) {
                    const bounds = L.latLngBounds(routes[0].coordinates);
                    this.map.fitBounds(bounds, { padding: [20, 20] });
                }
            });
        };

        showRouting();
    }

    removeRoute() {
        if (this.routeControl) {
            this.map.removeControl(this.routeControl);
            this.routeControl = null;
        }
    }

    // Geocoding functions
    async geocodeAddress(address) {
        try {
            const response = await fetch(`../api/geocode.php?action=search&q=${encodeURIComponent(address)}`);
            const result = await response.json();
            if (!result.success) throw new Error(result.message || 'Address not found');
            const list = result.data?.results || [];
            if (list.length === 0) throw new Error('Address not found');
            return list.map(r => ({ lat: r.lat, lng: r.lng, display_name: r.display_name || r.address, address: r.address }));
        } catch (error) {
            console.error('Geocoding error:', error);
            throw error;
        }
    }

    async reverseGeocode(lat, lng) {
        try {
            const response = await fetch(`../api/geocode.php?action=reverse&lat=${encodeURIComponent(lat)}&lng=${encodeURIComponent(lng)}`);
            const result = await response.json();
            if (!result.success) throw new Error(result.message || 'Address not found for coordinates');
            return { address: result.data?.address || '', details: result.data?.details || {} };
        } catch (error) {
            console.error('Reverse geocoding error:', error);
            throw error;
        }
    }

    // Distance calculation
    calculateDistance(lat1, lng1, lat2, lng2) {
        const R = 6371; // Earth's radius in kilometers
        const dLat = this.toRadians(lat2 - lat1);
        const dLng = this.toRadians(lng2 - lng1);
        
        const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                  Math.cos(this.toRadians(lat1)) * Math.cos(this.toRadians(lat2)) *
                  Math.sin(dLng / 2) * Math.sin(dLng / 2);
        
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        const distance = R * c;
        
        return distance;
    }

    toRadians(degrees) {
        return degrees * (Math.PI / 180);
    }

    // Address picker modal
    showAddressPicker(callback) {
        const modalHtml = `
            <div class="address-picker-modal">
                <div class="address-search">
                    <input type="text" id="address-search-input" class="form-control" placeholder="Search for an address...">
                    <button type="button" id="search-address-btn" class="btn btn-primary">Search</button>
                </div>
                <div id="map-container" style="height: 400px; margin: 1rem 0;"></div>
                <div class="selected-address">
                    <label class="form-label">Selected Address:</label>
                    <textarea id="selected-address" class="form-control" rows="2" readonly></textarea>
                </div>
            </div>
        `;

        Swal.fire({
            title: 'Select Address',
            html: modalHtml,
            width: '80%',
            showCancelButton: true,
            confirmButtonText: 'Use This Address',
            cancelButtonText: 'Cancel',
            didOpen: () => {
                // Initialize map in modal
                const modalMap = this.initializeMap('map-container', {
                    center: this.mindanaoCenter,
                    zoom: 10,
                    getCurrentLocation: true,
                    onMapClick: (latlng) => {
                        this.reverseGeocode(latlng.lat, latlng.lng)
                            .then(result => {
                                const container = Swal.getHtmlContainer();
                                const addrEl = container ? container.querySelector('#selected-address') : null;
                                if (addrEl) {
                                    addrEl.value = result.address;
                                }
                                // Add marker at selected location
                                this.clearMarkers();
                                this.addMarker(latlng.lat, latlng.lng, {
                                    popup: result.address,
                                    icon: this.createCustomIcon('delivery')
                                });
                            })
                            .catch(error => {
                                alerts.error('Geocoding Error', error?.message || 'Unable to get address for selected location');
                            });
                    }
                });

                // Search functionality
                const container = Swal.getHtmlContainer();
                const searchBtn = container ? container.querySelector('#search-address-btn') : null;
                const searchInput = container ? container.querySelector('#address-search-input') : null;
                const selectedAddr = container ? container.querySelector('#selected-address') : null;

                if (searchBtn) searchBtn.addEventListener('click', () => {
                    const searchTerm = searchInput ? searchInput.value : '';
                    if (searchTerm) {
                        this.geocodeAddress(searchTerm)
                            .then(results => {
                                if (results.length > 0) {
                                    const result = results[0];
                                    modalMap.setView([result.lat, result.lng], 15);
                                    if (selectedAddr) selectedAddr.value = result.address;
                                    
                                    this.clearMarkers();
                                    this.addMarker(result.lat, result.lng, {
                                        popup: result.address,
                                        icon: this.createCustomIcon('delivery')
                                    });
                                } else {
                                    alerts.warning('Address Not Found', 'No results found for the searched address');
                                }
                            })
                            .catch(error => {
                                alerts.error('Search Error', error?.message || 'Unable to search for address');
                            });
                    }
                });

                // Enter key search
                if (searchInput) searchInput.addEventListener('keypress', (e) => {
                    if (e.key === 'Enter' && searchBtn) {
                        searchBtn.click();
                    }
                });
            },
            preConfirm: () => {
                const container = Swal.getHtmlContainer();
                const selectedAddr = container ? container.querySelector('#selected-address') : null;
                const selectedAddress = selectedAddr ? selectedAddr.value : '';
                if (!selectedAddress) {
                    Swal.showValidationMessage('Please select an address');
                    return false;
                }
                return selectedAddress;
            }
        }).then((result) => {
            if (result.isConfirmed && callback) {
                callback(result.value);
            }
        });
    }

    // Utility function to resize map
    invalidateSize() {
        if (this.map) {
            setTimeout(() => {
                this.map.invalidateSize();
            }, 100);
        }
    }
}

// Add custom CSS for map markers
const mapStyles = `
<style>
.current-location-dot {
    width: 12px;
    height: 12px;
    background: #0EA5E9;
    border: 3px solid white;
    border-radius: 50%;
    box-shadow: 0 2px 4px rgba(0,0,0,0.3);
}

.custom-marker {
    background: white;
    border-radius: 50%;
    box-shadow: 0 2px 4px rgba(0,0,0,0.3);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 16px;
    border: 2px solid white;
}

.pickup-marker {
    background: rgba(14, 165, 233, 0.1);
}

.delivery-marker {
    background: rgba(16, 185, 129, 0.1);
}

.rider-marker {
    background: rgba(245, 158, 11, 0.1);
}

.restaurant-marker {
    background: rgba(239, 68, 68, 0.1);
}

.address-picker-modal .address-search {
    display: flex;
    gap: 0.5rem;
    margin-bottom: 1rem;
}

.address-picker-modal .address-search input {
    flex: 1;
}

.leaflet-routing-container {
    display: none;
}
</style>
`;

// Inject styles
document.head.insertAdjacentHTML('beforeend', mapStyles);

// Initialize global map manager
const mapManager = new MapManager();

// Export for global use
window.mapManager = mapManager;
