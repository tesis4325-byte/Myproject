// RM Delivery - SweetAlert Customizations
class AlertManager {
    constructor() {
        this.defaultConfig = {
            customClass: {
                popup: 'rm-alert-popup',
                header: 'rm-alert-header',
                title: 'rm-alert-title',
                content: 'rm-alert-content',
                confirmButton: 'rm-btn rm-btn-primary',
                cancelButton: 'rm-btn rm-btn-secondary'
            },
            buttonsStyling: false,
            showClass: {
                popup: 'animate__animated animate__fadeInUp animate__faster'
            },
            hideClass: {
                popup: 'animate__animated animate__fadeOutDown animate__faster'
            }
        };
    }

    // Success Alert
    success(title, message = '', options = {}) {
        return Swal.fire({
            ...this.defaultConfig,
            icon: 'success',
            title: title,
            text: message,
            confirmButtonText: 'Great!',
            ...options
        });
    }

    // Error Alert
    error(title, message = '', options = {}) {
        return Swal.fire({
            ...this.defaultConfig,
            icon: 'error',
            title: title,
            text: message,
            confirmButtonText: 'OK',
            ...options
        });
    }

    // Warning Alert
    warning(title, message = '', options = {}) {
        return Swal.fire({
            ...this.defaultConfig,
            icon: 'warning',
            title: title,
            text: message,
            confirmButtonText: 'OK',
            ...options
        });
    }

    // Info Alert
    info(title, message = '', options = {}) {
        return Swal.fire({
            ...this.defaultConfig,
            icon: 'info',
            title: title,
            text: message,
            confirmButtonText: 'Got it',
            ...options
        });
    }

    // Confirmation Dialog
    confirm(title, message = '', confirmText = 'Yes', cancelText = 'No', options = {}) {
        return Swal.fire({
            ...this.defaultConfig,
            icon: 'question',
            title: title,
            text: message,
            showCancelButton: true,
            confirmButtonText: confirmText,
            cancelButtonText: cancelText,
            reverseButtons: true,
            ...options
        });
    }

    // Delete Confirmation
    confirmDelete(itemName = 'this item', options = {}) {
        return Swal.fire({
            ...this.defaultConfig,
            icon: 'warning',
            title: 'Are you sure?',
            html: `You are about to delete <strong>${itemName}</strong>.<br>This action cannot be undone.`,
            showCancelButton: true,
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'Cancel',
            reverseButtons: true,
            customClass: {
                ...this.defaultConfig.customClass,
                confirmButton: 'rm-btn rm-btn-danger'
            },
            ...options
        });
    }

    // Loading Alert
    loading(title = 'Loading...', message = 'Please wait') {
        return Swal.fire({
            ...this.defaultConfig,
            title: title,
            text: message,
            allowOutsideClick: false,
            allowEscapeKey: false,
            showConfirmButton: false,
            willOpen: () => {
                Swal.showLoading();
            }
        });
    }

    // Toast Notification
    toast(message, type = 'info', position = 'top-end', timer = 3000) {
        const Toast = Swal.mixin({
            toast: true,
            position: position,
            showConfirmButton: false,
            timer: timer,
            timerProgressBar: true,
            customClass: {
                popup: 'rm-toast-popup',
                title: 'rm-toast-title'
            },
            didOpen: (toast) => {
                toast.addEventListener('mouseenter', Swal.stopTimer);
                toast.addEventListener('mouseleave', Swal.resumeTimer);
            }
        });

        return Toast.fire({
            icon: type,
            title: message
        });
    }

    // Input Dialog
    input(title, inputType = 'text', placeholder = '', options = {}) {
        return Swal.fire({
            ...this.defaultConfig,
            title: title,
            input: inputType,
            inputPlaceholder: placeholder,
            showCancelButton: true,
            confirmButtonText: 'Submit',
            cancelButtonText: 'Cancel',
            inputValidator: (value) => {
                if (!value) {
                    return 'This field is required!';
                }
            },
            ...options
        });
    }

    // Multi-step Form
    async multiStep(steps) {
        const results = {};
        
        for (let i = 0; i < steps.length; i++) {
            const step = steps[i];
            const result = await Swal.fire({
                ...this.defaultConfig,
                title: step.title,
                text: step.text,
                input: step.input || 'text',
                inputPlaceholder: step.placeholder || '',
                inputValue: step.defaultValue || '',
                showCancelButton: true,
                confirmButtonText: i === steps.length - 1 ? 'Finish' : 'Next',
                cancelButtonText: i === 0 ? 'Cancel' : 'Back',
                progressSteps: steps.map((_, index) => index + 1),
                currentProgressStep: i,
                inputValidator: step.validator || ((value) => {
                    if (!value) return 'This field is required!';
                })
            });

            if (result.isDismissed) {
                if (i === 0) {
                    return { cancelled: true };
                } else {
                    i -= 2; // Go back one step
                    continue;
                }
            }

            results[step.key] = result.value;
        }

        return { cancelled: false, data: results };
    }

    // Custom HTML Alert
    html(title, htmlContent, options = {}) {
        return Swal.fire({
            ...this.defaultConfig,
            title: title,
            html: htmlContent,
            confirmButtonText: 'OK',
            ...options
        });
    }

    // Booking Status Alert
    bookingStatus(status, bookingNumber, message = '') {
        let icon, title, color;
        
        switch (status) {
            case 'pending':
                icon = 'info';
                title = 'Booking Received';
                color = '#0EA5E9';
                break;
            case 'accepted':
                icon = 'success';
                title = 'Booking Accepted';
                color = '#10B981';
                break;
            case 'picked_up':
                icon = 'info';
                title = 'Order Picked Up';
                color = '#F59E0B';
                break;
            case 'on_the_way':
                icon = 'info';
                title = 'On The Way';
                color = '#8B5CF6';
                break;
            case 'delivered':
                icon = 'success';
                title = 'Delivered Successfully';
                color = '#10B981';
                break;
            case 'cancelled':
                icon = 'error';
                title = 'Booking Cancelled';
                color = '#EF4444';
                break;
            default:
                icon = 'info';
                title = 'Status Update';
                color = '#6B7280';
        }

        return Swal.fire({
            ...this.defaultConfig,
            icon: icon,
            title: title,
            html: `
                <div class="booking-status-alert">
                    <p><strong>Booking #${bookingNumber}</strong></p>
                    ${message ? `<p>${message}</p>` : ''}
                </div>
            `,
            confirmButtonText: 'OK',
            customClass: {
                ...this.defaultConfig.customClass,
                popup: `rm-alert-popup booking-status-${status}`
            }
        });
    }

    // Rating Dialog
    rating(title = 'Rate Your Experience', options = {}) {
        return Swal.fire({
            ...this.defaultConfig,
            title: title,
            html: `
                <div class="rating-container">
                    <div class="stars" id="rating-stars">
                        ${[1, 2, 3, 4, 5].map(i => 
                            `<i class="fas fa-star star" data-rating="${i}"></i>`
                        ).join('')}
                    </div>
                    <textarea id="rating-comment" class="form-control mt-3" placeholder="Leave a comment (optional)" rows="3"></textarea>
                </div>
            `,
            showCancelButton: true,
            confirmButtonText: 'Submit Rating',
            cancelButtonText: 'Skip',
            didOpen: () => {
                const stars = document.querySelectorAll('.star');
                let selectedRating = 0;

                stars.forEach((star, index) => {
                    star.addEventListener('click', () => {
                        selectedRating = index + 1;
                        updateStars(selectedRating);
                    });

                    star.addEventListener('mouseover', () => {
                        updateStars(index + 1);
                    });
                });

                document.getElementById('rating-stars').addEventListener('mouseleave', () => {
                    updateStars(selectedRating);
                });

                function updateStars(rating) {
                    stars.forEach((star, index) => {
                        if (index < rating) {
                            star.classList.add('active');
                        } else {
                            star.classList.remove('active');
                        }
                    });
                }
            },
            preConfirm: () => {
                const rating = document.querySelectorAll('.star.active').length;
                const comment = document.getElementById('rating-comment').value;
                
                if (rating === 0) {
                    Swal.showValidationMessage('Please select a rating');
                    return false;
                }
                
                return { rating, comment };
            },
            ...options
        });
    }

    // File Upload Progress
    uploadProgress(filename) {
        return Swal.fire({
            title: 'Uploading File',
            html: `
                <div class="upload-progress">
                    <p>Uploading: <strong>${filename}</strong></p>
                    <div class="progress-bar">
                        <div class="progress-fill" id="upload-progress-fill"></div>
                    </div>
                    <p id="upload-percentage">0%</p>
                </div>
            `,
            allowOutsideClick: false,
            allowEscapeKey: false,
            showConfirmButton: false
        });
    }

    updateUploadProgress(percentage) {
        const fill = document.getElementById('upload-progress-fill');
        const text = document.getElementById('upload-percentage');
        
        if (fill && text) {
            fill.style.width = `${percentage}%`;
            text.textContent = `${percentage}%`;
        }
    }

    // Network Error Alert
    networkError() {
        return this.error(
            'Connection Error',
            'Unable to connect to the server. Please check your internet connection and try again.',
            {
                confirmButtonText: 'Retry',
                showCancelButton: true,
                cancelButtonText: 'Cancel'
            }
        );
    }

    // Session Expired Alert
    sessionExpired() {
        return this.warning(
            'Session Expired',
            'Your session has expired. Please log in again to continue.',
            {
                confirmButtonText: 'Login',
                allowOutsideClick: false,
                allowEscapeKey: false
            }
        );
    }
}

// Initialize global alert manager
const alerts = new AlertManager();

// Add custom CSS for alerts
const alertStyles = `
<style>
.rm-alert-popup {
    font-family: 'Inter', sans-serif !important;
    border-radius: 1rem !important;
    box-shadow: 0 20px 25px -5px rgb(0 0 0 / 0.1), 0 8px 10px -6px rgb(0 0 0 / 0.1) !important;
}

.rm-alert-title {
    color: #1E293B !important;
    font-weight: 700 !important;
}

.rm-btn {
    padding: 0.75rem 1.5rem !important;
    border-radius: 0.5rem !important;
    font-weight: 600 !important;
    transition: all 0.3s ease !important;
    border: none !important;
}

.rm-btn-primary {
    background: linear-gradient(135deg, #0EA5E9, #1E3A8A) !important;
    color: white !important;
}

.rm-btn-secondary {
    background: white !important;
    color: #0EA5E9 !important;
    border: 2px solid #0EA5E9 !important;
}

.rm-btn-danger {
    background: #EF4444 !important;
    color: white !important;
}

.rm-toast-popup {
    border-radius: 0.75rem !important;
    box-shadow: 0 10px 15px -3px rgb(0 0 0 / 0.1) !important;
}

.rating-container {
    text-align: center;
    padding: 1rem 0;
}

.stars {
    font-size: 2rem;
    margin-bottom: 1rem;
}

.star {
    color: #E5E7EB;
    cursor: pointer;
    transition: color 0.2s ease;
    margin: 0 0.25rem;
}

.star:hover,
.star.active {
    color: #F59E0B;
}

.upload-progress {
    text-align: center;
    padding: 1rem 0;
}

.progress-bar {
    width: 100%;
    height: 8px;
    background: #E5E7EB;
    border-radius: 4px;
    overflow: hidden;
    margin: 1rem 0;
}

.progress-fill {
    height: 100%;
    background: linear-gradient(135deg, #0EA5E9, #1E3A8A);
    width: 0%;
    transition: width 0.3s ease;
}

.booking-status-alert {
    text-align: center;
    padding: 1rem 0;
}

.booking-status-pending .swal2-icon.swal2-info {
    border-color: #0EA5E9 !important;
    color: #0EA5E9 !important;
}

.booking-status-delivered .swal2-icon.swal2-success {
    border-color: #10B981 !important;
}

.booking-status-cancelled .swal2-icon.swal2-error {
    border-color: #EF4444 !important;
}
</style>
`;

// Inject styles
document.head.insertAdjacentHTML('beforeend', alertStyles);

// Export for global use
window.alerts = alerts;
