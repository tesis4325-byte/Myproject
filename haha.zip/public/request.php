<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Custom Request - RM Delivery</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/animations.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <!-- Header -->
    <header class="header">
        <div class="container">
            <div class="header-content">
            <a href="index.php" class="logo">
            <div class="logo-icon"><img src="assets/uploads/logo.png" alt="RM Delivery Logo"></div>
                    <span>RM Delivery Services</span>
                </a>
                <!-- Mobile Menu Toggle -->
                <button class="menu-toggle" aria-label="Toggle navigation" aria-expanded="false" aria-controls="primary-nav">
                    <i class="fas fa-bars"></i>
                </button>
                <nav id="primary-nav">
                    <ul class="nav-links">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="food.php">Food Delivery</a></li>
                        <li><a href="pickup.php">Pickup & Deliver</a></li>
                        <li><a href="bills.php">Pay Bills</a></li>
                    </ul>
                </nav>
            </div>
        </div>
    </header>

    <!-- Main Content -->
    <main style="padding: 2rem 0; min-height: calc(100vh - 200px);">
        <div class="container">
            <!-- Page Header -->
            <div class="text-center mb-4">
                <h1 class="animate-fade-in-up">Custom Request Service</h1>
                <p class="animate-fade-in-up delay-200">Have a special request? We'll make it happen!</p>
            </div>

            <!-- Service Examples -->
            <div class="card animate-fade-in-up delay-300" style="margin-bottom: 2rem;">
                <div class="card-header">
                    <h3><i class="fas fa-lightbulb"></i> What We Can Do For You</h3>
                </div>
                <div class="card-body">
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 1.5rem;">
                        <div class="example-card">
                            <div class="example-icon">
                                <i class="fas fa-shopping-bag"></i>
                            </div>
                            <h5>Shopping & Errands</h5>
                            <ul>
                                <li>Grocery shopping</li>
                                <li>Pharmacy runs</li>
                                <li>Gift purchases</li>
                                <li>Market visits</li>
                            </ul>
                        </div>
                        <div class="example-card">
                            <div class="example-icon">
                                <i class="fas fa-file-alt"></i>
                            </div>
                            <h5>Document Services</h5>
                            <ul>
                                <li>Document submission</li>
                                <li>Form filing</li>
                                <li>Certificate pickup</li>
                                <li>Legal documents</li>
                            </ul>
                        </div>
                        <div class="example-card">
                            <div class="example-icon">
                                <i class="fas fa-tools"></i>
                            </div>
                            <h5>Special Tasks</h5>
                            <ul>
                                <li>Queue assistance</li>
                                <li>Event setup help</li>
                                <li>Pet care errands</li>
                                <li>Emergency assistance</li>
                            </ul>
                        </div>
                        <div class="example-card">
                            <div class="example-icon">
                                <i class="fas fa-clock"></i>
                            </div>
                            <h5>Time-Sensitive</h5>
                            <ul>
                                <li>Last-minute needs</li>
                                <li>Urgent deliveries</li>
                                <li>Same-day services</li>
                                <li>Emergency requests</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Custom Request Form -->
            <div class="card animate-fade-in-up delay-400">
                <div class="card-header">
                    <h3><i class="fas fa-edit"></i> Submit Your Custom Request</h3>
                </div>
                <div class="card-body">
                    <form id="custom-request-form">
                        <!-- Customer Information -->
                        <div class="form-section">
                            <h4>Your Information</h4>
                            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 1rem;">
                                <div class="form-group">
                                    <label class="form-label">Full Name *</label>
                                    <input type="text" class="form-control" name="customer_name" required>
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Phone Number *</label>
                                    <input type="tel" class="form-control" name="customer_phone" required>
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Email (Optional)</label>
                                    <input type="email" class="form-control" name="customer_email">
                                </div>
                            </div>
                        </div>

                        <!-- Request Details -->
                        <div class="form-section">
                            <h4>Request Details</h4>
                            <div class="form-group">
                                <label class="form-label">Request Title *</label>
                                <input type="text" class="form-control" name="request_title" required placeholder="Brief title for your request">
                            </div>
                            <div class="form-group">
                                <label class="form-label">Detailed Description *</label>
                                <textarea class="form-control" name="request_description" rows="5" required placeholder="Please describe your request in detail. Include what you need done, where, when, and any specific requirements..."></textarea>
                            </div>
                            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem;">
                                <div class="form-group">
                                    <label class="form-label">Request Category</label>
                                    <select class="form-control form-select" name="request_category">
                                        <option value="">Select category...</option>
                                        <option value="shopping">Shopping & Errands</option>
                                        <option value="documents">Document Services</option>
                                        <option value="delivery">Special Delivery</option>
                                        <option value="assistance">Personal Assistance</option>
                                        <option value="emergency">Emergency Request</option>
                                        <option value="business">Business Services</option>
                                        <option value="other">Other</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Urgency Level</label>
                                    <select class="form-control form-select" name="urgency_level">
                                        <option value="standard">Standard (24-48 hours)</option>
                                        <option value="urgent">Urgent (Same day)</option>
                                        <option value="emergency">Emergency (ASAP)</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Estimated Duration</label>
                                    <select class="form-control form-select" name="estimated_duration">
                                        <option value="">Select duration...</option>
                                        <option value="30min">30 minutes or less</option>
                                        <option value="1hour">1 hour</option>
                                        <option value="2hours">2 hours</option>
                                        <option value="half_day">Half day (4 hours)</option>
                                        <option value="full_day">Full day (8 hours)</option>
                                        <option value="multiple_days">Multiple days</option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <!-- Location Information -->
                        <div class="form-section">
                            <h4>Location Information</h4>
                            <div class="form-group">
                                <label class="form-label">Service Location *</label>
                                <textarea class="form-control" name="service_location" rows="3" required placeholder="Where should the service be performed? Include complete address and landmarks..."></textarea>
                                <button type="button" class="btn btn-secondary btn-sm mt-2" onclick="selectServiceLocationFromMap()">
                                    <i class="fas fa-map-marker-alt"></i> Select from Map
                                </button>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Additional Locations</label>
                                <textarea class="form-control" name="additional_locations" rows="2" placeholder="Any other locations involved in this request (pickup points, delivery destinations, etc.)"></textarea>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Location Access Instructions</label>
                                <textarea class="form-control" name="location_instructions" rows="2" placeholder="How to access the location (gate codes, floor numbers, contact persons, etc.)"></textarea>
                            </div>
                        </div>

                        <!-- Requirements & Preferences -->
                        <div class="form-section">
                            <h4>Requirements & Preferences</h4>
                            <div class="form-group">
                                <label class="form-label">Special Requirements</label>
                                <div class="checkbox-group" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 0.5rem;">
                                    <label class="checkbox-label">
                                        <input type="checkbox" name="requirements[]" value="id_required"> ID Required
                                    </label>
                                    <label class="checkbox-label">
                                        <input type="checkbox" name="requirements[]" value="cash_handling"> Cash Handling
                                    </label>
                                    <label class="checkbox-label">
                                        <input type="checkbox" name="requirements[]" value="vehicle_needed"> Vehicle Needed
                                    </label>
                                    <label class="checkbox-label">
                                        <input type="checkbox" name="requirements[]" value="photo_proof"> Photo Proof Required
                                    </label>
                                    <label class="checkbox-label">
                                        <input type="checkbox" name="requirements[]" value="receipt_needed"> Receipt Collection
                                    </label>
                                    <label class="checkbox-label">
                                        <input type="checkbox" name="requirements[]" value="confidential"> Confidential Task
                                    </label>
                                </div>
                            </div>
                            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 1rem;">
                                <div class="form-group">
                                    <label class="form-label">Budget Range</label>
                                    <select class="form-control form-select" name="budget_range">
                                        <option value="">Select budget...</option>
                                        <option value="under_500">Under ₱500</option>
                                        <option value="500_1000">₱500 - ₱1,000</option>
                                        <option value="1000_2000">₱1,000 - ₱2,000</option>
                                        <option value="2000_5000">₱2,000 - ₱5,000</option>
                                        <option value="over_5000">Over ₱5,000</option>
                                        <option value="discuss">Discuss with agent</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Preferred Time</label>
                                    <select class="form-control form-select" name="preferred_time">
                                        <option value="">Any time</option>
                                        <option value="morning">Morning (8AM - 12PM)</option>
                                        <option value="afternoon">Afternoon (12PM - 5PM)</option>
                                        <option value="evening">Evening (5PM - 8PM)</option>
                                        <option value="specific">Specific time (mention in notes)</option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <!-- Contact & Communication -->
                        <div class="form-section">
                            <h4>Communication Preferences</h4>
                            <div class="form-group">
                                <label class="form-label">How should we contact you?</label>
                                <div class="checkbox-group" style="display: flex; gap: 1rem; flex-wrap: wrap;">
                                    <label class="checkbox-label">
                                        <input type="checkbox" name="contact_methods[]" value="call" checked> Phone Call
                                    </label>
                                    <label class="checkbox-label">
                                        <input type="checkbox" name="contact_methods[]" value="sms"> SMS
                                    </label>
                                    <label class="checkbox-label">
                                        <input type="checkbox" name="contact_methods[]" value="email"> Email
                                    </label>
                                    <label class="checkbox-label">
                                        <input type="checkbox" name="contact_methods[]" value="whatsapp"> WhatsApp
                                    </label>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Best Time to Contact You</label>
                                <input type="text" class="form-control" name="best_contact_time" placeholder="e.g., Weekdays 9AM-5PM, Anytime, etc.">
                            </div>
                            <div class="form-group">
                                <label class="form-label">Additional Notes</label>
                                <textarea class="form-control" name="additional_notes" rows="3" placeholder="Any other information that would help us serve you better..."></textarea>
                            </div>
                        </div>

                        <!-- File Attachments -->
                        <div class="form-section">
                            <h4>Supporting Files (Optional)</h4>
                            <div class="form-group">
                                <label class="form-label">Upload Reference Files</label>
                                <input type="file" class="form-control" name="reference_files" accept="image/*,.pdf,.doc,.docx" multiple>
                                <small class="form-text">Upload any reference images, documents, or files that would help explain your request</small>
                            </div>
                        </div>

                        <!-- Submit Button -->
                        <div class="text-center">
                            <button type="submit" class="btn btn-primary btn-lg">
                                <i class="fas fa-paper-plane"></i> Submit Custom Request
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </main>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h4>RM Delivery Services</h4>
                    <h5 style=\"margin-top: 0.75rem;\">Mission</h5>
                    <p>To provide fast, reliable, and hassle-free delivery services in Tagum City and nearby areas from food, parcels, groceries, to special requests ensuring every customer experiences convenience and trust with every ride.</p>
                    <h5>Vision</h5>
                    <p>To be the most trusted and go-to delivery partner in Davao del Norte, known for excellent service, professional riders, and innovative solutions that make daily transactions easier for every Filipino household.</p>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2024 RM Delivery. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <script src="assets/js/main.js"></script>
    <script src="assets/js/alerts.js"></script>
    <script src="assets/js/map.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    
    <script>
        class CustomRequest {
            constructor() {
                this.init();
            }

            init() {
                this.setupEventListeners();
            }

            setupEventListeners() {
                document.getElementById('custom-request-form').addEventListener('submit', (e) => {
                    e.preventDefault();
                    this.submitRequest();
                });
            }

            async submitRequest() {
                const formData = new FormData(document.getElementById('custom-request-form'));
                
                // Validate required fields
                if (!formData.get('customer_name') || !formData.get('customer_phone') || 
                    !formData.get('request_title') || !formData.get('request_description') || 
                    !formData.get('service_location')) {
                    alerts.warning('Missing Information', 'Please fill in all required fields.');
                    return;
                }

                // Collect checkbox values
                const requirements = [];
                document.querySelectorAll('input[name="requirements[]"]:checked').forEach(checkbox => {
                    requirements.push(checkbox.value);
                });

                const contactMethods = [];
                document.querySelectorAll('input[name="contact_methods[]"]:checked').forEach(checkbox => {
                    contactMethods.push(checkbox.value);
                });

                const requestData = {
                    type: 'custom_request',
                    customer_name: formData.get('customer_name'),
                    customer_phone: formData.get('customer_phone'),
                    customer_email: formData.get('customer_email'),
                    request_title: formData.get('request_title'),
                    request_description: formData.get('request_description'),
                    request_category: formData.get('request_category'),
                    urgency_level: formData.get('urgency_level'),
                    estimated_duration: formData.get('estimated_duration'),
                    // API requires a delivery_address; map service_location to delivery_address
                    delivery_address: formData.get('service_location'),
                    delivery_notes: formData.get('additional_notes'),
                    additional_locations: formData.get('additional_locations'),
                    location_instructions: formData.get('location_instructions'),
                    requirements: requirements,
                    budget_range: formData.get('budget_range'),
                    preferred_time: formData.get('preferred_time'),
                    contact_methods: contactMethods,
                    best_contact_time: formData.get('best_contact_time'),
                    // Basic fees to ensure totals compute server-side
                    payment_method: 'cod',
                    delivery_fee: 50,
                    service_fee: 0
                };

                alerts.loading('Processing Request', 'Please wait while we review your custom request...');

                try {
                    // Real API call
                    const resp = await fetch('../api/bookings.php', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify(requestData)
                    });
                    const json = await resp.json();
                    if (!json.success) throw new Error(json.message || 'Request failed');

                    const bookingNumber = json.data && json.data.booking_number ? json.data.booking_number : 'N/A';
                    const totalAmount = json.data && json.data.total_amount ? parseFloat(json.data.total_amount) : 50; // default to delivery fee

                    const urgencyText = {
                        'standard': 'Standard (24-48 hours)',
                        'urgent': 'Urgent (Same day)',
                        'emergency': 'Emergency (ASAP)'
                    };

                    alerts.success('Request Submitted Successfully!', '', {
                        html: `
                            <div class="request-success">
                                <p><strong>Booking Number:</strong> ${bookingNumber}</p>
                                <p><strong>Service:</strong> ${requestData.request_title}</p>
                                <p><strong>Priority:</strong> ${urgencyText[requestData.urgency_level] || 'Standard'}</p>
                                <p><strong>Estimated Total:</strong> ₱${totalAmount.toFixed(2)}</p>
                                <p>Our team will review your request and contact you within 30 minutes to discuss details and provide a quote.</p>
                                <p><small>We'll call you at ${requestData.customer_phone}</small></p>
                            </div>
                        `,
                        confirmButtonText: 'Track Request'
                    }).then(() => {
                        this.resetForm();
                        window.location.href = 'index.php';
                    });

                } catch (error) {
                    console.error('Request submission error:', error);
                    alerts.error('Request Failed', 'Something went wrong. Please try again.');
                }
            }

            resetForm() {
                document.getElementById('custom-request-form').reset();
            }
        }

        function selectServiceLocationFromMap() {
            mapManager.showAddressPicker((address) => {
                document.querySelector('textarea[name="service_location"]').value = address;
            });
        }

        // Initialize custom request system
        const customRequest = new CustomRequest();
    </script>

    <style>
        .form-section {
            margin-bottom: 2rem;
            padding-bottom: 1.5rem;
            border-bottom: 1px solid var(--gray-200);
        }

        .form-section:last-child {
            border-bottom: none;
        }

        .form-section h4 {
            color: var(--gray-800);
            margin-bottom: 1rem;
            font-size: 1.25rem;
        }

        .example-card {
            background: var(--gray-50);
            padding: 1.5rem;
            border-radius: 0.5rem;
            border: 1px solid var(--gray-200);
        }

        .example-icon {
            width: 50px;
            height: 50px;
            background: var(--primary-color);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            margin-bottom: 1rem;
            font-size: 1.25rem;
        }

        .example-card h5 {
            margin-bottom: 0.75rem;
            color: var(--gray-800);
        }

        .example-card ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .example-card li {
            padding: 0.25rem 0;
            color: var(--gray-600);
            font-size: 0.9rem;
        }

        .example-card li:before {
            content: "✓";
            color: var(--success-color);
            margin-right: 0.5rem;
            font-weight: bold;
        }

        .checkbox-group {
            margin-top: 0.5rem;
        }

        .checkbox-label {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 0.9rem;
            color: var(--gray-700);
            cursor: pointer;
        }

        .checkbox-label input[type="checkbox"] {
            margin: 0;
        }

        .request-success {
            text-align: center;
            padding: 1rem 0;
        }

        .request-success p {
            margin-bottom: 0.5rem;
        }
    </style>
</body>
</html>
