<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Food Delivery - RM Delivery</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/animations.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <!-- Header -->
    <header class="header">
        <div class="container">
            <div class="header-content">
            <a href="index.php" class="logo">
            <div class="logo-icon"><img src="assets/uploads/logo.png" alt="RM Delivery Logo"></div>
                    <span>RM Delivery Services</span>
                </a>
                <!-- Mobile Menu Toggle -->
                <button class="menu-toggle" aria-label="Toggle navigation" aria-expanded="false" aria-controls="primary-nav">
                    <i class="fas fa-bars"></i>
                </button>
                <nav id="primary-nav">
                    <ul class="nav-links">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="pickup.php">Pickup & Deliver</a></li>
                        <li><a href="bills.php">Pay Bills</a></li>
                        <li><a href="request.php">Custom Request</a></li>
                    </ul>
                </nav>
            </div>
        </div>
    </header>

    <!-- Main Content -->
    <main style="padding: 2rem 0; min-height: calc(100vh - 200px);">
        <div class="container">
            <!-- Page Header -->
            <div class="text-center mb-4">
                <h1 class="animate-fade-in-up">Food Delivery</h1>
                <p class="animate-fade-in-up delay-200">Order from your favorite restaurants</p>
            </div>

            <!-- Restaurant Selection -->
            <div class="card animate-fade-in-up delay-300" style="margin-bottom: 2rem;">
                <div class="card-header">
                    <h3><i class="fas fa-utensils"></i> Select Restaurant</h3>
                </div>
                <div class="card-body">
                    <div id="restaurants-grid" class="services-grid">
                        <!-- Restaurants will be loaded here -->
                    </div>
                </div>
            </div>

            <!-- Order Form -->
            <div id="order-section" class="card animate-fade-in-up delay-400" style="display: none;">
                <div class="card-header">
                    <h3><i class="fas fa-shopping-cart"></i> Your Order</h3>
                    <div id="restaurant-info"></div>
                </div>
                <div class="card-body">
                    <!-- Menu Items -->
                    <div id="menu-items" class="mb-4">
                        <!-- Menu will be loaded here -->
                    </div>

                    <!-- Cart -->
                    <div id="cart-section" style="display: none;">
                        <h4>Order Summary</h4>
                        <div id="cart-items"></div>
                        <div class="cart-total">
                            <div class="d-flex justify-between">
                                <span>Subtotal:</span>
                                <span id="cart-subtotal">₱0.00</span>
                            </div>
                            <div class="d-flex justify-between">
                                <span>Delivery Fee:</span>
                                <span id="cart-delivery-fee">₱50.00</span>
                            </div>
                            <div class="d-flex justify-between" style="font-weight: bold; border-top: 1px solid var(--gray-300); padding-top: 0.5rem; margin-top: 0.5rem;">
                                <span>Total:</span>
                                <span id="cart-total">₱50.00</span>
                            </div>
                        </div>
                    </div>

                    <!-- Customer Information Form -->
                    <form id="food-order-form" style="display: none; margin-top: 2rem;">
                        <h4>Delivery Information</h4>
                        <div class="form-group">
                            <label class="form-label">Your Name *</label>
                            <input type="text" class="form-control" name="customer_name" required>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Phone Number *</label>
                            <input type="tel" class="form-control" name="customer_phone" required>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Email (Optional)</label>
                            <input type="email" class="form-control" name="customer_email">
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Delivery Address *</label>
                            <textarea class="form-control" name="delivery_address" rows="3" required></textarea>
                            <button type="button" class="btn btn-secondary btn-sm mt-2" onclick="selectAddressFromMap()">
                                <i class="fas fa-map-marker-alt"></i> Select from Map
                            </button>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Special Instructions</label>
                            <textarea class="form-control" name="delivery_notes" rows="2" placeholder="Any special delivery instructions..."></textarea>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Payment Method</label>
                            <select class="form-control form-select" name="payment_method" required>
                                <option value="cod">Cash on Delivery</option>
                                <option value="online">Online Payment</option>
                            </select>
                        </div>
                        
                        <div class="d-flex gap-3">
                            <button type="button" class="btn btn-secondary" onclick="goBackToMenu()">
                                <i class="fas fa-arrow-left"></i> Back to Menu
                            </button>
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-check"></i> Place Order
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </main>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h4>RM Delivery Services</h4>
                    <h5 style="margin-top: 0.75rem;">Mission</h5>
                    <p>To provide fast, reliable, and hassle-free delivery services in Tagum City and nearby areas from food, parcels, groceries, to special requests ensuring every customer experiences convenience and trust with every ride.</p>
                    <h5>Vision</h5>
                    <p>To be the most trusted and go-to delivery partner in Davao del Norte, known for excellent service, professional riders, and innovative solutions that make daily transactions easier for every Filipino household.</p>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2024 RM Delivery. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <script src="assets/js/main.js"></script>
    <script src="assets/js/alerts.js"></script>
    <script src="assets/js/map.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    
    <script>
        class FoodDelivery {
            constructor() {
                this.selectedRestaurant = null;
                this.cart = [];
                this.init();
            }

            init() {
                this.loadRestaurants();
                this.setupEventListeners();
            }

            // Ensure image URLs resolve under the app base (e.g., http://localhost/rmdelivery)
            resolveImageUrl(path) {
                if (!path) return '';
                path = String(path).trim();
                if (/^https?:\/\//i.test(path)) return path; // full URL

                const pathname = window.location.pathname || '';
                const base = pathname.includes('/public/') ? pathname.substring(0, pathname.indexOf('/public/')) : '';

                // Absolute-from-root: /admin/assets/images/...
                if (path.startsWith('/')) return base + path;

                // Relative admin path without leading slash
                if (path.startsWith('admin/')) return `${base}/${path}`;

                // Bare filename (no slashes) -> assume uploaded menu image
                // Default to /uploads/menus since menu images are stored there
                if (!path.includes('/')) return `${base}/uploads/menus/${path}`;

                // Other relative paths under project
                return `${base}/${path}`;
            }

            setupEventListeners() {
                document.getElementById('food-order-form').addEventListener('submit', (e) => {
                    e.preventDefault();
                    this.submitOrder();
                });
            }

            async loadRestaurants() {
                try {
                    const resp = await fetch('../api/merchants.php?action=list&status=active&limit=100');
                    const json = await resp.json();
                    if (!json.success) throw new Error(json.message || 'Failed to load');
                    const merchants = (json.data && json.data.merchants) ? json.data.merchants : [];
                    const restaurants = merchants.map(m => ({
                        id: parseInt(m.id),
                        name: m.name,
                        description: m.description || m.address || '',
                        image: m.logo || '',
                        rating: m.avg_rating ? parseFloat(m.avg_rating) : (m.rating ? parseFloat(m.rating) : 4.3),
                        delivery_time: '20-40 mins',
                        is_open: (m.is_active == 1) || (m.status === 'active')
                    }));
                    this.renderRestaurants(restaurants);
                } catch (error) {
                    console.error('Error loading restaurants:', error);
                    alerts.error('Error', 'Failed to load restaurants');
                }
            }

            renderRestaurants(restaurants) {
                const grid = document.getElementById('restaurants-grid');
                grid.innerHTML = restaurants.map(restaurant => `
                    <div class="service-card ${!restaurant.is_open ? 'opacity-50' : ''}" 
                         onclick="foodDelivery.selectRestaurant(${restaurant.id})"
                         style="cursor: ${restaurant.is_open ? 'pointer' : 'not-allowed'}">
                        <div class="service-icon" style="background: ${restaurant.is_open ? 'linear-gradient(135deg, var(--primary-color), var(--secondary-color))' : 'var(--gray-400)'}">
                            ${restaurant.image 
                                ? `<img src="${this.resolveImageUrl(restaurant.image)}" alt="${restaurant.name} logo" onerror="this.outerHTML='\\u003Ci class=\\'fas fa-utensils\\'\\u003E\\u003C/i\\u003E'">`
                                : `<i class=\"fas fa-utensils\"></i>`}
                        </div>
                        <h3>${restaurant.name}</h3>
                        <p>${restaurant.description}</p>
                        <div class="restaurant-info">
                            <div class="d-flex justify-between align-center mb-2">
                                <span><i class="fas fa-star" style="color: #F59E0B;"></i> ${restaurant.rating}</span>
                                <span><i class="fas fa-clock"></i> ${restaurant.delivery_time}</span>
                            </div>
                            <span class="status ${restaurant.is_open ? 'text-success' : 'text-danger'}">
                                ${restaurant.is_open ? 'Open' : 'Closed'}
                            </span>
                        </div>
                    </div>
                `).join('');
            }

            async selectRestaurant(restaurantId) {
                const restaurant = await this.getRestaurantById(restaurantId);
                if (!restaurant.is_open) {
                    alerts.warning('Restaurant Closed', 'This restaurant is currently closed.');
                    return;
                }

                this.selectedRestaurant = restaurant;
                await this.loadMenu(restaurantId);
                
                document.getElementById('restaurant-info').innerHTML = `
                    <div class="selected-restaurant">
                        <h4>${restaurant.name}</h4>
                        <p>${restaurant.description}</p>
                    </div>
                `;
                
                document.getElementById('order-section').style.display = 'block';
                document.getElementById('order-section').scrollIntoView({ behavior: 'smooth' });
            }

            async getRestaurantById(id) {
                try {
                    const resp = await fetch(`../api/merchants.php?action=details&merchant_id=${id}`);
                    const json = await resp.json();
                    if (!json.success) throw new Error(json.message || 'Failed to load');
                    const m = json.data && json.data.merchant ? json.data.merchant : null;
                    if (!m) throw new Error('Merchant not found');
                    return {
                        id: parseInt(m.id),
                        name: m.name,
                        description: m.description || m.address || '',
                        is_open: (m.is_active == 1) || (m.status === 'active')
                    };
                } catch (e) {
                    console.error(e);
                    alerts.error('Error', 'Failed to load restaurant');
                    return { id, name: 'Restaurant', description: '', is_open: false };
                }
            }

            async loadMenu(restaurantId) {
                try {
                    const resp = await fetch(`../api/menus.php?action=by_merchant&merchant_id=${restaurantId}`);
                    const json = await resp.json();
                    if (!json.success) throw new Error(json.message || 'Failed to load');
                    const items = (json.data && json.data.menu_items) ? json.data.menu_items : [];
                    const menuItems = items.map(i => ({
                        id: parseInt(i.id),
                        name: i.name,
                        description: i.description || '',
                        price: parseFloat(i.price),
                        category: i.category || i.category_name || 'Menu',
                        image: i.image || ''
                    }));
                    this.renderMenu(menuItems);
                } catch (error) {
                    console.error('Error loading menu:', error);
                    alerts.error('Error', 'Failed to load menu');
                }
            }

            renderMenu(menuItems) {
                const container = document.getElementById('menu-items');
                const categories = [...new Set(menuItems.map(item => item.category))];
                
                container.innerHTML = categories.map(category => {
                    const categoryItems = menuItems.filter(item => item.category === category);
                    return `
                        <div class="menu-category mb-4">
                            <h5 class="mb-3">${category}</h5>
                            <div class="menu-items-grid" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 1rem;">
                                ${categoryItems.map(item => `
                                    <div class="menu-item card">
                                        <div class="card-body">
                                            <div class="d-flex justify-between align-start" style="gap: 0.75rem;">
                                                <div class="menu-thumb" style="width: 72px; height: 72px; flex: 0 0 72px; border-radius: 8px; overflow: hidden; background: var(--gray-200); display: flex; align-items: center; justify-content: center;">
                                                    ${item.image
                                                        ? `<img src="${this.resolveImageUrl(item.image)}" alt="${item.name}" style="width: 100%; height: 100%; object-fit: cover;" onerror="this.outerHTML='\u003Cdiv class=\'text-muted\' style=\'font-size:12px\'\u003ENo Image\u003C/div\u003E'">`
                                                        : `<div class="text-muted" style="font-size:12px">No Image</div>`}
                                                </div>
                                                <div style="flex: 1; min-width: 0;">
                                                    <h6 style="margin: 0 0 4px;">${item.name}</h6>
                                                    <p class="text-muted" style="font-size: 0.9rem; margin: 0 0 0.5rem;">${item.description}</p>
                                                    <p class="price" style="font-weight: bold; color: var(--primary-color); margin: 0;">₱${item.price.toFixed(2)}</p>
                                                </div>
                                                <div class="quantity-controls" style="display: flex; align-items: center; gap: 0.5rem;">
                                                    <button type="button" class="btn btn-sm btn-secondary" onclick="foodDelivery.decreaseQuantity(${item.id})">-</button>
                                                    <span id="qty-${item.id}" style="min-width: 20px; text-align: center;">0</span>
                                                    <button type="button" class="btn btn-sm btn-primary" onclick="foodDelivery.increaseQuantity(${item.id}, '${item.name}', ${item.price})">+</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                `).join('')}
                            </div>
                        </div>
                    `;
                }).join('');
            }

            increaseQuantity(itemId, itemName, itemPrice) {
                const qtyElement = document.getElementById(`qty-${itemId}`);
                let currentQty = parseInt(qtyElement.textContent);
                currentQty++;
                qtyElement.textContent = currentQty;

                // Update cart
                const existingItem = this.cart.find(item => item.id === itemId);
                if (existingItem) {
                    existingItem.quantity = currentQty;
                } else {
                    this.cart.push({
                        id: itemId,
                        name: itemName,
                        price: itemPrice,
                        quantity: currentQty
                    });
                }

                this.updateCart();
            }

            decreaseQuantity(itemId) {
                const qtyElement = document.getElementById(`qty-${itemId}`);
                let currentQty = parseInt(qtyElement.textContent);
                
                if (currentQty > 0) {
                    currentQty--;
                    qtyElement.textContent = currentQty;

                    // Update cart
                    const existingItem = this.cart.find(item => item.id === itemId);
                    if (existingItem) {
                        if (currentQty === 0) {
                            this.cart = this.cart.filter(item => item.id !== itemId);
                        } else {
                            existingItem.quantity = currentQty;
                        }
                    }

                    this.updateCart();
                }
            }

            updateCart() {
                const cartSection = document.getElementById('cart-section');
                const cartItems = document.getElementById('cart-items');
                const orderForm = document.getElementById('food-order-form');

                if (this.cart.length === 0) {
                    cartSection.style.display = 'none';
                    orderForm.style.display = 'none';
                    return;
                }

                cartSection.style.display = 'block';
                
                cartItems.innerHTML = this.cart.map(item => `
                    <div class="cart-item d-flex justify-between align-center mb-2">
                        <div>
                            <span>${item.name}</span>
                            <small class="text-muted"> x${item.quantity}</small>
                        </div>
                        <span>₱${(item.price * item.quantity).toFixed(2)}</span>
                    </div>
                `).join('');

                const subtotal = this.cart.reduce((total, item) => total + (item.price * item.quantity), 0);
                const deliveryFee = 50;
                const total = subtotal + deliveryFee;

                document.getElementById('cart-subtotal').textContent = `₱${subtotal.toFixed(2)}`;
                document.getElementById('cart-total').textContent = `₱${total.toFixed(2)}`;

                // Show order form
                orderForm.style.display = 'block';
            }

            goBackToMenu() {
                document.getElementById('food-order-form').style.display = 'none';
                document.getElementById('menu-items').scrollIntoView({ behavior: 'smooth' });
            }

            async submitOrder() {
                if (this.cart.length === 0) {
                    alerts.warning('Empty Cart', 'Please add items to your cart before placing an order.');
                    return;
                }

                const formData = new FormData(document.getElementById('food-order-form'));
                
                const orderData = {
                    type: 'food_delivery',
                    merchant_id: this.selectedRestaurant.id,
                    customer_name: formData.get('customer_name'),
                    customer_phone: formData.get('customer_phone'),
                    customer_email: formData.get('customer_email'),
                    delivery_address: formData.get('delivery_address'),
                    delivery_notes: formData.get('delivery_notes'),
                    payment_method: formData.get('payment_method'),
                    items: this.cart.map(i => ({ id: i.id, item_name: i.name, price: i.price, quantity: i.quantity, total_price: i.price * i.quantity })),
                    subtotal: this.cart.reduce((total, item) => total + (item.price * item.quantity), 0),
                    delivery_fee: 50
                };

                alerts.loading('Processing Order', 'Please wait while we process your order...');

                try {
                    const resp = await fetch('../api/bookings.php', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify(orderData)
                    });
                    const json = await resp.json();
                    if (!json.success) throw new Error(json.message || 'Order failed');
                    const bookingNumber = json.data && json.data.booking_number ? json.data.booking_number : 'N/A';
                    const totalAmount = json.data && json.data.total_amount ? parseFloat(json.data.total_amount) : (orderData.subtotal + orderData.delivery_fee);

                    alerts.success('Order Placed Successfully!', '', {
                        html: `
                            <div class="order-success">
                                <p><strong>Booking Number:</strong> ${bookingNumber}</p>
                                <p><strong>Restaurant:</strong> ${this.selectedRestaurant.name}</p>
                                <p><strong>Total Amount:</strong> ₱${totalAmount.toFixed(2)}</p>
                                <p>Your order is being prepared. You'll receive a call from our rider shortly.</p>
                            </div>
                        `,
                        confirmButtonText: 'Track Order'
                    }).then(() => {
                        this.resetOrder();
                        window.location.href = 'index.php';
                    });

                } catch (error) {
                    console.error('Order submission error:', error);
                    alerts.error('Order Failed', 'Something went wrong. Please try again.');
                }
            }

            resetOrder() {
                this.cart = [];
                this.selectedRestaurant = null;
                document.getElementById('order-section').style.display = 'none';
                document.getElementById('food-order-form').reset();
                
                // Reset all quantity displays
                document.querySelectorAll('[id^="qty-"]').forEach(element => {
                    element.textContent = '0';
                });
            }
        }

        function selectAddressFromMap() {
            mapManager.showAddressPicker((address) => {
                document.querySelector('textarea[name="delivery_address"]').value = address;
            });
        }

        // Initialize food delivery system
        const foodDelivery = new FoodDelivery();
    </script>
</body>
</html>
