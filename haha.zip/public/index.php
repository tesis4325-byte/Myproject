<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RM Delivery - Fast & Reliable Delivery Service</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/animations.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <!-- Header -->
    <header class="header">
        <div class="container">
            <div class="header-content">
                <a href="index.php" class="logo">
                    <div class="logo-icon"><img src="assets/uploads/logo.png" alt="RM Delivery Logo"></div>
                    <span>RM Delivery Services</span>
                </a>
                <!-- Mobile Menu Toggle -->
                <button class="menu-toggle" aria-label="Toggle navigation" aria-expanded="false" aria-controls="primary-nav">
                    <i class="fas fa-bars"></i>
                </button>
                <nav id="primary-nav">
                    <ul class="nav-links">
                        <li><a href="#services">Services</a></li>
                        <li><a href="#about">About</a></li>
                        <li><a href="#contact">Contact</a></li>
                        <li><a href="track.php">Track Your Order</a></li>
                        <li><a href="http://localhost/rmdelivery/admin/index.php">Admin</a></li>
                        <li><a href="http://localhost/rmdelivery/rider/index.php">Rider</a></li>
                    </ul>
                </nav>
            </div>
        </div>
    </header>

    <!-- Hero Section -->
    <section class="hero">
        <div class="container">
            <div class="hero-content">
                <h1>Fast, Reliable Delivery Service</h1>
                <p>Your trusted partner for food delivery, pickup services, bill payments, and custom requests across the Tagum City</p>
            </div>
        </div>
    </section>

    <!-- Services Section -->
    <section class="services" id="services">
        <div class="container">
            <div class="text-center">
                <h2>Our Services</h2>
                <p>Choose from our wide range of delivery and service options</p>
            </div>
            
            <div class="services-grid" id="servicesGrid">
                <!-- Food Delivery -->
                <div class="service-card" onclick="window.location.href='http://localhost/rmdelivery/public/food.php'">
                    <div class="service-icon">
                        <i class="fas fa-utensils"></i>
                    </div>
                    <h3>Food Delivery</h3>
                    <p>Order from your favorite restaurants and get fresh, hot meals delivered to your doorstep</p>
                    <a href="http://localhost/rmdelivery/public/food.php" class="btn btn-primary">Order Food</a>
                </div>

                <!-- Pickup & Deliver -->
                <div class="service-card" onclick="window.location.href='http://localhost/rmdelivery/public/pickup.php'">
                    <div class="service-icon">
                        <i class="fas fa-shipping-fast"></i>
                    </div>
                    <h3>Pickup & Deliver</h3>
                    <p>Need something picked up and delivered? We'll handle it quickly and safely</p>
                    <a href="http://localhost/rmdelivery/public/pickup.php" class="btn btn-primary">Book Pickup</a>
                </div>

                <!-- Pay Bills -->
                <div class="service-card" onclick="window.location.href='http://localhost/rmdelivery/public/bills.php'">
                    <div class="service-icon">
                        <i class="fas fa-file-invoice-dollar"></i>
                    </div>
                    <h3>Pay Bills</h3>
                    <p>Pay your utility bills, internet, and other services through our convenient platform</p>
                    <a href="http://localhost/rmdelivery/public/bills.php" class="btn btn-primary">Pay Bills</a>
                </div>

                <!-- Custom Requests -->
                <div class="service-card" onclick="window.location.href='http://localhost/rmdelivery/public/request.php'">
                    <div class="service-icon">
                        <i class="fas fa-concierge-bell"></i>
                    </div>
                    <h3>Custom Requests</h3>
                    <p>Special requests? We're here to help with your unique delivery needs</p>
                    <a href="http://localhost/rmdelivery/public/request.php" class="btn btn-primary">Make Request</a>
                </div>
            </div>
        </div>
    </section>

    <!-- About Section -->
    <section class="about" id="about" style="padding: 4rem 0; background: var(--white);">
        <div class="container">
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 4rem; align-items: center;">
                <div>
                    <h2>Why Choose RM Delivery?</h2>
                    <div style="display: flex; flex-direction: column; gap: 1.5rem;">
                        <div style="display: flex; align-items: center; gap: 1rem;">
                            <div style="width: 50px; height: 50px; background: var(--primary-color); border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white;">
                                <i class="fas fa-clock"></i>
                            </div>
                            <div>
                                <h4>Fast Delivery</h4>
                                <p style="margin: 0; color: var(--gray-600);">Quick and efficient service across Mindanao</p>
                            </div>
                        </div>
                        <div style="display: flex; align-items: center; gap: 1rem;">
                            <div style="width: 50px; height: 50px; background: var(--success-color); border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white;">
                                <i class="fas fa-shield-alt"></i>
                            </div>
                            <div>
                                <h4>Safe & Secure</h4>
                                <p style="margin: 0; color: var(--gray-600);">Your items are handled with care and security</p>
                            </div>
                        </div>
                        <div style="display: flex; align-items: center; gap: 1rem;">
                            <div style="width: 50px; height: 50px; background: var(--warning-color); border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white;">
                                <i class="fas fa-map-marked-alt"></i>
                            </div>
                            <div>
                                <h4>Real-time Tracking</h4>
                                <p style="margin: 0; color: var(--gray-600);">Track your orders and deliveries in real-time</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div style="text-align: center;">
                    <div style="width: 300px; height: 300px; background: linear-gradient(135deg, var(--primary-color), var(--secondary-color)); border-radius: 50%; margin: 0 auto; display: flex; align-items: center; justify-content: center; overflow: hidden;">
                        <img src="assets/uploads/logo.png" alt="RM Delivery Logo" style="width: 88%; height: 88%; border-radius: 50%; object-fit: cover; display: block;" />
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Contact Section -->
    <section class="contact" id="contact" style="padding: 4rem 0; background: var(--light-bg);">
        <div class="container">
            <div class="text-center">
                <h2>Get In Touch</h2>
                <p>Have questions? We're here to help!</p>
            </div>
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 2rem; margin-top: 2rem;">
                <div class="card">
                    <div class="card-body text-center">
                        <div style="width: 60px; height: 60px; background: var(--primary-color); border-radius: 50%; margin: 0 auto 1rem; display: flex; align-items: center; justify-content: center; color: white;">
                            <i class="fas fa-phone"></i>
                        </div>
                        <h4>Call Us</h4>
                        <p>+63 912 345 6789</p>
                    </div>
                </div>
                <div class="card">
                    <div class="card-body text-center">
                        <div style="width: 60px; height: 60px; background: var(--success-color); border-radius: 50%; margin: 0 auto 1rem; display: flex; align-items: center; justify-content: center; color: white;">
                            <i class="fas fa-envelope"></i>
                        </div>
                        <h4>Email Us</h4>
                        <p>support@rmdelivery.com</p>
                    </div>
                </div>
                <div class="card">
                    <div class="card-body text-center">
                        <div style="width: 60px; height: 60px; background: var(--warning-color); border-radius: 50%; margin: 0 auto 1rem; display: flex; align-items: center; justify-content: center; color: white;">
                            <i class="fas fa-map-marker-alt"></i>
                        </div>
                        <h4>Visit Us</h4>
                        <p>Mindanao, Philippines</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h4>RM Delivery Services</h4>
                    <h5 style="margin-top: 0.75rem;">Mission</h5>
                    <p>To provide fast, reliable, and hassle-free delivery services in Tagum City and nearby areas from food, parcels, groceries, to special requests ensuring every customer experiences convenience and trust with every ride.</p>
                    <h5>Vision</h5>
                    <p>To be the most trusted and go-to delivery partner in Davao del Norte, known for excellent service, professional riders, and innovative solutions that make daily transactions easier for every Filipino household.</p>
                </div>
                <div class="footer-section">
                    <h4>Services</h4>
                    <p><a href="http://localhost/rmdelivery/public/food.php">Food Delivery</a></p>
                    <p><a href="http://localhost/rmdelivery/public/pickup.php">Pickup & Deliver</a></p>
                    <p><a href="http://localhost/rmdelivery/public/bills.php">Pay Bills</a></p>
                    <p><a href="http://localhost/rmdelivery/public/request.php">Custom Requests</a></p>
                </div>
                <div class="footer-section">
                    <h4>Support</h4>
                    <p><a href="#">Help Center</a></p>
                    <p><a href="#">Contact Us</a></p>
                    <p><a href="track.php">Track Order</a></p>
                    <p><a href="#">FAQ</a></p>
                </div>
                <div class="footer-section">
                    <h4>Connect</h4>
                    <p><a href="#">Facebook</a></p>
                    <p><a href="#">Twitter</a></p>
                    <p><a href="#">Instagram</a></p>
                    <p><a href="#">LinkedIn</a></p>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2021 RM Delivery Services. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <!-- Service Selection Modal -->
    <div id="serviceModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title" id="modalTitle">Select Service</h3>
                <button class="modal-close" onclick="closeModal()">&times;</button>
            </div>
            <div class="modal-body" id="modalBody">
                <!-- Content will be loaded dynamically -->
            </div>
        </div>
    </div>

    <script src="assets/js/main.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</body>
</html>
