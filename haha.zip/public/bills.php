<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pay Bills - RM Delivery</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/animations.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <!-- Header -->
    <header class="header">
        <div class="container">
            <div class="header-content">
            <a href="index.php" class="logo">
            <div class="logo-icon"><img src="assets/uploads/logo.png" alt="RM Delivery Logo"></div>
                    <span>RM Delivery Services</span>
                </a>
                <!-- Mobile Menu Toggle -->
                <button class="menu-toggle" aria-label="Toggle navigation" aria-expanded="false" aria-controls="primary-nav">
                    <i class="fas fa-bars"></i>
                </button>
                <nav id="primary-nav">
                    <ul class="nav-links">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="food.php">Food Delivery</a></li>
                        <li><a href="pickup.php">Pickup & Deliver</a></li>
                        <li><a href="request.php">Custom Request</a></li>
                    </ul>
                </nav>
            </div>
        </div>
    </header>

    <!-- Main Content -->
    <main style="padding: 2rem 0; min-height: calc(100vh - 200px);">
        <div class="container">
            <!-- Page Header -->
            <div class="text-center mb-4">
                <h1 class="animate-fade-in-up">Bill Payment Service</h1>
                <p class="animate-fade-in-up delay-200">Pay your bills conveniently through our delivery service</p>
            </div>

            <!-- Service Categories -->
            <div class="card animate-fade-in-up delay-300" style="margin-bottom: 2rem;">
                <div class="card-header">
                    <h3><i class="fas fa-credit-card"></i> Available Bill Payment Services</h3>
                </div>
                <div class="card-body">
                    <div class="services-grid">
                        <div class="service-card" onclick="selectBillType('utilities')">
                            <div class="service-icon" style="background: linear-gradient(135deg, #F59E0B, #D97706);">
                                <i class="fas fa-bolt"></i>
                            </div>
                            <h3>Utilities</h3>
                            <p>Electric, Water, Internet, Cable TV</p>
                        </div>
                        <div class="service-card" onclick="selectBillType('government')">
                            <div class="service-icon" style="background: linear-gradient(135deg, #10B981, #059669);">
                                <i class="fas fa-university"></i>
                            </div>
                            <h3>Government</h3>
                            <p>SSS, PhilHealth, Pag-IBIG, Taxes</p>
                        </div>
                        <div class="service-card" onclick="selectBillType('insurance')">
                            <div class="service-icon" style="background: linear-gradient(135deg, #8B5CF6, #7C3AED);">
                                <i class="fas fa-shield-alt"></i>
                            </div>
                            <h3>Insurance</h3>
                            <p>Life, Health, Auto, Property Insurance</p>
                        </div>
                        <div class="service-card" onclick="selectBillType('loans')">
                            <div class="service-icon" style="background: linear-gradient(135deg, #EF4444, #DC2626);">
                                <i class="fas fa-money-bill-wave"></i>
                            </div>
                            <h3>Loans & Credit</h3>
                            <p>Bank Loans, Credit Cards, Financing</p>
                        </div>
                        <div class="service-card" onclick="selectBillType('education')">
                            <div class="service-icon" style="background: linear-gradient(135deg, #06B6D4, #0891B2);">
                                <i class="fas fa-graduation-cap"></i>
                            </div>
                            <h3>Education</h3>
                            <p>School Fees, Tuition, Training</p>
                        </div>
                        <div class="service-card" onclick="selectBillType('other')">
                            <div class="service-icon" style="background: linear-gradient(135deg, #6B7280, #4B5563);">
                                <i class="fas fa-ellipsis-h"></i>
                            </div>
                            <h3>Other Bills</h3>
                            <p>Membership, Subscriptions, Others</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Bill Payment Form -->
            <div id="bill-payment-form" class="card animate-fade-in-up delay-400" style="display: none;">
                <div class="card-header">
                    <h3><i class="fas fa-file-invoice-dollar"></i> Bill Payment Details</h3>
                    <div id="selected-category"></div>
                </div>
                <div class="card-body">
                    <form id="payment-form">
                        <!-- Customer Information -->
                        <div class="form-section">
                            <h4>Your Information</h4>
                            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 1rem;">
                                <div class="form-group">
                                    <label class="form-label">Full Name *</label>
                                    <input type="text" class="form-control" name="customer_name" required>
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Phone Number *</label>
                                    <input type="tel" class="form-control" name="customer_phone" required>
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Email (Optional)</label>
                                    <input type="email" class="form-control" name="customer_email">
                                </div>
                            </div>
                        </div>

                        <!-- Bill Information -->
                        <div class="form-section">
                            <h4>Bill Information</h4>
                            <div class="form-group">
                                <label class="form-label">Bill Type/Company *</label>
                                <select class="form-control form-select" name="bill_company" id="bill-company" required>
                                    <option value="">Select company...</option>
                                </select>
                            </div>
                            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 1rem;">
                                <div class="form-group">
                                    <label class="form-label">Account Number/Reference *</label>
                                    <input type="text" class="form-control" name="account_number" required placeholder="Enter account number or reference">
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Account Name</label>
                                    <input type="text" class="form-control" name="account_name" placeholder="Name on the account">
                                </div>
                            </div>
                            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem;">
                                <div class="form-group">
                                    <label class="form-label">Amount to Pay *</label>
                                    <input type="number" class="form-control" name="amount" step="0.01" min="1" required placeholder="0.00">
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Due Date</label>
                                    <input type="date" class="form-control" name="due_date">
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Additional Notes</label>
                                <textarea class="form-control" name="bill_notes" rows="2" placeholder="Any additional information or special instructions"></textarea>
                            </div>
                        </div>

                        <!-- Payment Location -->
                        <div class="form-section">
                            <h4>Payment Location</h4>
                            <div class="form-group">
                                <label class="form-label">Where should we pay this bill? *</label>
                                <select class="form-control form-select" name="payment_location" required>
                                    <option value="">Select payment location...</option>
                                    <option value="bayad_center">Bayad Center</option>
                                    <option value="mlhuillier">M Lhuillier</option>
                                    <option value="cebuana">Cebuana Lhuillier</option>
                                    <option value="palawan">Palawan Pawnshop</option>
                                    <option value="sm_bills">SM Bills Payment</option>
                                    <option value="robinson_bills">Robinson's Bills Payment</option>
                                    <option value="bank">Bank Branch</option>
                                    <option value="company_office">Company Office</option>
                                    <option value="other">Other (specify in notes)</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Preferred Branch/Location</label>
                                <input type="text" class="form-control" name="preferred_branch" placeholder="Specific branch or location preference">
                            </div>
                        </div>

                        <!-- Delivery Information -->
                        <div class="form-section">
                            <h4>Receipt Delivery</h4>
                            <div class="form-group">
                                <label class="form-label">Delivery Address *</label>
                                <textarea class="form-control" name="delivery_address" rows="3" required placeholder="Where should we deliver the payment receipt?"></textarea>
                                <button type="button" class="btn btn-secondary btn-sm mt-2" onclick="selectAddressFromMap()">
                                    <i class="fas fa-map-marker-alt"></i> Select from Map
                                </button>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Delivery Instructions</label>
                                <textarea class="form-control" name="delivery_notes" rows="2" placeholder="Any special delivery instructions"></textarea>
                            </div>
                        </div>

                        <!-- Service Fee -->
                        <div class="form-section">
                            <h4>Service Information</h4>
                            <div class="alert alert-info">
                                <i class="fas fa-info-circle"></i>
                                <strong>Service Fee:</strong> ₱25 processing fee + ₱50 delivery fee. Total service charge: ₱75
                            </div>
                            <div class="form-group">
                                <label class="form-label">Payment Method for Service Fee</label>
                                <select class="form-control form-select" name="service_payment" required>
                                    <option value="cod">Cash on Delivery (pay when receipt is delivered)</option>
                                    <option value="online">Online Payment (pay now)</option>
                                </select>
                            </div>
                        </div>

                        <!-- File Upload -->
                        <div class="form-section">
                            <h4>Supporting Documents (Optional)</h4>
                            <div class="form-group">
                                <label class="form-label">Upload Bill Statement or Reference</label>
                                <input type="file" class="form-control" name="bill_document" accept="image/*,.pdf" multiple>
                                <small class="form-text">Upload photos of your bill statement for reference (JPG, PNG, PDF)</small>
                            </div>
                        </div>

                        <!-- Submit Button -->
                        <div class="text-center">
                            <button type="button" class="btn btn-secondary me-3" onclick="goBackToCategories()">
                                <i class="fas fa-arrow-left"></i> Back to Categories
                            </button>
                            <button type="submit" class="btn btn-primary btn-lg">
                                <i class="fas fa-credit-card"></i> Submit Payment Request
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </main>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h4>RM Delivery Services </h4>
                    <h5 style="margin-top: 0.75rem;">Mission</h5>
                    <p>To provide fast, reliable, and hassle-free delivery services in Tagum City and nearby areas from food, parcels, groceries, to special requests ensuring every customer experiences convenience and trust with every ride.</p>
                    <h5>Vision</h5>
                    <p>To be the most trusted and go-to delivery partner in Davao del Norte, known for excellent service, professional riders, and innovative solutions that make daily transactions easier for every Filipino household.</p>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2024 RM Delivery. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <script src="assets/js/main.js"></script>
    <script src="assets/js/alerts.js"></script>
    <script src="assets/js/map.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    
    <script>
        class BillPayment {
            constructor() {
                this.selectedCategory = null;
                this.billCompanies = {
                    utilities: [
                        { value: 'meralco', text: 'Meralco (Electric)' },
                        { value: 'maynilad', text: 'Maynilad (Water)' },
                        { value: 'manila_water', text: 'Manila Water' },
                        { value: 'pldt', text: 'PLDT' },
                        { value: 'globe', text: 'Globe Telecom' },
                        { value: 'smart', text: 'Smart Communications' },
                        { value: 'sky_cable', text: 'Sky Cable' },
                        { value: 'cignal', text: 'Cignal TV' }
                    ],
                    government: [
                        { value: 'sss', text: 'Social Security System (SSS)' },
                        { value: 'philhealth', text: 'PhilHealth' },
                        { value: 'pagibig', text: 'Pag-IBIG Fund' },
                        { value: 'bir', text: 'Bureau of Internal Revenue (BIR)' },
                        { value: 'lto', text: 'Land Transportation Office (LTO)' },
                        { value: 'nbi', text: 'National Bureau of Investigation (NBI)' },
                        { value: 'dfa', text: 'Department of Foreign Affairs (DFA)' }
                    ],
                    insurance: [
                        { value: 'philam', text: 'Philam Life' },
                        { value: 'sunlife', text: 'Sun Life Financial' },
                        { value: 'axa', text: 'AXA Philippines' },
                        { value: 'prudential', text: 'Prudential' },
                        { value: 'insular', text: 'Insular Life' },
                        { value: 'malayan', text: 'Malayan Insurance' }
                    ],
                    loans: [
                        { value: 'bpi', text: 'Bank of the Philippine Islands (BPI)' },
                        { value: 'bdo', text: 'Banco de Oro (BDO)' },
                        { value: 'metrobank', text: 'Metropolitan Bank' },
                        { value: 'pnb', text: 'Philippine National Bank (PNB)' },
                        { value: 'security_bank', text: 'Security Bank' },
                        { value: 'unionbank', text: 'Union Bank' },
                        { value: 'home_credit', text: 'Home Credit' },
                        { value: 'cashalo', text: 'Cashalo' }
                    ],
                    education: [
                        { value: 'up', text: 'University of the Philippines' },
                        { value: 'ateneo', text: 'Ateneo de Manila University' },
                        { value: 'dlsu', text: 'De La Salle University' },
                        { value: 'ust', text: 'University of Santo Tomas' },
                        { value: 'feu', text: 'Far Eastern University' },
                        { value: 'mapua', text: 'Mapua University' },
                        { value: 'tesda', text: 'TESDA' }
                    ],
                    other: [
                        { value: 'netflix', text: 'Netflix' },
                        { value: 'spotify', text: 'Spotify' },
                        { value: 'gym', text: 'Gym Membership' },
                        { value: 'condo', text: 'Condominium Association' },
                        { value: 'village', text: 'Village Association' },
                        { value: 'other_specify', text: 'Other (Please specify in notes)' }
                    ]
                };
                this.init();
            }

            init() {
                this.setupEventListeners();
            }

            setupEventListeners() {
                document.getElementById('payment-form').addEventListener('submit', (e) => {
                    e.preventDefault();
                    this.submitPayment();
                });
            }

            selectBillType(category) {
                this.selectedCategory = category;
                this.populateBillCompanies(category);
                this.showPaymentForm(category);
            }

            populateBillCompanies(category) {
                const select = document.getElementById('bill-company');
                const companies = this.billCompanies[category] || [];
                
                select.innerHTML = '<option value="">Select company...</option>';
                companies.forEach(company => {
                    const option = document.createElement('option');
                    option.value = company.value;
                    option.textContent = company.text;
                    select.appendChild(option);
                });
            }

            showPaymentForm(category) {
                const categoryNames = {
                    utilities: 'Utilities',
                    government: 'Government Services',
                    insurance: 'Insurance',
                    loans: 'Loans & Credit',
                    education: 'Education',
                    other: 'Other Bills'
                };

                document.getElementById('selected-category').innerHTML = `
                    <div class="selected-category">
                        <span class="badge badge-primary">${categoryNames[category]}</span>
                    </div>
                `;

                document.getElementById('bill-payment-form').style.display = 'block';
                document.getElementById('bill-payment-form').scrollIntoView({ behavior: 'smooth' });
            }

            goBackToCategories() {
                document.getElementById('bill-payment-form').style.display = 'none';
                document.getElementById('payment-form').reset();
                this.selectedCategory = null;
                window.scrollTo({ top: 0, behavior: 'smooth' });
            }

            async submitPayment() {
                const formData = new FormData(document.getElementById('payment-form'));
                
                // Validate required fields
                if (!formData.get('customer_name') || !formData.get('customer_phone') || 
                    !formData.get('bill_company') || !formData.get('account_number') || 
                    !formData.get('amount') || !formData.get('payment_location') || 
                    !formData.get('delivery_address')) {
                    alerts.warning('Missing Information', 'Please fill in all required fields.');
                    return;
                }

                const amount = parseFloat(formData.get('amount'));
                if (amount < 1) {
                    alerts.warning('Invalid Amount', 'Please enter a valid amount to pay.');
                    return;
                }

                const paymentData = {
                    type: 'bill_payment',
                    category: this.selectedCategory,
                    customer_name: formData.get('customer_name'),
                    customer_phone: formData.get('customer_phone'),
                    customer_email: formData.get('customer_email'),
                    bill_company: formData.get('bill_company'),
                    account_number: formData.get('account_number'),
                    account_name: formData.get('account_name'),
                    amount: amount,
                    due_date: formData.get('due_date'),
                    bill_notes: formData.get('bill_notes'),
                    payment_location: formData.get('payment_location'),
                    preferred_branch: formData.get('preferred_branch'),
                    delivery_address: formData.get('delivery_address'),
                    delivery_notes: formData.get('delivery_notes'),
                    payment_method: formData.get('service_payment'),
                    // Break down the service fee into processing (25) + delivery (50)
                    service_fee: 25,
                    delivery_fee: 50
                };

                alerts.loading('Processing Payment Request', 'Please wait while we process your bill payment request...');

                try {
                    // Real API call
                    const resp = await fetch('../api/bookings.php', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify(paymentData)
                    });
                    const json = await resp.json();
                    if (!json.success) throw new Error(json.message || 'Booking failed');

                    const bookingNumber = json.data && json.data.booking_number ? json.data.booking_number : 'N/A';
                    const totalAmount = json.data && json.data.total_amount ? parseFloat(json.data.total_amount) : (amount + 75);

                    alerts.success('Payment Request Submitted!', '', {
                        html: `
                            <div class="payment-success">
                                <p><strong>Booking Number:</strong> ${bookingNumber}</p>
                                <p><strong>Service:</strong> Bill Payment</p>
                                <p><strong>Bill Amount:</strong> ₱${amount.toFixed(2)}</p>
                                <p><strong>Total (incl. service):</strong> ₱${totalAmount.toFixed(2)}</p>
                                <p>We will process your bill payment and deliver the receipt to your specified address.</p>
                                <p><small>You will receive a confirmation call within 30 minutes.</small></p>
                            </div>
                        `,
                        confirmButtonText: 'Track Request'
                    }).then(() => {
                        this.resetForm();
                        window.location.href = 'index.php';
                    });

                } catch (error) {
                    console.error('Payment submission error:', error);
                    alerts.error('Payment Request Failed', 'Something went wrong. Please try again.');
                }
            }

            resetForm() {
                document.getElementById('payment-form').reset();
                document.getElementById('bill-payment-form').style.display = 'none';
                this.selectedCategory = null;
            }
        }

        function selectBillType(category) {
            billPayment.selectBillType(category);
        }

        function goBackToCategories() {
            billPayment.goBackToCategories();
        }

        function selectAddressFromMap() {
            mapManager.showAddressPicker((address) => {
                document.querySelector('textarea[name="delivery_address"]').value = address;
            });
        }

        // Initialize bill payment system
        const billPayment = new BillPayment();
    </script>

    <style>
        .form-section {
            margin-bottom: 2rem;
            padding-bottom: 1.5rem;
            border-bottom: 1px solid var(--gray-200);
        }

        .form-section:last-child {
            border-bottom: none;
        }

        .form-section h4 {
            color: var(--gray-800);
            margin-bottom: 1rem;
            font-size: 1.25rem;
        }

        .selected-category {
            margin-top: 0.5rem;
        }

        .badge {
            display: inline-block;
            padding: 0.25rem 0.5rem;
            font-size: 0.875rem;
            font-weight: 500;
            border-radius: 0.375rem;
        }

        .badge-primary {
            background-color: var(--primary-color);
            color: white;
        }

        .payment-success {
            text-align: center;
            padding: 1rem 0;
        }

        .payment-success p {
            margin-bottom: 0.5rem;
        }

        .me-3 {
            margin-right: 1rem;
        }
    </style>
</body>
</html>
