<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pickup & Deliver - RM Delivery</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/animations.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <!-- Header -->
    <header class="header">
        <div class="container">
            <div class="header-content">
            <a href="index.php" class="logo">
            <div class="logo-icon"><img src="assets/uploads/logo.png" alt="RM Delivery Logo"></div>
                    <span>RM Delivery Services</span>
                </a>
                <!-- Mobile Menu Toggle -->
                <button class="menu-toggle" aria-label="Toggle navigation" aria-expanded="false" aria-controls="primary-nav">
                    <i class="fas fa-bars"></i>
                </button>
                <nav id="primary-nav">
                    <ul class="nav-links">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="food.php">Food Delivery</a></li>
                        <li><a href="bills.php">Pay Bills</a></li>
                        <li><a href="request.php">Custom Request</a></li>
                    </ul>
                </nav>
            </div>
        </div>
    </header>

    <!-- Main Content -->
    <main style="padding: 2rem 0; min-height: calc(100vh - 200px);">
        <div class="container">
            <!-- Page Header -->
            <div class="text-center mb-4">
                <h1 class="animate-fade-in-up">Pickup & Deliver Service</h1>
                <p class="animate-fade-in-up delay-200">Need something picked up and delivered? We've got you covered!</p>
            </div>

            <!-- Service Info -->
            <div class="card animate-fade-in-up delay-300" style="margin-bottom: 2rem;">
                <div class="card-body">
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 2rem;">
                        <div class="text-center">
                            <div style="width: 60px; height: 60px; background: var(--primary-color); border-radius: 50%; margin: 0 auto 1rem; display: flex; align-items: center; justify-content: center; color: white;">
                                <i class="fas fa-clock"></i>
                            </div>
                            <h5>Fast Pickup</h5>
                            <p>We'll pick up your items within 30 minutes</p>
                        </div>
                        <div class="text-center">
                            <div style="width: 60px; height: 60px; background: var(--success-color); border-radius: 50%; margin: 0 auto 1rem; display: flex; align-items: center; justify-content: center; color: white;">
                                <i class="fas fa-shield-alt"></i>
                            </div>
                            <h5>Safe Handling</h5>
                            <p>Your items are handled with care and security</p>
                        </div>
                        <div class="text-center">
                            <div style="width: 60px; height: 60px; background: var(--warning-color); border-radius: 50%; margin: 0 auto 1rem; display: flex; align-items: center; justify-content: center; color: white;">
                                <i class="fas fa-map-marked-alt"></i>
                            </div>
                            <h5>Real-time Tracking</h5>
                            <p>Track your delivery in real-time</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Pickup Form -->
            <div class="card animate-fade-in-up delay-400">
                <div class="card-header">
                    <h3><i class="fas fa-shipping-fast"></i> Book Pickup & Delivery</h3>
                </div>
                <div class="card-body">
                    <form id="pickup-form">
                        <!-- Customer Information -->
                        <div class="form-section">
                            <h4>Your Information</h4>
                            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 1rem;">
                                <div class="form-group">
                                    <label class="form-label">Full Name *</label>
                                    <input type="text" class="form-control" name="customer_name" required>
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Phone Number *</label>
                                    <input type="tel" class="form-control" name="customer_phone" required>
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Email (Optional)</label>
                                    <input type="email" class="form-control" name="customer_email">
                                </div>
                            </div>
                        </div>

                        <!-- Pickup Information -->
                        <div class="form-section">
                            <h4>Pickup Details</h4>
                            <div class="form-group">
                                <label class="form-label">Pickup Address *</label>
                                <textarea class="form-control" name="pickup_address" rows="3" required placeholder="Enter the complete pickup address..."></textarea>
                                <button type="button" class="btn btn-secondary btn-sm mt-2" onclick="selectPickupFromMap()">
                                    <i class="fas fa-map-marker-alt"></i> Select from Map
                                </button>
                            </div>
                            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 1rem;">
                                <div class="form-group">
                                    <label class="form-label">Pickup Contact Person</label>
                                    <input type="text" class="form-control" name="pickup_contact" placeholder="Name of person at pickup location">
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Pickup Contact Number</label>
                                    <input type="tel" class="form-control" name="pickup_phone" placeholder="Phone number at pickup location">
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Pickup Instructions</label>
                                <textarea class="form-control" name="pickup_notes" rows="2" placeholder="Any special instructions for pickup (e.g., floor number, gate code, etc.)"></textarea>
                            </div>
                        </div>

                        <!-- Item Information -->
                        <div class="form-section">
                            <h4>Item Details</h4>
                            <div class="form-group">
                                <label class="form-label">Item Description *</label>
                                <textarea class="form-control" name="item_description" rows="3" required placeholder="Describe the items to be picked up (size, weight, fragility, etc.)"></textarea>
                            </div>
                            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem;">
                                <div class="form-group">
                                    <label class="form-label">Item Category</label>
                                    <select class="form-control form-select" name="item_category">
                                        <option value="">Select category...</option>
                                        <option value="documents">Documents</option>
                                        <option value="electronics">Electronics</option>
                                        <option value="clothing">Clothing</option>
                                        <option value="food">Food Items</option>
                                        <option value="medicine">Medicine</option>
                                        <option value="gifts">Gifts</option>
                                        <option value="other">Other</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Estimated Weight</label>
                                    <select class="form-control form-select" name="item_weight">
                                        <option value="">Select weight...</option>
                                        <option value="light">Light (under 1kg)</option>
                                        <option value="medium">Medium (1-5kg)</option>
                                        <option value="heavy">Heavy (5-10kg)</option>
                                        <option value="very_heavy">Very Heavy (over 10kg)</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Handling Requirements</label>
                                    <select class="form-control form-select" name="handling_type">
                                        <option value="standard">Standard</option>
                                        <option value="fragile">Fragile</option>
                                        <option value="urgent">Urgent</option>
                                        <option value="confidential">Confidential</option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <!-- Delivery Information -->
                        <div class="form-section">
                            <h4>Delivery Details</h4>
                            <div class="form-group">
                                <label class="form-label">Delivery Address *</label>
                                <textarea class="form-control" name="delivery_address" rows="3" required placeholder="Enter the complete delivery address..."></textarea>
                                <button type="button" class="btn btn-secondary btn-sm mt-2" onclick="selectDeliveryFromMap()">
                                    <i class="fas fa-map-marker-alt"></i> Select from Map
                                </button>
                            </div>
                            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 1rem;">
                                <div class="form-group">
                                    <label class="form-label">Delivery Contact Person</label>
                                    <input type="text" class="form-control" name="delivery_contact" placeholder="Name of person at delivery location">
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Delivery Contact Number</label>
                                    <input type="tel" class="form-control" name="delivery_phone" placeholder="Phone number at delivery location">
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Delivery Instructions</label>
                                <textarea class="form-control" name="delivery_notes" rows="2" placeholder="Any special instructions for delivery"></textarea>
                            </div>
                        </div>

                        <!-- Scheduling -->
                        <div class="form-section">
                            <h4>Scheduling</h4>
                            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem;">
                                <div class="form-group">
                                    <label class="form-label">Pickup Time</label>
                                    <select class="form-control form-select" name="pickup_time">
                                        <option value="asap">As soon as possible</option>
                                        <option value="morning">Morning (8AM - 12PM)</option>
                                        <option value="afternoon">Afternoon (12PM - 5PM)</option>
                                        <option value="evening">Evening (5PM - 8PM)</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Delivery Priority</label>
                                    <select class="form-control form-select" name="delivery_priority">
                                        <option value="standard">Standard (Same day)</option>
                                        <option value="express">Express (Within 2 hours)</option>
                                        <option value="urgent">Urgent (Within 1 hour)</option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <!-- Payment -->
                        <div class="form-section">
                            <h4>Payment Information</h4>
                            <div class="form-group">
                                <label class="form-label">Payment Method</label>
                                <select class="form-control form-select" name="payment_method" required>
                                    <option value="cod">Cash on Delivery</option>
                                    <option value="online">Online Payment</option>
                                    <option value="pickup_pays">Pickup Location Pays</option>
                                </select>
                            </div>
                            <div class="alert alert-info">
                                <i class="fas fa-info-circle"></i>
                                <strong>Delivery Fee:</strong> Starting at ₱50 + ₱10 per kilometer. Final fee will be calculated based on distance and item requirements.
                            </div>
                        </div>

                        <!-- Submit Button -->
                        <div class="text-center">
                            <button type="submit" class="btn btn-primary btn-lg">
                                <i class="fas fa-shipping-fast"></i> Book Pickup & Delivery
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Distance Calculator -->
            <div id="distance-info" class="card mt-3" style="display: none;">
                <div class="card-body">
                    <h5><i class="fas fa-route"></i> Delivery Information</h5>
                    <div id="distance-details"></div>
                </div>
            </div>
        </div>
    </main>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h4>RM Delivery Services</h4>
                    <h5 style="margin-top: 0.75rem;">Mission</h5>
                    <p>To provide fast, reliable, and hassle-free delivery services in Tagum City and nearby areas from food, parcels, groceries, to special requests ensuring every customer experiences convenience and trust with every ride.</p>
                    <h5>Vision</h5>
                    <p>To be the most trusted and go-to delivery partner in Davao del Norte, known for excellent service, professional riders, and innovative solutions that make daily transactions easier for every Filipino household.</p>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2024 RM Delivery. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <script src="assets/js/main.js"></script>
    <script src="assets/js/alerts.js"></script>
    <script src="assets/js/map.js?v=2"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    
    <script>
        class PickupDelivery {
            constructor() {
                this.pickupCoords = null;
                this.deliveryCoords = null;
                this.init();
            }

            init() {
                this.setupEventListeners();
            }

            setupEventListeners() {
                document.getElementById('pickup-form').addEventListener('submit', (e) => {
                    e.preventDefault();
                    this.submitBooking();
                });

                // Auto-calculate distance when addresses change
                const pickupAddress = document.querySelector('textarea[name="pickup_address"]');
                const deliveryAddress = document.querySelector('textarea[name="delivery_address"]');
                
                pickupAddress.addEventListener('blur', () => this.calculateDistance());
                deliveryAddress.addEventListener('blur', () => this.calculateDistance());
            }

            async calculateDistance() {
                const pickupAddress = document.querySelector('textarea[name="pickup_address"]').value;
                const deliveryAddress = document.querySelector('textarea[name="delivery_address"]').value;

                if (!pickupAddress || !deliveryAddress) return;

                try {
                    // Geocode addresses
                    const pickupResults = await mapManager.geocodeAddress(pickupAddress);
                    const deliveryResults = await mapManager.geocodeAddress(deliveryAddress);

                    if (pickupResults.length > 0 && deliveryResults.length > 0) {
                        this.pickupCoords = { lat: pickupResults[0].lat, lng: pickupResults[0].lng };
                        this.deliveryCoords = { lat: deliveryResults[0].lat, lng: deliveryResults[0].lng };

                        const distance = mapManager.calculateDistance(
                            this.pickupCoords.lat, this.pickupCoords.lng,
                            this.deliveryCoords.lat, this.deliveryCoords.lng
                        );

                        const baseFee = 50;
                        const perKmFee = 10;
                        const estimatedFee = baseFee + (distance * perKmFee);

                        this.showDistanceInfo(distance, estimatedFee);
                    }
                } catch (error) {
                    console.error('Distance calculation error:', error);
                }
            }

            showDistanceInfo(distance, estimatedFee) {
                const distanceInfo = document.getElementById('distance-info');
                const distanceDetails = document.getElementById('distance-details');

                distanceDetails.innerHTML = `
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem;">
                        <div class="text-center">
                            <div style="font-size: 1.5rem; font-weight: bold; color: var(--primary-color);">
                                ${distance.toFixed(1)} km
                            </div>
                            <div class="text-muted">Distance</div>
                        </div>
                        <div class="text-center">
                            <div style="font-size: 1.5rem; font-weight: bold; color: var(--success-color);">
                                ₱${estimatedFee.toFixed(2)}
                            </div>
                            <div class="text-muted">Estimated Fee</div>
                        </div>
                        <div class="text-center">
                            <div style="font-size: 1.5rem; font-weight: bold; color: var(--warning-color);">
                                ${Math.ceil(distance * 2 + 15)} mins
                            </div>
                            <div class="text-muted">Estimated Time</div>
                        </div>
                    </div>
                `;

                distanceInfo.style.display = 'block';
            }

            async submitBooking() {
                const formData = new FormData(document.getElementById('pickup-form'));
                
                // Validate required fields
                if (!formData.get('customer_name') || !formData.get('customer_phone') || 
                    !formData.get('pickup_address') || !formData.get('delivery_address') || 
                    !formData.get('item_description')) {
                    alerts.warning('Missing Information', 'Please fill in all required fields.');
                    return;
                }

                const bookingData = {
                    type: 'pickup_deliver',
                    customer_name: formData.get('customer_name'),
                    customer_phone: formData.get('customer_phone'),
                    customer_email: formData.get('customer_email'),
                    pickup_address: formData.get('pickup_address'),
                    pickup_contact: formData.get('pickup_contact'),
                    pickup_phone: formData.get('pickup_phone'),
                    pickup_notes: formData.get('pickup_notes'),
                    delivery_address: formData.get('delivery_address'),
                    delivery_contact: formData.get('delivery_contact'),
                    delivery_phone: formData.get('delivery_phone'),
                    delivery_notes: formData.get('delivery_notes'),
                    item_description: formData.get('item_description'),
                    item_category: formData.get('item_category'),
                    item_weight: formData.get('item_weight'),
                    handling_type: formData.get('handling_type'),
                    pickup_time: formData.get('pickup_time'),
                    delivery_priority: formData.get('delivery_priority'),
                    payment_method: formData.get('payment_method'),
                    pickup_coords: this.pickupCoords,
                    delivery_coords: this.deliveryCoords
                };

                alerts.loading('Processing Booking', 'Please wait while we process your pickup request...');

                try {
                    // Real API call
                    const resp = await fetch('../api/bookings.php', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify(bookingData)
                    });
                    const json = await resp.json();
                    if (!json.success) throw new Error(json.message || 'Booking failed');

                    const bookingNumber = json.data && json.data.booking_number ? json.data.booking_number : 'N/A';
                    // Prefer server-calculated total; fallback to client estimate
                    const totalAmount = json.data && json.data.total_amount ? parseFloat(json.data.total_amount) : this.calculateEstimatedFee();

                    alerts.success('Booking Created Successfully!', '', {
                        html: `
                            <div class="booking-success">
                                <p><strong>Booking Number:</strong> ${bookingNumber}</p>
                                <p><strong>Service:</strong> Pickup & Delivery</p>
                                <p><strong>Estimated Fee:</strong> ₱${totalAmount.toFixed(2)}</p>
                                <p>Our rider will contact you shortly to confirm pickup details.</p>
                            </div>
                        `,
                        confirmButtonText: 'Track Booking'
                    }).then(() => {
                        this.resetForm();
                        window.location.href = 'index.php';
                    });

                } catch (error) {
                    console.error('Booking submission error:', error);
                    alerts.error('Booking Failed', 'Something went wrong. Please try again.');
                }
            }

            calculateEstimatedFee() {
                if (this.pickupCoords && this.deliveryCoords) {
                    const distance = mapManager.calculateDistance(
                        this.pickupCoords.lat, this.pickupCoords.lng,
                        this.deliveryCoords.lat, this.deliveryCoords.lng
                    );
                    return 50 + (distance * 10);
                }
                return 50; // Base fee
            }

            resetForm() {
                document.getElementById('pickup-form').reset();
                document.getElementById('distance-info').style.display = 'none';
                this.pickupCoords = null;
                this.deliveryCoords = null;
            }
        }

        function selectPickupFromMap() {
            mapManager.showAddressPicker((address) => {
                document.querySelector('textarea[name="pickup_address"]').value = address;
                pickupDelivery.calculateDistance();
            });
        }

        function selectDeliveryFromMap() {
            mapManager.showAddressPicker((address) => {
                document.querySelector('textarea[name="delivery_address"]').value = address;
                pickupDelivery.calculateDistance();
            });
        }

        // Initialize pickup delivery system
        const pickupDelivery = new PickupDelivery();
    </script>

    <style>
        .form-section {
            margin-bottom: 2rem;
            padding-bottom: 1.5rem;
            border-bottom: 1px solid var(--gray-200);
        }

        .form-section:last-child {
            border-bottom: none;
        }

        .form-section h4 {
            color: var(--gray-800);
            margin-bottom: 1rem;
            font-size: 1.25rem;
        }

        .booking-success {
            text-align: center;
            padding: 1rem 0;
        }

        .booking-success p {
            margin-bottom: 0.5rem;
        }
    </style>
</body>
</html>
