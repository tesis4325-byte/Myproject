<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'rider') {
    header('Location: index.php');
    exit();
}

$pageTitle = 'Delivery History';
$riderName = $_SESSION['name'] ?? 'Rider';
$riderId = $_SESSION['user_id'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?> - RM Delivery Rider</title>
    <link rel="stylesheet" href="assets/css/rider.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body>
    <!-- Floating hamburger for mobile -->
    <button class="sidebar-toggle floating-sidebar-toggle" aria-label="Toggle menu" onclick="toggleSidebar()">
        <i class="fas fa-bars"></i>
    </button>
    <div class="rider-app">
        <!-- Header -->
        <header class="rider-header">
            <div class="header-left">
                <a href="dashboard.php" class="back-btn">
                    <i class="fas fa-arrow-left"></i>
                </a>
                <div class="page-title">
                    <h2>Delivery History</h2>
                    <span class="subtitle">Your completed deliveries</span>
                </div>
            </div>
            
            <div class="header-right">
                <div class="rider-info">
                    <span class="rider-name"><?php echo htmlspecialchars($riderName); ?></span>
                    <span class="rider-status online">Online</span>
                </div>
            </div>
        </header>

        <!-- Body with Sidebar + Main Content -->
        <div class="rider-body">
            <?php include __DIR__ . '/templates/sidebar.php'; ?>
            <div class="sidebar-backdrop" id="sidebarBackdrop" onclick="closeSidebar()"></div>
            <main class="rider-main">
            <!-- History Stats -->
            <div class="history-stats">
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-check-circle"></i>
                    </div>
                    <div class="stat-content">
                        <h3 id="totalDeliveries">0</h3>
                        <p>Total Deliveries</p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-peso-sign"></i>
                    </div>
                    <div class="stat-content">
                        <h3 id="totalEarnings">₱0.00</h3>
                        <p>Total Earnings</p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-route"></i>
                    </div>
                    <div class="stat-content">
                        <h3 id="totalDistance">0 km</h3>
                        <p>Distance Covered</p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-star"></i>
                    </div>
                    <div class="stat-content">
                        <h3 id="averageRating">5.0</h3>
                        <p>Average Rating</p>
                    </div>
                </div>
            </div>

            <!-- History Filters -->
            <div class="history-filters">
                <div class="filter-group">
                    <label>Date Range:</label>
                    <select id="dateRange" onchange="filterHistory()">
                        <option value="today">Today</option>
                        <option value="week">This Week</option>
                        <option value="month" selected>This Month</option>
                        <option value="quarter">Last 3 Months</option>
                        <option value="year">This Year</option>
                        <option value="custom">Custom Range</option>
                    </select>
                </div>
                
                <div class="custom-date-range" id="customDateRange" style="display: none;">
                    <input type="date" id="startDate" onchange="filterHistory()">
                    <span>to</span>
                    <input type="date" id="endDate" onchange="filterHistory()">
                </div>
                
                <div class="filter-group">
                    <label>Status:</label>
                    <select id="statusFilter" onchange="filterHistory()">
                        <option value="all">All Status</option>
                        <option value="delivered">Delivered</option>
                        <option value="cancelled">Cancelled</option>
                    </select>
                </div>
                
                <div class="filter-actions">
                    <button class="btn btn-secondary" onclick="exportHistory()">
                        <i class="fas fa-download"></i> Export
                    </button>
                    <button class="refresh-btn" onclick="loadHistory()">
                        <i class="fas fa-sync-alt"></i>
                    </button>
                </div>
            </div>

            <!-- History List -->
            <div class="history-container">
                <div class="history-list" id="historyList">
                    <div class="loading-state">
                        <i class="fas fa-spinner fa-spin"></i>
                        <p>Loading history...</p>
                    </div>
                </div>
            </div>
            </main>
        </div>
    </div>

    <!-- History Detail Modal -->
    <div class="modal" id="historyModal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Delivery Details</h3>
                <button class="close-btn" onclick="closeModal('historyModal')">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="modal-body" id="historyModalBody">
                <!-- History details will be loaded here -->
            </div>
        </div>
    </div>

    <script src="assets/js/rider.js"></script>
    <script>
        // Sidebar toggle helpers (only define if not already present)
        if (typeof openSidebar !== 'function') {
            function openSidebar() {
                document.body.classList.add('sidebar-open');
                const backdrop = document.getElementById('sidebarBackdrop');
                if (backdrop) backdrop.style.display = 'block';
            }
        }
        if (typeof closeSidebar !== 'function') {
            function closeSidebar() {
                document.body.classList.remove('sidebar-open');
                const backdrop = document.getElementById('sidebarBackdrop');
                if (backdrop) backdrop.style.display = 'none';
            }
        }
        if (typeof toggleSidebar !== 'function') {
            function toggleSidebar() {
                if (document.body.classList.contains('sidebar-open')) {
                    closeSidebar();
                } else {
                    openSidebar();
                }
            }
        }

        document.addEventListener('DOMContentLoaded', function() {
            // Close on ESC
            document.addEventListener('keydown', function(e) {
                if (e.key === 'Escape') closeSidebar();
            });
            // Reset state on resize
            window.addEventListener('resize', function() {
                const backdrop = document.getElementById('sidebarBackdrop');
                if (window.innerWidth > 768) {
                    document.body.classList.remove('sidebar-open');
                    if (backdrop) backdrop.style.display = 'none';
                } else if (backdrop) {
                    backdrop.style.display = document.body.classList.contains('sidebar-open') ? 'block' : 'none';
                }
            });
        });
        class HistoryManager {
            constructor() {
                this.riderId = <?php echo $riderId; ?>;
                this.currentFilters = {
                    dateRange: 'month',
                    status: 'all',
                    startDate: null,
                    endDate: null
                };
                this.history = [];
                this.init();
            }

            async init() {
                await this.loadStats();
                await this.loadHistory();
                this.setupEventListeners();
            }

            setupEventListeners() {
                document.getElementById('dateRange').addEventListener('change', (e) => {
                    const customRange = document.getElementById('customDateRange');
                    if (e.target.value === 'custom') {
                        customRange.style.display = 'flex';
                    } else {
                        customRange.style.display = 'none';
                    }
                });
            }

            // Compute date_from and date_to based on current filters
            computeDateRangeParams() {
                const params = {};
                const today = new Date();
                const pad = (n) => String(n).padStart(2, '0');
                const toYMD = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;

                switch (this.currentFilters.dateRange) {
                    case 'today': {
                        const d = new Date();
                        const ymd = toYMD(d);
                        params.date_from = ymd;
                        params.date_to = ymd;
                        break;
                    }
                    case 'week': {
                        const d = new Date();
                        const day = d.getDay();
                        const diffToMonday = (day + 6) % 7; // 0=Sunday -> 6
                        const start = new Date(d);
                        start.setDate(d.getDate() - diffToMonday);
                        params.date_from = toYMD(start);
                        params.date_to = toYMD(d);
                        break;
                    }
                    case 'month': {
                        const start = new Date(today.getFullYear(), today.getMonth(), 1);
                        params.date_from = toYMD(start);
                        params.date_to = toYMD(today);
                        break;
                    }
                    case 'quarter': {
                        const start = new Date(today);
                        start.setMonth(start.getMonth() - 2, 1); // last 3 months starting day 1
                        params.date_from = toYMD(start);
                        params.date_to = toYMD(today);
                        break;
                    }
                    case 'year': {
                        const start = new Date(today.getFullYear(), 0, 1);
                        params.date_from = toYMD(start);
                        params.date_to = toYMD(today);
                        break;
                    }
                    case 'custom': {
                        if (this.currentFilters.startDate) params.date_from = this.currentFilters.startDate;
                        if (this.currentFilters.endDate) params.date_to = this.currentFilters.endDate;
                        break;
                    }
                }

                return params;
            }

            async loadStats() {
                try {
                    // Use the existing 'history' endpoint and read its 'stats'
                    const rangeParams = this.computeDateRangeParams();
                    const qs = new URLSearchParams({ action: 'history', rider_id: String(this.riderId), ...rangeParams });
                    const response = await fetch(`../api/riders.php?${qs.toString()}` , { credentials: 'same-origin' });
                    if (!response.ok) {
                        const text = await response.text();
                        console.error('History stats API error:', response.status, text);
                        throw new Error(`API ${response.status}`);
                    }
                    const result = await response.json();

                    if (result.success) {
                        const stats = (result.data && result.data.stats) ? result.data.stats : {};
                        this.updateStats({
                            total_deliveries: Number(stats.total_deliveries || 0),
                            total_earnings: Number(stats.total_earnings || 0),
                            total_distance: Number(stats.total_distance || 0),
                            average_rating: Number(stats.avg_rating || 0)
                        });
                    }
                } catch (error) {
                    console.error('Error loading stats:', error);
                }
            }

            updateStats(stats) {
                document.getElementById('totalDeliveries').textContent = stats.total_deliveries || 0;
                document.getElementById('totalEarnings').textContent = '₱' + (stats.total_earnings || 0).toFixed(2);
                document.getElementById('totalDistance').textContent = (stats.total_distance || 0).toFixed(1) + ' km';
                document.getElementById('averageRating').textContent = (stats.average_rating || 5.0).toFixed(1);
            }

            async loadHistory() {
                try {
                    const rangeParams = this.computeDateRangeParams();
                    const params = new URLSearchParams({ action: 'history', rider_id: String(this.riderId), ...rangeParams });

                    const response = await fetch(`../api/riders.php?${params.toString()}` , { credentials: 'same-origin' });
                    if (!response.ok) {
                        const text = await response.text();
                        console.error('History list API error:', response.status, text);
                        throw new Error(`API ${response.status}`);
                    }
                    const result = await response.json();

                    if (result.success) {
                        // Backend returns { stats, deliveries: { 'YYYY-MM-DD': [ ... ] } }
                        const grouped = (result.data && result.data.deliveries) ? result.data.deliveries : {};
                        // Flatten to an array so UI grouping works
                        const flat = [];
                        Object.keys(grouped).forEach(date => {
                            const arr = Array.isArray(grouped[date]) ? grouped[date] : [];
                            arr.forEach(item => flat.push(item));
                        });
                        this.history = flat;
                        this.displayHistory();
                    } else {
                        this.showError(result.message || 'Failed to load history');
                    }
                } catch (error) {
                    console.error('Error loading history:', error);
                    this.showError('Network error occurred');
                }
            }

            displayHistory() {
                const container = document.getElementById('historyList');
                
                if (this.history.length === 0) {
                    container.innerHTML = `
                        <div class="empty-state">
                            <i class="fas fa-history"></i>
                            <h3>No delivery history found</h3>
                            <p>Complete some deliveries to see your history here</p>
                        </div>
                    `;
                    return;
                }

                // Group history by date
                const groupedHistory = this.groupHistoryByDate(this.history);
                
                container.innerHTML = Object.entries(groupedHistory).map(([date, deliveries]) => `
                    <div class="history-group">
                        <div class="history-date">
                            <h4>${this.formatGroupDate(date)}</h4>
                            <span class="delivery-count">${deliveries.length} deliveries</span>
                        </div>
                        <div class="history-items">
                            ${deliveries.map(delivery => this.renderHistoryItem(delivery)).join('')}
                        </div>
                    </div>
                `).join('');
            }

            groupHistoryByDate(history) {
                const grouped = {};
                history.forEach(item => {
                    const date = new Date(item.completed_at || item.created_at).toDateString();
                    if (!grouped[date]) {
                        grouped[date] = [];
                    }
                    grouped[date].push(item);
                });
                return grouped;
            }

            renderHistoryItem(delivery) {
                const statusClass = delivery.status === 'delivered' ? 'success' : 'danger';
                const statusIcon = delivery.status === 'delivered' ? 'check-circle' : 'times-circle';
                
                return `
                    <div class="history-item" onclick="viewHistoryDetails(${delivery.id})">
                        <div class="history-item-header">
                            <div class="delivery-info">
                                <span class="delivery-id">#${delivery.id}</span>
                                <span class="status-badge status-${statusClass}">
                                    <i class="fas fa-${statusIcon}"></i>
                                    ${delivery.status}
                                </span>
                            </div>
                            <div class="delivery-earnings">
                                <span class="amount">₱${delivery.total_amount}</span>
                                <span class="time">${this.formatTime(delivery.completed_at || delivery.created_at)}</span>
                            </div>
                        </div>
                        
                        <div class="history-item-content">
                            <div class="customer-info">
                                <i class="fas fa-user"></i>
                                <span>${delivery.customer_name}</span>
                            </div>
                            
                            <div class="location-info">
                                <div class="location-item">
                                    <i class="fas fa-map-marker-alt pickup-icon"></i>
                                    <span>${this.truncateAddress(delivery.pickup_address)}</span>
                                </div>
                                <div class="location-item">
                                    <i class="fas fa-map-marker-alt delivery-icon"></i>
                                    <span>${this.truncateAddress(delivery.delivery_address)}</span>
                                </div>
                            </div>
                            
                            <div class="delivery-metrics">
                                <div class="metric">
                                    <i class="fas fa-route"></i>
                                    <span>${this.formatDistance(delivery.distance)}</span>
                                </div>
                                <div class="metric">
                                    <i class="fas fa-clock"></i>
                                    <span>${delivery.duration || 'N/A'}</span>
                                </div>
                                ${delivery.rating ? `
                                    <div class="metric">
                                        <i class="fas fa-star"></i>
                                        <span>${delivery.rating}/5</span>
                                    </div>
                                ` : ''}
                            </div>
                        </div>
                    </div>
                `;
            }

            formatGroupDate(dateString) {
                const date = new Date(dateString);
                const today = new Date();
                const yesterday = new Date(today);
                yesterday.setDate(yesterday.getDate() - 1);
                
                if (date.toDateString() === today.toDateString()) {
                    return 'Today';
                } else if (date.toDateString() === yesterday.toDateString()) {
                    return 'Yesterday';
                } else {
                    return date.toLocaleDateString('en-PH', {
                        weekday: 'long',
                        year: 'numeric',
                        month: 'long',
                        day: 'numeric'
                    });
                }
            }

            formatTime(timestamp) {
                const date = new Date(timestamp);
                return date.toLocaleTimeString('en-PH', {
                    hour: '2-digit',
                    minute: '2-digit'
                });
            }

            formatDistance(val) {
                const n = Number(val);
                if (!isFinite(n)) return '0.0 km';
                return `${n.toFixed(1)} km`;
            }

            truncateAddress(address) {
                if (!address) return '';
                if (address.length <= 40) return address;
                return address.substring(0, 40) + '...';
            }

            showError(message) {
                if (typeof Swal !== 'undefined') {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: message
                    });
                } else {
                    alert(message);
                }
            }
        }

        let historyManager;

        document.addEventListener('DOMContentLoaded', function() {
            historyManager = new HistoryManager();
        });

        function filterHistory() {
            const dateRange = document.getElementById('dateRange').value;
            const status = document.getElementById('statusFilter').value;
            const startDate = document.getElementById('startDate').value;
            const endDate = document.getElementById('endDate').value;
            
            historyManager.currentFilters = {
                dateRange,
                status,
                startDate: dateRange === 'custom' ? startDate : null,
                endDate: dateRange === 'custom' ? endDate : null
            };
            
            historyManager.loadStats();
            historyManager.loadHistory();
        }

        function exportHistory() {
            const params = new URLSearchParams({
                action: 'export_history',
                rider_id: historyManager.riderId,
                date_range: historyManager.currentFilters.dateRange,
                status: historyManager.currentFilters.status
            });

            if (historyManager.currentFilters.startDate) {
                params.append('start_date', historyManager.currentFilters.startDate);
            }
            if (historyManager.currentFilters.endDate) {
                params.append('end_date', historyManager.currentFilters.endDate);
            }

            window.open(`../api/riders.php?${params}`, '_blank');
        }

        async function viewHistoryDetails(deliveryId) {
            // Use already-loaded history to show details
            const delivery = (historyManager && Array.isArray(historyManager.history))
                ? historyManager.history.find(d => Number(d.id) === Number(deliveryId))
                : null;
            if (delivery) {
                displayHistoryDetails(delivery);
            } else {
                historyManager?.showError('Delivery not found in current history');
            }
        }

        function displayHistoryDetails(delivery) {
            const modalBody = document.getElementById('historyModalBody');
            
            modalBody.innerHTML = `
                <div class="delivery-details">
                    <div class="detail-section">
                        <h4>Delivery Information</h4>
                        <div class="detail-grid">
                            <div class="detail-item">
                                <label>Order ID:</label>
                                <span>#${delivery.id}</span>
                            </div>
                            <div class="detail-item">
                                <label>Status:</label>
                                <span class="status-badge status-${delivery.status === 'delivered' ? 'success' : 'danger'}">
                                    ${delivery.status}
                                </span>
                            </div>
                            <div class="detail-item">
                                <label>Amount:</label>
                                <span>₱${delivery.total_amount}</span>
                            </div>
                            <div class="detail-item">
                                <label>Distance:</label>
                                <span>${delivery.distance} km</span>
                            </div>
                            <div class="detail-item">
                                <label>Duration:</label>
                                <span>${delivery.duration || 'N/A'}</span>
                            </div>
                            ${delivery.rating ? `
                                <div class="detail-item">
                                    <label>Rating:</label>
                                    <span>${delivery.rating}/5 ⭐</span>
                                </div>
                            ` : ''}
                        </div>
                    </div>
                    
                    <div class="detail-section">
                        <h4>Customer Information</h4>
                        <div class="detail-grid">
                            <div class="detail-item">
                                <label>Name:</label>
                                <span>${delivery.customer_name}</span>
                            </div>
                            <div class="detail-item">
                                <label>Phone:</label>
                                <span>${delivery.customer_phone}</span>
                            </div>
                        </div>
                    </div>
                    
                    <div class="detail-section">
                        <h4>Addresses</h4>
                        <div class="address-item">
                            <label><i class="fas fa-map-marker-alt pickup-icon"></i> Pickup:</label>
                            <p>${delivery.pickup_address}</p>
                        </div>
                        <div class="address-item">
                            <label><i class="fas fa-map-marker-alt delivery-icon"></i> Delivery:</label>
                            <p>${delivery.delivery_address}</p>
                        </div>
                    </div>
                    
                    <div class="detail-section">
                        <h4>Timeline</h4>
                        <div class="timeline">
                            <div class="timeline-item">
                                <span class="timeline-time">${historyManager.formatTime(delivery.created_at)}</span>
                                <span class="timeline-event">Order Created</span>
                            </div>
                            ${delivery.accepted_at ? `
                                <div class="timeline-item">
                                    <span class="timeline-time">${historyManager.formatTime(delivery.accepted_at)}</span>
                                    <span class="timeline-event">Accepted by Rider</span>
                                </div>
                            ` : ''}
                            ${delivery.picked_up_at ? `
                                <div class="timeline-item">
                                    <span class="timeline-time">${historyManager.formatTime(delivery.picked_up_at)}</span>
                                    <span class="timeline-event">Picked Up</span>
                                </div>
                            ` : ''}
                            ${delivery.completed_at ? `
                                <div class="timeline-item">
                                    <span class="timeline-time">${historyManager.formatTime(delivery.completed_at)}</span>
                                    <span class="timeline-event">Delivered</span>
                                </div>
                            ` : ''}
                        </div>
                    </div>
                </div>
            `;
            
            document.getElementById('historyModal').style.display = 'block';
        }

        function closeModal(modalId) {
            document.getElementById(modalId).style.display = 'none';
        }

        function logout() {
            if (typeof Swal !== 'undefined') {
                Swal.fire({
                    title: 'Logout',
                    text: 'Are you sure you want to logout?',
                    icon: 'question',
                    showCancelButton: true,
                    confirmButtonText: 'Yes, logout'
                }).then((result) => {
                    if (result.isConfirmed) {
                        window.location.href = '../api/auth.php?action=logout';
                    }
                });
            } else {
                if (confirm('Are you sure you want to logout?')) {
                    window.location.href = '../api/auth.php?action=logout';
                }
            }
        }

    </script>

    <style>
        .history-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
            margin-bottom: 2rem;
        }

        .history-filters {
            background: var(--white);
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            padding: 1rem;
            margin-bottom: 1rem;
            display: flex;
            align-items: center;
            gap: 1rem;
            flex-wrap: wrap;
        }

        .filter-group {
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .filter-group label {
            font-weight: 600;
            color: var(--gray-700);
        }

        .filter-group select, .filter-group input {
            padding: 0.5rem;
            border: 1px solid var(--gray-300);
            border-radius: var(--border-radius);
        }

        .custom-date-range {
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .history-container {
            flex: 1;
            overflow-y: auto;
        }

        .history-group {
            margin-bottom: 2rem;
        }

        .history-date {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1rem;
            background: var(--gray-100);
            border-radius: var(--border-radius);
            margin-bottom: 1rem;
        }

        .history-date h4 {
            margin: 0;
            color: var(--gray-800);
        }

        .delivery-count {
            color: var(--gray-600);
            font-size: 0.9rem;
        }

        .history-items {
            display: flex;
            flex-direction: column;
            gap: 1rem;
        }

        .history-item {
            background: var(--white);
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            padding: 1rem;
            cursor: pointer;
            transition: transform 0.2s ease;
        }

        .history-item:hover {
            transform: translateY(-2px);
            box-shadow: var(--box-shadow-lg);
        }

        .history-item-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1rem;
        }

        .delivery-info {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .delivery-id {
            font-weight: 700;
            color: var(--gray-800);
        }

        .delivery-earnings {
            text-align: right;
        }

        .delivery-earnings .amount {
            display: block;
            font-weight: 700;
            color: var(--success-color);
            font-size: 1.1rem;
        }

        .delivery-earnings .time {
            color: var(--gray-600);
            font-size: 0.8rem;
        }

        .history-item-content {
            display: grid;
            grid-template-columns: 1fr 2fr 1fr;
            gap: 1rem;
            align-items: start;
        }

        .customer-info {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            color: var(--gray-700);
        }

        .location-info {
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
        }

        .location-item {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 0.9rem;
            color: var(--gray-600);
        }

        .delivery-metrics {
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
        }

        .metric {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 0.8rem;
            color: var(--gray-600);
        }

        .delivery-details {
            padding: 1rem;
        }

        .detail-section {
            margin-bottom: 2rem;
        }

        .detail-section h4 {
            margin-bottom: 1rem;
            color: var(--gray-800);
            border-bottom: 2px solid var(--primary-color);
            padding-bottom: 0.5rem;
        }

        .detail-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
        }

        .detail-item {
            display: flex;
            flex-direction: column;
            gap: 0.25rem;
        }

        .detail-item label {
            font-weight: 600;
            color: var(--gray-600);
            font-size: 0.9rem;
        }

        .address-item {
            margin-bottom: 1rem;
        }

        .address-item label {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-weight: 600;
            color: var(--gray-700);
            margin-bottom: 0.5rem;
        }

        .timeline {
            border-left: 2px solid var(--gray-300);
            padding-left: 1rem;
        }

        .timeline-item {
            position: relative;
            margin-bottom: 1rem;
            display: flex;
            gap: 1rem;
        }

        .timeline-item::before {
            content: '';
            position: absolute;
            left: -1.5rem;
            top: 0.5rem;
            width: 10px;
            height: 10px;
            border-radius: 50%;
            background: var(--primary-color);
        }

        .timeline-time {
            font-weight: 600;
            color: var(--gray-600);
            min-width: 80px;
        }

        .timeline-event {
            color: var(--gray-800);
        }

        @media (max-width: 768px) {
            .history-filters {
                flex-direction: column;
                align-items: stretch;
            }

            .history-item-content {
                grid-template-columns: 1fr;
                gap: 1rem;
            }

            .detail-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</body>
</html>
