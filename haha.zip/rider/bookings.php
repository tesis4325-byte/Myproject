<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'rider') {
    header('Location: index.php');
    exit();
}

$pageTitle = 'Bookings';
$riderName = $_SESSION['name'] ?? 'Rider';
$riderId = $_SESSION['user_id'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?> - RM Delivery Rider</title>
    <link rel="stylesheet" href="assets/css/rider.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body>
    <!-- Floating hamburger for mobile -->
    <button class="sidebar-toggle floating-sidebar-toggle" aria-label="Toggle menu" onclick="toggleSidebar()">
        <i class="fas fa-bars"></i>
    </button>
    <div class="rider-app">
        <!-- Header -->
        <header class="rider-header">
            <div class="header-left">
                <a href="dashboard.php" class="back-btn">
                    <i class="fas fa-arrow-left"></i>
                </a>
                <div class="page-title">
                    <h2>My Bookings</h2>
                    <span class="subtitle">Manage your deliveries</span>
                </div>
            </div>
            
            <div class="header-right">
                <div class="rider-info">
                    <span class="rider-name"><?php echo htmlspecialchars($riderName); ?></span>
                    <span class="rider-status online">Online</span>
                </div>
            </div>
        </header>

        <!-- Body with Sidebar + Main Content -->
        <div class="rider-body">
            <?php include __DIR__ . '/templates/sidebar.php'; ?>
            <div class="sidebar-backdrop" id="sidebarBackdrop" onclick="closeSidebar()"></div>
            <main class="rider-main">
            <!-- Booking Filters -->
            <div class="booking-filters h-scroll">
                <div class="filter-tabs">
                    <button class="filter-tab active" data-status="all" onclick="filterBookings('all')">
                        All <span class="count" id="allCount">0</span>
                    </button>
                    <button class="filter-tab" data-status="available" onclick="filterBookings('available')">
                        Available <span class="count" id="availableCount">0</span>
                    </button>
                    <button class="filter-tab" data-status="assigned" onclick="filterBookings('assigned')">
                        Assigned <span class="count" id="assignedCount">0</span>
                    </button>
                    <button class="filter-tab" data-status="picked_up" onclick="filterBookings('picked_up')">
                        In Transit <span class="count" id="transitCount">0</span>
                    </button>
                </div>
                
                <div class="filter-actions">
                    <button class="refresh-btn" onclick="loadBookings()">
                        <i class="fas fa-sync-alt"></i>
                    </button>
                    <div class="sort-dropdown">
                        <select id="sortBy" onchange="sortBookings()">
                            <option value="created_at">Newest First</option>
                            <option value="distance">Distance</option>
                            <option value="amount">Amount</option>
                            <option value="priority">Priority</option>
                        </select>
                    </div>
                </div>
            </div>

            <!-- Bookings List -->
            <div class="bookings-container h-scroll">
                <div class="bookings-list" id="bookingsList">
                    <div class="loading-state">
                        <i class="fas fa-spinner fa-spin"></i>
                        <p>Loading bookings...</p>
                    </div>
                </div>
            </div>
            </main>
        </div>
    </div>

    <!-- Booking Detail Modal -->
    <div class="modal" id="bookingModal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Booking Details</h3>
                <button class="close-btn" onclick="closeModal('bookingModal')">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="modal-body" id="bookingModalBody">
                <!-- Booking details will be loaded here -->
            </div>
        </div>
    </div>

    <script src="assets/js/rider.js"></script>
    <script>
        // Sidebar toggle helpers (only define if not already present)
        if (typeof openSidebar !== 'function') {
            function openSidebar() {
                document.body.classList.add('sidebar-open');
                const backdrop = document.getElementById('sidebarBackdrop');
                if (backdrop) backdrop.style.display = 'block';
            }
        }
        if (typeof closeSidebar !== 'function') {
            function closeSidebar() {
                document.body.classList.remove('sidebar-open');
                const backdrop = document.getElementById('sidebarBackdrop');
                if (backdrop) backdrop.style.display = 'none';
            }
        }
        if (typeof toggleSidebar !== 'function') {
            function toggleSidebar() {
                if (document.body.classList.contains('sidebar-open')) {
                    closeSidebar();
                } else {
                    openSidebar();
                }
            }
        }

        document.addEventListener('DOMContentLoaded', function() {
            // Close on ESC
            document.addEventListener('keydown', function(e) {
                if (e.key === 'Escape') closeSidebar();
            });
            // Reset state on resize
            window.addEventListener('resize', function() {
                const backdrop = document.getElementById('sidebarBackdrop');
                if (window.innerWidth > 768) {
                    document.body.classList.remove('sidebar-open');
                    if (backdrop) backdrop.style.display = 'none';
                } else if (backdrop) {
                    backdrop.style.display = document.body.classList.contains('sidebar-open') ? 'block' : 'none';
                }
            });
        });
        class BookingsManager {
            constructor() {
                this.riderId = <?php echo $riderId; ?>;
                this.currentFilter = 'all';
                this.currentSort = 'created_at';
                this.bookings = [];
                this.allBookings = [];
                this.availableBookings = [];
                this.init();
            }

            async init() {
                await this.loadBookings();
                this.startAutoRefresh();
            }

            async loadBookings() {
                try {
                    // Fetch all rider bookings (status=all) and available pool in parallel
                    const [riderRes, availRes] = await Promise.all([
                        fetch(`../api/riders.php?action=bookings&rider_id=${this.riderId}&status=all&sort=${this.currentSort}`),
                        fetch(`../api/riders.php?action=available_bookings`)
                    ]);
                    const [riderJson, availJson] = await Promise.all([riderRes.json(), availRes.json()]);

                    if (!riderJson.success) throw new Error(riderJson.message || 'Failed to load rider bookings');
                    if (!availJson.success) throw new Error(availJson.message || 'Failed to load available bookings');

                    this.allBookings = riderJson.data.bookings || [];
                    this.availableBookings = (availJson.data.bookings || []).map(b => ({
                        ...b,
                        status: 'available',
                        customer_name: b.customer_name || b.customer_full_name || 'Customer',
                        customer_phone: b.customer_phone || '',
                        pickup_address: b.pickup_address || (b.merchant_address || ''),
                        delivery_address: b.delivery_address || '',
                        total_amount: b.total_amount || b.delivery_fee || 0,
                        distance: b.distance || 0,
                    }));

                    // Compute counts from full datasets
                    const assignedCount = this.allBookings.filter(b => b.status === 'accepted' || b.status === 'assigned').length;
                    const transitCount = this.allBookings.filter(b => b.status === 'picked_up' || b.status === 'on_the_way').length;
                    const counts = {
                        all: this.allBookings.length,
                        available: this.availableBookings.length,
                        assigned: assignedCount,
                        picked_up: transitCount,
                    };
                    this.updateCounts(counts);

                    // Choose which to display based on currentFilter
                    let listToShow = [];
                    if (this.currentFilter === 'available') {
                        listToShow = this.availableBookings;
                    } else if (this.currentFilter === 'assigned') {
                        listToShow = this.allBookings.filter(b => b.status === 'accepted' || b.status === 'assigned');
                    } else if (this.currentFilter === 'picked_up') {
                        listToShow = this.allBookings.filter(b => b.status === 'picked_up' || b.status === 'on_the_way');
                    } else if (this.currentFilter === 'all') {
                        listToShow = this.allBookings;
                    } else {
                        // any specific status
                        listToShow = this.allBookings.filter(b => b.status === this.currentFilter);
                    }

                    // Apply client-side sort
                    listToShow = this.sortList(listToShow, this.currentSort);
                    this.bookings = listToShow;
                    this.displayBookings();
                } catch (error) {
                    console.error('Error loading bookings:', error);
                    this.showError('Network error occurred');
                }
            }

            displayBookings() {
                const container = document.getElementById('bookingsList');
                
                if (this.bookings.length === 0) {
                    container.innerHTML = `
                        <div class="empty-state">
                            <i class="fas fa-inbox"></i>
                            <h3>No bookings found</h3>
                            <p>Check back later for new delivery opportunities</p>
                        </div>
                    `;
                    return;
                }

                container.innerHTML = this.bookings.map(booking => this.renderBookingCard(booking)).join('');
            }

            // Sort helper for list rendering
            sortList(list, sortKey) {
                const arr = Array.isArray(list) ? [...list] : [];
                const priorityWeight = (p) => ({
                    'urgent': 4,
                    'high': 3,
                    'medium': 2,
                    'low': 1
                }[(p || '').toString().toLowerCase()] || 0);

                switch (sortKey) {
                    case 'distance':
                        // Ascending: nearest first
                        return arr.sort((a, b) => (Number(a.distance) || Infinity) - (Number(b.distance) || Infinity));
                    case 'amount':
                        // Descending: highest first
                        const getAmt = (x) => Number(x?.total_amount ?? x?.delivery_fee ?? 0);
                        return arr.sort((a, b) => getAmt(b) - getAmt(a));
                    case 'priority':
                        // Descending: urgent > high > medium > low
                        return arr.sort((a, b) => priorityWeight(b.priority) - priorityWeight(a.priority));
                    case 'created_at':
                    default:
                        // Descending: newest first
                        const ts = (x) => {
                            const d = new Date(x?.created_at);
                            return isNaN(d) ? 0 : d.getTime();
                        };
                        return arr.sort((a, b) => ts(b) - ts(a));
                }
            }

            renderBookingCard(booking) {
                const statusClass = this.getStatusClass(booking.status);
                const priorityClass = this.getPriorityClass(booking.priority);
                
                return `
                    <div class="booking-card ${statusClass}" data-booking-id="${booking.id}">
                        <div class="booking-header">
                            <div class="booking-id">#${booking.id}</div>
                            <div class="booking-badges">
                                <span class="status-badge ${statusClass}">${this.formatStatus(booking.status)}</span>
                                ${booking.priority ? `<span class="priority-badge ${priorityClass}">${booking.priority}</span>` : ''}
                            </div>
                        </div>

                        <div class="booking-content grid-two">
                            <div class="section">
                                <div class="row-line">
                                    <div class="row-label"><i class="fas fa-user"></i> Customer</div>
                                    <div class="row-value">${booking.customer_name || '—'}</div>
                                </div>
                                <div class="row-line">
                                    <div class="row-label"><i class="fas fa-phone"></i> Phone</div>
                                    <div class="row-value">${booking.customer_phone || '—'}</div>
                                </div>
                                <div class="row-line">
                                    <div class="row-label"><i class="fas fa-store"></i> Merchant</div>
                                    <div class="row-value">${booking.merchant_name || '—'}</div>
                                </div>
                            </div>

                            <div class="section">
                                <div class="row-line">
                                    <div class="row-label"><i class="fas fa-map-marker-alt pickup-icon"></i> Pickup</div>
                                    <div class="row-value wrap">${booking.pickup_address || booking.merchant_address || '—'}</div>
                                </div>
                                <div class="row-line">
                                    <div class="row-label"><i class="fas fa-map-marker-alt delivery-icon"></i> Delivery</div>
                                    <div class="row-value wrap">${booking.delivery_address || '—'}</div>
                                </div>
                            </div>
                        </div>

                        <div class="booking-footer">
                            <div class="booking-details">
                                <div class="detail-item">
                                    <i class="fas fa-peso-sign"></i>
                                    <span>${this.formatAmount(booking.total_amount)}</span>
                                </div>
                                <div class="detail-item">
                                    <i class="fas fa-route"></i>
                                    <span>${this.formatDistance(booking.distance)}</span>
                                </div>
                                <div class="detail-item">
                                    <i class="fas fa-clock"></i>
                                    <span>${this.formatDateTime(booking.created_at)}</span>
                                </div>
                                ${booking.estimated_time ? `
                                    <div class="detail-item">
                                        <i class="fas fa-stopwatch"></i>
                                        <span>${booking.estimated_time} min</span>
                                    </div>
                                ` : ''}
                            </div>
                            <div class="booking-actions">
                                ${this.renderBookingActions(booking)}
                            </div>
                        </div>
                    </div>
                `;
            }

            renderBookingActions(booking) {
                switch (booking.status) {
                    case 'available':
                        return `
                            <button class="btn btn-primary" onclick="acceptBooking(${booking.id})">
                                <i class="fas fa-check"></i> Accept
                            </button>
                            <button class="btn btn-secondary" onclick="viewBookingDetails(${booking.id})">
                                <i class="fas fa-eye"></i> Details
                            </button>
                        `;
                    case 'assigned':
                        return `
                            <button class="btn btn-success" onclick="markPickedUp(${booking.id})">
                                <i class="fas fa-box"></i> Picked Up
                            </button>
                            <button class="btn btn-info" onclick="callCustomer('${booking.customer_phone}')">
                                <i class="fas fa-phone"></i> Call
                            </button>
                            <button class="btn btn-warning" onclick="openNavigation('${booking.pickup_address}')">
                                <i class="fas fa-map"></i> Navigate
                            </button>
                        `;
                    case 'picked_up':
                        return `
                            <button class="btn btn-success" onclick="markDelivered(${booking.id})">
                                <i class="fas fa-check-circle"></i> Delivered
                            </button>
                            <button class="btn btn-info" onclick="callCustomer('${booking.customer_phone}')">
                                <i class="fas fa-phone"></i> Call
                            </button>
                            <button class="btn btn-warning" onclick="openNavigation('${booking.delivery_address}')">
                                <i class="fas fa-map"></i> Navigate
                            </button>
                        `;
                    default:
                        return `
                            <button class="btn btn-secondary" onclick="viewBookingDetails(${booking.id})">
                                <i class="fas fa-eye"></i> View Details
                            </button>
                        `;
                }
            }

            updateCounts(counts) {
                document.getElementById('allCount').textContent = counts.all || 0;
                document.getElementById('availableCount').textContent = counts.available || 0;
                document.getElementById('assignedCount').textContent = counts.assigned || 0;
                document.getElementById('transitCount').textContent = counts.picked_up || 0;
            }

            getStatusClass(status) {
                const classes = {
                    'available': 'status-available',
                    'pending': 'status-available',
                    'assigned': 'status-assigned',
                    'accepted': 'status-assigned',
                    'picked_up': 'status-transit',
                    'on_the_way': 'status-transit',
                    'delivered': 'status-delivered',
                    'cancelled': 'status-cancelled'
                };
                return classes[status] || 'status-default';
            }

            getPriorityClass(priority) {
                const classes = {
                    'low': 'priority-low',
                    'medium': 'priority-medium',
                    'high': 'priority-high',
                    'urgent': 'priority-urgent'
                };
                return classes[priority] || 'priority-medium';
            }

            formatStatus(status) {
                const statuses = {
                    'available': 'Available',
                    'pending': 'Available',
                    'assigned': 'Assigned',
                    'accepted': 'Assigned',
                    'picked_up': 'In Transit',
                    'on_the_way': 'In Transit',
                    'delivered': 'Delivered',
                    'cancelled': 'Cancelled'
                };
                return statuses[status] || status;
            }

            formatTime(timestamp) {
                // kept for compatibility; prefer formatDateTime
                return this.formatDateTime(timestamp);
            }

            formatAmount(value) {
                const n = Number(value || 0);
                return '₱' + n.toFixed(2);
            }

            formatDistance(value) {
                const n = Number(value);
                if (!isFinite(n) || n <= 0) return '—';
                return n.toFixed(1) + ' km';
            }

            formatDateTime(ts) {
                const d = new Date(ts);
                if (isNaN(d)) return ts || '—';
                return d.toLocaleString(undefined, {
                    year: 'numeric', month: 'short', day: 'numeric',
                    hour: '2-digit', minute: '2-digit'
                });
            }

            startAutoRefresh() {
                setInterval(() => {
                    this.loadBookings();
                }, 30000); // Refresh every 30 seconds
            }

            showError(message) {
                if (typeof Swal !== 'undefined') {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: message
                    });
                } else {
                    alert(message);
                }
            }

            showSuccess(message) {
                if (typeof Swal !== 'undefined') {
                    Swal.fire({
                        icon: 'success',
                        title: 'Success',
                        text: message,
                        timer: 2000,
                        showConfirmButton: false
                    });
                } else {
                    alert(message);
                }
            }
        }

        let bookingsManager;

        document.addEventListener('DOMContentLoaded', function() {
            bookingsManager = new BookingsManager();
        });

        function filterBookings(status) {
            // Update active tab
            document.querySelectorAll('.filter-tab').forEach(tab => {
                tab.classList.remove('active');
            });
            document.querySelector(`[data-status="${status}"]`).classList.add('active');
            
            bookingsManager.currentFilter = status;
            bookingsManager.loadBookings();
        }

        function sortBookings() {
            const sortBy = document.getElementById('sortBy').value;
            bookingsManager.currentSort = sortBy;
            // Re-render using current cached data for snappy UI
            bookingsManager.bookings = bookingsManager.sortList(
                bookingsManager.bookings,
                bookingsManager.currentSort
            );
            bookingsManager.displayBookings();
            // Also refresh in background to get latest
            bookingsManager.loadBookings();
        }

        async function acceptBooking(bookingId) {
            try {
                const response = await fetch('../api/riders.php?action=accept_booking', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        booking_id: bookingId,
                        rider_id: bookingsManager.riderId
                    })
                });
                
                const result = await response.json();
                
                if (result.success) {
                    bookingsManager.showSuccess('Booking accepted successfully!');
                    bookingsManager.loadBookings();
                } else {
                    bookingsManager.showError(result.message || 'Failed to accept booking');
                }
            } catch (error) {
                console.error('Error accepting booking:', error);
                bookingsManager.showError('Network error occurred');
            }
        }

        async function markPickedUp(bookingId) {
            try {
                const response = await fetch('../api/riders.php?action=update_status', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        booking_id: bookingId,
                        status: 'picked_up',
                        rider_id: bookingsManager.riderId
                    })
                });
                
                const result = await response.json();
                
                if (result.success) {
                    bookingsManager.showSuccess('Order marked as picked up!');
                    bookingsManager.loadBookings();
                } else {
                    bookingsManager.showError(result.message || 'Failed to update status');
                }
            } catch (error) {
                console.error('Error updating status:', error);
                bookingsManager.showError('Network error occurred');
            }
        }

        async function markDelivered(bookingId) {
            try {
                const response = await fetch('../api/riders.php?action=update_status', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        booking_id: bookingId,
                        status: 'delivered',
                        rider_id: bookingsManager.riderId
                    })
                });
                
                const result = await response.json();
                
                if (result.success) {
                    bookingsManager.showSuccess('Order delivered successfully!');
                    bookingsManager.loadBookings();
                } else {
                    bookingsManager.showError(result.message || 'Failed to update status');
                }
            } catch (error) {
                console.error('Error updating status:', error);
                bookingsManager.showError('Network error occurred');
            }
        }

        function callCustomer(phone) {
            window.open(`tel:${phone}`);
        }

        function openNavigation(address) {
            const encodedAddress = encodeURIComponent(address);
            window.open(`https://www.google.com/maps/search/${encodedAddress}`, '_blank');
        }

        async function viewBookingDetails(bookingId) {
            try {
                const res = await fetch(`../api/bookings.php?action=details&booking_id=${bookingId}`);
                const json = await res.json();
                if (!json.success) {
                    return bookingsManager.showError(json.message || 'Failed to load booking details');
                }
                const b = json.data.booking || {};
                const items = json.data.items || [];
                const body = document.getElementById('bookingModalBody');
                const fmt = (v) => (v === null || v === undefined || v === '' ? '—' : v);
                const amt = (n) => '₱' + Number(n || 0).toFixed(2);
                body.innerHTML = `
                    <div class="detail-grid">
                        <div>
                            <h4>Order</h4>
                            <p><strong>#</strong> ${fmt(b.id)} (${fmt(b.booking_number)})</p>
                            <p><strong>Status:</strong> ${bookingsManager.formatStatus(b.status)}</p>
                            <p><strong>Created:</strong> ${bookingsManager.formatDateTime(b.created_at)}</p>
                        </div>
                        <div>
                            <h4>Customer</h4>
                            <p><strong>Name:</strong> ${fmt(b.customer_name)}</p>
                            <p><strong>Phone:</strong> ${fmt(b.customer_phone)}</p>
                            ${b.customer_email ? `<p><strong>Email:</strong> ${b.customer_email}</p>` : ''}
                        </div>
                        <div>
                            <h4>Merchant</h4>
                            <p><strong>Name:</strong> ${fmt(b.merchant_name)}</p>
                            <p><strong>Phone:</strong> ${fmt(b.merchant_phone)}</p>
                            <p><strong>Address:</strong> ${fmt(b.merchant_address)}</p>
                        </div>
                        <div>
                            <h4>Addresses</h4>
                            <p><strong>Pickup:</strong> ${fmt(b.pickup_address)}</p>
                            <p><strong>Delivery:</strong> ${fmt(b.delivery_address)}</p>
                        </div>
                        <div>
                            <h4>Payment</h4>
                            <p><strong>Subtotal:</strong> ${amt(b.subtotal)}</p>
                            <p><strong>Delivery Fee:</strong> ${amt(b.delivery_fee)}</p>
                            <p><strong>Service Fee:</strong> ${amt(b.service_fee)}</p>
                            <p><strong>Total:</strong> ${amt(b.total_amount)}</p>
                        </div>
                        ${b.rider_name ? `<div>
                            <h4>Rider</h4>
                            <p><strong>Name:</strong> ${fmt(b.rider_name)}</p>
                            <p><strong>Phone:</strong> ${fmt(b.rider_phone)}</p>
                        </div>` : ''}
                    </div>
                    ${items.length ? `
                        <div class="items-section">
                            <h4>Items</h4>
                            <table class="items-table">
                                <thead><tr><th>Item</th><th>Qty</th><th>Price</th><th>Total</th></tr></thead>
                                <tbody>
                                    ${items.map(it => `
                                        <tr>
                                            <td>${fmt(it.item_name)}</td>
                                            <td>${fmt(it.quantity)}</td>
                                            <td>${amt(it.price)}</td>
                                            <td>${amt(it.total_price)}</td>
                                        </tr>
                                    `).join('')}
                                </tbody>
                            </table>
                        </div>
                    ` : ''}
                `;
                openModal('bookingModal');
            } catch (e) {
                console.error('details error', e);
                bookingsManager.showError('Network error loading details');
            }
        }

        function openModal(id) {
            document.getElementById(id).style.display = 'block';
        }

        function closeModal(modalId) {
            document.getElementById(modalId).style.display = 'none';
        }

        function logout() {
            if (typeof Swal !== 'undefined') {
                Swal.fire({
                    title: 'Logout',
                    text: 'Are you sure you want to logout?',
                    icon: 'question',
                    showCancelButton: true,
                    confirmButtonText: 'Yes, logout'
                }).then((result) => {
                    if (result.isConfirmed) {
                        window.location.href = '../api/auth.php?action=logout';
                    }
                });
            } else {
                if (confirm('Are you sure you want to logout?')) {
                    window.location.href = '../api/auth.php?action=logout';
                }
            }
        }

        // removed legacy header menu listener
    </script>

    <style>
        .back-btn {
            background: none;
            border: none;
            color: var(--primary-color);
            font-size: 1.2rem;
            cursor: pointer;
            padding: 0.5rem;
            margin-right: 1rem;
            text-decoration: none;
        }

        .page-title h2 {
            margin: 0;
            color: var(--gray-800);
        }

        .page-title .subtitle {
            font-size: 0.8rem;
            color: var(--gray-600);
        }

            .booking-filters {
                background: var(--white);
                border-radius: var(--border-radius);
                box-shadow: var(--box-shadow);
                padding: 1rem;
                display: flex;
                align-items: center;
                justify-content: flex-start;
                flex-wrap: nowrap;
                gap: 0.75rem;
                overflow-x: auto;
                -webkit-overflow-scrolling: touch;
            }

            .filter-tabs {
                display: flex;
                gap: 0.5rem;
                flex-wrap: nowrap;
                min-width: max-content;
            }
        }

        .filter-tab {
            background: var(--gray-100);
            border: none;
            padding: 0.5rem 1rem;
            border-radius: var(--border-radius);
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            transition: all 0.3s ease;
            white-space: nowrap;
            flex-shrink: 0;
        }

        .filter-tab.active {
            background: var(--primary-color);
            color: white;
        }

        .filter-tab .count {
            background: rgba(255, 255, 255, 0.2);
            padding: 0.2rem 0.5rem;
            border-radius: 1rem;
            font-size: 0.7rem;
            font-weight: 600;
        }

        .filter-actions {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .bookings-container {
            flex: 1;
            overflow-y: auto;
        }

        .booking-card {
            background: var(--white);
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            border: 1px solid var(--gray-200);
            margin-bottom: 1rem;
            overflow: hidden;
            transition: transform 0.2s ease;
        }

        .booking-card:hover {
            transform: translateY(-2px);
            box-shadow: var(--box-shadow-lg);
        }

        .booking-header {
            background: #fff;
            padding: 0.85rem 1rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid var(--gray-100);
        }

        .booking-id {
            font-weight: 700;
            color: var(--gray-800);
            letter-spacing: .2px;
        }

        .booking-badges { display: flex; gap: 0.5rem; align-items: center; }

        .status-badge, .priority-badge {
            padding: 0.22rem 0.55rem;
            border-radius: 999px;
            font-size: 0.72rem;
            font-weight: 700;
        }
        .status-badge.status-available { background: #ecfdf5; color: #065f46; }
        .status-badge.status-assigned { background: #fff7ed; color: #9a3412; }
        .status-badge.status-transit { background: #eff6ff; color: #1e40af; }
        .status-badge.status-delivered { background: #dcfce7; color: #166534; }
        .status-badge.status-cancelled { background: #fee2e2; color: #991b1b; }

        .status-available { border-left: 2px solid var(--success-color); padding-left: .5rem; }
        .status-assigned { border-left: 2px solid var(--warning-color); padding-left: .5rem; }
        .status-transit { border-left: 2px solid var(--info-color); padding-left: .5rem; }
        .status-delivered { border-left: 2px solid var(--success-color); padding-left: .5rem; }
        .status-cancelled { border-left: 2px solid var(--danger-color); padding-left: .5rem; }

        .booking-content {
            padding: 1rem;
        }

        /* New structured layout */
        .grid-two { display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; }
        .section { background: #fff; border-radius: .5rem; padding: .75rem 1rem; border: 1px solid var(--gray-100); }
        .row-line { display: flex; gap: .75rem; align-items: flex-start; padding: .45rem 0; border-bottom: 1px dashed var(--gray-100); }
        .row-line:last-child { border-bottom: 0; }
        .row-label { font-weight: 600; color: var(--gray-600); min-width: 92px; display: flex; gap: .5rem; align-items: center; }
        .row-value { color: var(--gray-800); font-size: .95rem; line-height: 1.35; }
        .row-value.wrap { white-space: normal; overflow-wrap: anywhere; }

        .customer-info {
            margin-bottom: 1rem;
        }

        .customer-info h4 {
            margin: 0 0 0.5rem 0;
            color: var(--gray-800);
        }

        .location-info {
            margin-bottom: 1rem;
        }

        .pickup-location, .delivery-location {
            display: flex;
            align-items: flex-start;
            gap: 0.5rem;
            margin-bottom: 0.5rem;
        }

        .pickup-icon { color: var(--warning-color); }
        .delivery-icon { color: var(--success-color); }

        .booking-details {
            display: flex;
            flex-wrap: wrap;
            gap: 1rem;
            margin-bottom: 1rem;
        }

        .detail-item {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            color: var(--gray-600);
            font-size: 0.9rem;
        }

        .booking-footer { display: flex; justify-content: space-between; align-items: center; gap: 1rem; flex-wrap: wrap; background: var(--gray-50); border-top: 1px solid var(--gray-100); padding: .75rem 1rem; }
        .booking-actions { display: flex; gap: .5rem; flex-wrap: wrap; }

        .empty-state, .loading-state {
            text-align: center;
            padding: 3rem;
            color: var(--gray-500);
        }

        .empty-state i, .loading-state i {
            font-size: 3rem;
            margin-bottom: 1rem;
            display: block;
        }

        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 1000;
        }

        .modal-content {
            background: var(--white);
            margin: 5% auto;
            padding: 0;
            border-radius: var(--border-radius);
            max-width: 600px;
            width: 90%;
            max-height: 80vh;
            overflow-y: auto;
        }

        .modal-header {
            background: var(--primary-color);
            color: white;
            padding: 1rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .close-btn {
            background: none;
            border: none;
            color: white;
            font-size: 1.2rem;
            cursor: pointer;
        }

        @media (max-width: 768px) {
            .booking-filters {
                flex-direction: row;
                align-items: center;
            }

            .filter-tabs {
                justify-content: flex-start;
                flex-wrap: nowrap;
                min-width: max-content;
            }

            .filter-actions {
                display: inline-flex;
                align-items: center;
                gap: 0.5rem;
                flex-shrink: 0;
                min-width: max-content;
            }
            .sort-dropdown select { min-width: 160px; }

            .booking-actions {
                flex-direction: column;
                width: 100%;
            }

            .booking-details {
                flex-direction: column;
                gap: 0.5rem;
            }

            .grid-two { grid-template-columns: 1fr; }
            .booking-footer { align-items: stretch; }
            .booking-actions .btn { width: 100%; justify-content: center; }
        }
    </style>
</body>
</html>
