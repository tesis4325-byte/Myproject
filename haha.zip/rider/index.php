<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rider Login - RM Delivery</title>
    <link rel="stylesheet" href="assets/css/rider.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body class="login-page">
    <div class="login-container">
        <div class="login-card">
            <div class="login-header">
                <div class="logo">
                    <i class="fas fa-motorcycle"></i>
                    <h1>RM Delivery</h1>
                    <p>Rider Portal</p>
                </div>
            </div>
            
            <form id="riderLoginForm" class="login-form">
                <div class="form-group">
                    <label for="phone">Phone Number</label>
                    <div class="input-group">
                        <i class="fas fa-phone"></i>
                        <input type="tel" id="phone" name="phone" required placeholder="09XXXXXXXXX">
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="password">Password</label>
                    <div class="input-group">
                        <i class="fas fa-lock"></i>
                        <input type="password" id="password" name="password" required placeholder="Enter your password">
                        <button type="button" class="password-toggle" onclick="togglePassword()">
                            <i class="fas fa-eye" id="passwordToggleIcon"></i>
                        </button>
                    </div>
                </div>
                
                <div class="form-options">
                    <label class="remember-me">
                        <input type="checkbox" name="remember_me">
                        <span class="checkmark"></span>
                        Remember me
                    </label>
                    <a href="#" class="forgot-password">Forgot Password?</a>
                </div>
                
                <button type="submit" class="login-btn">
                    <i class="fas fa-sign-in-alt"></i>
                    Sign In
                </button>
            </form>
            
            <div class="login-footer">
                <p>Don't have an account? <a href="#" onclick="showRegistrationInfo()">Contact Admin</a></p>
            </div>
        </div>
        
        <div class="login-info">
            <div class="info-card">
                <h3>Welcome Riders!</h3>
                <div class="features">
                    <div class="feature">
                        <i class="fas fa-map-marked-alt"></i>
                        <span>Real-time GPS tracking</span>
                    </div>
                    <div class="feature">
                        <i class="fas fa-peso-sign"></i>
                        <span>Instant earnings tracking</span>
                    </div>
                    <div class="feature">
                        <i class="fas fa-mobile-alt"></i>
                        <span>Mobile-optimized interface</span>
                    </div>
                    <div class="feature">
                        <i class="fas fa-shield-alt"></i>
                        <span>Safety features & panic button</span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="assets/js/rider.js"></script>
    <script>
        document.getElementById('riderLoginForm').addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            const loginData = {
                phone: formData.get('phone'),
                password: formData.get('password'),
                remember_me: formData.get('remember_me') ? true : false,
                user_type: 'rider'
            };
            
            try {
                const response = await fetch('../api/auth.php?action=login', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify(loginData)
                });
                
                const result = await response.json();
                
                if (result.success) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Login Successful!',
                        text: 'Welcome back, ' + result.data.name,
                        timer: 1500,
                        showConfirmButton: false
                    }).then(() => {
                        window.location.href = 'dashboard.php';
                    });
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Login Failed',
                        text: result.message || 'Invalid credentials'
                    });
                }
            } catch (error) {
                console.error('Login error:', error);
                Swal.fire({
                    icon: 'error',
                    title: 'Connection Error',
                    text: 'Please check your internet connection and try again.'
                });
            }
        });
        
        function togglePassword() {
            const passwordInput = document.getElementById('password');
            const toggleIcon = document.getElementById('passwordToggleIcon');
            
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                toggleIcon.classList.remove('fa-eye');
                toggleIcon.classList.add('fa-eye-slash');
            } else {
                passwordInput.type = 'password';
                toggleIcon.classList.remove('fa-eye-slash');
                toggleIcon.classList.add('fa-eye');
            }
        }
        
        function showRegistrationInfo() {
            Swal.fire({
                icon: 'info',
                title: 'Rider Registration',
                html: `
                    <p>To become a rider, please contact our admin team:</p>
                    <div style="margin: 1rem 0;">
                        <strong>Phone:</strong> +63 912 345 6789<br>
                        <strong>Email:</strong> admin@rmdelivery.com
                    </div>
                    <p><small>We'll verify your documents and vehicle registration before creating your account.</small></p>
                `,
                confirmButtonText: 'Got it!'
            });
        }
    </script>
</body>
</html>
