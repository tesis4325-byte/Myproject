<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'rider') {
    header('Location: index.php');
    exit();
}

$pageTitle = 'Dashboard';
$riderName = $_SESSION['name'] ?? 'Rider';
$riderId = $_SESSION['user_id'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?> - RM Delivery Rider</title>
    <link rel="stylesheet" href="assets/css/rider.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
</head>
<body>
    <!-- Floating hamburger for mobile -->
    <button class="sidebar-toggle floating-sidebar-toggle" aria-label="Toggle menu" onclick="toggleSidebar()">
        <i class="fas fa-bars"></i>
    </button>
    <div class="rider-app">
        <!-- Header -->
        <header class="rider-header">
            <div class="header-left">
                <div class="rider-info">
                    <div class="rider-avatar">
                        <i class="fas fa-user"></i>
                    </div>
                    <div class="rider-details">
                        <h3><?php echo htmlspecialchars($riderName); ?></h3>
                        <span class="rider-status online" id="riderStatus">Online</span>
                    </div>
                </div>
            </div>
            
            <div class="header-center">
                <div class="earnings-display">
                    <div class="earnings-item">
                        <span class="label">Today</span>
                        <span class="amount" id="todayEarnings">₱0.00</span>
                    </div>
                    <div class="earnings-item">
                        <span class="label">This Week</span>
                        <span class="amount" id="weekEarnings">₱0.00</span>
                    </div>
                </div>
            </div>
            
            <div class="header-right">
                <button class="status-toggle" onclick="toggleOnlineStatus()">
                    <i class="fas fa-power-off"></i>
                </button>
            </div>
        </header>

        <!-- Body with Sidebar + Main Content -->
        <div class="rider-body">
            <?php include __DIR__ . '/templates/sidebar.php'; ?>
            <div class="sidebar-backdrop" id="sidebarBackdrop" onclick="closeSidebar()"></div>
            <main class="rider-main">
            <!-- Stats Cards -->
            <div class="stats-section">
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-box"></i>
                    </div>
                    <div class="stat-content">
                        <h3 id="totalDeliveries">0</h3>
                        <p>Total Deliveries</p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-clock"></i>
                    </div>
                    <div class="stat-content">
                        <h3 id="pendingDeliveries">0</h3>
                        <p>Pending</p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-star"></i>
                    </div>
                    <div class="stat-content">
                        <h3 id="riderRating">5.0</h3>
                        <p>Rating</p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-route"></i>
                    </div>
                    <div class="stat-content">
                        <h3 id="totalDistance">0</h3>
                        <p>KM Today</p>
                    </div>
                </div>
            </div>

            <!-- Current Delivery -->
            <div class="current-delivery" id="currentDelivery" style="display: none;">
                <div class="delivery-header">
                    <h3>Current Delivery</h3>
                    <span class="delivery-status" id="deliveryStatus">Pickup</span>
                </div>
                <div class="delivery-content">
                    <div class="delivery-info">
                        <div class="customer-info">
                            <h4 id="customerName">Customer Name</h4>
                            <p id="customerPhone">Phone Number</p>
                            <p id="deliveryAddress">Delivery Address</p>
                        </div>
                        <div class="delivery-details">
                            <div class="detail-item">
                                <span class="label">Order ID:</span>
                                <span id="orderId">#12345</span>
                            </div>
                            <div class="detail-item">
                                <span class="label">Amount:</span>
                                <span id="orderAmount">₱250.00</span>
                            </div>
                            <div class="detail-item">
                                <span class="label">Distance:</span>
                                <span id="deliveryDistance">2.5 km</span>
                            </div>
                        </div>
                    </div>
                    <div class="delivery-actions">
                        <button class="btn btn-primary" id="primaryAction" onclick="handlePrimaryAction()">
                            Arrived at Pickup
                        </button>
                        <button class="btn btn-secondary" onclick="callCustomer()">
                            <i class="fas fa-phone"></i> Call
                        </button>
                        <button class="btn btn-secondary" onclick="openNavigation()">
                            <i class="fas fa-map"></i> Navigate
                        </button>
                    </div>
                </div>
            </div>

            <!-- Available Bookings -->
            <div class="available-bookings">
                <div class="section-header">
                    <h3>Available Bookings</h3>
                    <button class="refresh-btn" onclick="loadAvailableBookings()">
                        <i class="fas fa-sync-alt"></i>
                    </button>
                </div>
                <div class="bookings-list" id="availableBookingsList">
                    <div class="no-bookings">
                        <i class="fas fa-inbox"></i>
                        <p>No available bookings</p>
                    </div>
                </div>
            </div>

            <!-- Map Container -->
            <div class="map-container">
                <div class="map-header">
                    <h3>Live Tracking</h3>
                    <div class="map-controls">
                        <button class="map-btn" onclick="centerMap()">
                            <i class="fas fa-crosshairs"></i>
                        </button>
                        <button class="map-btn" onclick="toggleFullscreen()">
                            <i class="fas fa-expand"></i>
                        </button>
                        <button class="map-btn" onclick="riderManager && riderManager.requestLocationPermission()" title="Enable Location">
                            <i class="fas fa-location-arrow"></i>
                        </button>
                        <button class="map-btn" onclick="setManualLocation()" title="Set Manual Location">
                            <i class="fas fa-map-marker-alt"></i>
                        </button>
                    </div>
                </div>
                <div id="riderMap" class="rider-map"></div>
            </div>
            </main>
        </div>
    </div>

    <script src="assets/js/rider.js"></script>
    <script>
        class RiderDashboard {
            constructor() {
                this.riderId = <?php echo $riderId; ?>;
                this.isOnline = true;
                this.currentBooking = null;
                this.map = null;
                this.riderMarker = null;
                this.currentPosition = null;
                this.init();
            }

            async init() {
                await this.initMap();
                await this.loadStats();
                await this.loadCurrentBooking();
                await this.loadAvailableBookings();
                if (await this.canUseGeolocation()) {
                    this.startLocationTracking();
                } else {
                    // Try manual fallback from localStorage
                    const saved = localStorage.getItem('manualLocation');
                    if (saved) {
                        const { lat, lng } = JSON.parse(saved);
                        if (isFinite(lat) && isFinite(lng)) {
                            this.applyManualLocation(lat, lng, true);
                        }
                    }
                    if (typeof Swal !== 'undefined') {
                        Swal.fire({
                            icon: 'info',
                            title: 'Enable Location',
                            text: 'Location is blocked. Allow location in your browser or click the red pin icon to set your location manually.',
                            confirmButtonText: 'OK'
                        });
                    }
                }
                this.startDataRefresh();
            }

            initMap() {
                // Initialize map centered on Mindanao, Philippines
                this.map = L.map('riderMap').setView([8.4542, 124.6319], 13);
                
                L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                    attribution: '© OpenStreetMap contributors'
                }).addTo(this.map);

                // Get current location
                if (navigator.geolocation) {
                    // Only attempt if permission is not explicitly denied
                    this.canUseGeolocation().then((allowed) => {
                        if (!allowed) return;
                        navigator.geolocation.getCurrentPosition(
                            (position) => {
                                const lat = position.coords.latitude;
                                const lng = position.coords.longitude;
                                this.currentPosition = [lat, lng];
                                this.map.setView([lat, lng], 15);
                                this.riderMarker = L.marker([lat, lng])
                                    .addTo(this.map)
                                    .bindPopup('Your Location');
                            },
                            (error) => {
                                this.handleGeoError(error);
                            }
                        );
                    });
                }
            }

            async loadStats() {
                try {
                    const response = await fetch(`../api/riders.php?action=dashboard_stats`);
                    const result = await response.json();
                    
                    if (result.success) {
                        this.updateStats(result.data);
                    }
                } catch (error) {
                    console.error('Error loading stats:', error);
                }
            }

            updateStats(stats) {
                document.getElementById('totalDeliveries').textContent = stats.total_deliveries || 0;
                document.getElementById('pendingDeliveries').textContent = stats.pending_deliveries || 0;
                document.getElementById('riderRating').textContent = (stats.rating || 5.0).toFixed(1);
                document.getElementById('totalDistance').textContent = (stats.distance_today || 0).toFixed(1);
                document.getElementById('todayEarnings').textContent = '₱' + (stats.earnings_today || 0).toFixed(2);
                document.getElementById('weekEarnings').textContent = '₱' + (stats.earnings_week || 0).toFixed(2);
            }

            async loadCurrentBooking() {
                try {
                    const response = await fetch(`../api/riders.php?action=current_delivery`);
                    const result = await response.json();
                    
                    if (result.success && result.data) {
                        this.displayCurrentBooking(result.data.delivery);
                    } else {
                        document.getElementById('currentDelivery').style.display = 'none';
                    }
                } catch (error) {
                    console.error('Error loading current booking:', error);
                }
            }

            displayCurrentBooking(booking) {
                this.currentBooking = booking;
                const container = document.getElementById('currentDelivery');
                
                document.getElementById('customerName').textContent = booking.customer_name;
                document.getElementById('customerPhone').textContent = booking.customer_phone;
                document.getElementById('deliveryAddress').textContent = booking.delivery_address;
                document.getElementById('orderId').textContent = '#' + booking.id;
                document.getElementById('orderAmount').textContent = '₱' + booking.total_amount;
                document.getElementById('deliveryDistance').textContent = booking.distance + ' km';
                
                const statusElement = document.getElementById('deliveryStatus');
                const primaryButton = document.getElementById('primaryAction');
                
                switch (booking.status) {
                    case 'accepted':
                        statusElement.textContent = 'Pickup';
                        primaryButton.textContent = 'Arrived at Pickup';
                        break;
                    case 'picked_up':
                        statusElement.textContent = 'Delivering';
                        primaryButton.textContent = 'Delivered';
                        break;
                    default:
                        statusElement.textContent = booking.status;
                        primaryButton.textContent = 'Update Status';
                }
                
                container.style.display = 'block';
            }

            async loadAvailableBookings() {
                try {
                    const response = await fetch(`../api/riders.php?action=available_bookings`);
                    const result = await response.json();
                    
                    if (result.success) {
                        const list = (result.data.bookings || []).map(b => ({
                            ...b,
                            customer_name: b.customer_name || b.customer_full_name || 'Customer',
                            pickup_address: b.pickup_address || (b.merchant_address || ''),
                            delivery_address: b.delivery_address || '',
                            total_amount: b.total_amount || b.delivery_fee || 0,
                            distance: b.distance || 0,
                        }));
                        this.displayAvailableBookings(list);
                    }
                } catch (error) {
                    console.error('Error loading available bookings:', error);
                }
            }

            displayAvailableBookings(bookings) {
                const container = document.getElementById('availableBookingsList');
                
                if (bookings.length === 0) {
                    container.innerHTML = `
                        <div class="no-bookings">
                            <i class="fas fa-inbox"></i>
                            <p>No available bookings</p>
                        </div>
                    `;
                    return;
                }

                container.innerHTML = bookings.map(booking => `
                    <div class="booking-card">
                        <div class="booking-info">
                            <h4>${booking.customer_name}</h4>
                            <p><i class="fas fa-map-marker-alt"></i> ${booking.pickup_address}</p>
                            <p><i class="fas fa-arrow-right"></i> ${booking.delivery_address}</p>
                        </div>
                        <div class="booking-details">
                            <div class="booking-amount">₱${booking.total_amount}</div>
                            <div class="booking-distance">${booking.distance} km</div>
                            <button class="btn btn-primary btn-sm" onclick="acceptBooking(${booking.id})">
                                Accept
                            </button>
                        </div>
                    </div>
                `).join('');
            }

            startLocationTracking() {
                if (navigator.geolocation) {
                    navigator.geolocation.watchPosition(
                        (position) => {
                            const lat = position.coords.latitude;
                            const lng = position.coords.longitude;
                            this.currentPosition = [lat, lng];
                            if (this.riderMarker) {
                                this.riderMarker.setLatLng([lat, lng]);
                            }
                            // Update location on server
                            this.updateLocation(lat, lng);
                        },
                        (error) => {
                            this.handleGeoError(error);
                        },
                        {
                            enableHighAccuracy: true,
                            timeout: 10000,
                            maximumAge: 60000
                        }
                    );
                }
            }

            async canUseGeolocation() {
                try {
                    if (!('permissions' in navigator)) return true; // No Permissions API; let browser prompt
                    const status = await navigator.permissions.query({ name: 'geolocation' });
                    return status.state !== 'denied';
                } catch (e) {
                    return true;
                }
            }

            handleGeoError(error) {
                // Consolidated, user-friendly handler
                let msg = 'Location error';
                if (error && typeof error.code !== 'undefined') {
                    switch (error.code) {
                        case error.PERMISSION_DENIED:
                            msg = 'Location access denied. Please allow location in your browser settings.';
                            break;
                        case error.POSITION_UNAVAILABLE:
                            msg = 'Location information unavailable.';
                            break;
                        case error.TIMEOUT:
                            msg = 'Location request timed out.';
                            break;
                    }
                }
                console.warn(msg);
                if (typeof Swal !== 'undefined') {
                    Swal.fire({ icon: 'warning', title: 'Location', text: msg, timer: 4000, showConfirmButton: false });
                }
            }

            applyManualLocation(lat, lng, centerOnly = false) {
                this.currentPosition = [lat, lng];
                if (this.map) {
                    this.map.setView([lat, lng], 15);
                    if (this.riderMarker) {
                        this.riderMarker.setLatLng([lat, lng]);
                    } else {
                        this.riderMarker = L.marker([lat, lng]).addTo(this.map).bindPopup('Your Location');
                    }
                }
                if (!centerOnly) {
                    this.updateLocation(lat, lng);
                }
            }

            async updateLocation(lat, lng) {
                try {
                    await fetch('../api/riders.php?action=update_location', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({
                            rider_id: this.riderId,
                            latitude: lat,
                            longitude: lng
                        })
                    });
                } catch (error) {
                    console.error('Error updating location:', error);
                }
            }

            startDataRefresh() {
                setInterval(() => {
                    this.loadStats();
                    this.loadCurrentBooking();
                    if (!this.currentBooking) {
                        this.loadAvailableBookings();
                    }
                }, 30000); // Refresh every 30 seconds
            }
        }

        let dashboard;

        document.addEventListener('DOMContentLoaded', function() {
            dashboard = new RiderDashboard();
            // Sidebar toggle setup
            const sidebar = document.querySelector('.rider-sidebar');
            const backdrop = document.getElementById('sidebarBackdrop');

            // Close sidebar when clicking outside handled by backdrop onclick

            // Close on ESC
            document.addEventListener('keydown', function(e) {
                if (e.key === 'Escape') {
                    closeSidebar();
                }
            });

            // Reset state on resize to desktop
            window.addEventListener('resize', function() {
                if (window.innerWidth > 768) {
                    document.body.classList.remove('sidebar-open');
                    if (backdrop) backdrop.style.display = 'none';
                } else if (backdrop) {
                    // keep CSS-controlled display via class only
                    backdrop.style.display = document.body.classList.contains('sidebar-open') ? 'block' : 'none';
                }
            });
        });

        function openSidebar() {
            document.body.classList.add('sidebar-open');
            const backdrop = document.getElementById('sidebarBackdrop');
            if (backdrop) backdrop.style.display = 'block';
        }

        function closeSidebar() {
            document.body.classList.remove('sidebar-open');
            const backdrop = document.getElementById('sidebarBackdrop');
            if (backdrop) backdrop.style.display = 'none';
        }

        function toggleSidebar() {
            if (document.body.classList.contains('sidebar-open')) {
                closeSidebar();
            } else {
                openSidebar();
            }
        }

        function toggleOnlineStatus() {
            dashboard.isOnline = !dashboard.isOnline;
            const statusElement = document.getElementById('riderStatus');
            const toggleBtn = document.querySelector('.status-toggle');
            
            if (dashboard.isOnline) {
                statusElement.textContent = 'Online';
                statusElement.className = 'rider-status online';
                toggleBtn.style.color = '#28a745';
            } else {
                statusElement.textContent = 'Offline';
                statusElement.className = 'rider-status offline';
                toggleBtn.style.color = '#dc3545';
            }
        }

        // Panic and header dropdown removed

        function logout() {
            Swal.fire({
                title: 'Logout',
                text: 'Are you sure you want to logout?',
                icon: 'question',
                showCancelButton: true,
                confirmButtonText: 'Yes, logout'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = '../api/auth.php?action=logout&redirect=1';
                }
            });
        }

        function handlePrimaryAction() {
            if (dashboard.currentBooking) {
                const booking = dashboard.currentBooking;
                let newStatus = '';
                
                switch (booking.status) {
                    case 'accepted':
                        newStatus = 'picked_up';
                        break;
                    case 'picked_up':
                        newStatus = 'delivered';
                        break;
                }
                
                if (newStatus) {
                    updateBookingStatus(booking.id, newStatus);
                }
            }
        }

        async function updateBookingStatus(bookingId, status) {
            try {
                const response = await fetch('../api/riders.php?action=update_booking_status', {
                    method: 'PUT',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        booking_id: bookingId,
                        status: status,
                        rider_id: dashboard.riderId
                    })
                });
                
                const result = await response.json();
                
                if (result.success) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Status Updated',
                        timer: 1500,
                        showConfirmButton: false
                    });
                    dashboard.loadCurrentBooking();
                    dashboard.loadStats();
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Update Failed',
                        text: result.message
                    });
                }
            } catch (error) {
                console.error('Error updating status:', error);
            }
        }

        async function acceptBooking(bookingId) {
            try {
                const response = await fetch('../api/riders.php?action=accept_booking', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        booking_id: bookingId,
                        rider_id: dashboard.riderId
                    })
                });
                
                const result = await response.json();
                
                if (result.success) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Booking Accepted',
                        timer: 1500,
                        showConfirmButton: false
                    });
                    dashboard.loadCurrentBooking();
                    dashboard.loadAvailableBookings();
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Accept Failed',
                        text: result.message
                    });
                }
            } catch (error) {
                console.error('Error accepting booking:', error);
            }
        }

        function callCustomer() {
            if (dashboard.currentBooking) {
                window.open(`tel:${dashboard.currentBooking.customer_phone}`);
            }
        }

        function openNavigation() {
            if (dashboard.currentBooking && dashboard.currentPosition) {
                const address = encodeURIComponent(dashboard.currentBooking.delivery_address);
                window.open(`https://www.google.com/maps/dir/${dashboard.currentPosition[0]},${dashboard.currentPosition[1]}/${address}`, '_blank');
            }
        }

        function centerMap() {
            if (dashboard.currentPosition && dashboard.map) {
                dashboard.map.setView(dashboard.currentPosition, 15);
            }
        }

        function setManualLocation() {
            const saved = localStorage.getItem('manualLocation');
            let preset = '';
            if (saved) {
                try {
                    const { lat, lng } = JSON.parse(saved);
                    if (isFinite(lat) && isFinite(lng)) preset = `${lat},${lng}`;
                } catch (e) {}
            }
            const input = prompt('Enter your location as latitude,longitude (e.g., 8.4811,124.6477):', preset);
            if (!input) return;
            const parts = input.split(',').map(s => parseFloat(s.trim()));
            if (parts.length !== 2 || !isFinite(parts[0]) || !isFinite(parts[1])) {
                alert('Invalid format. Please enter as latitude,longitude');
                return;
            }
            const lat = parts[0];
            const lng = parts[1];
            try { localStorage.setItem('manualLocation', JSON.stringify({ lat, lng })); } catch (e) {}
            dashboard.applyManualLocation(lat, lng);
        }

        function toggleFullscreen() {
            const mapContainer = document.querySelector('.map-container');
            if (mapContainer.classList.contains('fullscreen')) {
                mapContainer.classList.remove('fullscreen');
            } else {
                mapContainer.classList.add('fullscreen');
            }
            setTimeout(() => {
                dashboard.map.invalidateSize();
            }, 300);
        }

        // Removed header dropdown click-outside handler
    </script>
</body>
</html>
