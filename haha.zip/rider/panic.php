<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'rider') {
    header('Location: index.php');
    exit();
}

$pageTitle = 'Panic Alert';
$riderName = $_SESSION['name'] ?? 'Rider';
$riderId = $_SESSION['user_id'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?> - RM Delivery Rider</title>
    <link rel="stylesheet" href="assets/css/rider.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body>
    <!-- Floating hamburger for mobile -->
    <button class="sidebar-toggle floating-sidebar-toggle" aria-label="Toggle menu" onclick="toggleSidebar()">
        <i class="fas fa-bars"></i>
    </button>
    <div class="rider-app panic-app">
        <!-- Header -->
        <header class="rider-header panic-header">
            <div class="header-left">
                <a href="dashboard.php" class="back-btn">
                    <i class="fas fa-arrow-left"></i>
                </a>
                <div class="page-title">
                    <h2>Emergency Alert</h2>
                    <span class="subtitle">Safety first - get help when needed</span>
                </div>
            </div>
            
            <div class="header-right">
                <div class="emergency-status" id="emergencyStatus">
                    <span class="status-indicator safe"></span>
                    <span class="status-text">Safe</span>
                </div>
            </div>
        </header>

        <!-- Body with Sidebar + Main Content -->
        <div class="rider-body">
            <?php include __DIR__ . '/templates/sidebar.php'; ?>
            <div class="sidebar-backdrop" id="sidebarBackdrop" onclick="closeSidebar()"></div>
            <main class="rider-main panic-main">
            <!-- Emergency Actions -->
            <div class="emergency-actions">
                <div class="panic-button-container">
                    <button class="panic-button" id="panicButton" onclick="triggerPanic()">
                        <div class="panic-icon">
                            <i class="fas fa-exclamation-triangle"></i>
                        </div>
                        <div class="panic-text">
                            <h3>EMERGENCY</h3>
                            <p>Tap to send alert</p>
                        </div>
                    </button>
                </div>
                
                <div class="quick-actions">
                    <button class="quick-action-btn" onclick="callEmergency('911')">
                        <i class="fas fa-phone"></i>
                        <span>Call 911</span>
                    </button>
                    <button class="quick-action-btn" onclick="callEmergency('117')">
                        <i class="fas fa-shield-alt"></i>
                        <span>Call PNP (117)</span>
                    </button>
                    <button class="quick-action-btn" onclick="shareLocation()">
                        <i class="fas fa-map-marker-alt"></i>
                        <span>Share Location</span>
                    </button>
                </div>
            </div>

            <!-- Emergency Contacts -->
            <div class="emergency-contacts">
                <h3>Emergency Contacts</h3>
                <div class="contacts-list" id="contactsList">
                    <div class="contact-item">
                        <div class="contact-info">
                            <h4>RM Delivery Support</h4>
                            <p>24/7 Emergency Hotline</p>
                        </div>
                        <button class="contact-btn" onclick="callContact('+639123456789')">
                            <i class="fas fa-phone"></i>
                        </button>
                    </div>
                    <div class="contact-item">
                        <div class="contact-info">
                            <h4>Local Police</h4>
                            <p>Emergency Response</p>
                        </div>
                        <button class="contact-btn" onclick="callContact('117')">
                            <i class="fas fa-phone"></i>
                        </button>
                    </div>
                    <div class="contact-item">
                        <div class="contact-info">
                            <h4>Medical Emergency</h4>
                            <p>Ambulance Service</p>
                        </div>
                        <button class="contact-btn" onclick="callContact('911')">
                            <i class="fas fa-phone"></i>
                        </button>
                    </div>
                </div>
            </div>

            <!-- Safety Tips -->
            <div class="safety-tips">
                <h3>Safety Tips</h3>
                <div class="tips-list">
                    <div class="tip-item">
                        <i class="fas fa-shield-alt"></i>
                        <div>
                            <h4>Stay Alert</h4>
                            <p>Always be aware of your surroundings during deliveries</p>
                        </div>
                    </div>
                    <div class="tip-item">
                        <i class="fas fa-map-marker-alt"></i>
                        <div>
                            <h4>Share Location</h4>
                            <p>Keep location services on for emergency tracking</p>
                        </div>
                    </div>
                    <div class="tip-item">
                        <i class="fas fa-phone"></i>
                        <div>
                            <h4>Emergency Contacts</h4>
                            <p>Save important numbers in your phone for quick access</p>
                        </div>
                    </div>
                    <div class="tip-item">
                        <i class="fas fa-eye"></i>
                        <div>
                            <h4>Trust Your Instincts</h4>
                            <p>If something feels wrong, prioritize your safety</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Recent Alerts -->
            <div class="recent-alerts" id="recentAlerts" style="display: none;">
                <h3>Recent Alerts</h3>
                <div class="alerts-list" id="alertsList">
                    <!-- Recent alerts will be loaded here -->
                </div>
            </div>
        </main>
        </div>
    </div>

    <!-- Panic Confirmation Modal -->
    <div class="modal panic-modal" id="panicModal">
        <div class="modal-content">
            <div class="panic-modal-header">
                <h3>Emergency Alert</h3>
                <div class="countdown" id="countdown">5</div>
            </div>
            <div class="modal-body">
                <div class="panic-modal-content">
                    <i class="fas fa-exclamation-triangle"></i>
                    <h4>Sending Emergency Alert</h4>
                    <p>Your location and emergency alert will be sent to:</p>
                    <ul>
                        <li>RM Delivery Support Team</li>
                        <li>Local Emergency Services</li>
                        <li>Your Emergency Contacts</li>
                    </ul>
                    <div class="modal-actions">
                        <button class="btn btn-danger" onclick="confirmPanic()">
                            <i class="fas fa-exclamation-triangle"></i> Send Alert Now
                        </button>
                        <button class="btn btn-secondary" onclick="cancelPanic()">
                            <i class="fas fa-times"></i> Cancel
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="assets/js/rider.js"></script>
    <script>
        // Sidebar toggle helpers (only define if not already present)
        if (typeof openSidebar !== 'function') {
            function openSidebar() {
                document.body.classList.add('sidebar-open');
                const backdrop = document.getElementById('sidebarBackdrop');
                if (backdrop) backdrop.style.display = 'block';
            }
        }
        if (typeof closeSidebar !== 'function') {
            function closeSidebar() {
                document.body.classList.remove('sidebar-open');
                const backdrop = document.getElementById('sidebarBackdrop');
                if (backdrop) backdrop.style.display = 'none';
            }
        }
        if (typeof toggleSidebar !== 'function') {
            function toggleSidebar() {
                if (document.body.classList.contains('sidebar-open')) {
                    closeSidebar();
                } else {
                    openSidebar();
                }
            }
        }

        document.addEventListener('DOMContentLoaded', function() {
            // Close on ESC
            document.addEventListener('keydown', function(e) {
                if (e.key === 'Escape') closeSidebar();
            });
            // Reset state on resize
            window.addEventListener('resize', function() {
                const backdrop = document.getElementById('sidebarBackdrop');
                if (window.innerWidth > 768) {
                    document.body.classList.remove('sidebar-open');
                    if (backdrop) backdrop.style.display = 'none';
                } else if (backdrop) {
                    backdrop.style.display = document.body.classList.contains('sidebar-open') ? 'block' : 'none';
                }
            });
        });
        class PanicManager {
            constructor() {
                this.riderId = <?php echo $riderId; ?>;
                this.currentLocation = null;
                this.panicTimer = null;
                this.countdownTimer = null;
                this.init();
            }

            async init() {
                await this.getCurrentLocation();
                await this.loadRecentAlerts();
                this.setupEventListeners();
            }

            setupEventListeners() {
                // Get current location periodically
                if (navigator.geolocation) {
                    navigator.geolocation.watchPosition(
                        (position) => {
                            this.currentLocation = {
                                latitude: position.coords.latitude,
                                longitude: position.coords.longitude,
                                accuracy: position.coords.accuracy
                            };
                        },
                        (error) => {
                            console.error('Location error:', error);
                        },
                        {
                            enableHighAccuracy: true,
                            timeout: 10000,
                            maximumAge: 60000
                        }
                    );
                }
            }

            async getCurrentLocation() {
                return new Promise((resolve, reject) => {
                    if (!navigator.geolocation) {
                        reject(new Error('Geolocation not supported'));
                        return;
                    }

                    navigator.geolocation.getCurrentPosition(
                        (position) => {
                            this.currentLocation = {
                                latitude: position.coords.latitude,
                                longitude: position.coords.longitude,
                                accuracy: position.coords.accuracy
                            };
                            resolve(this.currentLocation);
                        },
                        (error) => {
                            console.error('Location error:', error);
                            reject(error);
                        },
                        {
                            enableHighAccuracy: true,
                            timeout: 10000,
                            maximumAge: 60000
                        }
                    );
                });
            }

            async loadRecentAlerts() {
                try {
                    const response = await fetch(`../api/riders.php?action=panic_alerts&rider_id=${this.riderId}`, { credentials: 'same-origin' });
                    if (!response.ok) {
                        const text = await response.text();
                        console.error('panic_alerts API error:', response.status, text);
                        return;
                    }
                    const result = await response.json();
                    const alerts = (result && result.success && result.data && result.data.alerts) ? result.data.alerts : [];
                    if (alerts.length > 0) {
                        this.displayRecentAlerts(alerts);
                        document.getElementById('recentAlerts').style.display = 'block';
                    }
                } catch (error) {
                    console.error('Error loading alerts:', error);
                }
            }

            displayRecentAlerts(alerts) {
                const container = document.getElementById('alertsList');
                
                container.innerHTML = alerts.map(alert => `
                    <div class="alert-item">
                        <div class="alert-info">
                            <div class="alert-status ${alert.status}">
                                <i class="fas fa-${this.getAlertIcon(alert.status)}"></i>
                                <span>${this.formatAlertStatus(alert.status)}</span>
                            </div>
                            <div class="alert-time">${this.formatTime(alert.created_at)}</div>
                        </div>
                        <div class="alert-details">
                            <p>${alert.message || 'Emergency alert sent'}</p>
                            ${alert.resolved_at ? `<small>Resolved: ${this.formatTime(alert.resolved_at)}</small>` : ''}
                        </div>
                    </div>
                `).join('');
            }

            getAlertIcon(status) {
                const icons = {
                    'active': 'exclamation-triangle',
                    'resolved': 'check-circle',
                    'cancelled': 'times-circle'
                };
                return icons[status] || 'exclamation-triangle';
            }

            formatAlertStatus(status) {
                const statuses = {
                    'active': 'Active',
                    'resolved': 'Resolved',
                    'cancelled': 'Cancelled'
                };
                return statuses[status] || status;
            }

            formatTime(timestamp) {
                const date = new Date(timestamp);
                return date.toLocaleString('en-PH');
            }

            startPanicCountdown() {
                // Use flex to center modal content
                document.getElementById('panicModal').style.display = 'flex';
                let countdown = 5;
                document.getElementById('countdown').textContent = countdown;
                
                this.countdownTimer = setInterval(() => {
                    countdown--;
                    document.getElementById('countdown').textContent = countdown;
                    
                    if (countdown <= 0) {
                        clearInterval(this.countdownTimer);
                        this.sendPanicAlert();
                    }
                }, 1000);
            }

            async sendPanicAlert() {
                try {
                    // Update UI to show alert is being sent
                    this.updateEmergencyStatus('alert');
                    
                    const lat = this.currentLocation?.latitude ?? null;
                    const lng = this.currentLocation?.longitude ?? null;
                    const payload = {
                        latitude: lat,
                        longitude: lng,
                        message: 'Emergency alert triggered by rider'
                    };

                    const response = await fetch('../api/riders.php?action=send_panic_alert', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        credentials: 'same-origin',
                        body: JSON.stringify(payload)
                    });
                    
                    if (!response.ok) {
                        const text = await response.text();
                        console.error('send_panic_alert API error:', response.status, text);
                        this.showError('Failed to send emergency alert');
                        this.updateEmergencyStatus('safe');
                        return;
                    }

                    const result = await response.json();
                    
                    if (result.success) {
                        this.showSuccess('Emergency alert sent successfully!');
                        this.updateEmergencyStatus('sent');
                        document.getElementById('panicModal').style.display = 'none';
                        this.loadRecentAlerts();
                    } else {
                        this.showError(result.message || 'Failed to send emergency alert');
                        this.updateEmergencyStatus('safe');
                    }
                } catch (error) {
                    console.error('Error sending panic alert:', error);
                    this.showError('Network error occurred while sending alert');
                    this.updateEmergencyStatus('safe');
                }
            }

            updateEmergencyStatus(status) {
                const statusElement = document.getElementById('emergencyStatus');
                const indicator = statusElement.querySelector('.status-indicator');
                const text = statusElement.querySelector('.status-text');
                
                indicator.className = `status-indicator ${status}`;
                
                switch (status) {
                    case 'safe':
                        text.textContent = 'Safe';
                        break;
                    case 'alert':
                        text.textContent = 'Sending Alert...';
                        break;
                    case 'sent':
                        text.textContent = 'Alert Sent';
                        break;
                }
            }

            showSuccess(message) {
                if (typeof Swal !== 'undefined') {
                    Swal.fire({
                        icon: 'success',
                        title: 'Alert Sent',
                        text: message,
                        confirmButtonText: 'OK'
                    });
                } else {
                    alert(message);
                }
            }

            showError(message) {
                if (typeof Swal !== 'undefined') {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: message,
                        confirmButtonText: 'OK'
                    });
                } else {
                    alert(message);
                }
            }
        }

        let panicManager;

        document.addEventListener('DOMContentLoaded', function() {
            panicManager = new PanicManager();
        });

        function triggerPanic() {
            if (typeof Swal !== 'undefined') {
                Swal.fire({
                    title: 'Emergency Alert',
                    text: 'This will send your location and emergency alert to support team and emergency services. Continue?',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#dc3545',
                    confirmButtonText: 'Send Alert',
                    cancelButtonText: 'Cancel'
                }).then((result) => {
                    if (result.isConfirmed) {
                        panicManager.startPanicCountdown();
                    }
                });
            } else {
                if (confirm('Send emergency alert?')) {
                    panicManager.startPanicCountdown();
                }
            }
        }

        function confirmPanic() {
            if (panicManager.countdownTimer) {
                clearInterval(panicManager.countdownTimer);
            }
            panicManager.sendPanicAlert();
        }

        function cancelPanic() {
            if (panicManager.countdownTimer) {
                clearInterval(panicManager.countdownTimer);
            }
            document.getElementById('panicModal').style.display = 'none';
        }

        function callEmergency(number) {
            window.open(`tel:${number}`);
        }

        function callContact(number) {
            window.open(`tel:${number}`);
        }

        function shareLocation() {
            if (panicManager.currentLocation) {
                const { latitude, longitude } = panicManager.currentLocation;
                const locationUrl = `https://www.google.com/maps?q=${latitude},${longitude}`;
                
                if (navigator.share) {
                    navigator.share({
                        title: 'My Current Location',
                        text: 'Emergency - This is my current location',
                        url: locationUrl
                    });
                } else {
                    // Fallback: copy to clipboard
                    navigator.clipboard.writeText(locationUrl).then(() => {
                        panicManager.showSuccess('Location URL copied to clipboard');
                    });
                }
            } else {
                panicManager.showError('Location not available');
            }
        }
    </script>

    <style>
        .panic-app {
            background: linear-gradient(135deg, #ff6b6b, #ee5a24);
            min-height: 100vh;
        }

        .panic-header {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(255, 255, 255, 0.2);
        }

        .panic-header .page-title h2 {
            color: white;
        }

        .panic-header .page-title .subtitle {
            color: rgba(255, 255, 255, 0.8);
        }

        .panic-header .back-btn {
            color: white;
        }

        .emergency-status {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            color: white;
        }

        .status-indicator {
            width: 12px;
            height: 12px;
            border-radius: 50%;
            animation: pulse 2s infinite;
        }

        .status-indicator.safe {
            background: #2ecc71;
        }

        .status-indicator.alert {
            background: #f39c12;
        }

        .status-indicator.sent {
            background: #e74c3c;
        }

        .panic-main {
            padding: 2rem;
            max-width: 600px;
            margin: 0 auto;
        }

        .emergency-actions {
            margin-bottom: 3rem;
        }

        .panic-button-container {
            display: flex;
            justify-content: center;
            margin-bottom: 2rem;
        }

        .panic-button {
            width: 200px;
            height: 200px;
            border-radius: 50%;
            background: linear-gradient(135deg, #e74c3c, #c0392b);
            border: 8px solid rgba(255, 255, 255, 0.3);
            color: white;
            cursor: pointer;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            gap: 1rem;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
            transition: all 0.3s ease;
            animation: pulse 2s infinite;
        }

        .panic-button:hover {
            transform: scale(1.05);
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.4);
        }

        .panic-icon {
            font-size: 3rem;
        }

        .panic-text h3 {
            font-size: 1.5rem;
            font-weight: 700;
            margin: 0;
        }

        .panic-text p {
            font-size: 0.9rem;
            margin: 0;
            opacity: 0.8;
        }

        .quick-actions {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 1rem;
        }

        .quick-action-btn {
            background: #ffffff;
            border: 1px solid #e5e7eb;
            color: #333;
            padding: 1rem;
            border-radius: var(--border-radius);
            cursor: pointer;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 0.5rem;
            transition: all 0.3s ease;
            box-shadow: 0 1px 2px rgba(0,0,0,0.06);
        }

        .quick-action-btn:hover {
            background: #fafafa;
            transform: translateY(-2px);
        }

        .quick-action-btn i {
            font-size: 1.5rem;
        }

        .emergency-contacts, .safety-tips, .recent-alerts {
            background: #ffffff;
            border-radius: var(--border-radius);
            padding: 1.5rem;
            margin-bottom: 2rem;
            border: 1px solid #e5e7eb;
            color: #333;
            box-shadow: 0 6px 18px rgba(0,0,0,0.06);
        }

        .emergency-contacts h3, .safety-tips h3, .recent-alerts h3 {
            color: #222;
            margin-bottom: 1rem;
        }

        .contact-item {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 1rem;
            background: #f8f9fa;
            border-radius: var(--border-radius);
            margin-bottom: 1rem;
            border: 1px solid #e5e7eb;
        }

        .contact-item:last-child {
            margin-bottom: 0;
        }

        .contact-info h4 {
            color: #222;
            margin: 0 0 0.25rem 0;
        }

        .contact-info p {
            color: #555;
            margin: 0;
            font-size: 0.9rem;
        }

        .contact-btn {
            background: var(--success-color);
            color: white;
            border: none;
            padding: 0.75rem;
            border-radius: 50%;
            cursor: pointer;
            font-size: 1.2rem;
        }

        .tips-list {
            display: grid;
            gap: 1rem;
        }

        .tip-item {
            display: flex;
            align-items: flex-start;
            gap: 1rem;
            padding: 1rem;
            background: #f8f9fa;
            border-radius: var(--border-radius);
            border: 1px solid #e5e7eb;
        }

        .tip-item i {
            color: #e74c3c;
            font-size: 1.5rem;
            margin-top: 0.25rem;
        }

        .tip-item h4 {
            color: #222;
            margin: 0 0 0.5rem 0;
        }

        .tip-item p {
            color: #555;
            margin: 0;
            font-size: 0.9rem;
        }

        /* Modal overlay and centering */
        .modal {
            position: fixed;
            inset: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            display: none; /* toggled to flex in JS */
            align-items: center;
            justify-content: center;
            z-index: 1000;
            padding: 1rem;
        }

        .panic-modal .modal-content {
            background: #ffffff;
            width: 100%;
            max-width: 520px;
            border-radius: var(--border-radius);
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            overflow: hidden;
        }

        .panic-modal-header {
            background: var(--danger-color);
            color: white;
            padding: 1rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .countdown {
            font-size: 2rem;
            font-weight: 700;
            background: rgba(255, 255, 255, 0.2);
            width: 50px;
            height: 50px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .panic-modal-content {
            text-align: center;
            padding: 2rem;
        }

        .panic-modal-content i {
            font-size: 4rem;
            color: var(--danger-color);
            margin-bottom: 1rem;
        }

        .panic-modal-content ul {
            text-align: left;
            margin: 1rem 0;
        }

        .modal-actions {
            display: flex;
            gap: 1rem;
            justify-content: center;
            margin-top: 2rem;
        }

        .alert-item {
            padding: 1rem;
            background: #ffffff;
            border-radius: var(--border-radius);
            margin-bottom: 1rem;
            border: 1px solid #e5e7eb;
        }

        .alert-info {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 0.5rem;
        }

        .alert-status {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            color: #333;
        }

        .alert-time {
            color: #666;
            font-size: 0.8rem;
        }

        .alert-details p {
            color: #333;
            margin: 0;
        }

        .alert-details small {
            color: #777;
        }

        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.05); }
            100% { transform: scale(1); }
        }

        @media (max-width: 768px) {
            .panic-button {
                width: 150px;
                height: 150px;
            }

            .panic-icon {
                font-size: 2rem;
            }

            .panic-text h3 {
                font-size: 1.2rem;
            }
        }
    </style>
</body>
</html>
