// RM Delivery Rider Map JavaScript - OpenStreetMap Integration for Mindanao

class RiderMapManager {
    constructor(containerId, options = {}) {
        this.containerId = containerId;
        this.map = null;
        this.riderMarker = null;
        this.pickupMarker = null;
        this.deliveryMarker = null;
        this.routeControl = null;
        this.currentPosition = null;
        this.isTracking = false;
        this.watchId = null;
        
        // Default options
        this.options = {
            center: [8.4542, 124.6319], // Mindanao center coordinates
            zoom: 13,
            enableTracking: true,
            showRoute: true,
            ...options
        };
        
        this.init();
    }

    init() {
        this.initMap();
        if (this.options.enableTracking) {
            this.startLocationTracking();
        }
    }

    initMap() {
        // Initialize Leaflet map
        this.map = L.map(this.containerId).setView(this.options.center, this.options.zoom);
        
        // Add OpenStreetMap tile layer
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '© OpenStreetMap contributors',
            maxZoom: 19
        }).addTo(this.map);

        // Add custom controls
        this.addCustomControls();
        
        // Set up event listeners
        this.setupEventListeners();
    }

    addCustomControls() {
        // Center on rider button
        const centerControl = L.control({ position: 'topright' });
        centerControl.onAdd = () => {
            const div = L.DomUtil.create('div', 'leaflet-bar leaflet-control');
            div.innerHTML = '<a href="#" title="Center on my location"><i class="fas fa-crosshairs"></i></a>';
            div.onclick = (e) => {
                e.preventDefault();
                this.centerOnRider();
            };
            return div;
        };
        centerControl.addTo(this.map);

        // Toggle tracking button
        const trackingControl = L.control({ position: 'topright' });
        trackingControl.onAdd = () => {
            const div = L.DomUtil.create('div', 'leaflet-bar leaflet-control');
            div.innerHTML = '<a href="#" title="Toggle location tracking" id="trackingToggle"><i class="fas fa-location-arrow"></i></a>';
            div.onclick = (e) => {
                e.preventDefault();
                this.toggleTracking();
            };
            return div;
        };
        trackingControl.addTo(this.map);

        // Fullscreen button
        const fullscreenControl = L.control({ position: 'topright' });
        fullscreenControl.onAdd = () => {
            const div = L.DomUtil.create('div', 'leaflet-bar leaflet-control');
            div.innerHTML = '<a href="#" title="Toggle fullscreen"><i class="fas fa-expand"></i></a>';
            div.onclick = (e) => {
                e.preventDefault();
                this.toggleFullscreen();
            };
            return div;
        };
        fullscreenControl.addTo(this.map);
    }

    setupEventListeners() {
        // Map click event
        this.map.on('click', (e) => {
            console.log('Map clicked at:', e.latlng);
        });

        // Map zoom event
        this.map.on('zoomend', () => {
            console.log('Map zoom level:', this.map.getZoom());
        });
    }

    startLocationTracking() {
        if (!navigator.geolocation) {
            console.error('Geolocation not supported');
            return;
        }

        const options = {
            enableHighAccuracy: true,
            timeout: 10000,
            maximumAge: 60000
        };

        // Get initial position
        navigator.geolocation.getCurrentPosition(
            (position) => {
                this.updateRiderPosition(position);
            },
            (error) => {
                console.error('Geolocation error:', error);
                this.handleLocationError(error);
            },
            options
        );

        // Watch position changes
        this.watchId = navigator.geolocation.watchPosition(
            (position) => {
                this.updateRiderPosition(position);
            },
            (error) => {
                console.error('Location tracking error:', error);
                this.handleLocationError(error);
            },
            options
        );

        this.isTracking = true;
        this.updateTrackingButton();
    }

    stopLocationTracking() {
        if (this.watchId) {
            navigator.geolocation.clearWatch(this.watchId);
            this.watchId = null;
        }
        this.isTracking = false;
        this.updateTrackingButton();
    }

    updateRiderPosition(position) {
        const lat = position.coords.latitude;
        const lng = position.coords.longitude;
        const accuracy = position.coords.accuracy;
        
        this.currentPosition = [lat, lng];

        // Create or update rider marker
        if (this.riderMarker) {
            this.riderMarker.setLatLng([lat, lng]);
        } else {
            this.riderMarker = L.marker([lat, lng], {
                icon: this.createRiderIcon()
            }).addTo(this.map);
            
            this.riderMarker.bindPopup(`
                <div class="rider-popup">
                    <strong>Your Location</strong><br>
                    <small>Accuracy: ${accuracy.toFixed(0)}m</small>
                </div>
            `);
        }

        // Add accuracy circle
        if (this.accuracyCircle) {
            this.map.removeLayer(this.accuracyCircle);
        }
        this.accuracyCircle = L.circle([lat, lng], {
            radius: accuracy,
            color: '#007bff',
            fillColor: '#007bff',
            fillOpacity: 0.1,
            weight: 1
        }).addTo(this.map);

        // Center map on first position
        if (!this.hasInitialPosition) {
            this.map.setView([lat, lng], 15);
            this.hasInitialPosition = true;
        }

        // Update route if pickup/delivery markers exist
        if (this.options.showRoute && (this.pickupMarker || this.deliveryMarker)) {
            this.updateRoute();
        }

        // Trigger position update event
        this.onPositionUpdate(lat, lng, accuracy);
    }

    createRiderIcon() {
        return L.divIcon({
            className: 'rider-marker',
            html: '<div class="rider-marker-inner"><i class="fas fa-motorcycle"></i></div>',
            iconSize: [30, 30],
            iconAnchor: [15, 15]
        });
    }

    createPickupIcon() {
        return L.divIcon({
            className: 'pickup-marker',
            html: '<div class="pickup-marker-inner"><i class="fas fa-map-marker-alt"></i></div>',
            iconSize: [25, 25],
            iconAnchor: [12, 25]
        });
    }

    createDeliveryIcon() {
        return L.divIcon({
            className: 'delivery-marker',
            html: '<div class="delivery-marker-inner"><i class="fas fa-map-marker-alt"></i></div>',
            iconSize: [25, 25],
            iconAnchor: [12, 25]
        });
    }

    setPickupLocation(lat, lng, address = '') {
        if (this.pickupMarker) {
            this.map.removeLayer(this.pickupMarker);
        }

        this.pickupMarker = L.marker([lat, lng], {
            icon: this.createPickupIcon()
        }).addTo(this.map);

        this.pickupMarker.bindPopup(`
            <div class="pickup-popup">
                <strong><i class="fas fa-box"></i> Pickup Location</strong><br>
                ${address || `${lat.toFixed(6)}, ${lng.toFixed(6)}`}
            </div>
        `);

        if (this.options.showRoute) {
            this.updateRoute();
        }
    }

    setDeliveryLocation(lat, lng, address = '') {
        if (this.deliveryMarker) {
            this.map.removeLayer(this.deliveryMarker);
        }

        this.deliveryMarker = L.marker([lat, lng], {
            icon: this.createDeliveryIcon()
        }).addTo(this.map);

        this.deliveryMarker.bindPopup(`
            <div class="delivery-popup">
                <strong><i class="fas fa-home"></i> Delivery Location</strong><br>
                ${address || `${lat.toFixed(6)}, ${lng.toFixed(6)}`}
            </div>
        `);

        if (this.options.showRoute) {
            this.updateRoute();
        }
    }

    updateRoute() {
        if (!this.currentPosition) return;

        // Remove existing route
        if (this.routeControl) {
            this.map.removeControl(this.routeControl);
        }

        let waypoints = [L.latLng(this.currentPosition[0], this.currentPosition[1])];

        // Add pickup point if exists and no delivery yet
        if (this.pickupMarker && !this.deliveryMarker) {
            waypoints.push(this.pickupMarker.getLatLng());
        }
        // Add delivery point if exists
        else if (this.deliveryMarker) {
            waypoints.push(this.deliveryMarker.getLatLng());
        }

        if (waypoints.length > 1) {
            this.routeControl = L.Routing.control({
                waypoints: waypoints,
                routeWhileDragging: false,
                addWaypoints: false,
                createMarker: () => null, // Don't create default markers
                lineOptions: {
                    styles: [{
                        color: '#007bff',
                        weight: 4,
                        opacity: 0.7
                    }]
                },
                router: L.Routing.osrmv1({
                    serviceUrl: 'https://router.project-osrm.org/route/v1'
                })
            }).addTo(this.map);

            // Hide the routing instructions panel
            this.routeControl.getContainer().style.display = 'none';
        }
    }

    centerOnRider() {
        if (this.currentPosition) {
            this.map.setView(this.currentPosition, 16);
        }
    }

    toggleTracking() {
        if (this.isTracking) {
            this.stopLocationTracking();
        } else {
            this.startLocationTracking();
        }
    }

    updateTrackingButton() {
        const button = document.getElementById('trackingToggle');
        if (button) {
            const icon = button.querySelector('i');
            if (this.isTracking) {
                icon.className = 'fas fa-location-arrow';
                button.style.color = '#007bff';
                button.title = 'Stop location tracking';
            } else {
                icon.className = 'fas fa-location-slash';
                button.style.color = '#dc3545';
                button.title = 'Start location tracking';
            }
        }
    }

    toggleFullscreen() {
        const container = document.getElementById(this.containerId);
        const parent = container.parentElement;
        
        if (parent.classList.contains('map-fullscreen')) {
            parent.classList.remove('map-fullscreen');
        } else {
            parent.classList.add('map-fullscreen');
        }
        
        // Invalidate map size after transition
        setTimeout(() => {
            this.map.invalidateSize();
        }, 300);
    }

    fitBounds() {
        const markers = [];
        
        if (this.riderMarker) markers.push(this.riderMarker.getLatLng());
        if (this.pickupMarker) markers.push(this.pickupMarker.getLatLng());
        if (this.deliveryMarker) markers.push(this.deliveryMarker.getLatLng());
        
        if (markers.length > 1) {
            const group = new L.featureGroup(markers.map(pos => L.marker(pos)));
            this.map.fitBounds(group.getBounds().pad(0.1));
        }
    }

    clearMarkers() {
        if (this.pickupMarker) {
            this.map.removeLayer(this.pickupMarker);
            this.pickupMarker = null;
        }
        if (this.deliveryMarker) {
            this.map.removeLayer(this.deliveryMarker);
            this.deliveryMarker = null;
        }
        if (this.routeControl) {
            this.map.removeControl(this.routeControl);
            this.routeControl = null;
        }
    }

    handleLocationError(error) {
        let message = 'Location access denied';
        
        switch (error.code) {
            case error.PERMISSION_DENIED:
                message = 'Location access denied. Please enable location services.';
                break;
            case error.POSITION_UNAVAILABLE:
                message = 'Location information unavailable.';
                break;
            case error.TIMEOUT:
                message = 'Location request timed out.';
                break;
        }
        
        console.warn(message);
        this.onLocationError(error, message);
    }

    // Event callbacks (can be overridden)
    onPositionUpdate(lat, lng, accuracy) {
        // Override this method to handle position updates
        console.log('Position updated:', lat, lng, accuracy);
    }

    onLocationError(error, message) {
        // Override this method to handle location errors
        console.error('Location error:', error, message);
    }

    // Utility methods
    calculateDistance(lat1, lng1, lat2, lng2) {
        const R = 6371; // Earth's radius in kilometers
        const dLat = this.toRadians(lat2 - lat1);
        const dLng = this.toRadians(lng2 - lng1);
        const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                  Math.cos(this.toRadians(lat1)) * Math.cos(this.toRadians(lat2)) *
                  Math.sin(dLng / 2) * Math.sin(dLng / 2);
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        return R * c;
    }

    toRadians(degrees) {
        return degrees * (Math.PI / 180);
    }

    // Cleanup method
    destroy() {
        if (this.watchId) {
            navigator.geolocation.clearWatch(this.watchId);
        }
        if (this.map) {
            this.map.remove();
        }
    }
}

// Mindanao-specific locations and utilities
class MindanaoMapUtils {
    static getMajorCities() {
        return {
            'Davao City': [7.0731, 125.6128],
            'Cagayan de Oro': [8.4542, 124.6319],
            'Zamboanga City': [6.9214, 122.0790],
            'Butuan': [8.9470, 125.5406],
            'Iligan': [8.2280, 124.2452],
            'Cotabato City': [7.2231, 124.2452],
            'General Santos': [6.1164, 125.1716],
            'Marawi': [8.0021, 124.2928],
            'Dipolog': [8.5958, 123.3417],
            'Surigao': [9.7859, 125.4955]
        };
    }

    static getProvinces() {
        return {
            'Agusan del Norte': [8.9470, 125.5406],
            'Agusan del Sur': [8.3500, 125.9833],
            'Basilan': [6.4375, 121.9731],
            'Bukidnon': [8.1333, 125.1333],
            'Camiguin': [9.1667, 124.7333],
            'Compostela Valley': [7.6667, 126.0833],
            'Davao del Norte': [7.4167, 125.6500],
            'Davao del Sur': [6.7833, 125.3333],
            'Davao Oriental': [7.0000, 126.5000],
            'Lanao del Norte': [8.0000, 123.8333],
            'Lanao del Sur': [7.8333, 124.3333],
            'Maguindanao': [6.9333, 124.4000],
            'Misamis Occidental': [8.5000, 123.8333],
            'Misamis Oriental': [8.6500, 124.9000],
            'North Cotabato': [7.3333, 124.8333],
            'Sarangani': [5.9167, 125.2167],
            'South Cotabato': [6.3500, 124.8500],
            'Sultan Kudarat': [6.5833, 124.2500],
            'Sulu': [6.0500, 121.0000],
            'Surigao del Norte': [9.7500, 125.5000],
            'Surigao del Sur': [8.6167, 126.1667],
            'Tawi-Tawi': [5.1333, 119.9500],
            'Zamboanga del Norte': [8.5500, 123.2500],
            'Zamboanga del Sur': [7.8333, 123.3000],
            'Zamboanga Sibugay': [7.6000, 122.8000]
        };
    }

    static isWithinMindanao(lat, lng) {
        // Rough bounding box for Mindanao
        return lat >= 4.5 && lat <= 10.5 && lng >= 119.0 && lng <= 127.0;
    }

    static getNearestCity(lat, lng) {
        const cities = this.getMajorCities();
        let nearest = null;
        let minDistance = Infinity;

        for (const [city, coords] of Object.entries(cities)) {
            const distance = this.calculateDistance(lat, lng, coords[0], coords[1]);
            if (distance < minDistance) {
                minDistance = distance;
                nearest = { city, coords, distance };
            }
        }

        return nearest;
    }

    static calculateDistance(lat1, lng1, lat2, lng2) {
        const R = 6371;
        const dLat = (lat2 - lat1) * Math.PI / 180;
        const dLng = (lng2 - lng1) * Math.PI / 180;
        const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                  Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
                  Math.sin(dLng / 2) * Math.sin(dLng / 2);
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        return R * c;
    }
}

// Export for use in other scripts
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { RiderMapManager, MindanaoMapUtils };
}

// Global initialization function
function initRiderMap(containerId, options = {}) {
    return new RiderMapManager(containerId, options);
}
