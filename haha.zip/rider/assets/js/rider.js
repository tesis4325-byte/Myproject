// RM Delivery Rider JavaScript

class RiderManager {
    constructor() {
        this.isOnline = true;
        this.currentLocation = null;
        this.watchId = null;
        this.geoBlocked = false;
        this.loggedGeoDeniedOnce = false; // to suppress repeated logs
        this.init();
    }

    async saveSettings(formEl) {
        const currentPassword = (document.getElementById('currentPassword')?.value || '').trim();
        const newPassword = (document.getElementById('newPassword')?.value || '').trim();

        if (!currentPassword || !newPassword) {
            this.showWarning('Please fill both current and new password.');
            return;
        }
        if (newPassword.length < 6) {
            this.showWarning('New password must be at least 6 characters.');
            return;
        }

        try {
            const res = await fetch('../api/riders.php?action=change_password', {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ current_password: currentPassword, new_password: newPassword })
            });
            const data = await res.json();
            if (!res.ok || !data.success) throw new Error(data.message || 'Password change failed');

            // Clear fields after success
            document.getElementById('currentPassword').value = '';
            document.getElementById('newPassword').value = '';
            this.showSuccess('Password updated successfully');
        } catch (err) {
            console.error('Failed to change password:', err);
            this.showError(err.message || 'Failed to change password');
        }
    }

    async saveVehicleInfo(formEl) {
        const vehicleType = (document.getElementById('vehicleType')?.value || '').trim();
        const plateNumber = (document.getElementById('plateNumber')?.value || '').trim();

        if (!vehicleType && !plateNumber) {
            this.showWarning('Please select a vehicle type or enter a plate number.');
            return;
        }

        try {
            const res = await fetch('../api/riders.php?action=update_profile', {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ vehicle_type: vehicleType, vehicle_plate: plateNumber })
            });
            const data = await res.json();
            if (!res.ok || !data.success) throw new Error(data.message || 'Update failed');

            this.showSuccess('Vehicle information updated');
        } catch (err) {
            console.error('Failed to update vehicle info:', err);
            this.showError(err.message || 'Failed to update vehicle information');
        }
    }

    // Profile loading for rider/profile.php
    async loadProfileIfOnPage() {
        // Only run on the profile page where these elements exist
        const nameEl = document.getElementById('profileName');
        const phoneEl = document.getElementById('profilePhone');
        const ratingEl = document.getElementById('profileRating');
        const deliveriesEl = document.getElementById('profileDeliveries');
        const personalForm = document.getElementById('personalInfoForm');
        const vehicleForm = document.getElementById('vehicleInfoForm');

        if (!nameEl && !personalForm && !vehicleForm) return; // not on profile page

        try {
            const res = await this.get('../api/riders.php?action=profile');
            const profile = (res && res.data && res.data.rider) ? res.data.rider : null;
            if (!profile) throw new Error('Profile not found');

            // Header info
            if (nameEl) nameEl.textContent = profile.full_name || 'Unknown Rider';
            if (phoneEl) phoneEl.textContent = profile.phone || '';
            if (ratingEl) ratingEl.textContent = (profile.rating != null ? Number(profile.rating).toFixed(1) : '5.0');
            if (deliveriesEl) deliveriesEl.textContent = profile.total_deliveries != null ? profile.total_deliveries : '0';

            // Personal form
            if (personalForm) {
                const firstNameInput = document.getElementById('firstName');
                const lastNameInput = document.getElementById('lastName');
                const emailInput = document.getElementById('email');
                const phoneInput = document.getElementById('phone');

                const fullName = profile.full_name || '';
                let first = fullName;
                let last = '';
                if (fullName.includes(' ')) {
                    const parts = fullName.trim().split(/\s+/);
                    first = parts.slice(0, -1).join(' ');
                    last = parts.slice(-1).join(' ');
                }

                if (firstNameInput) firstNameInput.value = first;
                if (lastNameInput) lastNameInput.value = last;
                if (emailInput) emailInput.value = profile.email || '';
                if (phoneInput) phoneInput.value = profile.phone || '';
            }

            // Vehicle form
            if (vehicleForm) {
                const vehicleTypeSel = document.getElementById('vehicleType');
                const plateInput = document.getElementById('plateNumber');
                const vt = (profile.vehicle_type || '').toLowerCase();
                if (vehicleTypeSel && vt) {
                    // Only set if option exists to avoid leaving an invalid value selected
                    const hasOption = Array.from(vehicleTypeSel.options).some(o => o.value === vt);
                    if (hasOption) vehicleTypeSel.value = vt;
                }
                if (plateInput) plateInput.value = profile.vehicle_plate || '';
            }

            // Profile image: if server later provides a photo URL, set here
            const img = document.getElementById('profileImage');
            if (img && profile.photo_url) {
                img.src = profile.photo_url;
            }
        } catch (err) {
            console.error('Failed to load profile:', err);
            // Keep placeholders but notify user subtly
            this.showWarning('Could not load your profile details.');
        }
    }

    async savePersonalInfo(formEl) {
        const firstName = (document.getElementById('firstName')?.value || '').trim();
        const lastName  = (document.getElementById('lastName')?.value || '').trim();
        const email     = (document.getElementById('email')?.value || '').trim();
        const phone     = (document.getElementById('phone')?.value || '').trim();

        // Basic validation
        if (!firstName && !lastName && !email && !phone) {
            this.showWarning('Please fill at least one field to update.');
            return;
        }

        try {
            const res = await fetch('../api/riders.php?action=update_personal_info', {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ first_name: firstName, last_name: lastName, email, phone })
            });
            const data = await res.json();
            if (!res.ok || !data.success) throw new Error(data.message || 'Update failed');

            // Update header display
            const fullName = [firstName, lastName].filter(Boolean).join(' ').trim();
            const nameEl = document.getElementById('profileName');
            const phoneEl = document.getElementById('profilePhone');
            if (nameEl && fullName) nameEl.textContent = fullName;
            if (phoneEl && phone) phoneEl.textContent = phone;

            this.showSuccess('Personal information updated');
        } catch (err) {
            console.error('Failed to update personal info:', err);
            this.showError(err.message || 'Failed to update personal info');
        }
    }

    init() {
        this.setupEventListeners();
        this.startLocationTracking();
        this.loadProfileIfOnPage();
    }

    setupEventListeners() {
        // Handle form submissions
        document.addEventListener('submit', (e) => {
            if (e.target.id === 'riderLoginForm') {
                this.handleLogin(e);
                return;
            }
            if (e.target.id === 'personalInfoForm') {
                e.preventDefault();
                this.savePersonalInfo(e.target);
                return;
            }
            if (e.target.id === 'vehicleInfoForm') {
                e.preventDefault();
                this.saveVehicleInfo(e.target);
                return;
            }
            if (e.target.id === 'settingsForm') {
                e.preventDefault();
                this.saveSettings(e.target);
                return;
            }
        });

        // Profile image upload handling
        const fileInput = document.getElementById('profileImageInput');
        if (fileInput) {
            fileInput.addEventListener('change', async (e) => {
                const file = e.target.files && e.target.files[0];
                if (!file) return;
                try {
                    // Instant preview
                    const img = document.getElementById('profileImage');
                    if (img) {
                        const tmpUrl = URL.createObjectURL(file);
                        img.src = tmpUrl;
                    }

                    // Upload
                    const formData = new FormData();
                    formData.append('profile_image', file);
                    const response = await fetch('../api/riders.php?action=upload_profile_image', {
                        method: 'POST',
                        body: formData,
                    });

                    const result = await response.json();
                    if (!response.ok || !result.success) {
                        throw new Error(result.message || 'Upload failed');
                    }

                    // Use returned URL and bust cache
                    if (img && result.data && result.data.photo_url) {
                        img.src = result.data.photo_url + `?t=${Date.now()}`;
                    }
                    this.showSuccess('Profile image updated');
                } catch (err) {
                    console.error('Upload error:', err);
                    this.showError('Failed to upload profile image');
                } finally {
                    e.target.value = '';
                }
            });
        }

        // Handle clicks outside dropdown menus
        document.addEventListener('click', (e) => {
            this.handleOutsideClicks(e);
        });

        // Handle online/offline status
        window.addEventListener('online', () => {
            this.handleConnectionChange(true);
        });

        window.addEventListener('offline', () => {
            this.handleConnectionChange(false);
        });
    }

    async handleLogin(e) {
        e.preventDefault();
        
        const form = e.target;
        const submitBtn = form.querySelector('button[type="submit"]');
        const originalText = submitBtn.innerHTML;
        
        // Show loading state
        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Signing In...';
        submitBtn.disabled = true;
        
        try {
            const formData = new FormData(form);
            const loginData = {
                phone: formData.get('phone'),
                password: formData.get('password'),
                remember_me: formData.get('remember_me') ? true : false,
                user_type: 'rider'
            };
            
            const response = await fetch('../api/auth.php?action=login', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(loginData)
            });
            
            const result = await response.json();
            
            if (result.success) {
                this.showSuccess('Login successful! Welcome back, ' + result.data.name);
                setTimeout(() => {
                    window.location.href = 'dashboard.php';
                }, 1500);
            } else {
                this.showError(result.message || 'Invalid credentials');
            }
        } catch (error) {
            console.error('Login error:', error);
            this.showError('Connection error. Please check your internet connection.');
        } finally {
            // Restore button state
            submitBtn.innerHTML = originalText;
            submitBtn.disabled = false;
        }
    }

    startLocationTracking() {
        if (this.geoBlocked) return; // don't spam when blocked
        if (!navigator.geolocation) {
            console.warn('Geolocation not supported');
            return;
        }

        // Warn if not secure context and not localhost
        try {
            const isLocal = /^(localhost|127\.0\.0\.1)$/i.test(location.hostname);
            if (!window.isSecureContext && !isLocal) {
                this.showWarning('Site is not secure (HTTPS). Location may be blocked. Use https:// or localhost for testing.');
            }
        } catch (_) {}

        const options = {
            enableHighAccuracy: true,
            timeout: 10000,
            maximumAge: 60000
        };

        // Get initial position
        navigator.geolocation.getCurrentPosition(
            (position) => {
                this.updateLocation(position);
            },
            (error) => {
                this.handleLocationError(error);
            },
            options
        );

        // Watch position changes
        this.watchId = navigator.geolocation.watchPosition(
            (position) => {
                this.updateLocation(position);
            },
            (error) => {
                this.handleLocationError(error);
            },
            options
        );
    }

    updateLocation(position) {
        this.currentLocation = {
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
            accuracy: position.coords.accuracy,
            timestamp: position.timestamp
        };

        // Send location to server if rider is logged in
        if (this.isLoggedIn()) {
            this.sendLocationToServer();
        }
    }

    async sendLocationToServer() {
        if (!this.currentLocation) return;

        try {
            await fetch('../api/rider.php?action=update_location', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    latitude: this.currentLocation.latitude,
                    longitude: this.currentLocation.longitude,
                    accuracy: this.currentLocation.accuracy
                })
            });
        } catch (error) {
            console.error('Error sending location:', error);
        }
    }

    handleLocationError(error) {
        let message = 'Location access denied';

        if (!error || typeof error.code === 'undefined') {
            console.warn(message);
            return;
        }

        switch (error.code) {
            case error.PERMISSION_DENIED:
                message = 'Location access denied. Please enable location services.';
                // Only show once per session
                if (!this.loggedGeoDeniedOnce) {
                    this.showLocationBanner(message);
                    console.warn(message);
                    this.loggedGeoDeniedOnce = true;
                }
                // Stop watching to avoid repeated errors
                this.geoBlocked = true;
                if (this.watchId) {
                    try { navigator.geolocation.clearWatch(this.watchId); } catch(_) {}
                    this.watchId = null;
                }
                break;
            case error.POSITION_UNAVAILABLE:
                message = 'Location information unavailable.';
                this.showWarning(message);
                break;
            case error.TIMEOUT:
                message = 'Location request timed out.';
                this.showWarning(message);
                break;
            default:
                this.showWarning(message);
        }
        // Do not spam console beyond the first warning
    }

    requestLocationPermission() {
        if (!navigator.geolocation) return;
        const options = { enableHighAccuracy: true, timeout: 10000, maximumAge: 60000 };
        navigator.geolocation.getCurrentPosition(
            (pos) => {
                this.removeLocationBanner();
                this.updateLocation(pos);
                // Resume tracking after successful permission
                this.geoBlocked = false;
                this.loggedGeoDeniedOnce = false; // reset so future denials can warn once again
                if (!this.watchId) {
                    this.startLocationTracking();
                }
            },
            (err) => this.handleLocationError(err),
            options
        );
    }

    showLocationBanner(text) {
        // Avoid duplicate banner
        if (document.getElementById('location-permission-banner')) return;

        const banner = document.createElement('div');
        banner.id = 'location-permission-banner';
        banner.innerHTML = `
            <div style="display:flex; align-items:center; gap:10px;">
                <span>📍 ${text}</span>
                <button id="retry-location-btn" style="padding:6px 10px; border:none; background:#007bff; color:#fff; border-radius:4px; cursor:pointer;">Retry</button>
                <button id="dismiss-location-btn" style="padding:6px 10px; border:1px solid #ccc; background:#fff; color:#333; border-radius:4px; cursor:pointer;">Dismiss</button>
            </div>`;
        Object.assign(banner.style, {
            position: 'fixed',
            bottom: '20px',
            right: '20px',
            background: '#fff8e1',
            border: '1px solid #ffe58f',
            color: '#8a6d3b',
            padding: '12px 14px',
            borderRadius: '8px',
            zIndex: 10000,
            boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
        });
        document.body.appendChild(banner);

        const retryBtn = banner.querySelector('#retry-location-btn');
        const dismissBtn = banner.querySelector('#dismiss-location-btn');
        retryBtn.addEventListener('click', () => this.requestLocationPermission());
        dismissBtn.addEventListener('click', () => this.removeLocationBanner());
    }

    removeLocationBanner() {
        const banner = document.getElementById('location-permission-banner');
        if (banner && banner.parentNode) {
            banner.parentNode.removeChild(banner);
        }
    }

    handleConnectionChange(isOnline) {
        if (isOnline) {
            this.showSuccess('Connection restored');
            // Sync any pending data
            this.syncPendingData();
        } else {
            this.showWarning('Connection lost. Working offline.');
        }
    }

    async syncPendingData() {
        // Sync any offline data when connection is restored
        try {
            const pendingData = this.getPendingData();
            if (pendingData.length > 0) {
                await this.sendPendingData(pendingData);
                this.clearPendingData();
            }
        } catch (error) {
            console.error('Error syncing data:', error);
        }
    }

    getPendingData() {
        const data = localStorage.getItem('pendingRiderData');
        return data ? JSON.parse(data) : [];
    }

    addPendingData(data) {
        const pending = this.getPendingData();
        pending.push({
            ...data,
            timestamp: Date.now()
        });
        localStorage.setItem('pendingRiderData', JSON.stringify(pending));
    }

    clearPendingData() {
        localStorage.removeItem('pendingRiderData');
    }

    async sendPendingData(data) {
        for (const item of data) {
            try {
                await fetch('../api/rider.php?action=sync_data', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify(item)
                });
            } catch (error) {
                console.error('Error sending pending data:', error);
            }
        }
    }

    handleOutsideClicks(e) {
        // Close dropdown menus when clicking outside
        const dropdowns = document.querySelectorAll('.dropdown-menu');
        dropdowns.forEach(dropdown => {
            const menuBtn = dropdown.previousElementSibling;
            if (!menuBtn.contains(e.target) && !dropdown.contains(e.target)) {
                dropdown.style.display = 'none';
            }
        });
    }

    isLoggedIn() {
        // Check if user is logged in (you can implement your own logic)
        return document.body.classList.contains('logged-in') || 
               window.location.pathname.includes('dashboard');
    }

    // Utility methods for notifications
    showSuccess(message) {
        if (typeof Swal !== 'undefined') {
            Swal.fire({
                icon: 'success',
                title: 'Success',
                text: message,
                timer: 3000,
                showConfirmButton: false,
                toast: true,
                position: 'top-end'
            });
        } else {
            this.showToast(message, 'success');
        }
    }

    showError(message) {
        if (typeof Swal !== 'undefined') {
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: message,
                confirmButtonText: 'OK'
            });
        } else {
            this.showToast(message, 'error');
        }
    }

    showWarning(message) {
        if (typeof Swal !== 'undefined') {
            Swal.fire({
                icon: 'warning',
                title: 'Warning',
                text: message,
                timer: 5000,
                showConfirmButton: false,
                toast: true,
                position: 'top-end'
            });
        } else {
            this.showToast(message, 'warning');
        }
    }

    showInfo(message) {
        if (typeof Swal !== 'undefined') {
            Swal.fire({
                icon: 'info',
                title: 'Info',
                text: message,
                timer: 3000,
                showConfirmButton: false,
                toast: true,
                position: 'top-end'
            });
        } else {
            this.showToast(message, 'info');
        }
    }

    showToast(message, type = 'info') {
        // Fallback toast notification if SweetAlert is not available
        const toast = document.createElement('div');
        toast.className = `toast toast-${type}`;
        toast.textContent = message;
        
        // Style the toast
        Object.assign(toast.style, {
            position: 'fixed',
            top: '20px',
            right: '20px',
            padding: '12px 20px',
            borderRadius: '8px',
            color: 'white',
            fontWeight: '600',
            zIndex: '10000',
            maxWidth: '300px',
            wordWrap: 'break-word'
        });

        // Set background color based on type
        const colors = {
            success: '#28a745',
            error: '#dc3545',
            warning: '#ffc107',
            info: '#17a2b8'
        };
        toast.style.backgroundColor = colors[type] || colors.info;

        document.body.appendChild(toast);

        // Remove toast after 3 seconds
        setTimeout(() => {
            if (toast.parentNode) {
                toast.parentNode.removeChild(toast);
            }
        }, 3000);
    }

    // Format utilities
    formatCurrency(amount) {
        return new Intl.NumberFormat('en-PH', {
            style: 'currency',
            currency: 'PHP'
        }).format(amount);
    }

    formatDistance(distance) {
        if (distance < 1) {
            return (distance * 1000).toFixed(0) + ' m';
        }
        return distance.toFixed(1) + ' km';
    }

    formatTime(timestamp) {
        const date = new Date(timestamp);
        return date.toLocaleTimeString('en-PH', {
            hour: '2-digit',
            minute: '2-digit'
        });
    }

    formatDate(timestamp) {
        const date = new Date(timestamp);
        return date.toLocaleDateString('en-PH', {
            month: 'short',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    }

    // API helper methods
    async makeRequest(url, options = {}) {
        const defaultOptions = {
            headers: {
                'Content-Type': 'application/json',
            }
        };

        const finalOptions = { ...defaultOptions, ...options };

        try {
            const response = await fetch(url, finalOptions);
            const result = await response.json();
            
            if (!response.ok) {
                throw new Error(result.message || 'Request failed');
            }
            
            return result;
        } catch (error) {
            console.error('API request error:', error);
            
            // Store request for later if offline
            if (!navigator.onLine) {
                this.addPendingData({
                    url,
                    options: finalOptions,
                    type: 'api_request'
                });
            }
            
            throw error;
        }
    }

    async get(url) {
        return this.makeRequest(url, { method: 'GET' });
    }

    async post(url, data) {
        return this.makeRequest(url, {
            method: 'POST',
            body: JSON.stringify(data)
        });
    }

    async put(url, data) {
        return this.makeRequest(url, {
            method: 'PUT',
            body: JSON.stringify(data)
        });
    }

    async delete(url) {
        return this.makeRequest(url, { method: 'DELETE' });
    }

    // Cleanup method
    destroy() {
        if (this.watchId) {
            navigator.geolocation.clearWatch(this.watchId);
        }
    }
}

// Global utility functions
function togglePassword() {
    const passwordInput = document.getElementById('password');
    const toggleIcon = document.getElementById('passwordToggleIcon');
    
    if (passwordInput && toggleIcon) {
        if (passwordInput.type === 'password') {
            passwordInput.type = 'text';
            toggleIcon.classList.remove('fa-eye');
            toggleIcon.classList.add('fa-eye-slash');
        } else {
            passwordInput.type = 'password';
            toggleIcon.classList.remove('fa-eye-slash');
            toggleIcon.classList.add('fa-eye');
        }
    }
}

function showRegistrationInfo() {
    if (typeof Swal !== 'undefined') {
        Swal.fire({
            icon: 'info',
            title: 'Rider Registration',
            html: `
                <p>To become a rider, please contact our admin team:</p>
                <div style="margin: 1rem 0;">
                    <strong>Phone:</strong> +63 912 345 6789<br>
                    <strong>Email:</strong> admin@rmdelivery.com
                </div>
                <p><small>We'll verify your documents and vehicle registration before creating your account.</small></p>
            `,
            confirmButtonText: 'Got it!'
        });
    } else {
        alert('To become a rider, please contact our admin team at +63 912 345 6789 or admin@rmdelivery.com');
    }
}

// Initialize rider manager when DOM is loaded
let riderManager;

document.addEventListener('DOMContentLoaded', function() {
    riderManager = new RiderManager();
});

// Cleanup on page unload
window.addEventListener('beforeunload', function() {
    if (riderManager) {
        riderManager.destroy();
    }
});

// Export for use in other scripts
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { RiderManager };
}
