<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'rider') {
    header('Location: index.php');
    exit();
}

$pageTitle = 'Profile';
$riderName = $_SESSION['name'] ?? 'Rider';
$riderId = $_SESSION['user_id'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?> - RM Delivery Rider</title>
    <link rel="stylesheet" href="assets/css/rider.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body>
    <!-- Floating hamburger for mobile -->
    <button class="sidebar-toggle floating-sidebar-toggle" aria-label="Toggle menu" onclick="toggleSidebar()">
        <i class="fas fa-bars"></i>
    </button>
    <div class="rider-app">
        <!-- Header -->
        <header class="rider-header">
            <div class="header-left">
                <a href="dashboard.php" class="back-btn">
                    <i class="fas fa-arrow-left"></i>
                </a>
                <div class="page-title">
                    <h2>My Profile</h2>
                    <span class="subtitle">Manage your account</span>
                </div>
            </div>
            
            <div class="header-right">
                <div class="rider-info">
                    <span class="rider-name"><?php echo htmlspecialchars($riderName); ?></span>
                    <span class="rider-status online">Online</span>
                </div>
            </div>
        </header>

        <!-- Body with Sidebar + Main Content -->
        <div class="rider-body">
            <?php include __DIR__ . '/templates/sidebar.php'; ?>
            <div class="sidebar-backdrop" id="sidebarBackdrop" onclick="closeSidebar()"></div>
            <main class="rider-main profile-main">
            <!-- Profile Tabs -->
            <div class="profile-tabs">
                <button class="tab-button active" data-tab="personal" onclick="switchTab('personal')">
                    <i class="fas fa-user"></i> Personal Info
                </button>
                <button class="tab-button" data-tab="vehicle" onclick="switchTab('vehicle')">
                    <i class="fas fa-motorcycle"></i> Vehicle
                </button>
                <button class="tab-button" data-tab="documents" onclick="switchTab('documents')">
                    <i class="fas fa-file-alt"></i> Documents
                </button>
                <button class="tab-button" data-tab="settings" onclick="switchTab('settings')">
                    <i class="fas fa-cog"></i> Settings
                </button>
            </div>

            <!-- Personal Info Tab -->
            <div class="tab-content active" id="personalTab">
                <div class="profile-card">
                    <div class="profile-header">
                        <div class="profile-avatar">
                            <img id="profileImage" src="../admin/assets/images/default-avatar.svg" alt="Profile" onerror="this.onerror=null;this.src='../admin/assets/images/default-avatar.svg'">
                            <input type="file" id="profileImageInput" accept="image/*" style="display:none" />
                            <button type="button" class="avatar-upload" onclick="document.getElementById('profileImageInput').click()">
                                <i class="fas fa-camera"></i>
                            </button>
                        </div>
                        <div class="profile-info">
                            <h3 id="profileName">Loading...</h3>
                            <p id="profilePhone">Loading...</p>
                            <div class="profile-stats">
                                <div class="stat">
                                    <span class="stat-value" id="profileRating">5.0</span>
                                    <span class="stat-label">Rating</span>
                                </div>
                                <div class="stat">
                                    <span class="stat-value" id="profileDeliveries">0</span>
                                    <span class="stat-label">Deliveries</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <form id="personalInfoForm" class="profile-form">
                        <div class="form-section">
                            <h4>Personal Information</h4>
                            <div class="form-grid">
                                <div class="form-group">
                                    <label for="firstName">First Name</label>
                                    <input type="text" id="firstName" name="first_name" required>
                                </div>
                                <div class="form-group">
                                    <label for="lastName">Last Name</label>
                                    <input type="text" id="lastName" name="last_name" required>
                                </div>
                                <div class="form-group">
                                    <label for="email">Email</label>
                                    <input type="email" id="email" name="email" required>
                                </div>
                                <div class="form-group">
                                    <label for="phone">Phone Number</label>
                                    <input type="tel" id="phone" name="phone" required>
                                </div>
                            </div>
                        </div>
                        
                        <div class="form-actions">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save"></i> Save Changes
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Vehicle Tab -->
            <div class="tab-content" id="vehicleTab">
                <div class="profile-card">
                    <form id="vehicleInfoForm" class="profile-form">
                        <div class="form-section">
                            <h4>Vehicle Information</h4>
                            <div class="form-grid">
                                <div class="form-group">
                                    <label for="vehicleType">Vehicle Type</label>
                                    <select id="vehicleType" name="vehicle_type" required>
                                        <option value="">Select Vehicle Type</option>
                                        <option value="motorcycle">Motorcycle</option>
                                        <option value="bicycle">Bicycle</option>
                                        <option value="car">Car</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="plateNumber">Plate Number</label>
                                    <input type="text" id="plateNumber" name="plate_number" required>
                                </div>
                            </div>
                        </div>
                        
                        <div class="form-actions">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save"></i> Save Vehicle Info
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Documents Tab -->
            <div class="tab-content" id="documentsTab">
                <div class="profile-card">
                    <div class="documents-section">
                        <h4>Required Documents</h4>
                        <div class="documents-grid">
                            <div class="document-item">
                                <div class="document-icon">
                                    <i class="fas fa-id-card"></i>
                                </div>
                                <div class="document-info">
                                    <h5>Valid ID</h5>
                                    <p>Government-issued ID</p>
                                    <span class="document-status pending" id="validIdStatus">Pending</span>
                                </div>
                                <div class="document-actions">
                                    <input type="file" id="validIdFile" accept="image/*" style="display: none;">
                                    <button class="btn btn-sm btn-secondary" onclick="document.getElementById('validIdFile').click()">
                                        <i class="fas fa-upload"></i> Upload
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Settings Tab -->
            <div class="tab-content" id="settingsTab">
                <div class="profile-card">
                    <form id="settingsForm" class="profile-form">
                        <div class="form-section">
                            <h4>Account Settings</h4>
                            <div class="form-grid">
                                <div class="form-group">
                                    <label for="currentPassword">Current Password</label>
                                    <input type="password" id="currentPassword" name="current_password">
                                </div>
                                <div class="form-group">
                                    <label for="newPassword">New Password</label>
                                    <input type="password" id="newPassword" name="new_password">
                                </div>
                            </div>
                        </div>
                        
                        <div class="form-actions">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save"></i> Save Settings
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </main>
        </div>
    </div>

    <script src="assets/js/rider.js"></script>
    <script>
        // Sidebar toggle helpers (only define if not already present)
        if (typeof openSidebar !== 'function') {
            function openSidebar() {
                document.body.classList.add('sidebar-open');
                const backdrop = document.getElementById('sidebarBackdrop');
                if (backdrop) backdrop.style.display = 'block';
            }
        }
        if (typeof closeSidebar !== 'function') {
            function closeSidebar() {
                document.body.classList.remove('sidebar-open');
                const backdrop = document.getElementById('sidebarBackdrop');
                if (backdrop) backdrop.style.display = 'none';
            }
        }
        if (typeof toggleSidebar !== 'function') {
            function toggleSidebar() {
                if (document.body.classList.contains('sidebar-open')) {
                    closeSidebar();
                } else {
                    openSidebar();
                }
            }
        }

        document.addEventListener('DOMContentLoaded', function() {
            // Close on ESC
            document.addEventListener('keydown', function(e) {
                if (e.key === 'Escape') closeSidebar();
            });
            // Reset state on resize
            window.addEventListener('resize', function() {
                const backdrop = document.getElementById('sidebarBackdrop');
                if (window.innerWidth > 768) {
                    document.body.classList.remove('sidebar-open');
                    if (backdrop) backdrop.style.display = 'none';
                } else if (backdrop) {
                    backdrop.style.display = document.body.classList.contains('sidebar-open') ? 'block' : 'none';
                }
            });
        });
        function switchTab(tabName) {
            document.querySelectorAll('.tab-button').forEach(btn => {
                btn.classList.remove('active');
            });
            document.querySelector(`[data-tab="${tabName}"]`).classList.add('active');
            
            document.querySelectorAll('.tab-content').forEach(content => {
                content.classList.remove('active');
            });
            document.getElementById(`${tabName}Tab`).classList.add('active');
        }

        // kept for backward compatibility if referenced elsewhere
        function uploadProfileImage() {
            const input = document.getElementById('profileImageInput');
            if (input) input.click();
        }
    </script>

    <style>
        .profile-main {
            max-width: 800px;
            margin: 0 auto;
        }

        .profile-tabs {
            display: flex;
            gap: 0.5rem;
            margin-bottom: 2rem;
            border-bottom: 2px solid var(--gray-200);
        }

        .tab-button {
            padding: 0.75rem 1rem;
            border: none;
            background: none;
            color: var(--gray-600);
            cursor: pointer;
            border-bottom: 2px solid transparent;
            transition: all 0.3s ease;
        }

        .tab-button.active {
            color: var(--primary-color);
            border-bottom-color: var(--primary-color);
        }

        .tab-content {
            display: none;
        }

        .tab-content.active {
            display: block;
        }

        .profile-card {
            background: var(--white);
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            padding: 2rem;
        }

        .profile-header {
            display: flex;
            align-items: center;
            gap: 2rem;
            margin-bottom: 2rem;
            padding-bottom: 2rem;
            border-bottom: 1px solid var(--gray-200);
        }

        .profile-avatar {
            position: relative;
        }

        .profile-avatar img {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            object-fit: cover;
        }

        .avatar-upload {
            position: absolute;
            bottom: 0;
            right: 0;
            background: var(--primary-color);
            color: white;
            border: none;
            border-radius: 50%;
            width: 30px;
            height: 30px;
            cursor: pointer;
        }

        .profile-stats {
            display: flex;
            gap: 2rem;
            margin-top: 1rem;
        }

        .stat {
            text-align: center;
        }

        .stat-value {
            display: block;
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--primary-color);
        }

        .stat-label {
            font-size: 0.8rem;
            color: var(--gray-600);
        }

        .form-section {
            margin-bottom: 2rem;
        }

        .form-section h4 {
            margin-bottom: 1rem;
            color: var(--gray-800);
            border-bottom: 2px solid var(--primary-color);
            padding-bottom: 0.5rem;
        }

        .form-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1rem;
        }

        .form-group {
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
        }

        .form-group label {
            font-weight: 600;
            color: var(--gray-700);
        }

        .form-group input, .form-group select, .form-group textarea {
            padding: 0.75rem;
            border: 1px solid var(--gray-300);
            border-radius: var(--border-radius);
        }

        .form-actions {
            display: flex;
            gap: 1rem;
            justify-content: flex-end;
            margin-top: 2rem;
        }

        .documents-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 1rem;
        }

        .document-item {
            display: flex;
            align-items: center;
            gap: 1rem;
            padding: 1rem;
            border: 1px solid var(--gray-200);
            border-radius: var(--border-radius);
        }

        .document-icon {
            font-size: 2rem;
            color: var(--primary-color);
        }

        .document-info {
            flex: 1;
        }

        .document-status {
            padding: 0.25rem 0.5rem;
            border-radius: 1rem;
            font-size: 0.7rem;
            font-weight: 600;
        }

        .document-status.pending {
            background: var(--warning-color);
            color: white;
        }

        .document-status.approved {
            background: var(--success-color);
            color: white;
        }
    </style>
</body>
</html>
