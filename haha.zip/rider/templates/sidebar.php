<?php
// Rider Sidebar Template
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['user_id']) || ($_SESSION['user_type'] ?? '') !== 'rider') {
    // Do not render if not a rider
    return;
}
$active = basename(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH));
$riderName = $_SESSION['name'] ?? 'Rider';
?>
<aside class="rider-sidebar light">
    <div class="sidebar-header">
        <div class="logo">
            <i class="fas fa-motorcycle"></i>
            <span>Rider Panel</span>
        </div>
        <button class="close-sidebar-btn" aria-label="Close menu" onclick="closeSidebar()">
            <i class="fas fa-times"></i>
        </button>
    </div>

    <div class="sidebar-profile">
        <div class="avatar"><i class="fas fa-user"></i></div>
        <div class="meta">
            <div class="name"><?php echo htmlspecialchars($riderName); ?></div>
            <div class="role">Delivery Rider</div>
        </div>
    </div>

    <nav class="sidebar-nav">
        <ul class="sidebar-menu">
            <li class="menu-item <?php echo $active === 'dashboard.php' ? 'active' : ''; ?>">
                <a href="dashboard.php">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="menu-item <?php echo $active === 'bookings.php' ? 'active' : ''; ?>">
                <a href="bookings.php">
                    <i class="fas fa-list"></i>
                    <span>Bookings</span>
                </a>
            </li>
            <li class="menu-item <?php echo $active === 'history.php' ? 'active' : ''; ?>">
                <a href="history.php">
                    <i class="fas fa-history"></i>
                    <span>History</span>
                </a>
            </li>
            <li class="menu-item <?php echo $active === 'profile.php' ? 'active' : ''; ?>">
                <a href="profile.php">
                    <i class="fas fa-user"></i>
                    <span>Profile</span>
                </a>
            </li>
            <li class="menu-item <?php echo $active === 'panic.php' ? 'active' : ''; ?>">
                <a href="panic.php">
                    <i class="fas fa-exclamation-triangle"></i>
                    <span>Panic</span>
                </a>
            </li>
        </ul>
    </nav>

    <div class="sidebar-footer">
        <button class="logout-btn" onclick="window.location.href='../api/auth.php?action=logout&redirect=1'">
            <i class="fas fa-sign-out-alt"></i><span>Logout</span>
        </button>
    </div>
</aside>


