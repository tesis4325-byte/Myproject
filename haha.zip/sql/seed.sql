-- RM Delivery Management System - Sample Data
-- Default accounts and sample data for testing

USE rmdelivery_db;

-- Insert default Admin account
INSERT INTO users (username, email, phone, password, role, full_name, status, created_at) VALUES
('admin', 'admin@rmdelivery.com', '09123456789', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', 'System Administrator', 'active', NOW());

-- Insert default Rider user account
INSERT INTO users (username, email, phone, password, role, full_name, status, created_at) VALUES
('rider001', 'rider@rmdelivery.com', '09987654321', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'rider', 'Test Rider', 'active', NOW());

-- Insert rider details for the test rider
INSERT INTO riders (user_id, license_number, vehicle_type, vehicle_plate, vehicle_model, emergency_contact, emergency_name, created_at) VALUES
(2, 'LIC123456789', 'motorcycle', 'ABC-1234', 'Honda Click 150i', '+639111222333', 'Emergency Contact', NOW());

-- Insert sample customers
INSERT INTO customers (full_name, email, phone, address, created_at) VALUES
('John Doe', 'john@example.com', '09111111111', '123 Main St, Cagayan de Oro', NOW()),
('Jane Smith', 'jane@example.com', '09222222222', '456 Oak Ave, Butuan City', NOW());

-- Insert sample merchants
INSERT INTO merchants (name, slug, email, phone, address, lat, lng, created_at) VALUES
('Jollibee CDO', 'jollibee-cdo', 'jollibee@example.com', '09333333333', 'Limketkai Mall, Cagayan de Oro', 8.4542, 124.6319, NOW()),
('Mang Inasal Butuan', 'mang-inasal-butuan', 'manginasal@example.com', '09444444444', 'Gaisano Mall, Butuan City', 8.9470, 125.5406, NOW());

-- Insert sample menu items
INSERT INTO menu_items (merchant_id, name, description, category, price, is_available, status, created_at) VALUES
(1, 'Chickenjoy', 'Crispy fried chicken', 'Main Course', 89.00, 1, 'active', NOW()),
(1, 'Jolly Spaghetti', 'Sweet style spaghetti', 'Pasta', 65.00, 1, 'active', NOW()),
(1, 'Burger Steak', 'Beef patty with rice', 'Main Course', 75.00, 1, 'active', NOW()),
(2, 'Chicken Inasal', 'Grilled chicken', 'Grilled', 120.00, 1, 'active', NOW()),
(2, 'Pork BBQ', 'Grilled pork skewers', 'Grilled', 45.00, 1, 'active', NOW());

-- Insert sample bookings
INSERT INTO bookings (
    booking_number, customer_id, merchant_id, rider_id, type,
    customer_name, customer_phone,
    pickup_address, delivery_address, 
    delivery_lat, delivery_lng,
    items, subtotal, delivery_fee, total_amount,
    status, accepted_at, picked_up_at, delivered_at, created_at
) VALUES
(
    'RM001', 1, 1, 1, 'food_delivery',
    'John Doe', '09111111111',
    'Limketkai Mall, CDO', '123 Main St, CDO',
    8.4542, 124.6319,
    '[{"name":"Chickenjoy","quantity":1,"price":89.00},{"name":"Jolly Spaghetti","quantity":1,"price":65.00}]',
    154.00, 50.00, 204.00,
    'delivered', DATE_SUB(NOW(), INTERVAL 1 DAY), DATE_SUB(NOW(), INTERVAL 1 DAY), DATE_SUB(NOW(), INTERVAL 23 HOUR), DATE_SUB(NOW(), INTERVAL 1 DAY)
),
(
    'RM002', 2, 2, 1, 'food_delivery', 
    'Jane Smith', '09222222222',
    'Gaisano Mall, Butuan', '456 Oak Ave, Butuan',
    8.9470, 125.5406,
    '[{"name":"Chicken Inasal","quantity":1,"price":120.00},{"name":"Pork BBQ","quantity":1,"price":45.00}]',
    165.00, 60.00, 225.00,
    'delivered', DATE_SUB(NOW(), INTERVAL 2 DAY), DATE_SUB(NOW(), INTERVAL 2 DAY), DATE_SUB(NOW(), INTERVAL 47 HOUR), DATE_SUB(NOW(), INTERVAL 2 DAY)
);

-- Note: Default password for all accounts is 'password123'
-- Admin credentials: 09123456789 / password123  
-- Rider credentials: 09987654321 / password123
-- Customer credentials: 09111111111 / password123
