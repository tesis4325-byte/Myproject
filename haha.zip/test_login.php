<?php
// Simple login test
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'config/Database.php';

try {
    $db = Database::getInstance()->getConnection();
    
    // Test the exact login flow
    $phone = '09123456789';
    $password = 'password123';
    
    echo "<h2>Login Test for Admin</h2>";
    echo "Phone: $phone<br>";
    echo "Password: $password<br><br>";
    
    // Check if user exists
    $stmt = $db->prepare("SELECT * FROM users WHERE phone = ? AND role = 'admin' AND status = 'active'");
    $stmt->execute([$phone]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($user) {
        echo "✅ User found in database<br>";
        echo "User ID: " . $user['id'] . "<br>";
        echo "Full Name: " . $user['full_name'] . "<br>";
        echo "Role: " . $user['role'] . "<br>";
        echo "Status: " . $user['status'] . "<br><br>";
        
        // Test password
        $passwordValid = password_verify($password, $user['password']);
        echo "Password verification: " . ($passwordValid ? "✅ SUCCESS" : "❌ FAILED") . "<br><br>";
        
        if ($passwordValid) {
            echo "🎉 Login should work! Testing API call...<br><br>";
            
            // Test API call
            $loginData = [
                'phone' => $phone,
                'password' => $password,
                'user_type' => 'admin'
            ];
            
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, 'http://localhost/rmdelivery/api/auth.php?action=login');
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($loginData));
            curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            
            echo "API Response Code: $httpCode<br>";
            echo "API Response: <pre>$response</pre>";
        }
    } else {
        echo "❌ No user found with phone $phone and role 'admin'<br><br>";
        
        // Check what users exist
        $stmt = $db->query("SELECT id, username, phone, role, status FROM users");
        $allUsers = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo "All users in database:<br>";
        echo "<pre>" . print_r($allUsers, true) . "</pre>";
    }
    
} catch (Exception $e) {
    echo "❌ Error: " . $e->getMessage();
}
?>
