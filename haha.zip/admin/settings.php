<?php
$pageTitle = 'Settings';
include 'templates/header.php';
?>

<div class="dashboard-header">
    <div class="header-content">
        <div>
            <h1>Settings</h1>
            <p>Manage system and security settings</p>
        </div>
    </div>
</div>

<div class="dashboard-grid">
    <div class="dashboard-card">
        <div class="card-header">
            <h3>Security Settings</h3>
        </div>
        <div class="card-body">
            <div class="status-list" id="securitySettings">
                <div class="status-item">
                    <div class="status-content">
                        <h4>Password Policy</h4>
                        <p id="pwPolicy">Loading...</p>
                    </div>
                </div>
                <div class="status-item">
                    <div class="status-content">
                        <h4>Session</h4>
                        <p id="sessionPolicy">Loading...</p>
                    </div>
                </div>
                <div class="status-item">
                    <div class="status-content">
                        <h4>Two-Factor Authentication</h4>
                        <p id="twofaPolicy">Loading...</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="dashboard-card">
        <div class="card-header">
            <h3>System Settings</h3>
        </div>
        <div class="card-body">
            <div class="status-list" id="systemSettings">
                <div class="status-item">
                    <div class="status-content">
                        <h4>System Name</h4>
                        <p id="systemName">Loading...</p>
                    </div>
                </div>
                <div class="status-item">
                    <div class="status-content">
                        <h4>Admin Email</h4>
                        <p id="adminEmail">Loading...</p>
                    </div>
                </div>
                <div class="status-item">
                    <div class="status-content">
                        <h4>Timezone</h4>
                        <p id="timezone">Loading...</p>
                    </div>
                </div>
                <div class="status-item">
                    <div class="status-content">
                        <h4>Notifications</h4>
                        <p id="notifications">Loading...</p>
                    </div>
                </div>
                <div class="status-item">
                    <div class="status-content">
                        <h4>Maintenance Mode</h4>
                        <p id="maintenance">Loading...</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
(async function loadSettings() {
    try {
        const [secRes, sysRes] = await Promise.all([
            fetch('../api/system.php?action=security_settings'),
            fetch('../api/system.php?action=system_settings')
        ]);
        const sec = await secRes.json();
        const sys = await sysRes.json();

        if (sec.success) {
            const s = sec.data;
            const pw = `Min length: ${s.min_password_length}, Uppercase: ${s.require_uppercase ? 'Yes' : 'No'}, Numbers: ${s.require_numbers ? 'Yes' : 'No'}, Special chars: ${s.require_special_chars ? 'Yes' : 'No'}`;
            const sessionTxt = `Timeout: ${s.session_timeout} min, Max attempts: ${s.max_login_attempts}, Lockout: ${s.lockout_duration} min`;
            const twofa = `Enabled: ${s.enable_2fa ? 'Yes' : 'No'}${s.force_2fa ? ' (Forced)' : ''}`;
            document.getElementById('pwPolicy').textContent = pw;
            document.getElementById('sessionPolicy').textContent = sessionTxt;
            document.getElementById('twofaPolicy').textContent = twofa;
        }

        if (sys.success) {
            const s = sys.data;
            document.getElementById('systemName').textContent = s.system_name || '—';
            document.getElementById('adminEmail').textContent = s.admin_email || '—';
            document.getElementById('timezone').textContent = s.timezone || '—';
            const noti = [];
            if (s.email_notifications) noti.push('Email');
            if (s.sms_notifications) noti.push('SMS');
            if (s.push_notifications) noti.push('Push');
            document.getElementById('notifications').textContent = noti.length ? noti.join(', ') : 'None';
            document.getElementById('maintenance').textContent = s.maintenance_mode ? `ON${s.maintenance_message ? ' - ' + s.maintenance_message : ''}` : 'OFF';
        }
    } catch (e) {
        console.error('Failed to load settings', e);
        document.getElementById('pwPolicy').textContent = 'Failed to load';
        document.getElementById('sessionPolicy').textContent = 'Failed to load';
        document.getElementById('twofaPolicy').textContent = 'Failed to load';
        document.getElementById('systemName').textContent = 'Failed to load';
        document.getElementById('adminEmail').textContent = 'Failed to load';
        document.getElementById('timezone').textContent = 'Failed to load';
        document.getElementById('notifications').textContent = 'Failed to load';
        document.getElementById('maintenance').textContent = 'Failed to load';
    }
})();
</script>

<?php include 'templates/footer.php'; ?>
