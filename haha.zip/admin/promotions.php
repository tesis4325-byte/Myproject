<?php
$pageTitle = 'Promotions & Marketing';
include 'templates/header.php';
?>

<!-- Page Header -->
<div class="dashboard-header">
    <div class="header-content">
        <div>
            <h1>Promotions & Marketing</h1>
            <p>Manage banners, vouchers, and promotional campaigns</p>
        </div>
        <div class="header-actions">
            <button class="btn btn-secondary" onclick="exportPromotions()">
                <i class="fas fa-download"></i> Export
            </button>
            <button class="btn btn-primary" onclick="addPromotion()">
                <i class="fas fa-plus"></i> Add Promotion
            </button>
        </div>
    </div>
</div>

<!-- Promotion Stats -->
<div class="stats-grid">
    <div class="stat-card primary">
        <div class="stat-icon">
            <i class="fas fa-tags"></i>
        </div>
        <div class="stat-content">
            <h3 id="totalPromotions">0</h3>
            <p>Total Promotions</p>
        </div>
    </div>
    <div class="stat-card success">
        <div class="stat-icon">
            <i class="fas fa-play-circle"></i>
        </div>
        <div class="stat-content">
            <h3 id="activePromotions">0</h3>
            <p>Active Promotions</p>
        </div>
    </div>
    <div class="stat-card warning">
        <div class="stat-icon">
            <i class="fas fa-ticket-alt"></i>
        </div>
        <div class="stat-content">
            <h3 id="totalVouchers">0</h3>
            <p>Vouchers Used</p>
        </div>
    </div>
    <div class="stat-card info">
        <div class="stat-icon">
            <i class="fas fa-peso-sign"></i>
        </div>
        <div class="stat-content">
            <h3 id="totalSavings">₱0</h3>
            <p>Customer Savings</p>
        </div>
    </div>
</div>

<!-- Promotion Types -->
<div class="dashboard-card">
    <div class="card-header">
        <h3>Promotion Types</h3>
    </div>
    <div class="card-body">
        <div class="promotion-types">
            <div class="promo-type active" data-type="all" onclick="selectPromoType('all')">
                <div class="type-icon">
                    <i class="fas fa-list"></i>
                </div>
                <div class="type-info">
                    <h4>All Promotions</h4>
                    <p>View all campaigns</p>
                </div>
            </div>
            <div class="promo-type" data-type="banner" onclick="selectPromoType('banner')">
                <div class="type-icon">
                    <i class="fas fa-image"></i>
                </div>
                <div class="type-info">
                    <h4>Banners</h4>
                    <p>Homepage banners</p>
                </div>
            </div>
            <div class="promo-type" data-type="voucher" onclick="selectPromoType('voucher')">
                <div class="type-icon">
                    <i class="fas fa-ticket-alt"></i>
                </div>
                <div class="type-info">
                    <h4>Vouchers</h4>
                    <p>Discount codes</p>
                </div>
            </div>
            <div class="promo-type" data-type="announcement" onclick="selectPromoType('announcement')">
                <div class="type-icon">
                    <i class="fas fa-bullhorn"></i>
                </div>
                <div class="type-info">
                    <h4>Announcements</h4>
                    <p>System notifications</p>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Filters and Search -->
<div class="dashboard-card">
    <div class="card-header">
        <h3>Filter & Search</h3>
        <div class="card-actions">
            <button class="btn btn-sm btn-secondary" onclick="clearFilters()">Clear Filters</button>
        </div>
    </div>
    <div class="card-body">
        <div class="filters-grid">
            <div class="filter-group">
                <label class="form-label">Search</label>
                <input type="text" class="form-control search-input" placeholder="Search promotions...">
            </div>
            <div class="filter-group">
                <label class="form-label">Status</label>
                <select class="form-control filter-select" name="status">
                    <option value="">All Status</option>
                    <option value="active">Active</option>
                    <option value="inactive">Inactive</option>
                    <option value="scheduled">Scheduled</option>
                    <option value="expired">Expired</option>
                </select>
            </div>
            <div class="filter-group">
                <label class="form-label">Date Range</label>
                <div class="date-range">
                    <input type="date" class="form-control" name="start_date" id="startDate">
                    <span>to</span>
                    <input type="date" class="form-control" name="end_date" id="endDate">
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Promotions Table -->
<div class="dashboard-card">
    <div class="card-header">
        <h3>All Promotions</h3>
        <div class="card-actions">
            <div class="bulk-actions" style="display: none;">
                <button class="btn btn-sm btn-success" onclick="bulkActivate()">
                    <i class="fas fa-play"></i> Activate
                </button>
                <button class="btn btn-sm btn-warning" onclick="bulkDeactivate()">
                    <i class="fas fa-pause"></i> Deactivate
                </button>
                <button class="btn btn-sm btn-danger" onclick="bulkDelete()">
                    <i class="fas fa-trash"></i> Delete
                </button>
            </div>
        </div>
    </div>
    <div class="card-body">
        <div class="selection-info" style="display: none;"></div>
        <div class="table-responsive data-table-container" id="all-promotions-table">
            <table class="table data-table">
                <thead>
                    <tr>
                        <th><input type="checkbox" id="selectAll" onchange="toggleSelectAll()"></th>
                        <th>Promotion</th>
                        <th>Type</th>
                        <th>Status</th>
                        <th>Duration</th>
                        <th>Usage</th>
                        <th>Savings</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody id="promotionsTableBody">
                    <tr>
                        <td colspan="8" class="text-center">Loading promotions...</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
class PromotionsManager {
    constructor() {
        this.selectedPromotions = new Set();
        this.currentType = 'all';
        this.itemsById = new Map();
        this.init();
    }

    async init() {
        await this.loadStats();
        this.setupEventListeners();
        this.loadPromotions();
    }

    async loadStats() {
        try {
            const response = await fetch('../api/promotions.php?action=stats');
            const result = await response.json();
            
            if (result.success) {
                this.updateStats(result.data);
            }
        } catch (error) {
            console.error('Error loading stats:', error);
        }
    }

    updateStats(stats) {
        document.getElementById('totalPromotions').textContent = stats.total_promotions || 0;
        document.getElementById('activePromotions').textContent = stats.active_promotions || 0;
        document.getElementById('totalVouchers').textContent = stats.total_vouchers || 0;
        document.getElementById('totalSavings').textContent = '₱' + (stats.total_savings || 0).toLocaleString();
    }

    setupEventListeners() {
        document.querySelectorAll('.filter-select, input[name="start_date"], input[name="end_date"]').forEach(element => {
            element.addEventListener('change', () => {
                this.loadPromotions();
            });
        });

        const searchInput = document.querySelector('.search-input');
        if (searchInput) {
            let timeout;
            searchInput.addEventListener('input', (e) => {
                clearTimeout(timeout);
                timeout = setTimeout(() => {
                    this.loadPromotions();
                }, 300);
            });
        }
    }

    async loadPromotions() {
        try {
            const filters = this.getFilters();
            const queryString = new URLSearchParams(filters).toString();

            const response = await fetch(`../api/promotions.php?action=list&${queryString}`);
            const result = await response.json();

            if (result.success) {
                this.displayPromotions(result.data.promotions || []);
            } else {
                this.showError(result.message || 'Failed to load promotions');
            }
        } catch (error) {
            console.error('Error loading promotions:', error);
            this.showError('Network error occurred');
        }
    }

    getFilters() {
        const filters = {};
        
        if (this.currentType !== 'all') {
            filters.type = this.currentType;
        }
        
        const searchInput = document.querySelector('.search-input');
        if (searchInput && searchInput.value.trim()) {
            filters.search = searchInput.value.trim();
        }

        document.querySelectorAll('.filter-select').forEach(select => {
            if (select.value) {
                filters[select.name] = select.value;
            }
        });

        const startDate = document.getElementById('startDate').value;
        const endDate = document.getElementById('endDate').value;
        if (startDate) filters.start_date = startDate;
        if (endDate) filters.end_date = endDate;

        return filters;
    }

    displayPromotions(promotions) {
        const tbody = document.getElementById('promotionsTableBody');
        
        if (promotions.length === 0) {
            tbody.innerHTML = '<tr><td colspan="8" class="text-center">No promotions found</td></tr>';
            return;
        }

        // cache for quick access by ID
        this.itemsById.clear();
        promotions.forEach(p => this.itemsById.set(Number(p.id), p));

        tbody.innerHTML = promotions.map(promo => `
            <tr data-promotion-id="${promo.id}">
                <td>
                    <input type="checkbox" class="promotion-checkbox" value="${promo.id}" onchange="togglePromotionSelection(${promo.id})">
                </td>
                <td>
                    <div class="promotion-info">
                        <div class="promo-image">
                            <img src="${normalizePromoImage(promo.image)}" alt="${promo.title}">
                        </div>
                        <div class="promo-details">
                            <strong>${promo.title}</strong>
                            <br><small class="text-muted">${promo.description || 'No description'}</small>
                        </div>
                    </div>
                </td>
                <td>
                    <span class="badge badge-${this.getTypeColor(promo.type)}">${this.formatType(promo.type)}</span>
                </td>
                <td>
                    <span class="badge badge-${this.getStatusColor(promo.status)}">${promo.status}</span>
                </td>
                <td>
                    <div class="duration-info">
                        <small>Start: ${this.formatDate(promo.start_date)}</small>
                        <br><small>End: ${this.formatDate(promo.end_date)}</small>
                    </div>
                </td>
                <td>
                    <div class="usage-stats">
                        <strong>${promo.usage_count || 0}</strong> uses
                        ${promo.usage_limit ? `<br><small class="text-muted">Limit: ${promo.usage_limit}</small>` : ''}
                    </div>
                </td>
                <td>
                    <strong>₱${parseFloat(promo.total_savings || 0).toLocaleString()}</strong>
                </td>
                <td>
                    <div class="action-buttons">
                        <button class="btn btn-sm btn-primary" onclick="viewPromotion(${promo.id})">
                            <i class="fas fa-eye"></i>
                        </button>
                        <button class="btn btn-sm btn-warning" onclick="editPromotion(${promo.id})">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button class="btn btn-sm ${promo.status === 'active' ? 'btn-secondary' : 'btn-success'}" 
                                onclick="togglePromotionStatus(${promo.id}, '${promo.status === 'active' ? 'inactive' : 'active'}')">
                            <i class="fas fa-${promo.status === 'active' ? 'pause' : 'play'}"></i>
                        </button>
                        <button class="btn btn-sm btn-danger" onclick="deletePromotion(${promo.id})">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </td>
            </tr>
        `).join('');
    }

    getTypeColor(type) {
        const colors = {
            'banner': 'primary',
            'voucher': 'success',
            'announcement': 'info'
        };
        return colors[type] || 'secondary';
    }

    formatType(type) {
        const types = {
            'banner': 'Banner',
            'voucher': 'Voucher',
            'announcement': 'Announcement'
        };
        return types[type] || type;
    }

    getStatusColor(status) {
        const colors = {
            'active': 'success',
            'inactive': 'secondary',
            'scheduled': 'warning',
            'expired': 'danger'
        };
        return colors[status] || 'secondary';
    }

    formatDate(dateString) {
        const date = new Date(dateString);
        return date.toLocaleDateString('en-PH', {
            month: 'short',
            day: 'numeric',
            year: 'numeric'
        });
    }

    showError(message) {
        if (window.adminManager) {
            window.adminManager.showError(message);
        } else {
            alert(message);
        }
    }

    showSuccess(message) {
        if (window.adminManager) {
            window.adminManager.showSuccess(message);
        } else {
            alert(message);
        }
    }
}

let promotionsManager;

document.addEventListener('DOMContentLoaded', function() {
    promotionsManager = new PromotionsManager();
});

function selectPromoType(type) {
    document.querySelectorAll('.promo-type').forEach(t => {
        t.classList.remove('active');
    });
    document.querySelector(`[data-type="${type}"]`).classList.add('active');
    
    promotionsManager.currentType = type;
    promotionsManager.loadPromotions();
}

function toggleSelectAll() {
    const selectAll = document.getElementById('selectAll');
    const checkboxes = document.querySelectorAll('.promotion-checkbox');
    
    checkboxes.forEach(checkbox => {
        checkbox.checked = selectAll.checked;
        const promoId = parseInt(checkbox.value);
        if (selectAll.checked) {
            promotionsManager.selectedPromotions.add(promoId);
        } else {
            promotionsManager.selectedPromotions.delete(promoId);
        }
    });
    
    updateBulkActions();
}

function togglePromotionSelection(promoId) {
    const checkbox = document.querySelector(`input[value="${promoId}"]`);
    if (checkbox.checked) {
        promotionsManager.selectedPromotions.add(promoId);
    } else {
        promotionsManager.selectedPromotions.delete(promoId);
    }
    
    updateBulkActions();
}

function updateBulkActions() {
    const count = promotionsManager.selectedPromotions.size;
    const bulkActions = document.querySelector('.bulk-actions');
    const selectionInfo = document.querySelector('.selection-info');
    
    if (count > 0) {
        bulkActions.style.display = 'flex';
        selectionInfo.style.display = 'block';
        selectionInfo.textContent = `${count} promotion(s) selected`;
    } else {
        bulkActions.style.display = 'none';
        selectionInfo.style.display = 'none';
    }
}

function viewPromotion(promoId) {
    const p = promotionsManager.itemsById.get(Number(promoId));
    if (!p) return promotionsManager.showError('Promotion not found');
    const html = `
        <div style="text-align:left">
            ${p.image ? `<img src="${normalizePromoImage(p.image)}" style="width:100%;max-height:200px;object-fit:cover;border-radius:8px;margin-bottom:10px;"/>` : ''}
            <p><strong>Type:</strong> ${p.type}</p>
            <p><strong>Status:</strong> ${p.status}</p>
            <p><strong>Start:</strong> ${p.start_date || '-'} | <strong>End:</strong> ${p.end_date || '-'}</p>
            <p><strong>Usage:</strong> ${p.usage_count || 0}${p.usage_limit ? ` / ${p.usage_limit}` : ''}</p>
        </div>`;
    Swal.fire({ title: p.title, html, icon: 'info' });
}

function addPromotion() {
    const html = `
      <div class="swal2-content" style="text-align:left">
        <label class="form-label">Kind</label>
        <select id="promo_kind" class="swal2-input" style="width:100%">
          <option value="voucher">Voucher</option>
          <option value="banner">Banner</option>
        </select>
        <div id="voucher_fields">
          <label class="form-label">Code</label>
          <input id="promo_code" class="swal2-input" placeholder="e.g. SAVE50">
          <label class="form-label">Title</label>
          <input id="promo_title" class="swal2-input" placeholder="Promo title">
          <label class="form-label">Type</label>
          <select id="promo_type" class="swal2-input" style="width:100%">
            <option value="percentage">Percentage</option>
            <option value="fixed_amount">Fixed Amount</option>
            <option value="free_delivery">Free Delivery</option>
          </select>
          <label class="form-label">Value</label>
          <input id="promo_value" type="number" step="0.01" min="0" class="swal2-input" placeholder="e.g. 10 or 50">
          <label class="form-label">Description</label>
          <textarea id="promo_desc" class="swal2-textarea" placeholder="Optional"></textarea>
          <div style="display:flex;gap:8px">
            <div style="flex:1">
              <label class="form-label">Start Date</label>
              <input id="promo_start" type="date" class="swal2-input" style="width:100%">
            </div>
            <div style="flex:1">
              <label class="form-label">End Date</label>
              <input id="promo_end" type="date" class="swal2-input" style="width:100%">
            </div>
          </div>
        </div>
        <div id="banner_fields" style="display:none">
          <label class="form-label">Title</label>
          <input id="banner_title" class="swal2-input" placeholder="Banner title">
          <label class="form-label">Image URL</label>
          <input id="banner_image" class="swal2-input" placeholder="/uploads/banners/banner.png">
          <label class="form-label">Link (optional)</label>
          <input id="banner_link" class="swal2-input" placeholder="https://...">
          <div style="display:flex;gap:8px">
            <div style="flex:1">
              <label class="form-label">Start Date</label>
              <input id="banner_start" type="date" class="swal2-input" style="width:100%">
            </div>
            <div style="flex:1">
              <label class="form-label">End Date</label>
              <input id="banner_end" type="date" class="swal2-input" style="width:100%">
            </div>
          </div>
        </div>
      </div>`;

    Swal.fire({
      title: 'Add Promotion',
      html,
      showCancelButton: true,
      confirmButtonText: 'Save',
      didOpen: () => {
        const kindSel = document.getElementById('promo_kind');
        const vf = document.getElementById('voucher_fields');
        const bf = document.getElementById('banner_fields');
        kindSel.addEventListener('change', () => {
          const k = kindSel.value;
          vf.style.display = k === 'voucher' ? 'block' : 'none';
          bf.style.display = k === 'banner' ? 'block' : 'none';
        });
      },
      preConfirm: () => {
        const kind = (document.getElementById('promo_kind').value || 'voucher');
        if (kind === 'voucher') {
          const code = document.getElementById('promo_code').value.trim();
          const title = document.getElementById('promo_title').value.trim();
          const type = document.getElementById('promo_type').value;
          const value = parseFloat(document.getElementById('promo_value').value || '0');
          const start_date = (document.getElementById('promo_start').value);
          const end_date = (document.getElementById('promo_end').value);
          if (!code || !title || !type || !value || !start_date || !end_date) {
            Swal.showValidationMessage('Please fill all required voucher fields');
            return false;
          }
          return { kind: 'voucher', code, title, type, value, description: document.getElementById('promo_desc').value.trim(), start_date, end_date };
        } else {
          const title = document.getElementById('banner_title').value.trim();
          const image = document.getElementById('banner_image').value.trim();
          if (!title || !image) {
            Swal.showValidationMessage('Title and Image are required for banner');
            return false;
          }
          return { kind: 'banner', title, image, link: document.getElementById('banner_link').value.trim(), start_date: document.getElementById('banner_start').value, end_date: document.getElementById('banner_end').value };
        }
      }
    }).then(res => {
      if (!res.isConfirmed) return;
      fetch('../api/promotions.php?action=create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(res.value)
      }).then(r => r.json().then(j => ({ ok: r.ok, j }))).then(({ ok, j }) => {
        if (!ok || !j.success) throw new Error(j.message || 'Failed to save');
        promotionsManager.showSuccess('Promotion created');
        promotionsManager.loadPromotions();
      }).catch(err => promotionsManager.showError(err.message));
    });
}

function editPromotion(promoId) {
    const p = promotionsManager.itemsById.get(Number(promoId));
    if (!p) return promotionsManager.showError('Promotion not found');
    const isVoucher = p.type === 'voucher';
    const html = `
      <div class="swal2-content" style="text-align:left">
        <p><small>Type: ${p.type}</small></p>
        <div id="voucher_fields" style="${isVoucher ? '' : 'display:none'}">
          ${isVoucher ? `<label class="form-label">Code</label><input id="promo_code" class="swal2-input" value="${p.code || ''}">` : ''}
          <label class="form-label">Title</label>
          <input id="promo_title" class="swal2-input" value="${p.title || ''}">
          ${isVoucher ? `
          <label class="form-label">Type</label>
          <select id="promo_type" class="swal2-input" style="width:100%">
            <option value="percentage" ${p.type_value==='percentage'?'selected':''}>Percentage</option>
            <option value="fixed_amount" ${p.type_value==='fixed_amount'?'selected':''}>Fixed Amount</option>
            <option value="free_delivery" ${p.type_value==='free_delivery'?'selected':''}>Free Delivery</option>
          </select>
          <label class="form-label">Value</label>
          <input id="promo_value" type="number" step="0.01" min="0" class="swal2-input" value="${p.value || 0}">
          <label class="form-label">Description</label>
          <textarea id="promo_desc" class="swal2-textarea">${p.description || ''}</textarea>
          <div style="display:flex;gap:8px">
            <div style="flex:1">
              <label class="form-label">Start Date</label>
              <input id="promo_start" type="date" class="swal2-input" style="width:100%" value="${p.start_date || ''}">
            </div>
            <div style="flex:1">
              <label class="form-label">End Date</label>
              <input id="promo_end" type="date" class="swal2-input" style="width:100%" value="${p.end_date || ''}">
            </div>
          </div>` : ''}
        </div>
        <div id="banner_fields" style="${!isVoucher ? '' : 'display:none'}">
          ${!isVoucher ? `
          <label class="form-label">Title</label>
          <input id="banner_title" class="swal2-input" value="${p.title || ''}">
          <label class="form-label">Image URL</label>
          <input id="banner_image" class="swal2-input" value="${p.image || ''}">
          <label class="form-label">Link (optional)</label>
          <input id="banner_link" class="swal2-input" value="${p.description || ''}">
          <div style="display:flex;gap:8px">
            <div style="flex:1">
              <label class="form-label">Start Date</label>
              <input id="banner_start" type="date" class="swal2-input" style="width:100%" value="${p.start_date || ''}">
            </div>
            <div style="flex:1">
              <label class="form-label">End Date</label>
              <input id="banner_end" type="date" class="swal2-input" style="width:100%" value="${p.end_date || ''}">
            </div>
          </div>` : ''}
        </div>
      </div>`;

    Swal.fire({
      title: 'Edit Promotion',
      html,
      showCancelButton: true,
      confirmButtonText: 'Update',
      preConfirm: () => {
        if (isVoucher) {
          const payload = {
            kind: 'voucher', id: p.id,
            title: document.getElementById('promo_title').value.trim(),
            description: document.getElementById('promo_desc') ? document.getElementById('promo_desc').value.trim() : '',
            value: parseFloat(document.getElementById('promo_value').value || '0'),
            start_date: document.getElementById('promo_start').value,
            end_date: document.getElementById('promo_end').value
          };
          if (!payload.title) { Swal.showValidationMessage('Title is required'); return false; }
          return payload;
        } else {
          const payload = {
            kind: 'banner', id: p.id,
            title: document.getElementById('banner_title').value.trim(),
            image: document.getElementById('banner_image').value.trim(),
            link: document.getElementById('banner_link').value.trim(),
            start_date: document.getElementById('banner_start').value,
            end_date: document.getElementById('banner_end').value
          };
          if (!payload.title || !payload.image) { Swal.showValidationMessage('Title and Image are required'); return false; }
          return payload;
        }
      }
    }).then(res => {
      if (!res.isConfirmed) return;
      fetch('../api/promotions.php?action=update', {
        method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(res.value)
      }).then(r => r.json().then(j => ({ ok: r.ok, j }))).then(({ ok, j }) => {
        if (!ok || !j.success) throw new Error(j.message || 'Failed to update');
        promotionsManager.showSuccess('Promotion updated');
        promotionsManager.loadPromotions();
      }).catch(err => promotionsManager.showError(err.message));
    });
}

function togglePromotionStatus(promoId, newStatus) {
    const p = promotionsManager.itemsById.get(Number(promoId));
    if (!p) return promotionsManager.showError('Promotion not found');
    Swal.fire({
      title: `Set to ${newStatus}?`, icon: 'question', showCancelButton: true, confirmButtonText: 'Yes'
    }).then(res => {
      if (!res.isConfirmed) return;
      const payload = { kind: p.type === 'banner' ? 'banner' : 'voucher', id: p.id, status: newStatus };
      fetch('../api/promotions.php?action=toggle_status', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) })
        .then(r => r.json().then(j => ({ ok: r.ok, j })))
        .then(({ ok, j }) => { if (!ok || !j.success) throw new Error(j.message || 'Failed'); promotionsManager.loadPromotions(); })
        .catch(err => promotionsManager.showError(err.message));
    });
}

function deletePromotion(promoId) {
    const p = promotionsManager.itemsById.get(Number(promoId));
    if (!p) return promotionsManager.showError('Promotion not found');
    Swal.fire({ title: 'Delete this promotion?', icon: 'warning', showCancelButton: true, confirmButtonText: 'Delete' })
      .then(res => {
        if (!res.isConfirmed) return;
        fetch('../api/promotions.php?action=delete', { method: 'DELETE', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ kind: p.type === 'banner' ? 'banner' : 'voucher', id: p.id }) })
          .then(r => r.json().then(j => ({ ok: r.ok, j })))
          .then(({ ok, j }) => { if (!ok || !j.success) throw new Error(j.message || 'Failed'); promotionsManager.showSuccess('Deleted'); promotionsManager.loadPromotions(); })
          .catch(err => promotionsManager.showError(err.message));
      });
}

function clearFilters() {
    document.querySelectorAll('.filter-select').forEach(select => {
        select.value = '';
    });
    document.getElementById('startDate').value = '';
    document.getElementById('endDate').value = '';
    document.querySelector('.search-input').value = '';
    
    promotionsManager.loadPromotions();
}

function exportPromotions() {
    const filters = promotionsManager.getFilters();
    const queryString = new URLSearchParams(filters).toString();
    window.open(`../api/promotions.php?action=export&${queryString}`, '_blank');
}

// helpers
function normalizePromoImage(img) {
  if (!img) return '../assets/images/default-promo.png';
  if (img.startsWith('http')) return img;
  if (img.startsWith('/')) return '..' + img;
  return `../${img}`;
}

function bulkActivate() {
    const selectedIds = Array.from(promotionsManager.selectedPromotions);
    if (selectedIds.length === 0) {
        promotionsManager.showError('Please select promotions to activate');
        return;
    }
    alert('Bulk activate - IDs: ' + selectedIds.join(', '));
}

function bulkDeactivate() {
    const selectedIds = Array.from(promotionsManager.selectedPromotions);
    if (selectedIds.length === 0) {
        promotionsManager.showError('Please select promotions to deactivate');
        return;
    }
    alert('Bulk deactivate - IDs: ' + selectedIds.join(', '));
}

function bulkDelete() {
    const selectedIds = Array.from(promotionsManager.selectedPromotions);
    if (selectedIds.length === 0) {
        promotionsManager.showError('Please select promotions to delete');
        return;
    }
    
    const confirmed = confirm(`Delete ${selectedIds.length} promotions?`);
    if (confirmed) {
        alert('Bulk delete - IDs: ' + selectedIds.join(', '));
    }
}
</script>

<style>
.dashboard-card { margin-top: 1rem; }
.card-header { display:flex; align-items:center; justify-content:space-between; padding: 0.75rem 1rem; border-bottom: 1px solid var(--gray-200); }
.card-header h3 { margin:0; font-size:1.05rem; color: var(--gray-800); }
.card-actions { display:flex; gap:0.5rem; }

/* Filters layout */
.filters-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
    gap: 1rem 1.25rem;
    padding: 1rem;
}
.filter-group { display:flex; flex-direction:column; }
.filter-group .form-label { font-weight:600; color: var(--gray-700); margin-bottom: 0.375rem; }
.form-control { width: 100%; }
.search-input { height: 36px; }
.filter-select { height: 36px; }
.date-range { display:flex; align-items:center; gap:0.5rem; }
.date-range span { color: var(--gray-600); font-size: 0.875rem; }

/* Table spacing */
.data-table-container { padding: 0 1rem 1rem; }
.promotion-types {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 1rem;
}

.promo-type {
    display: flex;
    align-items: center;
    gap: 1rem;
    padding: 1rem;
    border: 2px solid var(--gray-200);
    border-radius: 0.5rem;
    cursor: pointer;
    transition: all 0.3s ease;
}

.promo-type:hover {
    border-color: var(--primary-color);
    background-color: var(--gray-50);
}

.promo-type.active {
    border-color: var(--primary-color);
    background-color: var(--primary-color);
    color: white;
}

.type-icon {
    font-size: 1.25rem;
    color: var(--primary-color);
}

.promo-type.active .type-icon {
    color: white;
}

.type-info h4 {
    margin: 0 0 0.25rem 0;
    font-size: 0.875rem;
}

.type-info p {
    margin: 0;
    font-size: 0.75rem;
    opacity: 0.8;
}

.promotion-info {
    display: flex;
    align-items: center;
    gap: 0.75rem;
}

.promo-image {
    width: 40px;
    height: 40px;
    border-radius: 8px;
    overflow: hidden;
    flex-shrink: 0;
}

.promo-image img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.promo-details strong {
    color: var(--gray-800);
}

.duration-info small {
    display: block;
    color: var(--gray-600);
}

.usage-stats strong {
    color: var(--gray-800);
}

.date-range {
    display: flex;
    align-items: center;
    gap: 0.5rem;
}

.date-range span {
    color: var(--gray-600);
    font-size: 0.875rem;
}
</style>

<?php include 'templates/footer.php'; ?>
