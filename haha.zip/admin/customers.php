<?php
$pageTitle = 'Customer Management';
include 'templates/header.php';
?>

<!-- Page Header -->
<div class="dashboard-header">
    <div class="header-content">
        <div>
            <h1>Customer Management</h1>
            <p>Manage customer accounts and view customer activity</p>
        </div>
        <div class="header-actions">
            <button class="btn btn-secondary" onclick="exportCustomers()">
                <i class="fas fa-download"></i> Export
            </button>
            <button class="btn btn-primary" onclick="addCustomer()">
                <i class="fas fa-plus"></i> Add Customer
            </button>
        </div>
    </div>
</div>

<!-- Customer Stats -->
<div class="stats-grid">
    <div class="stat-card primary">
        <div class="stat-icon">
            <i class="fas fa-users"></i>
        </div>
        <div class="stat-content">
            <h3 id="totalCustomers">0</h3>
            <p>Total Customers</p>
        </div>
    </div>
    <div class="stat-card success">
        <div class="stat-icon">
            <i class="fas fa-user-check"></i>
        </div>
        <div class="stat-content">
            <h3 id="activeCustomers">0</h3>
            <p>Active Customers</p>
        </div>
    </div>
    <div class="stat-card info">
        <div class="stat-icon">
            <i class="fas fa-user-plus"></i>
        </div>
        <div class="stat-content">
            <h3 id="newCustomers">0</h3>
            <p>New This Month</p>
        </div>
    </div>
    <div class="stat-card warning">
        <div class="stat-icon">
            <i class="fas fa-star"></i>
        </div>
        <div class="stat-content">
            <h3 id="vipCustomers">0</h3>
            <p>VIP Customers</p>
        </div>
    </div>
</div>

<!-- Filters and Search -->
<div class="dashboard-card">
    <div class="card-header">
        <h3>Filter & Search</h3>
        <div class="card-actions">
            <button class="btn btn-sm btn-secondary" onclick="clearFilters()">Clear Filters</button>
        </div>
    </div>
    <div class="card-body">
        <div class="filters-grid">
            <div class="filter-group">
                <label class="form-label">Search</label>
                <input type="text" class="form-control search-input" placeholder="Search by name, phone, email...">
            </div>
            <div class="filter-group">
                <label class="form-label">Status</label>
                <select class="form-control filter-select" name="status">
                    <option value="">All Status</option>
                    <option value="active">Active</option>
                    <option value="inactive">Inactive</option>
                    <option value="suspended">Suspended</option>
                </select>
            </div>
            <div class="filter-group">
                <label class="form-label">Customer Type</label>
                <select class="form-control filter-select" name="customer_type">
                    <option value="">All Types</option>
                    <option value="regular">Regular</option>
                    <option value="vip">VIP</option>
                    <option value="premium">Premium</option>
                </select>
            </div>
            <div class="filter-group">
                <label class="form-label">Registration Date</label>
                <div class="date-range">
                    <input type="date" class="form-control" name="start_date" id="startDate">
                    <span>to</span>
                    <input type="date" class="form-control" name="end_date" id="endDate">
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Customers Table -->
<div class="dashboard-card">
    <div class="card-header">
        <h3>All Customers</h3>
        <div class="card-actions">
            <div class="bulk-actions" style="display: none;">
                <button class="btn btn-sm btn-success" onclick="bulkActivate()">
                    <i class="fas fa-check"></i> Activate
                </button>
                <button class="btn btn-sm btn-warning" onclick="bulkSuspend()">
                    <i class="fas fa-pause"></i> Suspend
                </button>
                <button class="btn btn-sm btn-danger" onclick="bulkDelete()">
                    <i class="fas fa-trash"></i> Delete
                </button>
            </div>
        </div>
    </div>
    <div class="card-body">
        <div class="selection-info" style="display: none;"></div>
        <div class="table-responsive data-table-container" id="all-customers-table">
            <table class="table data-table">
                <thead>
                    <tr>
                        <th><input type="checkbox" id="selectAll" onchange="toggleSelectAll()"></th>
                        <th>Customer</th>
                        <th>Contact</th>
                        <th>Orders</th>
                        <th>Total Spent</th>
                        <th>Type</th>
                        <th>Status</th>
                        <th>Registered</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody id="customersTableBody">
                    <tr>
                        <td colspan="9" class="text-center">Loading customers...</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Legacy Customer modal removed; using SweetAlert for details and add/edit -->

<script>
class CustomersManager {
    constructor() {
        this.selectedCustomers = new Set();
        this.init();
    }

    async init() {
        await this.loadStats();
        this.setupEventListeners();
        this.loadCustomers();
    }

    async loadStats() {
        try {
            const response = await fetch('../api/customers.php?action=stats');
            const result = await response.json();
            
            if (result.success) {
                this.updateStats(result.data);
            }
        } catch (error) {
            console.error('Error loading stats:', error);
        }
    }

    updateStats(stats) {
        document.getElementById('totalCustomers').textContent = stats.total_customers || 0;
        document.getElementById('activeCustomers').textContent = stats.active_customers || 0;
        document.getElementById('newCustomers').textContent = stats.new_customers || 0;
        document.getElementById('vipCustomers').textContent = stats.vip_customers || 0;
    }

    setupEventListeners() {
        document.querySelectorAll('.filter-select, input[name="start_date"], input[name="end_date"]').forEach(element => {
            element.addEventListener('change', () => {
                this.loadCustomers();
            });
        });

        const searchInput = document.querySelector('.search-input');
        if (searchInput) {
            let timeout;
            searchInput.addEventListener('input', (e) => {
                clearTimeout(timeout);
                timeout = setTimeout(() => {
                    this.loadCustomers();
                }, 300);
            });
        }
    }

    async loadCustomers() {
        try {
            const filters = this.getFilters();
            const queryString = new URLSearchParams(filters).toString();

            const response = await fetch(`../api/customers.php?action=list&${queryString}`);
            const result = await response.json();

            if (result.success) {
                this.displayCustomers(result.data.customers || []);
            } else {
                this.showError(result.message || 'Failed to load customers');
            }
        } catch (error) {
            console.error('Error loading customers:', error);
            this.showError('Network error occurred');
        }
    }

    getFilters() {
        const filters = {};
        
        const searchInput = document.querySelector('.search-input');
        if (searchInput && searchInput.value.trim()) {
            filters.search = searchInput.value.trim();
        }

        document.querySelectorAll('.filter-select').forEach(select => {
            if (select.value) {
                filters[select.name] = select.value;
            }
        });

        const startDate = document.getElementById('startDate').value;
        const endDate = document.getElementById('endDate').value;
        if (startDate) filters.start_date = startDate;
        if (endDate) filters.end_date = endDate;

        return filters;
    }

    displayCustomers(customers) {
        const tbody = document.getElementById('customersTableBody');
        
        if (customers.length === 0) {
            tbody.innerHTML = '<tr><td colspan="9" class="text-center">No customers found</td></tr>';
            return;
        }

        tbody.innerHTML = customers.map(customer => `
            <tr data-customer-id="${customer.id}">
                <td>
                    <input type="checkbox" class="customer-checkbox" value="${customer.id}" onchange="toggleCustomerSelection(${customer.id})">
                </td>
                <td>
                    <div class="customer-info">
                        <div class="customer-avatar">
                            <img src="${customer.avatar || '../admin/assets/images/default-avatar.svg'}" alt="${customer.name}">
                        </div>
                        <div class="customer-details">
                            <strong>${customer.name}</strong>
                            <br><small class="text-muted">ID: ${customer.id}</small>
                        </div>
                    </div>
                </td>
                <td>
                    <div class="contact-info">
                        <div><i class="fas fa-phone"></i> ${customer.phone}</div>
                        ${customer.email ? `<div><i class="fas fa-envelope"></i> ${customer.email}</div>` : ''}
                    </div>
                </td>
                <td>
                    <div class="order-stats">
                        <strong>${customer.total_orders || 0}</strong> orders
                        <br><small class="text-muted">Last: ${customer.last_order_date ? this.formatDate(customer.last_order_date) : 'Never'}</small>
                    </div>
                </td>
                <td>
                    <strong>₱${parseFloat(customer.total_spent || 0).toLocaleString()}</strong>
                </td>
                <td>
                    <span class="badge badge-${this.getTypeColor(customer.customer_type)}">${customer.customer_type || 'Regular'}</span>
                </td>
                <td>
                    <span class="badge badge-${this.getStatusColor(customer.status)}">${customer.status}</span>
                </td>
                <td>
                    ${this.formatDate(customer.created_at)}
                </td>
                <td>
                    <div class="action-buttons">
                        <button class="btn btn-sm btn-primary" onclick="viewCustomer(${customer.id})" data-tooltip="View Details">
                            <i class="fas fa-eye"></i>
                        </button>
                        <button class="btn btn-sm btn-warning" onclick="editCustomer(${customer.id})" data-tooltip="Edit">
                            <i class="fas fa-edit"></i>
                        </button>
                        ${customer.status === 'active' ? `
                            <button class="btn btn-sm btn-secondary" onclick="suspendCustomer(${customer.id})" data-tooltip="Suspend">
                                <i class="fas fa-pause"></i>
                            </button>
                        ` : `
                            <button class="btn btn-sm btn-success" onclick="activateCustomer(${customer.id})" data-tooltip="Activate">
                                <i class="fas fa-play"></i>
                            </button>
                        `}
                        <button class="btn btn-sm btn-danger" onclick="deleteCustomer(${customer.id})" data-tooltip="Delete">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </td>
            </tr>
        `).join('');
    }

    getTypeColor(type) {
        const colors = {
            'regular': 'secondary',
            'vip': 'warning',
            'premium': 'success'
        };
        return colors[type] || 'secondary';
    }

    getStatusColor(status) {
        const colors = {
            'active': 'success',
            'inactive': 'secondary',
            'suspended': 'danger'
        };
        return colors[status] || 'secondary';
    }

    formatDate(dateString) {
        const date = new Date(dateString);
        return date.toLocaleDateString('en-PH', {
            month: 'short',
            day: 'numeric',
            year: 'numeric'
        });
    }

    showError(message) {
        if (window.Swal) {
            Swal.fire({ icon: 'error', title: 'Error', text: message || 'Something went wrong' });
        } else if (window.adminManager) {
            window.adminManager.showError(message);
        } else {
            alert(message);
        }
    }

    showSuccess(message) {
        if (window.Swal) {
            Swal.fire({ icon: 'success', title: 'Success', text: message || 'Operation completed' });
        } else if (window.adminManager) {
            window.adminManager.showSuccess(message);
        } else {
            alert(message);
        }
    }
}

let customersManager;

document.addEventListener('DOMContentLoaded', function() {
    customersManager = new CustomersManager();
});

function toggleSelectAll() {
    const selectAll = document.getElementById('selectAll');
    const checkboxes = document.querySelectorAll('.customer-checkbox');
    
    checkboxes.forEach(checkbox => {
        checkbox.checked = selectAll.checked;
        const customerId = parseInt(checkbox.value);
        if (selectAll.checked) {
            customersManager.selectedCustomers.add(customerId);
        } else {
            customersManager.selectedCustomers.delete(customerId);
        }
    });
    
    updateBulkActions();
}

function toggleCustomerSelection(customerId) {
    const checkbox = document.querySelector(`input[value="${customerId}"]`);
    if (checkbox.checked) {
        customersManager.selectedCustomers.add(customerId);
    } else {
        customersManager.selectedCustomers.delete(customerId);
    }
    
    updateBulkActions();
}

function updateBulkActions() {
    const count = customersManager.selectedCustomers.size;
    const bulkActions = document.querySelector('.bulk-actions');
    const selectionInfo = document.querySelector('.selection-info');
    
    if (count > 0) {
        bulkActions.style.display = 'flex';
        selectionInfo.style.display = 'block';
        selectionInfo.textContent = `${count} customer(s) selected`;
    } else {
        bulkActions.style.display = 'none';
        selectionInfo.style.display = 'none';
    }
}

async function viewCustomer(customerId) {
    try {
        const response = await fetch(`../api/customers.php?action=get&id=${customerId}`);
        const result = await response.json();
        
        if (result.success) {
            const c = result.data;
            const html = `
                <div class="customer-detail-modal" style="text-align:left">
                    <div class="profile-header" style="display:flex; align-items:center; gap:1rem; margin-bottom:1rem;">
                        <div class="profile-avatar" style="width:64px; height:64px; border-radius:50%; overflow:hidden; background:#f2f2f2">
                            <img src="${c.avatar || '../admin/assets/images/default-avatar.svg'}" alt="${c.name}" style="width:100%; height:100%; object-fit:cover;"/>
                        </div>
                        <div class="profile-info">
                            <h3 style="margin:0 0 .25rem 0">${c.name}</h3>
                            <div>
                                <span class="badge badge-${customersManager.getStatusColor(c.status)}">${c.status}</span>
                                <span class="badge badge-${customersManager.getTypeColor(c.customer_type)}">${c.customer_type || 'Regular'}</span>
                            </div>
                            <small class="text-muted">Customer ID: ${c.id}</small>
                        </div>
                    </div>
                    <div class="details-grid" style="display:grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap:1rem;">
                        <div class="detail-section">
                            <h4 style="margin:0 0 .5rem 0">Contact Information</h4>
                            <div class="detail-item"><label>Phone:</label> <span>${c.phone || ''}</span></div>
                            ${c.email ? `<div class=\"detail-item\"><label>Email:</label> <span>${c.email}</span></div>` : ''}
                            ${c.address ? `<div class=\"detail-item\"><label>Address:</label> <span>${c.address}</span></div>` : ''}
                        </div>
                        <div class="detail-section">
                            <h4 style="margin:0 0 .5rem 0">Order Statistics</h4>
                            <div class="detail-item"><label>Total Orders:</label> <span>${c.total_orders || 0}</span></div>
                            <div class="detail-item"><label>Total Spent:</label> <span>₱${parseFloat(c.total_spent || 0).toLocaleString()}</span></div>
                            <div class="detail-item"><label>Average Order:</label> <span>₱${parseFloat(c.average_order || 0).toLocaleString()}</span></div>
                            <div class="detail-item"><label>Last Order:</label> <span>${c.last_order_date ? customersManager.formatDate(c.last_order_date) : 'Never'}</span></div>
                        </div>
                        <div class="detail-section">
                            <h4 style="margin:0 0 .5rem 0">Account Information</h4>
                            <div class="detail-item"><label>Registered:</label> <span>${customersManager.formatDate(c.created_at)}</span></div>
                            <div class="detail-item"><label>Last Active:</label> <span>${c.last_login ? customersManager.formatDate(c.last_login) : 'Never'}</span></div>
                        </div>
                    </div>
                </div>`;

            if (window.Swal) {
                Swal.fire({
                    html,
                    width: 800,
                    showCloseButton: false,
                    confirmButtonText: 'Close'
                });
            } else {
                alert('Customer details: ' + JSON.stringify(result.data, null, 2));
            }
        } else {
            customersManager.showError(result.message || 'Failed to load customer details');
        }
    } catch (error) {
        console.error('Error loading customer:', error);
        customersManager.showError('Network error occurred');
    }
}

function displayCustomerDetails(customer) {
    document.getElementById('customerModalTitle').textContent = 'Customer Details';
    document.getElementById('customerModalBody').innerHTML = `
        <div class="customer-profile">
            <div class="profile-header">
                <div class="profile-avatar">
                    <img src="${customer.avatar || '../admin/assets/images/default-avatar.svg'}" alt="${customer.name}">
                </div>
                <div class="profile-info">
                    <h3>${customer.name}</h3>
                    <p class="text-muted">Customer ID: ${customer.id}</p>
                    <span class="badge badge-${customersManager.getStatusColor(customer.status)}">${customer.status}</span>
                    <span class="badge badge-${customersManager.getTypeColor(customer.customer_type)}">${customer.customer_type || 'Regular'}</span>
                </div>
            </div>
            
            <div class="profile-details">
                <div class="details-grid">
                    <div class="detail-section">
                        <h4>Contact Information</h4>
                        <div class="detail-item">
                            <label>Phone:</label>
                            <span>${customer.phone}</span>
                        </div>
                        ${customer.email ? `
                            <div class="detail-item">
                                <label>Email:</label>
                                <span>${customer.email}</span>
                            </div>
                        ` : ''}
                        ${customer.address ? `
                            <div class="detail-item">
                                <label>Address:</label>
                                <span>${customer.address}</span>
                            </div>
                        ` : ''}
                    </div>
                    
                    <div class="detail-section">
                        <h4>Order Statistics</h4>
                        <div class="detail-item">
                            <label>Total Orders:</label>
                            <span>${customer.total_orders || 0}</span>
                        </div>
                        <div class="detail-item">
                            <label>Total Spent:</label>
                            <span>₱${parseFloat(customer.total_spent || 0).toLocaleString()}</span>
                        </div>
                        <div class="detail-item">
                            <label>Average Order:</label>
                            <span>₱${parseFloat(customer.average_order || 0).toLocaleString()}</span>
                        </div>
                        <div class="detail-item">
                            <label>Last Order:</label>
                            <span>${customer.last_order_date ? customersManager.formatDate(customer.last_order_date) : 'Never'}</span>
                        </div>
                    </div>
                    
                    <div class="detail-section">
                        <h4>Account Information</h4>
                        <div class="detail-item">
                            <label>Registered:</label>
                            <span>${customersManager.formatDate(customer.created_at)}</span>
                        </div>
                        <div class="detail-item">
                            <label>Last Active:</label>
                            <span>${customer.last_login ? customersManager.formatDate(customer.last_login) : 'Never'}</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;
}

async function addCustomer() {
    if (!window.Swal) {
        alert('Please fill the customer form in the page.');
        return;
    }
    const { value: formValues } = await Swal.fire({
        title: 'Add New Customer',
        html: `
            <div class="form-grid">
                <div class="form-group">
                    <label class="form-label">Full Name *</label>
                    <input id="swalName" type="text" class="form-control" placeholder="Full name" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Phone Number *</label>
                    <input id="swalPhone" type="tel" class="form-control" placeholder="09XXXXXXXXX" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Email</label>
                    <input id="swalEmail" type="email" class="form-control" placeholder="optional">
                </div>
                <div class="form-group">
                    <label class="form-label">Customer Type</label>
                    <select id="swalType" class="form-control">
                        <option value="regular" selected>Regular</option>
                        <option value="vip">VIP</option>
                        <option value="premium">Premium</option>
                    </select>
                </div>
                <div class="form-group full-width">
                    <label class="form-label">Address</label>
                    <textarea id="swalAddress" class="form-control" rows="3" placeholder="optional"></textarea>
                </div>
            </div>
        `,
        focusConfirm: false,
        showCancelButton: true,
        confirmButtonText: 'Add Customer',
        preConfirm: () => {
            const name = document.getElementById('swalName').value.trim();
            const phone = document.getElementById('swalPhone').value.trim();
            const email = document.getElementById('swalEmail').value.trim();
            const customer_type = document.getElementById('swalType').value;
            const address = document.getElementById('swalAddress').value.trim();
            if (!name || !phone) {
                Swal.showValidationMessage('Name and Phone are required');
                return false;
            }
            return { name, phone, email, customer_type, address };
        }
    });

    if (!formValues) return; // cancelled

    try {
        await Swal.fire({ title: 'Saving...', allowOutsideClick: false, didOpen: () => Swal.showLoading() });
        const response = await fetch('../api/customers.php?action=create', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(formValues)
        });
        const result = await response.json();
        Swal.close();
        if (result.success) {
            customersManager.showSuccess('Customer added successfully');
            customersManager.loadCustomers();
        } else {
            customersManager.showError(result.message || 'Failed to add customer');
        }
    } catch (e) {
        Swal.close();
        customersManager.showError('Network error occurred');
    }
}

function editCustomer(customerId) {
    if (window.Swal) {
        Swal.fire({
            icon: 'info',
            title: 'Edit Customer',
            text: `Feature coming soon. Customer ID: ${customerId}`
        });
    } else {
        alert('Edit customer feature - ID: ' + customerId);
    }
}

async function suspendCustomer(customerId) {
    try {
        if (window.Swal) {
            const ask = await Swal.fire({
                title: 'Suspend this customer?',
                text: 'The customer will not be able to place orders while suspended.',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Yes, suspend',
                cancelButtonText: 'No'
            });
            if (!ask.isConfirmed) return;

            Swal.fire({
                title: 'Suspending... ',
                allowOutsideClick: false,
                didOpen: () => { Swal.showLoading(); }
            });
        } else {
            const confirmed = confirm('Are you sure you want to suspend this customer?');
            if (!confirmed) return;
        }

        const response = await fetch('../api/customers.php?action=suspend', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ customer_id: customerId })
        });

        const result = await response.json();
        
        if (window.Swal) Swal.close();

        if (result.success) {
            customersManager.showSuccess('Customer suspended successfully');
            customersManager.loadCustomers();
        } else {
            customersManager.showError(result.message || 'Failed to suspend customer');
        }
    } catch (error) {
        if (window.Swal) Swal.close();
        customersManager.showError('Network error occurred');
    }
}

async function activateCustomer(customerId) {
    try {
        if (window.Swal) {
            Swal.fire({
                title: 'Activating... ',
                allowOutsideClick: false,
                didOpen: () => { Swal.showLoading(); }
            });
        }
        const response = await fetch('../api/customers.php?action=activate', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ customer_id: customerId })
        });

        const result = await response.json();
        
        if (window.Swal) Swal.close();
        if (result.success) {
            customersManager.showSuccess('Customer activated successfully');
            customersManager.loadCustomers();
        } else {
            customersManager.showError(result.message || 'Failed to activate customer');
        }
    } catch (error) {
        if (window.Swal) Swal.close();
        customersManager.showError('Network error occurred');
    }
}

async function deleteCustomer(customerId) {
    try {
        if (window.Swal) {
            const ask = await Swal.fire({
                title: 'Delete this customer?',
                text: 'This action cannot be undone.',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Yes, delete',
                cancelButtonText: 'No'
            });
            if (!ask.isConfirmed) return;

            Swal.fire({
                title: 'Deleting... ',
                allowOutsideClick: false,
                didOpen: () => { Swal.showLoading(); }
            });
        } else {
            const confirmed = confirm('Are you sure you want to delete this customer? This action cannot be undone.');
            if (!confirmed) return;
        }

        const response = await fetch('../api/customers.php?action=delete', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ customer_id: customerId })
        });

        const result = await response.json();
        
        if (window.Swal) Swal.close();
        if (result.success) {
            customersManager.showSuccess('Customer deleted successfully');
            customersManager.loadCustomers();
        } else {
            customersManager.showError(result.message || 'Failed to delete customer');
        }
    } catch (error) {
        if (window.Swal) Swal.close();
        customersManager.showError('Network error occurred');
    }
}

// closeModal removed; using SweetAlert dialogs instead

function clearFilters() {
    document.querySelectorAll('.filter-select').forEach(select => {
        select.value = '';
    });
    document.getElementById('startDate').value = '';
    document.getElementById('endDate').value = '';
    document.querySelector('.search-input').value = '';
    
    customersManager.loadCustomers();
}

function exportCustomers() {
    const filters = customersManager.getFilters();
    const queryString = new URLSearchParams(filters).toString();
    window.open(`../api/customers.php?action=export&${queryString}`, '_blank');
}

function bulkActivate() {
    const selectedIds = Array.from(customersManager.selectedCustomers);
    if (selectedIds.length === 0) {
        customersManager.showError('Please select customers to activate');
        return;
    }
    if (window.Swal) {
        Swal.fire({
            icon: 'info',
            title: 'Bulk Activate',
            text: `Feature coming soon. Selected IDs: ${selectedIds.join(', ')}`
        });
    } else {
        alert('Bulk activate feature - Selected IDs: ' + selectedIds.join(', '));
    }
}

function bulkSuspend() {
    const selectedIds = Array.from(customersManager.selectedCustomers);
    if (selectedIds.length === 0) {
        customersManager.showError('Please select customers to suspend');
        return;
    }
    if (window.Swal) {
        Swal.fire({
            icon: 'info',
            title: 'Bulk Suspend',
            text: `Feature coming soon. Selected IDs: ${selectedIds.join(', ')}`
        });
    } else {
        alert('Bulk suspend feature - Selected IDs: ' + selectedIds.join(', '));
    }
}

function bulkDelete() {
    const selectedIds = Array.from(customersManager.selectedCustomers);
    if (selectedIds.length === 0) {
        customersManager.showError('Please select customers to delete');
        return;
    }
    if (window.Swal) {
        Swal.fire({
            title: `Delete ${selectedIds.length} selected customers?`,
            text: 'This action cannot be undone.',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete',
            cancelButtonText: 'No'
        }).then(res => {
            if (res.isConfirmed) {
                Swal.fire({
                    icon: 'info',
                    title: 'Bulk Delete',
                    text: `Feature coming soon. Selected IDs: ${selectedIds.join(', ')}`
                });
            }
        });
    } else {
        const confirmed = confirm(`Delete ${selectedIds.length} selected customers? This action cannot be undone.`);
        if (confirmed) {
            alert('Bulk delete feature - Selected IDs: ' + selectedIds.join(', '));
        }
    }
}
</script>

<style>
.dashboard-card { margin-top: 1rem; }
.card-header { display:flex; align-items:center; justify-content:space-between; padding: 0.75rem 1rem; border-bottom: 1px solid var(--gray-200); }
.card-header h3 { margin:0; font-size:1.05rem; color: var(--gray-800); }
.card-actions { display:flex; gap:0.5rem; }

/* Filters layout */
.filters-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
    gap: 1rem 1.25rem;
    padding: 1rem;
}
.filter-group { display:flex; flex-direction:column; }
.filter-group .form-label { font-weight:600; color: var(--gray-700); margin-bottom: 0.375rem; }
.form-control { width: 100%; }
.search-input { height: 36px; }
.filter-select { height: 36px; }
.date-range { display:flex; align-items:center; gap: 0.5rem; }
.date-range input.form-control { height: 36px; }

/* Table spacing */
.data-table-container { padding: 0 1rem 1rem; }

.customer-info {
    display: flex;
    align-items: center;
    gap: 0.75rem;
}

.customer-avatar {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    overflow: hidden;
    flex-shrink: 0;
}

.customer-avatar img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.customer-details strong {
    color: var(--gray-800);
}

.contact-info div {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    margin-bottom: 0.25rem;
}

.contact-info i {
    width: 12px;
    color: var(--gray-500);
}

.order-stats strong {
    color: var(--gray-800);
}

.profile-header {
    display: flex;
    align-items: center;
    gap: 1rem;
    margin-bottom: 2rem;
    padding-bottom: 1rem;
    border-bottom: 1px solid var(--gray-200);
}

.profile-avatar {
    width: 80px;
    height: 80px;
    border-radius: 50%;
    overflow: hidden;
}

.profile-avatar img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.profile-info h3 {
    margin: 0 0 0.5rem 0;
    color: var(--gray-800);
}

.profile-info .badge {
    margin-right: 0.5rem;
}

.details-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 2rem;
}

.detail-section h4 {
    margin-bottom: 1rem;
    color: var(--gray-800);
    border-bottom: 2px solid var(--primary-color);
    padding-bottom: 0.5rem;
}

.detail-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 0.5rem 0;
    border-bottom: 1px solid var(--gray-100);
}

.detail-item:last-child {
    border-bottom: none;
}

.detail-item label {
    font-weight: 600;
    color: var(--gray-600);
}

.form-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 1rem;
}

.form-group.full-width {
    grid-column: 1 / -1;
}
</style>

<?php include 'templates/footer.php'; ?>
