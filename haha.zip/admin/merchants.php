<?php
$pageTitle = 'Merchant Management';
include 'templates/header.php';
?>

<!-- Page Header -->
<div class="dashboard-header">
    <div class="header-content">
        <div>
            <h1>Merchant Management</h1>
            <p>Manage restaurants and merchant partners</p>
        </div>
        <div class="header-actions">
            <button class="btn btn-secondary" onclick="exportMerchants()">
                <i class="fas fa-download"></i> Export
            </button>
            <button class="btn btn-primary" onclick="addMerchant()">
                <i class="fas fa-plus"></i> Add Merchant
            </button>
        </div>
    </div>
</div>

<!-- Merchant Stats -->
<div class="stats-grid">
    <div class="stat-card primary">
        <div class="stat-icon">
            <i class="fas fa-store"></i>
        </div>
        <div class="stat-content">
            <h3 id="totalMerchants">0</h3>
            <p>Total Merchants</p>
        </div>
    </div>
    <div class="stat-card success">
        <div class="stat-icon">
            <i class="fas fa-check-circle"></i>
        </div>
        <div class="stat-content">
            <h3 id="activeMerchants">0</h3>
            <p>Active Merchants</p>
        </div>
    </div>
    <div class="stat-card warning">
        <div class="stat-icon">
            <i class="fas fa-clock"></i>
        </div>
        <div class="stat-content">
            <h3 id="pendingMerchants">0</h3>
            <p>Pending Approval</p>
        </div>
    </div>
    <div class="stat-card info">
        <div class="stat-icon">
            <i class="fas fa-peso-sign"></i>
        </div>
        <div class="stat-content">
            <h3 id="totalRevenue">₱0</h3>
            <p>Total Revenue</p>
        </div>
    </div>
</div>

<!-- Filters and Search -->
<div class="dashboard-card">
    <div class="card-header">
        <h3>Filter & Search</h3>
        <div class="card-actions">
            <button class="btn btn-sm btn-secondary" onclick="clearFilters()">Clear Filters</button>
        </div>
    </div>
    <div class="card-body">
        <div class="filters-grid">
            <div class="filter-group">
                <label class="form-label">Search</label>
                <input type="text" class="form-control search-input" placeholder="Search by name, address, phone...">
            </div>
            <div class="filter-group">
                <label class="form-label">Status</label>
                <select class="form-control filter-select" name="status">
                    <option value="">All Status</option>
                    <option value="active">Active</option>
                    <option value="inactive">Inactive</option>
                    <option value="pending">Pending</option>
                    <option value="suspended">Suspended</option>
                </select>
            </div>
            <div class="filter-group">
                <label class="form-label">Category</label>
                <select class="form-control filter-select" name="category">
                    <option value="">All Categories</option>
                    <option value="restaurant">Restaurant</option>
                    <option value="fast_food">Fast Food</option>
                    <option value="cafe">Cafe</option>
                    <option value="bakery">Bakery</option>
                    <option value="grocery">Grocery</option>
                </select>
            </div>
            <div class="filter-group">
                <label class="form-label">Rating</label>
                <select class="form-control filter-select" name="rating">
                    <option value="">All Ratings</option>
                    <option value="5">5 Stars</option>
                    <option value="4">4+ Stars</option>
                    <option value="3">3+ Stars</option>
                    <option value="2">2+ Stars</option>
                </select>
            </div>
        </div>
    </div>
</div>

<!-- Merchants Table -->
<div class="dashboard-card">
    <div class="card-header">
        <h3>All Merchants</h3>
        <div class="card-actions">
            <div class="bulk-actions" style="display: none;">
                <button class="btn btn-sm btn-success" onclick="bulkApprove()">
                    <i class="fas fa-check"></i> Approve
                </button>
                <button class="btn btn-sm btn-warning" onclick="bulkSuspend()">
                    <i class="fas fa-pause"></i> Suspend
                </button>
                <button class="btn btn-sm btn-danger" onclick="bulkDelete()">
                    <i class="fas fa-trash"></i> Delete
                </button>
            </div>
        </div>
    </div>
    <div class="card-body">
        <div class="selection-info" style="display: none;"></div>
        <div class="table-responsive data-table-container" id="all-merchants-table">
            <table class="table data-table">
                <thead>
                    <tr>
                        <th><input type="checkbox" id="selectAll" onchange="toggleSelectAll()"></th>
                        <th>Merchant</th>
                        <th>Contact</th>
                        <th>Category</th>
                        <th>Status</th>
                        <th>Rating</th>
                        <th>Orders</th>
                        <th>Revenue</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody id="merchantsTableBody">
                    <tr>
                        <td colspan="9" class="text-center">Loading merchants...</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
class MerchantsManager {
    constructor() {
        this.selectedMerchants = new Set();
        this.merchants = [];
        this.merchantMap = new Map();
        this.init();
    }

    async init() {
        await this.loadStats();
        this.setupEventListeners();
        this.loadMerchants();
    }

    async loadStats() {
        try {
            const response = await fetch('../api/merchants.php?action=stats');
            const result = await response.json();
            
            if (result.success) {
                this.updateStats(result.data);
            }
        } catch (error) {
            console.error('Error loading stats:', error);
        }
    }

    updateStats(stats) {
        document.getElementById('totalMerchants').textContent = stats.total_merchants || 0;
        document.getElementById('activeMerchants').textContent = stats.active_merchants || 0;
        document.getElementById('pendingMerchants').textContent = stats.pending_merchants || 0;
        document.getElementById('totalRevenue').textContent = '₱' + (Number(stats.total_revenue) || 0).toLocaleString();
    }

    setupEventListeners() {
        document.querySelectorAll('.filter-select').forEach(element => {
            element.addEventListener('change', () => {
                this.loadMerchants();
            });
        });

        const searchInput = document.querySelector('.search-input');
        if (searchInput) {
            let timeout;
            searchInput.addEventListener('input', (e) => {
                clearTimeout(timeout);
                timeout = setTimeout(() => {
                    this.loadMerchants();
                }, 300);
            });
        }
    }

    async loadMerchants() {
        try {
            const filters = this.getFilters();
            const queryString = new URLSearchParams(filters).toString();

            const response = await fetch(`../api/merchants.php?action=list&${queryString}`);
            const result = await response.json();

            if (result.success) {
                this.displayMerchants(result.data.merchants || []);
            } else {
                this.showError(result.message || 'Failed to load merchants');
            }
        } catch (error) {
            console.error('Error loading merchants:', error);
            this.showError('Network error occurred');
        }
    }

    getFilters() {
        const filters = {};
        
        const searchInput = document.querySelector('.search-input');
        if (searchInput && searchInput.value.trim()) {
            filters.search = searchInput.value.trim();
        }

        document.querySelectorAll('.filter-select').forEach(select => {
            if (select.value) {
                filters[select.name] = select.value;
            }
        });

        return filters;
    }

    displayMerchants(merchants) {
        const tbody = document.getElementById('merchantsTableBody');
        
        if (merchants.length === 0) {
            tbody.innerHTML = '<tr><td colspan="9" class="text-center">No merchants found</td></tr>';
            return;
        }

        // cache for quick lookup in actions
        this.merchants = merchants;
        this.merchantMap.clear();
        merchants.forEach(m => {
            const idNum = Number(m.id);
            this.merchantMap.set(idNum, m);
            this.merchantMap.set(String(m.id), m);
        });

        const normalizeLogo = (logo) => {
            const parts = window.location.pathname.split('/').filter(Boolean);
            const base = '/' + (parts.length ? parts[0] : ''); // e.g. '/rmdelivery'
            const toAbs = (p) => `${base}/${p.replace(/^\/+/, '')}`;
            if (!logo) return toAbs('admin/assets/images/default-avatar.svg');
            if (logo.startsWith('http://') || logo.startsWith('https://')) return logo;
            if (logo.startsWith('/')) return base + logo; // '/admin/..' => '/rmdelivery/admin/..'
            return toAbs(logo);
        };

        tbody.innerHTML = merchants.map(merchant => `
            <tr data-merchant-id="${merchant.id}">
                <td>
                    <input type="checkbox" class="merchant-checkbox" value="${merchant.id}" onchange="toggleMerchantSelection(${merchant.id})">
                </td>
                <td>
                    <div class="merchant-info">
                        <div class="merchant-logo">
                            <img src="${normalizeLogo(merchant.logo)}" alt="${merchant.name}">
                        </div>
                        <div class="merchant-details">
                            <strong>${merchant.name}</strong>
                            <br><small class="text-muted">${merchant.address}</small>
                        </div>
                    </div>
                </td>
                <td>
                    <div class="contact-info">
                        <div><i class="fas fa-phone"></i> ${merchant.phone}</div>
                        ${merchant.email ? `<div><i class="fas fa-envelope"></i> ${merchant.email}</div>` : ''}
                    </div>
                </td>
                <td>
                    <span class="badge badge-info">${merchant.category}</span>
                </td>
                <td>
                    <span class="badge badge-${this.getStatusColor(merchant.status)}">${merchant.status}</span>
                </td>
                <td>
                    <div class="rating-display">
                        <div class="stars">
                            ${this.generateStars(Number(merchant.rating) || 0)}
                        </div>
                        <small class="text-muted">${(Number(merchant.rating) || 0).toFixed(1)} (${merchant.total_reviews || 0})</small>
                    </div>
                </td>
                <td>
                    <div class="order-stats">
                        <strong>${merchant.total_orders || 0}</strong> orders
                        <br><small class="text-muted">This month: ${merchant.monthly_orders || 0}</small>
                    </div>
                </td>
                <td>
                    <div class="revenue-info">
                        <strong>₱${parseFloat(merchant.total_revenue || 0).toLocaleString()}</strong>
                        <br><small class="text-muted">Monthly: ₱${parseFloat(merchant.monthly_revenue || 0).toLocaleString()}</small>
                    </div>
                </td>
                <td>
                    <div class="action-buttons">
                        <button class="btn btn-sm btn-primary" onclick="viewMerchant(${merchant.id})">
                            <i class="fas fa-eye"></i>
                        </button>
                        <button class="btn btn-sm btn-warning" onclick="editMerchant(${merchant.id})">
                            <i class="fas fa-edit"></i>
                        </button>
                        ${merchant.status === 'pending' ? `
                            <button class="btn btn-sm btn-success" onclick="approveMerchant(${merchant.id})">
                                <i class="fas fa-check"></i>
                            </button>
                        ` : ''}
                        <button class="btn btn-sm btn-danger" onclick="deleteMerchant(${merchant.id})">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </td>
            </tr>
        `).join('');
    }

    getStatusColor(status) {
        const colors = {
            'active': 'success',
            'inactive': 'secondary',
            'pending': 'warning',
            'suspended': 'danger'
        };
        return colors[status] || 'secondary';
    }

    generateStars(rating) {
        const fullStars = Math.floor(rating);
        const hasHalfStar = rating % 1 >= 0.5;
        const emptyStars = 5 - fullStars - (hasHalfStar ? 1 : 0);
        
        let stars = '';
        
        for (let i = 0; i < fullStars; i++) {
            stars += '<i class="fas fa-star"></i>';
        }
        
        if (hasHalfStar) {
            stars += '<i class="fas fa-star-half-alt"></i>';
        }
        
        for (let i = 0; i < emptyStars; i++) {
            stars += '<i class="far fa-star"></i>';
        }
        
        return stars;
    }

    showError(message) {
        if (window.adminManager) {
            window.adminManager.showError(message);
        } else {
            alert(message);
        }
    }

    showSuccess(message) {
        if (window.adminManager) {
            window.adminManager.showSuccess(message);
        } else {
            alert(message);
        }
    }
}

let merchantsManager;

document.addEventListener('DOMContentLoaded', function() {
    merchantsManager = new MerchantsManager();
    window.merchantsManager = merchantsManager; // ensure global access
});

function toggleSelectAll() {
    const selectAll = document.getElementById('selectAll');
    const checkboxes = document.querySelectorAll('.merchant-checkbox');
    
    checkboxes.forEach(checkbox => {
        checkbox.checked = selectAll.checked;
        const merchantId = parseInt(checkbox.value);
        if (selectAll.checked) {
            merchantsManager.selectedMerchants.add(merchantId);
        } else {
            merchantsManager.selectedMerchants.delete(merchantId);
        }
    });
    
    updateBulkActions();
}

function toggleMerchantSelection(merchantId) {
    const checkbox = document.querySelector(`input[value="${merchantId}"]`);
    if (checkbox.checked) {
        merchantsManager.selectedMerchants.add(merchantId);
    } else {
        merchantsManager.selectedMerchants.delete(merchantId);
    }
    
    updateBulkActions();
}

function updateBulkActions() {
    const count = merchantsManager.selectedMerchants.size;
    const bulkActions = document.querySelector('.bulk-actions');
    const selectionInfo = document.querySelector('.selection-info');
    
    if (count > 0) {
        bulkActions.style.display = 'flex';
        selectionInfo.style.display = 'block';
        selectionInfo.textContent = `${count} merchant(s) selected`;
    } else {
        bulkActions.style.display = 'none';
        selectionInfo.style.display = 'none';
    }
}

function viewMerchant(merchantId) {
    const mm = window.merchantsManager;
    const idNum = Number(merchantId);
    let m = mm?.merchantMap?.get(idNum) || mm?.merchantMap?.get(String(merchantId));
    if (!m && Array.isArray(mm?.merchants)) {
        m = mm.merchants.find(x => String(x.id) === String(merchantId));
    }
    if (!m) {
        if (window.adminManager) adminManager.showError('Merchant not found in current list');
        else alert('Merchant not found');
        return;
    }
    const statusBadge = `<span class="badge badge-${mm.getStatusColor(m.status)}" style="text-transform:capitalize">${m.status}</span>`;
    const normalizeLogo = (logo) => {
        const parts = window.location.pathname.split('/').filter(Boolean);
        const base = '/' + (parts.length ? parts[0] : '');
        const toAbs = (p) => `${base}/${p.replace(/^\/+/, '')}`;
        if (!logo) return toAbs('admin/assets/images/default-avatar.svg');
        if (logo.startsWith('http://') || logo.startsWith('https://')) return logo;
        if (logo.startsWith('/')) return base + logo;
        return toAbs(logo);
    };
    const html = `
        <div style="text-align:left">
            <div style="display:flex; gap:1rem; align-items:center; margin-bottom:1rem;">
                <div style="width:64px;height:64px;border-radius:8px;overflow:hidden;background:#f2f2f2">
                    <img src="${normalizeLogo(m.logo)}" alt="${m.name}" style="width:100%;height:100%;object-fit:cover;"/>
                </div>
                <div>
                    <h3 style="margin:0 0 .25rem 0">${m.name}</h3>
                    <div style="display:flex; gap:.5rem; align-items:center;">${statusBadge}<span class="badge badge-info">${m.category || 'Uncategorized'}</span></div>
                    <small class="text-muted">Merchant ID: ${m.id}</small>
                </div>
            </div>
            <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:1rem;">
                <div>
                    <h4 style="margin:0 0 .5rem 0">Contact</h4>
                    <div><label>Phone:</label> <span>${m.phone || ''}</span></div>
                    ${m.email ? `<div><label>Email:</label> <span>${m.email}</span></div>` : ''}
                    ${m.address ? `<div><label>Address:</label> <span>${m.address}</span></div>` : ''}
                </div>
                <div>
                    <h4 style="margin:0 0 .5rem 0">Menu & Ops</h4>
                    ${m.menu_items_count !== undefined ? `<div><label>Menu Items:</label> <span>${m.menu_items_count}</span></div>` : ''}
                    ${m.last_order_date ? `<div><label>Last Order:</label> <span>${m.last_order_date}</span></div>` : ''}
                </div>
                <div>
                    <h4 style="margin:0 0 .5rem 0">Performance</h4>
                    <div><label>Rating:</label> <span>${(Number(m.avg_rating ?? m.rating)||0).toFixed(1)} (${m.total_reviews||0})</span></div>
                    <div><label>Total Orders:</label> <span>${m.delivered_orders ?? m.total_orders ?? 0}</span></div>
                    <div><label>Revenue (Total):</label> <span>₱${parseFloat(m.total_revenue||0).toLocaleString()}</span></div>
                    <div><label>Revenue (Month):</label> <span>₱${parseFloat(m.monthly_revenue||0).toLocaleString()}</span></div>
                </div>
            </div>
        </div>`;
    if (window.Swal) {
        Swal.fire({ html, width: 820, confirmButtonText: 'Close' });
    } else {
        alert(`${m.name} (ID: ${m.id})`);
    }
}

async function addMerchant() {
    if (!window.Swal) { alert('Add merchant requires SweetAlert2.'); return; }
    let geo = { lat: '', lng: '' };
    const { value: formValues, isConfirmed } = await Swal.fire({
        title: 'Add Merchant',
        width: 700,
        html: `
            <style>
                .swal2-form-grid{display:grid;grid-template-columns:1fr 1fr;gap:.75rem}
                .swal2-form-grid .full{grid-column:1 / span 2}
                .swal2-form-grid .half{grid-column:auto}
            </style>
            <div class="swal2-form-grid">
                <div class="full">
                    <label class="form-label" for="swal-merchant-name">Name <span style="color:#dc3545">*</span></label>
                    <input id="swal-merchant-name" class="swal2-input" placeholder="e.g. Jollibee Ayala" />
                </div>
                <div>
                    <label class="form-label" for="swal-merchant-phone">Phone <span style="color:#dc3545">*</span></label>
                    <input id="swal-merchant-phone" class="swal2-input" placeholder="0917 123 4567" />
                </div>
                <div>
                    <label class="form-label" for="swal-merchant-email">Email</label>
                    <input id="swal-merchant-email" class="swal2-input" placeholder="orders@merchant.com" />
                </div>
                <div class="full">
                    <label class="form-label" for="swal-merchant-address">Address <span style="color:#dc3545">*</span></label>
                    <input id="swal-merchant-address" class="swal2-input" placeholder="Cebu IT Park, Lahug" />
                    <small id="swal-geo-status" style="display:block;color:#6c757d;margin-top:.25rem;">Lat/Lng will be filled automatically from address</small>
                    <input id="swal-merchant-lat" type="hidden" />
                    <input id="swal-merchant-lng" type="hidden" />
                </div>
                <div>
                    <label class="form-label" for="swal-merchant-commission">Commission %</label>
                    <input id="swal-merchant-commission" class="swal2-input" placeholder="5" />
                </div>
                <div>
                    <label class="form-label" for="swal-merchant-service-fee">Service Fee</label>
                    <input id="swal-merchant-service-fee" class="swal2-input" placeholder="0" />
                </div>
                <div class="full">
                    <label class="form-label" for="swal-merchant-description">Description</label>
                    <textarea id="swal-merchant-description" class="swal2-textarea" rows="2" placeholder="Short description"></textarea>
                </div>
                <div class="full">
                    <label class="form-label" for="swal-merchant-logo-file">Logo (upload)</label>
                    <input id="swal-merchant-logo-file" type="file" accept="image/*" class="swal2-file" />
                </div>
                <div class="full form-check" style="margin-top:.25rem;">
                    <input type="checkbox" id="swal-merchant-active" class="form-check-input" checked />
                    <label class="form-check-label" for="swal-merchant-active">Active</label>
                </div>
            </div>
        `,
        focusConfirm: false,
        showCancelButton: true,
        confirmButtonText: 'Create',
        didOpen: () => {
            const status = document.getElementById('swal-geo-status');
            const addressEl = document.getElementById('swal-merchant-address');
            const latEl = document.getElementById('swal-merchant-lat');
            const lngEl = document.getElementById('swal-merchant-lng');
            const debounce = (fn, d=500)=>{let t;return (...a)=>{clearTimeout(t);t=setTimeout(()=>fn(...a),d)}};
            const geocode = async (addr) => {
                if (!addr || addr.length < 4) { status.textContent = 'Enter a more specific address'; return; }
                status.textContent = 'Finding location...';
                try {
                    const url = `https://nominatim.openstreetmap.org/search?format=json&limit=1&q=${encodeURIComponent(addr)}`;
                    const resp = await fetch(url, { headers: { 'Accept-Language': 'en' } });
                    const items = await resp.json();
                    if (items && items.length) {
                        latEl.value = items[0].lat; lngEl.value = items[0].lon; geo.lat = items[0].lat; geo.lng = items[0].lon;
                        status.textContent = `Location found: ${parseFloat(items[0].lat).toFixed(5)}, ${parseFloat(items[0].lon).toFixed(5)}`;
                        status.style.color = '#198754';
                    } else {
                        status.textContent = 'No match found'; status.style.color = '#dc3545';
                    }
                } catch(e) {
                    status.textContent = 'Geocoding failed'; status.style.color = '#dc3545';
                }
            };
            addressEl.addEventListener('input', debounce(()=>geocode(addressEl.value), 700));
            addressEl.addEventListener('blur', ()=>geocode(addressEl.value));
        },
        preConfirm: () => {
            const name = document.getElementById('swal-merchant-name').value.trim();
            const phone = document.getElementById('swal-merchant-phone').value.trim();
            const address = document.getElementById('swal-merchant-address').value.trim();
            const email = document.getElementById('swal-merchant-email').value.trim();
            const description = document.getElementById('swal-merchant-description').value.trim();
            const lat = document.getElementById('swal-merchant-lat').value.trim();
            const lng = document.getElementById('swal-merchant-lng').value.trim();
            const commission = document.getElementById('swal-merchant-commission').value.trim();
            const serviceFee = document.getElementById('swal-merchant-service-fee').value.trim();
            const isActive = document.getElementById('swal-merchant-active').checked ? 1 : 0;
            const logoInput = document.getElementById('swal-merchant-logo-file');
            const logoFile = (logoInput && logoInput.files && logoInput.files[0]) ? logoInput.files[0] : null;
            if (!name || !phone || !address) {
                Swal.showValidationMessage('Please fill in Name, Phone, and Address');
                return false;
            }
            // Basic numeric validation
            if (commission && isNaN(parseFloat(commission))) { Swal.showValidationMessage('Commission Rate must be a number'); return false; }
            if (serviceFee && isNaN(parseFloat(serviceFee))) { Swal.showValidationMessage('Service Fee must be a number'); return false; }
            // Keep values; actual submit will build FormData
            return { name, phone, address, email, description, lat, lng, commission, serviceFee, isActive, logoFile };
        }
    });

    if (!isConfirmed || !formValues) return;

    Swal.fire({
        title: 'Creating merchant...',
        allowOutsideClick: false,
        didOpen: () => { Swal.showLoading(); }
    });

    try {
        // Build multipart form-data for file upload
        const fd = new FormData();
        fd.append('name', formValues.name);
        fd.append('phone', formValues.phone);
        fd.append('address', formValues.address);
        if (formValues.email) fd.append('email', formValues.email);
        if (formValues.description) fd.append('description', formValues.description);
        if (formValues.lat || geo.lat) fd.append('lat', formValues.lat || geo.lat);
        if (formValues.lng || geo.lng) fd.append('lng', formValues.lng || geo.lng);
        if (formValues.commission) fd.append('commission_rate', formValues.commission);
        if (formValues.serviceFee) fd.append('service_fee', formValues.serviceFee);
        fd.append('is_active', formValues.isActive);
        if (formValues.logoFile) {
            // Optional 5MB client-side limit to avoid server rejection
            const maxSize = 5 * 1024 * 1024;
            if (formValues.logoFile.size > maxSize) {
                Swal.close();
                await Swal.fire({ icon: 'error', title: 'Logo too large', text: 'Max size is 5MB. Please choose a smaller image.' });
                return;
            }
            fd.append('logo', formValues.logoFile);
        }

        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 15000);
        const res = await fetch('../api/merchants.php?action=create', {
            method: 'POST',
            body: fd,
            signal: controller.signal
        });
        clearTimeout(timeoutId);
        const result = await res.json();
        if (result.success) {
            Swal.close();
            await Swal.fire({ icon: 'success', title: 'Merchant created' });
            merchantsManager.loadMerchants();
        } else {
            Swal.close();
            await Swal.fire({ icon: 'error', title: 'Failed to create', text: result.message || 'Unknown error' });
        }
    } catch (e) {
        Swal.close();
        if (e.name === 'AbortError') {
            await Swal.fire({ icon: 'error', title: 'Request timed out', text: 'The server took too long to respond. Please try again.' });
        } else {
            await Swal.fire({ icon: 'error', title: 'Network error', text: 'Please try again.' });
        }
    }
}

function editMerchant(merchantId) {
    if (window.Swal) {
        Swal.fire({ icon: 'info', title: 'Edit Merchant', text: `Feature coming soon. Merchant ID: ${merchantId}` });
    } else {
        alert('Edit merchant - ID: ' + merchantId);
    }
}

async function approveMerchant(merchantId) {
    if (window.Swal) {
        const ask = await Swal.fire({
            title: 'Approve this merchant?',
            icon: 'question',
            showCancelButton: true,
            confirmButtonText: 'Yes, approve',
            cancelButtonText: 'No'
        });
        if (!ask.isConfirmed) return;

        await Swal.fire({
            title: 'Approving...',
            allowOutsideClick: false,
            didOpen: () => { Swal.showLoading(); }
        });

        try {
            const res = await fetch('../api/merchants.php?action=update_status', {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ merchant_id: merchantId, status: 'active' })
            });
            const result = await res.json();
            if (result.success) {
                await Swal.fire({ icon: 'success', title: 'Merchant approved' });
                merchantsManager.loadMerchants();
            } else {
                await Swal.fire({ icon: 'error', title: 'Failed to approve', text: result.message || 'Unknown error' });
            }
        } catch (e) {
            await Swal.fire({ icon: 'error', title: 'Network error', text: 'Please try again.' });
        }
    } else {
        const confirmed = confirm('Approve this merchant?');
        if (!confirmed) return;
        try {
            fetch('../api/merchants.php?action=update_status', {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ merchant_id: merchantId, status: 'active' })
            }).then(() => merchantsManager.loadMerchants());
        } catch {}
    }
}

async function deleteMerchant(merchantId) {
    if (window.Swal) {
        const ask = await Swal.fire({
            title: 'Delete this merchant?',
            text: 'This action cannot be undone.',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete',
            cancelButtonText: 'No'
        });
        if (!ask.isConfirmed) return;

        Swal.fire({
            title: 'Deleting...',
            allowOutsideClick: false,
            didOpen: () => { Swal.showLoading(); }
        });

        try {
            const controller = new AbortController();
            const timeoutId = setTimeout(() => controller.abort(), 15000);
            const res = await fetch(`../api/merchants.php?action=delete`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({ merchant_id: String(merchantId) }),
                signal: controller.signal
            });
            clearTimeout(timeoutId);
            let result;
            try {
                result = await res.json();
            } catch (e) {
                result = { success: false, message: 'Invalid server response' };
            }
            if (res.ok && result.success) {
                await Swal.fire({ icon: 'success', title: 'Merchant deleted' });
                merchantsManager.loadMerchants();
            } else {
                await Swal.fire({ icon: 'error', title: 'Failed to delete', text: result.message || `HTTP ${res.status}` });
            }
        } catch (e) {
            if (e.name === 'AbortError') {
                await Swal.fire({ icon: 'error', title: 'Request timed out', text: 'The server took too long to respond.' });
            } else {
                await Swal.fire({ icon: 'error', title: 'Network error', text: 'Please try again.' });
            }
        }
    } else {
        const confirmed = confirm('Delete this merchant?');
        if (!confirmed) return;
        try {
            fetch(`../api/merchants.php?action=delete`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({ merchant_id: String(merchantId) })
            }).then(() => merchantsManager.loadMerchants());
        } catch {}
    }
}

function clearFilters() {
    document.querySelectorAll('.filter-select').forEach(select => {
        select.value = '';
    });
    document.querySelector('.search-input').value = '';
    
    merchantsManager.loadMerchants();
}

function exportMerchants() {
    const filters = merchantsManager.getFilters();
    const queryString = new URLSearchParams(filters).toString();
    window.open(`../api/merchants.php?action=export&${queryString}`, '_blank');
}

async function bulkApprove() {
    const selectedIds = Array.from(merchantsManager.selectedMerchants);
    if (selectedIds.length === 0) {
        merchantsManager.showError('Please select merchants to approve');
        return;
    }
    if (window.Swal) {
        const ask = await Swal.fire({
            title: `Approve ${selectedIds.length} merchant(s)?`,
            icon: 'question',
            showCancelButton: true,
            confirmButtonText: 'Yes, approve'
        });
        if (!ask.isConfirmed) return;
        await Swal.fire({ title: 'Processing...', allowOutsideClick: false, didOpen: () => { Swal.showLoading(); } });
        try {
            const res = await fetch('../api/merchants.php?action=bulk_action', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ action: 'activate', merchant_ids: selectedIds })
            });
            const result = await res.json();
            if (result.success) {
                await Swal.fire({ icon: 'success', title: 'Bulk approve completed' });
                merchantsManager.selectedMerchants.clear();
                updateBulkActions();
                merchantsManager.loadMerchants();
            } else {
                await Swal.fire({ icon: 'error', title: 'Bulk approve failed', text: result.message || 'Unknown error' });
            }
        } catch (e) {
            await Swal.fire({ icon: 'error', title: 'Network error', text: 'Please try again.' });
        }
    } else {
        // Fallback (no SweetAlert)
        try {
            fetch('../api/merchants.php?action=bulk_action', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ action: 'activate', merchant_ids: selectedIds })
            }).then(() => { merchantsManager.selectedMerchants.clear(); updateBulkActions(); merchantsManager.loadMerchants(); });
        } catch {}
    }
}

async function bulkSuspend() {
    const selectedIds = Array.from(merchantsManager.selectedMerchants);
    if (selectedIds.length === 0) {
        merchantsManager.showError('Please select merchants to suspend');
        return;
    }
    if (window.Swal) {
        const ask = await Swal.fire({
            title: `Suspend ${selectedIds.length} merchant(s)?`,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, suspend'
        });
        if (!ask.isConfirmed) return;
        await Swal.fire({ title: 'Processing...', allowOutsideClick: false, didOpen: () => { Swal.showLoading(); } });
        try {
            const res = await fetch('../api/merchants.php?action=bulk_action', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ action: 'suspend', merchant_ids: selectedIds })
            });
            const result = await res.json();
            if (result.success) {
                await Swal.fire({ icon: 'success', title: 'Bulk suspend completed' });
                merchantsManager.selectedMerchants.clear();
                updateBulkActions();
                merchantsManager.loadMerchants();
            } else {
                await Swal.fire({ icon: 'error', title: 'Bulk suspend failed', text: result.message || 'Unknown error' });
            }
        } catch (e) {
            await Swal.fire({ icon: 'error', title: 'Network error', text: 'Please try again.' });
        }
    } else {
        try {
            fetch('../api/merchants.php?action=bulk_action', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ action: 'suspend', merchant_ids: selectedIds })
            }).then(() => { merchantsManager.selectedMerchants.clear(); updateBulkActions(); merchantsManager.loadMerchants(); });
        } catch {}
    }
}

async function bulkDelete() {
    const selectedIds = Array.from(merchantsManager.selectedMerchants);
    if (selectedIds.length === 0) {
        merchantsManager.showError('Please select merchants to delete');
        return;
    }
    if (window.Swal) {
        const ask = await Swal.fire({
            title: `Delete ${selectedIds.length} merchant(s)?`,
            text: 'This action cannot be undone.',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete'
        });
        if (!ask.isConfirmed) return;
        await Swal.fire({ title: 'Processing...', allowOutsideClick: false, didOpen: () => { Swal.showLoading(); } });
        try {
            const res = await fetch('../api/merchants.php?action=bulk_action', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ action: 'delete', merchant_ids: selectedIds })
            });
            const result = await res.json();
            if (result.success) {
                await Swal.fire({ icon: 'success', title: 'Bulk delete completed' });
                merchantsManager.selectedMerchants.clear();
                updateBulkActions();
                merchantsManager.loadMerchants();
            } else {
                await Swal.fire({ icon: 'error', title: 'Bulk delete failed', text: result.message || 'Unknown error' });
            }
        } catch (e) {
            await Swal.fire({ icon: 'error', title: 'Network error', text: 'Please try again.' });
        }
    } else {
        const confirmed = confirm(`Delete ${selectedIds.length} merchants?`);
        if (!confirmed) return;
        try {
            fetch('../api/merchants.php?action=bulk_action', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ action: 'delete', merchant_ids: selectedIds })
            }).then(() => { merchantsManager.selectedMerchants.clear(); updateBulkActions(); merchantsManager.loadMerchants(); });
        } catch {}
    }
}
</script>

<style>
.dashboard-card { margin-top: 1rem; }
.card-header { display:flex; align-items:center; justify-content:space-between; padding: 0.75rem 1rem; border-bottom: 1px solid var(--gray-200); }
.card-header h3 { margin:0; font-size:1.05rem; color: var(--gray-800); }
.card-actions { display:flex; gap:0.5rem; }

/* Filters layout */
.filters-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
    gap: 1rem 1.25rem;
    padding: 1rem;
}
.filter-group { display:flex; flex-direction:column; }
.filter-group .form-label { font-weight:600; color: var(--gray-700); margin-bottom: 0.375rem; }
.form-control { width: 100%; }
.search-input { height: 36px; }
.filter-select { height: 36px; }

/* Table spacing */
.data-table-container { padding: 0 1rem 1rem; }

.merchant-info {
    display: flex;
    align-items: center;
    gap: 0.75rem;
}

.merchant-logo {
    width: 40px;
    height: 40px;
    border-radius: 8px;
    overflow: hidden;
    flex-shrink: 0;
}

.merchant-logo img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.merchant-details strong {
    color: var(--gray-800);
}

.contact-info div {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    margin-bottom: 0.25rem;
}

.contact-info i {
    width: 12px;
    color: var(--gray-500);
}

.rating-display .stars {
    color: #F59E0B;
    margin-bottom: 0.25rem;
}

.rating-display .stars i {
    margin-right: 0.125rem;
}

.order-stats strong,
.revenue-info strong {
    color: var(--gray-800);
}
</style>

<?php include 'templates/footer.php'; ?>
