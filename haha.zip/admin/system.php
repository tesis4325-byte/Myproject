<?php
$pageTitle = 'System Management';
include 'templates/header.php';
?>

<!-- Page Header -->
<div class="dashboard-header">
    <div class="header-content">
        <div>
            <h1>System Management</h1>
            <p>Manage roles, security settings, and system logs</p>
        </div>
        <div class="header-actions">
            <button class="btn btn-secondary" onclick="exportLogs()">
                <i class="fas fa-download"></i> Export Logs
            </button>
            <button class="btn btn-primary" onclick="addUser()">
                <i class="fas fa-plus"></i> Add User
            </button>
        </div>
    </div>
</div>

<!-- System Tabs -->
<div class="dashboard-card">
    <div class="card-header">
        <div class="system-tabs">
            <button class="tab-button active" data-tab="users" onclick="switchTab('users')">
                <i class="fas fa-users"></i> Users & Roles
            </button>
            <button class="tab-button" data-tab="security" onclick="switchTab('security')">
                <i class="fas fa-shield-alt"></i> Security
            </button>
            <button class="tab-button" data-tab="logs" onclick="switchTab('logs')">
                <i class="fas fa-file-alt"></i> System Logs
            </button>
            <button class="tab-button" data-tab="settings" onclick="switchTab('settings')">
                <i class="fas fa-cog"></i> Settings
            </button>
        </div>
    </div>
    <div class="card-body">
        <!-- Users & Roles Tab -->
        <div class="tab-content active" id="usersTab">
            <div class="section-header">
                <h3>System Users</h3>
                <div class="section-actions">
                    <select class="form-control" id="roleFilter" onchange="filterUsers()">
                        <option value="">All Roles</option>
                        <option value="admin">Admin</option>
                        <option value="manager">Manager</option>
                        <option value="support">Support</option>
                    </select>
                </div>
            </div>
            
            <div class="table-responsive data-table-container" id="system-users-table">
                <table class="table">
                    <thead>
                        <tr>
                            <th>User</th>
                            <th>Role</th>
                            <th>Status</th>
                            <th>Last Login</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody id="usersTableBody">
                        <tr>
                            <td colspan="5" class="text-center">Loading users...</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Security Tab -->
        <div class="tab-content" id="securityTab">
            <div class="security-sections">
                <div class="security-section">
                    <h4>Password Policy</h4>
                    <div class="form-group">
                        <label class="form-label">Minimum Password Length</label>
                        <input type="number" class="form-control" id="minPasswordLength" value="8" min="6" max="20">
                    </div>
                    <div class="form-group">
                        <label class="form-label">
                            <input type="checkbox" id="requireUppercase" checked> Require Uppercase Letters
                        </label>
                    </div>
                    <div class="form-group">
                        <label class="form-label">
                            <input type="checkbox" id="requireNumbers" checked> Require Numbers
                        </label>
                    </div>
                    <div class="form-group">
                        <label class="form-label">
                            <input type="checkbox" id="requireSpecialChars"> Require Special Characters
                        </label>
                    </div>
                </div>

                <div class="security-section">
                    <h4>Session Settings</h4>
                    <div class="form-group">
                        <label class="form-label">Session Timeout (minutes)</label>
                        <input type="number" class="form-control" id="sessionTimeout" value="30" min="15" max="480">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Max Login Attempts</label>
                        <input type="number" class="form-control" id="maxLoginAttempts" value="5" min="3" max="10">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Lockout Duration (minutes)</label>
                        <input type="number" class="form-control" id="lockoutDuration" value="15" min="5" max="60">
                    </div>
                </div>

                <div class="security-section">
                    <h4>Two-Factor Authentication</h4>
                    <div class="form-group">
                        <label class="form-label">
                            <input type="checkbox" id="enable2FA"> Enable 2FA for Admin Users
                        </label>
                    </div>
                    <div class="form-group">
                        <label class="form-label">
                            <input type="checkbox" id="force2FA"> Force 2FA for All Users
                        </label>
                    </div>
                </div>
            </div>
            
            <div class="section-actions">
                <button class="btn btn-primary" onclick="saveSecuritySettings()">Save Security Settings</button>
            </div>
        </div>

        <!-- System Logs Tab -->
        <div class="tab-content" id="logsTab">
            <div class="logs-filters">
                <div class="filters-grid">
                    <div class="filter-group">
                        <label class="form-label">Log Type</label>
                        <select class="form-control" id="logTypeFilter" onchange="filterLogs()">
                            <option value="">All Logs</option>
                            <option value="activity">Activity</option>
                            <option value="error">Error</option>
                            <option value="security">Security</option>
                            <option value="system">System</option>
                        </select>
                    </div>
                    <div class="filter-group">
                        <label class="form-label">Date Range</label>
                        <div class="date-range">
                            <input type="date" class="form-control" id="logStartDate">
                            <span>to</span>
                            <input type="date" class="form-control" id="logEndDate">
                        </div>
                    </div>
                    <div class="filter-group">
                        <label class="form-label">Search</label>
                        <input type="text" class="form-control" id="logSearch" placeholder="Search logs...">
                    </div>
                </div>
            </div>

            <div class="logs-container">
                <div class="log-entries" id="logEntries">
                    <div class="text-center">Loading logs...</div>
                </div>
            </div>
        </div>

        <!-- Settings Tab -->
        <div class="tab-content" id="settingsTab">
            <div class="settings-sections">
                <div class="settings-section">
                    <h4>General Settings</h4>
                    <div class="form-group">
                        <label class="form-label">System Name</label>
                        <input type="text" class="form-control" id="systemName" value="RM Delivery System">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Admin Email</label>
                        <input type="email" class="form-control" id="adminEmail" value="admin@rmdelivery.com">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Timezone</label>
                        <select class="form-control" id="systemTimezone">
                            <option value="Asia/Manila" selected>Asia/Manila</option>
                            <option value="UTC">UTC</option>
                        </select>
                    </div>
                </div>

                <div class="settings-section">
                    <h4>Notification Settings</h4>
                    <div class="form-group">
                        <label class="form-label">
                            <input type="checkbox" id="emailNotifications" checked> Enable Email Notifications
                        </label>
                    </div>
                    <div class="form-group">
                        <label class="form-label">
                            <input type="checkbox" id="smsNotifications"> Enable SMS Notifications
                        </label>
                    </div>
                    <div class="form-group">
                        <label class="form-label">
                            <input type="checkbox" id="pushNotifications" checked> Enable Push Notifications
                        </label>
                    </div>
                </div>

                <div class="settings-section">
                    <h4>Maintenance Mode</h4>
                    <div class="form-group">
                        <label class="form-label">
                            <input type="checkbox" id="maintenanceMode"> Enable Maintenance Mode
                        </label>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Maintenance Message</label>
                        <textarea class="form-control" id="maintenanceMessage" rows="3" placeholder="System is under maintenance. Please try again later."></textarea>
                    </div>
                </div>
            </div>
            
            <div class="section-actions">
                <button class="btn btn-primary" onclick="saveSystemSettings()">Save Settings</button>
            </div>
        </div>
    </div>
</div>

<script>
class SystemManager {
    constructor() {
        this.currentTab = 'users';
        this.init();
    }

    async init() {
        await this.loadUsers();
        this.loadSecuritySettings();
        this.loadSystemSettings();
        this.loadLogs();
    }

    async loadUsers() {
        try {
            const response = await fetch('../api/system.php?action=users');
            const result = await response.json();
            
            if (result.success) {
                this.displayUsers(result.data || []);
            }
        } catch (error) {
            console.error('Error loading users:', error);
        }
    }

    displayUsers(users) {
        const tbody = document.getElementById('usersTableBody');
        
        if (users.length === 0) {
            tbody.innerHTML = '<tr><td colspan="5" class="text-center">No users found</td></tr>';
            return;
        }

        tbody.innerHTML = users.map(user => `
            <tr>
                <td>
                    <div class="user-info">
                        <strong>${user.name}</strong>
                        <br><small class="text-muted">${user.email}</small>
                    </div>
                </td>
                <td>
                    <span class="badge badge-${this.getRoleColor(user.role)}">${user.role}</span>
                </td>
                <td>
                    <span class="badge badge-${user.status === 'active' ? 'success' : 'secondary'}">${user.status}</span>
                </td>
                <td>
                    ${user.last_login ? this.formatDate(user.last_login) : 'Never'}
                </td>
                <td>
                    <div class="action-buttons">
                        <button class="btn btn-sm btn-primary" onclick="editUser(${user.id})">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button class="btn btn-sm ${user.status === 'active' ? 'btn-warning' : 'btn-success'}" 
                                onclick="toggleUserStatus(${user.id}, '${user.status === 'active' ? 'inactive' : 'active'}')">
                            <i class="fas fa-${user.status === 'active' ? 'pause' : 'play'}"></i>
                        </button>
                        <button class="btn btn-sm btn-danger" onclick="deleteUser(${user.id})">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </td>
            </tr>
        `).join('');
    }

    getRoleColor(role) {
        const colors = {
            'admin': 'danger',
            'manager': 'warning',
            'support': 'info'
        };
        return colors[role] || 'secondary';
    }

    async loadSecuritySettings() {
        try {
            const response = await fetch('../api/system.php?action=security_settings');
            const result = await response.json();
            
            if (result.success && result.data) {
                const settings = result.data;
                document.getElementById('minPasswordLength').value = settings.min_password_length || 8;
                document.getElementById('requireUppercase').checked = settings.require_uppercase || false;
                document.getElementById('requireNumbers').checked = settings.require_numbers || false;
                document.getElementById('requireSpecialChars').checked = settings.require_special_chars || false;
                document.getElementById('sessionTimeout').value = settings.session_timeout || 30;
                document.getElementById('maxLoginAttempts').value = settings.max_login_attempts || 5;
                document.getElementById('lockoutDuration').value = settings.lockout_duration || 15;
                document.getElementById('enable2FA').checked = settings.enable_2fa || false;
                document.getElementById('force2FA').checked = settings.force_2fa || false;
            }
        } catch (error) {
            console.error('Error loading security settings:', error);
        }
    }

    async loadSystemSettings() {
        try {
            const response = await fetch('../api/system.php?action=system_settings');
            const result = await response.json();
            
            if (result.success && result.data) {
                const settings = result.data;
                document.getElementById('systemName').value = settings.system_name || 'RM Delivery System';
                document.getElementById('adminEmail').value = settings.admin_email || '';
                document.getElementById('systemTimezone').value = settings.timezone || 'Asia/Manila';
                document.getElementById('emailNotifications').checked = settings.email_notifications || false;
                document.getElementById('smsNotifications').checked = settings.sms_notifications || false;
                document.getElementById('pushNotifications').checked = settings.push_notifications || false;
                document.getElementById('maintenanceMode').checked = settings.maintenance_mode || false;
                document.getElementById('maintenanceMessage').value = settings.maintenance_message || '';
            }
        } catch (error) {
            console.error('Error loading system settings:', error);
        }
    }

    async loadLogs() {
        try {
            const response = await fetch('../api/system.php?action=logs');
            const result = await response.json();
            
            if (result.success) {
                this.displayLogs(result.data || []);
            }
        } catch (error) {
            console.error('Error loading logs:', error);
        }
    }

    displayLogs(logs) {
        const container = document.getElementById('logEntries');
        
        if (logs.length === 0) {
            container.innerHTML = '<div class="text-center">No logs found</div>';
            return;
        }

        container.innerHTML = logs.map(log => `
            <div class="log-entry ${log.type}">
                <div class="log-header">
                    <span class="log-type badge badge-${this.getLogTypeColor(log.type)}">${log.type}</span>
                    <span class="log-time">${this.formatDate(log.created_at)}</span>
                </div>
                <div class="log-message">${log.message}</div>
                ${log.details ? `<div class="log-details">${log.details}</div>` : ''}
            </div>
        `).join('');
    }

    getLogTypeColor(type) {
        const colors = {
            'activity': 'info',
            'error': 'danger',
            'security': 'warning',
            'system': 'primary'
        };
        return colors[type] || 'secondary';
    }

    formatDate(dateString) {
        const date = new Date(dateString);
        return date.toLocaleDateString('en-PH', {
            month: 'short',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    }

    showError(message) {
        if (window.adminManager) {
            window.adminManager.showError(message);
        } else {
            alert(message);
        }
    }

    showSuccess(message) {
        if (window.adminManager) {
            window.adminManager.showSuccess(message);
        } else {
            alert(message);
        }
    }
}

let systemManager;

document.addEventListener('DOMContentLoaded', function() {
    systemManager = new SystemManager();
});

function switchTab(tabName) {
    // Update tab buttons
    document.querySelectorAll('.tab-button').forEach(btn => {
        btn.classList.remove('active');
    });
    document.querySelector(`[data-tab="${tabName}"]`).classList.add('active');
    
    // Update tab content
    document.querySelectorAll('.tab-content').forEach(content => {
        content.classList.remove('active');
    });
    document.getElementById(`${tabName}Tab`).classList.add('active');
    
    systemManager.currentTab = tabName;
}

function addUser() {
    alert('Add new user form');
}

function editUser(userId) {
    alert('Edit user - ID: ' + userId);
}

function toggleUserStatus(userId, newStatus) {
    const confirmed = confirm(`Set user to ${newStatus}?`);
    if (confirmed) {
        alert(`Toggle user ${userId} to ${newStatus}`);
    }
}

function deleteUser(userId) {
    const confirmed = confirm('Delete this user?');
    if (confirmed) {
        alert('Delete user - ID: ' + userId);
    }
}

function filterUsers() {
    const role = document.getElementById('roleFilter').value;
    alert('Filter users by role: ' + role);
}

function saveSecuritySettings() {
    const settings = {
        min_password_length: document.getElementById('minPasswordLength').value,
        require_uppercase: document.getElementById('requireUppercase').checked,
        require_numbers: document.getElementById('requireNumbers').checked,
        require_special_chars: document.getElementById('requireSpecialChars').checked,
        session_timeout: document.getElementById('sessionTimeout').value,
        max_login_attempts: document.getElementById('maxLoginAttempts').value,
        lockout_duration: document.getElementById('lockoutDuration').value,
        enable_2fa: document.getElementById('enable2FA').checked,
        force_2fa: document.getElementById('force2FA').checked
    };
    
    alert('Save security settings: ' + JSON.stringify(settings));
}

function saveSystemSettings() {
    const settings = {
        system_name: document.getElementById('systemName').value,
        admin_email: document.getElementById('adminEmail').value,
        timezone: document.getElementById('systemTimezone').value,
        email_notifications: document.getElementById('emailNotifications').checked,
        sms_notifications: document.getElementById('smsNotifications').checked,
        push_notifications: document.getElementById('pushNotifications').checked,
        maintenance_mode: document.getElementById('maintenanceMode').checked,
        maintenance_message: document.getElementById('maintenanceMessage').value
    };
    
    alert('Save system settings: ' + JSON.stringify(settings));
}

function filterLogs() {
    const type = document.getElementById('logTypeFilter').value;
    const startDate = document.getElementById('logStartDate').value;
    const endDate = document.getElementById('logEndDate').value;
    const search = document.getElementById('logSearch').value;
    
    alert(`Filter logs - Type: ${type}, Dates: ${startDate} to ${endDate}, Search: ${search}`);
}

function exportLogs() {
    const filters = {
        type: document.getElementById('logTypeFilter').value,
        start_date: document.getElementById('logStartDate').value,
        end_date: document.getElementById('logEndDate').value,
        search: document.getElementById('logSearch').value
    };
    
    const queryString = new URLSearchParams(filters).toString();
    window.open(`../api/system.php?action=export_logs&${queryString}`, '_blank');
}
</script>

<style>
.system-tabs {
    display: flex;
    gap: 0.5rem;
    border-bottom: 2px solid var(--gray-200);
    margin-bottom: 2rem;
}

.tab-button {
    padding: 0.75rem 1rem;
    border: none;
    background: none;
    color: var(--gray-600);
    cursor: pointer;
    border-bottom: 2px solid transparent;
    transition: all 0.3s ease;
}

.tab-button:hover {
    color: var(--primary-color);
}

.tab-button.active {
    color: var(--primary-color);
    border-bottom-color: var(--primary-color);
}

.tab-content {
    display: none;
}

.tab-content.active {
    display: block;
}

.section-header {
    display: flex;
    justify-content: between;
    align-items: center;
    margin-bottom: 1rem;
}

.security-sections,
.settings-sections {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 2rem;
    margin-bottom: 2rem;
}

.security-section,
.settings-section {
    padding: 1.5rem;
    border: 1px solid var(--gray-200);
    border-radius: 0.5rem;
    background: var(--gray-50);
}

.security-section h4,
.settings-section h4 {
    margin-bottom: 1rem;
    color: var(--gray-800);
    border-bottom: 2px solid var(--primary-color);
    padding-bottom: 0.5rem;
}

.logs-filters {
    margin-bottom: 1rem;
}

.logs-container {
    max-height: 500px;
    overflow-y: auto;
    border: 1px solid var(--gray-200);
    border-radius: 0.5rem;
}

.log-entry {
    padding: 1rem;
    border-bottom: 1px solid var(--gray-200);
}

.log-entry:last-child {
    border-bottom: none;
}

.log-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 0.5rem;
}

.log-message {
    color: var(--gray-800);
    margin-bottom: 0.5rem;
}

.log-details {
    color: var(--gray-600);
    font-size: 0.875rem;
    background: var(--gray-100);
    padding: 0.5rem;
    border-radius: 0.25rem;
}

.section-actions {
    display: flex;
    justify-content: flex-end;
    gap: 1rem;
    margin-top: 2rem;
}

.date-range {
    display: flex;
    align-items: center;
    gap: 0.5rem;
}

.date-range span {
    color: var(--gray-600);
    font-size: 0.875rem;
}

.user-info strong {
    color: var(--gray-800);
}
</style>

<?php include 'templates/footer.php'; ?>
