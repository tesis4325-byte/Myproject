<?php
$pageTitle = 'Complaints Management';
include 'templates/header.php';
?>

<!-- Page Header -->
<div class="dashboard-header">
    <div class="header-content">
        <div>
            <h1>Complaints Management</h1>
            <p>Handle customer complaints and feedback</p>
        </div>
        <div class="header-actions">
            <button class="btn btn-secondary" onclick="exportComplaints()">
                <i class="fas fa-download"></i> Export
            </button>
            <button class="btn btn-primary" onclick="addComplaint()">
                <i class="fas fa-plus"></i> Add Complaint
            </button>
        </div>
    </div>
</div>

<!-- Complaint Stats -->
<div class="stats-grid">
    <div class="stat-card warning">
        <div class="stat-icon">
            <i class="fas fa-exclamation-triangle"></i>
        </div>
        <div class="stat-content">
            <h3 id="totalComplaints">0</h3>
            <p>Total Complaints</p>
        </div>
    </div>
    <div class="stat-card danger">
        <div class="stat-icon">
            <i class="fas fa-clock"></i>
        </div>
        <div class="stat-content">
            <h3 id="pendingComplaints">0</h3>
            <p>Pending</p>
        </div>
    </div>
    <div class="stat-card success">
        <div class="stat-icon">
            <i class="fas fa-check-circle"></i>
        </div>
        <div class="stat-content">
            <h3 id="resolvedComplaints">0</h3>
            <p>Resolved</p>
        </div>
    </div>
    <div class="stat-card info">
        <div class="stat-icon">
            <i class="fas fa-clock"></i>
        </div>
        <div class="stat-content">
            <h3 id="avgResolutionTime">0h</h3>
            <p>Avg Resolution Time</p>
        </div>
    </div>
</div>

<!-- Filters and Search -->
<div class="dashboard-card">
    <div class="card-header">
        <h3>Filter & Search</h3>
        <div class="card-actions">
            <button class="btn btn-sm btn-secondary" onclick="clearFilters()">Clear Filters</button>
        </div>
    </div>
    <div class="card-body">
        <div class="filters-grid">
            <div class="filter-group">
                <label class="form-label">Search</label>
                <input type="text" class="form-control search-input" placeholder="Search complaints...">
            </div>
            <div class="filter-group">
                <label class="form-label">Status</label>
                <select class="form-control filter-select" name="status">
                    <option value="">All Status</option>
                    <option value="pending">Pending</option>
                    <option value="investigating">Investigating</option>
                    <option value="resolved">Resolved</option>
                    <option value="closed">Closed</option>
                </select>
            </div>
            <div class="filter-group">
                <label class="form-label">Priority</label>
                <select class="form-control filter-select" name="priority">
                    <option value="">All Priorities</option>
                    <option value="low">Low</option>
                    <option value="medium">Medium</option>
                    <option value="high">High</option>
                    <option value="urgent">Urgent</option>
                </select>
            </div>
            <div class="filter-group">
                <label class="form-label">Category</label>
                <select class="form-control filter-select" name="category">
                    <option value="">All Categories</option>
                    <option value="delivery">Delivery Issues</option>
                    <option value="food_quality">Food Quality</option>
                    <option value="rider_behavior">Rider Behavior</option>
                    <option value="payment">Payment Issues</option>
                    <option value="app_bug">App Bug</option>
                    <option value="other">Other</option>
                </select>
            </div>
        </div>
    </div>
</div>

<!-- Complaints Table -->
<div class="dashboard-card">
    <div class="card-header">
        <h3>All Complaints</h3>
        <div class="card-actions">
            <div class="bulk-actions" style="display: none;">
                <button class="btn btn-sm btn-primary" onclick="bulkAssign()">
                    <i class="fas fa-user-plus"></i> Assign
                </button>
                <button class="btn btn-sm btn-success" onclick="bulkResolve()">
                    <i class="fas fa-check"></i> Resolve
                </button>
                <button class="btn btn-sm btn-secondary" onclick="bulkClose()">
                    <i class="fas fa-times"></i> Close
                </button>
            </div>
        </div>
    </div>
    <div class="card-body">
        <div class="selection-info" style="display: none;"></div>
        <div class="table-responsive data-table-container" id="all-complaints-table">
            <table class="table data-table">
                <thead>
                    <tr>
                        <th><input type="checkbox" id="selectAll" onchange="toggleSelectAll()"></th>
                        <th>Complaint</th>
                        <th>Customer</th>
                        <th>Category</th>
                        <th>Priority</th>
                        <th>Status</th>
                        <th>Assigned To</th>
                        <th>Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody id="complaintsTableBody">
                    <tr>
                        <td colspan="9" class="text-center">Loading complaints...</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
class ComplaintsManager {
    constructor() {
        this.selectedComplaints = new Set();
        this.init();
    }

    async init() {
        await this.loadStats();
        this.setupEventListeners();
        this.loadComplaints();
    }

    async loadStats() {
        try {
            const response = await fetch('../api/complaints.php?action=stats');
            const result = await response.json();
            
            if (result.success) {
                this.updateStats(result.data);
            }
        } catch (error) {
            console.error('Error loading stats:', error);
        }
    }

    updateStats(stats) {
        document.getElementById('totalComplaints').textContent = stats.total_complaints || 0;
        document.getElementById('pendingComplaints').textContent = stats.pending_complaints || 0;
        document.getElementById('resolvedComplaints').textContent = stats.resolved_complaints || 0;
        document.getElementById('avgResolutionTime').textContent = (stats.avg_resolution_time || 0) + 'h';
    }

    setupEventListeners() {
        document.querySelectorAll('.filter-select').forEach(element => {
            element.addEventListener('change', () => {
                this.loadComplaints();
            });
        });

        const searchInput = document.querySelector('.search-input');
        if (searchInput) {
            let timeout;
            searchInput.addEventListener('input', (e) => {
                clearTimeout(timeout);
                timeout = setTimeout(() => {
                    this.loadComplaints();
                }, 300);
            });
        }
    }

    async loadComplaints() {
        try {
            const filters = this.getFilters();
            const queryString = new URLSearchParams(filters).toString();

            const response = await fetch(`../api/complaints.php?action=list&${queryString}`);
            const result = await response.json();

            if (result.success) {
                this.displayComplaints(result.data.complaints || []);
            } else {
                this.showError(result.message || 'Failed to load complaints');
            }
        } catch (error) {
            console.error('Error loading complaints:', error);
            this.showError('Network error occurred');
        }
    }

    getFilters() {
        const filters = {};
        
        const searchInput = document.querySelector('.search-input');
        if (searchInput && searchInput.value.trim()) {
            filters.search = searchInput.value.trim();
        }

        document.querySelectorAll('.filter-select').forEach(select => {
            if (select.value) {
                filters[select.name] = select.value;
            }
        });

        return filters;
    }

    displayComplaints(complaints) {
        const tbody = document.getElementById('complaintsTableBody');
        
        if (complaints.length === 0) {
            tbody.innerHTML = '<tr><td colspan="9" class="text-center">No complaints found</td></tr>';
            return;
        }

        tbody.innerHTML = complaints.map(complaint => `
            <tr data-complaint-id="${complaint.id}">
                <td>
                    <input type="checkbox" class="complaint-checkbox" value="${complaint.id}" onchange="toggleComplaintSelection(${complaint.id})">
                </td>
                <td>
                    <div class="complaint-info">
                        <strong>${complaint.subject}</strong>
                        <br><small class="text-muted">${this.truncateText(complaint.description, 50)}</small>
                    </div>
                </td>
                <td>
                    <div class="customer-info">
                        <strong>${complaint.customer_name}</strong>
                        <br><small class="text-muted">${complaint.customer_phone}</small>
                    </div>
                </td>
                <td>
                    <span class="badge badge-info">${this.formatCategory(complaint.category)}</span>
                </td>
                <td>
                    <span class="badge badge-${this.getPriorityColor(complaint.priority)}">${complaint.priority}</span>
                </td>
                <td>
                    <span class="badge badge-${this.getStatusColor(complaint.status)}">${complaint.status}</span>
                </td>
                <td>
                    ${complaint.assigned_to ? `
                        <div class="assigned-info">
                            <strong>${complaint.assigned_to_name}</strong>
                        </div>
                    ` : '<span class="text-muted">Unassigned</span>'}
                </td>
                <td>
                    ${this.formatDate(complaint.created_at)}
                </td>
                <td>
                    <div class="action-buttons">
                        <button class="btn btn-sm btn-primary" onclick="viewComplaint(${complaint.id})">
                            <i class="fas fa-eye"></i>
                        </button>
                        <button class="btn btn-sm btn-warning" onclick="assignComplaint(${complaint.id})">
                            <i class="fas fa-user-plus"></i>
                        </button>
                        ${complaint.status !== 'resolved' && complaint.status !== 'closed' ? `
                            <button class="btn btn-sm btn-success" onclick="resolveComplaint(${complaint.id})">
                                <i class="fas fa-check"></i>
                            </button>
                        ` : ''}
                        <button class="btn btn-sm btn-danger" onclick="deleteComplaint(${complaint.id})">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </td>
            </tr>
        `).join('');
    }

    formatCategory(category) {
        const categories = {
            'delivery': 'Delivery Issues',
            'food_quality': 'Food Quality',
            'rider_behavior': 'Rider Behavior',
            'payment': 'Payment Issues',
            'app_bug': 'App Bug',
            'other': 'Other'
        };
        return categories[category] || category;
    }

    getPriorityColor(priority) {
        const colors = {
            'low': 'secondary',
            'medium': 'warning',
            'high': 'danger',
            'urgent': 'danger'
        };
        return colors[priority] || 'secondary';
    }

    getStatusColor(status) {
        const colors = {
            'pending': 'warning',
            'investigating': 'info',
            'resolved': 'success',
            'closed': 'secondary'
        };
        return colors[status] || 'secondary';
    }

    truncateText(text, length) {
        if (text.length <= length) return text;
        return text.substring(0, length) + '...';
    }

    formatDate(dateString) {
        const date = new Date(dateString);
        return date.toLocaleDateString('en-PH', {
            month: 'short',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    }

    showError(message) {
        if (window.adminManager) {
            window.adminManager.showError(message);
        } else {
            alert(message);
        }
    }

    showSuccess(message) {
        if (window.adminManager) {
            window.adminManager.showSuccess(message);
        } else {
            alert(message);
        }
    }
}

let complaintsManager;

document.addEventListener('DOMContentLoaded', function() {
    complaintsManager = new ComplaintsManager();
});

function toggleSelectAll() {
    const selectAll = document.getElementById('selectAll');
    const checkboxes = document.querySelectorAll('.complaint-checkbox');
    
    checkboxes.forEach(checkbox => {
        checkbox.checked = selectAll.checked;
        const complaintId = parseInt(checkbox.value);
        if (selectAll.checked) {
            complaintsManager.selectedComplaints.add(complaintId);
        } else {
            complaintsManager.selectedComplaints.delete(complaintId);
        }
    });
    
    updateBulkActions();
}

function toggleComplaintSelection(complaintId) {
    const checkbox = document.querySelector(`input[value="${complaintId}"]`);
    if (checkbox.checked) {
        complaintsManager.selectedComplaints.add(complaintId);
    } else {
        complaintsManager.selectedComplaints.delete(complaintId);
    }
    
    updateBulkActions();
}

function updateBulkActions() {
    const count = complaintsManager.selectedComplaints.size;
    const bulkActions = document.querySelector('.bulk-actions');
    const selectionInfo = document.querySelector('.selection-info');
    
    if (count > 0) {
        bulkActions.style.display = 'flex';
        selectionInfo.style.display = 'block';
        selectionInfo.textContent = `${count} complaint(s) selected`;
    } else {
        bulkActions.style.display = 'none';
        selectionInfo.style.display = 'none';
    }
}

function viewComplaint(complaintId) {
    alert('View complaint details - ID: ' + complaintId);
}

function addComplaint() {
    alert('Add new complaint form');
}

function assignComplaint(complaintId) {
    alert('Assign complaint - ID: ' + complaintId);
}

function resolveComplaint(complaintId) {
    const confirmed = confirm('Mark this complaint as resolved?');
    if (confirmed) {
        alert('Resolve complaint - ID: ' + complaintId);
    }
}

function deleteComplaint(complaintId) {
    const confirmed = confirm('Delete this complaint?');
    if (confirmed) {
        alert('Delete complaint - ID: ' + complaintId);
    }
}

function clearFilters() {
    document.querySelectorAll('.filter-select').forEach(select => {
        select.value = '';
    });
    document.querySelector('.search-input').value = '';
    
    complaintsManager.loadComplaints();
}

function exportComplaints() {
    const filters = complaintsManager.getFilters();
    const queryString = new URLSearchParams(filters).toString();
    window.open(`../api/complaints.php?action=export&${queryString}`, '_blank');
}

function bulkAssign() {
    const selectedIds = Array.from(complaintsManager.selectedComplaints);
    if (selectedIds.length === 0) {
        complaintsManager.showError('Please select complaints to assign');
        return;
    }
    alert('Bulk assign - IDs: ' + selectedIds.join(', '));
}

function bulkResolve() {
    const selectedIds = Array.from(complaintsManager.selectedComplaints);
    if (selectedIds.length === 0) {
        complaintsManager.showError('Please select complaints to resolve');
        return;
    }
    alert('Bulk resolve - IDs: ' + selectedIds.join(', '));
}

function bulkClose() {
    const selectedIds = Array.from(complaintsManager.selectedComplaints);
    if (selectedIds.length === 0) {
        complaintsManager.showError('Please select complaints to close');
        return;
    }
    alert('Bulk close - IDs: ' + selectedIds.join(', '));
}
</script>

<style>
.dashboard-card { margin-top: 1rem; }
.card-header { display:flex; align-items:center; justify-content:space-between; padding: 0.75rem 1rem; border-bottom: 1px solid var(--gray-200); }
.card-header h3 { margin:0; font-size:1.05rem; color: var(--gray-800); }
.card-actions { display:flex; gap:0.5rem; }

/* Filters layout */
.filters-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
    gap: 1rem 1.25rem;
    padding: 1rem;
}
.filter-group { display:flex; flex-direction:column; }
.filter-group .form-label { font-weight:600; color: var(--gray-700); margin-bottom: 0.375rem; }
.form-control { width: 100%; }
.search-input { height: 36px; }
.filter-select { height: 36px; }

/* Table spacing */
.data-table-container { padding: 0 1rem 1rem; }
.complaint-info strong {
    color: var(--gray-800);
}

.customer-info strong {
    color: var(--gray-800);
}

.assigned-info strong {
    color: var(--gray-800);
}
</style>

<?php include 'templates/footer.php'; ?>
