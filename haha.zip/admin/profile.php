<?php
$pageTitle = 'Profile';
include 'templates/header.php';
?>

<div class="dashboard-header">
    <div class="header-content">
        <div>
            <h1>My Profile</h1>
            <p>View and update your account information</p>
        </div>
    </div>
</div>

<div class="dashboard-grid">
    <div class="dashboard-card">
        <div class="card-header">
            <h3>Account Details</h3>
        </div>
        <div class="card-body">
            <div class="status-list">
                <div class="status-item">
                    <div class="status-content">
                        <h4>Name</h4>
                        <p><?php echo htmlspecialchars($_SESSION['name'] ?? 'Admin'); ?></p>
                    </div>
                </div>
                <div class="status-item">
                    <div class="status-content">
                        <h4>Email</h4>
                        <p><?php echo htmlspecialchars($_SESSION['email'] ?? ''); ?></p>
                    </div>
                </div>
                <div class="status-item">
                    <div class="status-content">
                        <h4>Role</h4>
                        <p class="badge badge-secondary"><?php echo htmlspecialchars($_SESSION['role'] ?? 'admin'); ?></p>
                    </div>
                </div>
                <div class="status-item">
                    <div class="status-content">
                        <h4>Member Since</h4>
                        <p><?php echo htmlspecialchars($_SESSION['created_at'] ?? ''); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="dashboard-card">
        <div class="card-header">
            <h3>Security</h3>
        </div>
        <div class="card-body">
            <p>Want to change your password? Contact the system administrator or add a password change endpoint here later.</p>
        </div>
    </div>
</div>

<?php include 'templates/footer.php'; ?>
