            </div>
        </main>
    </div>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="assets/js/admin.js"></script>
    <script src="assets/js/charts.js"></script>
    
    <script>
        // Global admin functions
        function toggleSidebar(force) {
            const body = document.body;
            const willOpen = typeof force === 'boolean' ? force : !body.classList.contains('sidebar-open');
            if (willOpen) {
                body.classList.add('sidebar-open');
            } else {
                body.classList.remove('sidebar-open');
            }
        }

        function toggleNotifications() {
            const menu = document.getElementById('notificationMenu');
            if (menu) menu.classList.toggle('show');
        }

        function toggleUserMenu() {
            const menu = document.getElementById('userMenu');
            if (menu) menu.classList.toggle('show');
        }

        // Close dropdowns when clicking outside
        document.addEventListener('click', function(event) {
            const notificationMenu = document.getElementById('notificationMenu');
            const userMenu = document.getElementById('userMenu');
            
            if (notificationMenu && !event.target.closest('.notification-dropdown')) {
                notificationMenu.classList.remove('show');
            }
            
            if (userMenu && !event.target.closest('.user-dropdown')) {
                userMenu.classList.remove('show');
            }
        });

        // Notifications wiring
        const NOTIF_API = '../api/notifications.php';

        function notifIcon(type) {
            switch (type) {
                case 'booking': return 'fa-shopping-cart text-primary';
                case 'payment': return 'fa-receipt text-success';
                case 'promotion': return 'fa-tags text-purple';
                case 'emergency': return 'fa-exclamation-triangle text-danger';
                case 'system':
                default: return 'fa-bell text-gray';
            }
        }

        function timeAgo(ts) {
            const date = new Date(ts.replace(' ', 'T'));
            const seconds = Math.floor((Date.now() - date.getTime()) / 1000);
            const intervals = [
                { label: 'year', secs: 31536000 },
                { label: 'month', secs: 2592000 },
                { label: 'day', secs: 86400 },
                { label: 'hour', secs: 3600 },
                { label: 'minute', secs: 60 }
            ];
            for (const it of intervals) {
                const count = Math.floor(seconds / it.secs);
                if (count >= 1) return `${count} ${it.label}${count>1?'s':''} ago`;
            }
            return 'just now';
        }

        async function fetchNotifications(limit = 10) {
            try {
                const res = await fetch(`${NOTIF_API}?action=list&limit=${limit}`, { credentials: 'include' });
                const json = await res.json();
                if (!json.success) throw new Error(json.message || 'Failed to load notifications');
                renderNotifications(json.data.items || []);
                updateBadge(json.data.unread_count || 0);
            } catch (e) {
                console.error('Notifications error:', e);
            }
        }

        function renderNotifications(items) {
            const list = document.getElementById('notificationList');
            if (!list) return;
            if (!items.length) {
                list.innerHTML = '<div class="text-center" style="padding: 12px; color: #6b7280;">No notifications</div>';
                return;
            }
            list.innerHTML = items.map(n => `
                <div class="notification-item ${n.is_read ? '' : 'unread'}" data-id="${n.id}">
                    <i class="fas ${notifIcon(n.type)}"></i>
                    <div>
                        <p>${escapeHtml(n.title || '')}</p>
                        <small>${timeAgo(n.created_at)}</small>
                    </div>
                </div>
            `).join('');
        }

        function updateBadge(count) {
            const badge = document.getElementById('notificationBadge');
            if (!badge) return;
            if (count > 0) {
                badge.textContent = count;
                badge.style.display = 'inline-block';
            } else {
                badge.textContent = '0';
                badge.style.display = 'none';
            }
        }

        async function markAllRead() {
            try {
                const res = await fetch(`${NOTIF_API}?action=mark_all_read`, { method: 'POST', credentials: 'include' });
                const json = await res.json();
                if (!json.success) throw new Error(json.message || 'Failed to mark as read');
                updateBadge(0);
                // Refresh list after marking read
                fetchNotifications();
            } catch (e) {
                console.error('Mark all read error:', e);
            }
        }

        function escapeHtml(str) {
            return String(str).replace(/[&<>"]+/g, s => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[s]));
        }

        // Attach handlers and start polling
        document.addEventListener('DOMContentLoaded', () => {
            const markBtn = document.getElementById('markAllReadBtn');
            if (markBtn) {
                markBtn.addEventListener('click', (e) => {
                    e.preventDefault();
                    markAllRead();
                });
            }
            // Initial load
            fetchNotifications();
            // Poll every 30s
            setInterval(fetchNotifications, 30000);

            // Close sidebar with ESC
            document.addEventListener('keydown', (e) => {
                if (e.key === 'Escape') toggleSidebar(false);
            });

            // Ensure sidebar closes when moving to desktop
            window.addEventListener('resize', () => {
                if (window.innerWidth > 1024) document.body.classList.remove('sidebar-open');
            });
        });
    </script>
</body>
</html>
