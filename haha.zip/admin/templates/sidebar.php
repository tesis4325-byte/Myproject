<?php
require_once __DIR__ . '/../../config/Database.php';
$pdo = Database::getInstance()->getConnection();
try {
    $bookingCount = (int)$pdo->query("SELECT COUNT(*) FROM bookings")->fetchColumn();
} catch (Exception $e) {
    $bookingCount = 0;
}
try {
    $complaintsCount = (int)$pdo->query("SELECT COUNT(*) FROM complaints")->fetchColumn();
} catch (Exception $e) {
    $complaintsCount = 0;
}
try {
    $activeRiders = (int)$pdo->query("SELECT COUNT(*) FROM riders WHERE is_online = 1")->fetchColumn();
} catch (Exception $e) {
    $activeRiders = 0;
}
?>
<aside class="admin-sidebar">
    <div class="sidebar-content">
        <ul class="sidebar-menu">
            <li class="menu-item <?php echo (basename($_SERVER['PHP_SELF']) == 'dashboard.php') ? 'active' : ''; ?>">
                <a href="dashboard.php">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="menu-item <?php echo (basename($_SERVER['PHP_SELF']) == 'bookings.php') ? 'active' : ''; ?>">
                <a href="bookings.php">
                    <i class="fas fa-shopping-cart"></i>
                    <span>Orders & Bookings</span>
                    <?php if (!empty($bookingCount)) { ?>
                        <span class="badge badge-primary"><?php echo $bookingCount; ?></span>
                    <?php } ?>
                </a>
            </li>
            <li class="menu-item <?php echo (basename($_SERVER['PHP_SELF']) == 'customers.php') ? 'active' : ''; ?>">
                <a href="customers.php">
                    <i class="fas fa-users"></i>
                    <span>Customers</span>
                </a>
            </li>
            <li class="menu-item <?php echo (basename($_SERVER['PHP_SELF']) == 'riders.php') ? 'active' : ''; ?>">
                <a href="riders.php">
                    <i class="fas fa-motorcycle"></i>
                    <span>Riders</span>
                </a>
            </li>
            <li class="menu-item <?php echo (basename($_SERVER['PHP_SELF']) == 'merchants.php') ? 'active' : ''; ?>">
                <a href="merchants.php">
                    <i class="fas fa-store"></i>
                    <span>Merchants</span>
                </a>
            </li>
            <li class="menu-item <?php echo (basename($_SERVER['PHP_SELF']) == 'menus.php') ? 'active' : ''; ?>">
                <a href="menus.php">
                    <i class="fas fa-utensils"></i>
                    <span>Menu Management</span>
                </a>
            </li>
            <li class="menu-item <?php echo (basename($_SERVER['PHP_SELF']) == 'reports.php') ? 'active' : ''; ?>">
                <a href="reports.php">
                    <i class="fas fa-chart-bar"></i>
                    <span>Reports & Analytics</span>
                </a>
            </li>
            <li class="menu-item <?php echo (basename($_SERVER['PHP_SELF']) == 'promotions.php') ? 'active' : ''; ?>">
                <a href="promotions.php">
                    <i class="fas fa-tags"></i>
                    <span>Promotions</span>
                </a>
            </li>
            <li class="menu-item <?php echo (basename($_SERVER['PHP_SELF']) == 'complaints.php') ? 'active' : ''; ?>">
                <a href="complaints.php">
                    <i class="fas fa-exclamation-triangle"></i>
                    <span>Complaints</span>
                    <?php if (!empty($complaintsCount)) { ?>
                        <span class="badge badge-warning"><?php echo $complaintsCount; ?></span>
                    <?php } ?>
                </a>
            </li>
            <li class="menu-item <?php echo (basename($_SERVER['PHP_SELF']) == 'system.php') ? 'active' : ''; ?>">
                <a href="system.php">
                    <i class="fas fa-cogs"></i>
                    <span>System Settings</span>
                </a>
            </li>
        </ul>
        
        <div class="sidebar-footer">
            <div class="system-status">
                <div class="status-item">
                    <span class="status-dot online"></span>
                    <span>System Online</span>
                </div>
                <div class="status-item">
                    <span class="status-dot"></span>
                    <span><?php echo $activeRiders; ?> Riders Active</span>
                </div>
            </div>
        </div>
    </div>
</aside>
