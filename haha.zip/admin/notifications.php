<?php
$pageTitle = 'Notifications';
include 'templates/header.php';
?>

<div class="dashboard-header">
    <div class="header-content">
        <div>
            <h1>Notifications</h1>
            <p>Latest system notifications</p>
        </div>
        <div class="header-actions">
            <button class="btn btn-primary" id="markAllRead"><i class="fas fa-check-double"></i> Mark all as read</button>
        </div>
    </div>
</div>

<div class="dashboard-card">
    <div class="card-header">
        <h3>Recent Notifications</h3>
    </div>
    <div class="card-body">
        <div class="status-list" id="notificationsList">
            <!-- Filled by script -->
        </div>
    </div>
</div>

<script>
// Simple client-side list for now. Later, wire this to an API endpoint.
const sampleNotifications = [
  { id: 1, icon: 'fa-shopping-cart text-primary', title: 'New order received', time: '2 minutes ago', unread: true },
  { id: 2, icon: 'fa-exclamation-triangle text-warning', title: 'Rider complaint filed', time: '15 minutes ago', unread: true },
  { id: 3, icon: 'fa-user-plus text-success', title: 'New rider registered', time: '1 hour ago', unread: false }
];

function renderNotifications(items) {
  const container = document.getElementById('notificationsList');
  if (!items.length) {
    container.innerHTML = '<div class="text-center">No notifications</div>';
    return;
  }
  container.innerHTML = items.map(n => `
    <div class="notification-item ${n.unread ? 'unread' : ''}">
      <i class="fas ${n.icon}"></i>
      <div>
        <p>${n.title}</p>
        <small>${n.time}</small>
      </div>
    </div>
  `).join('');
}

renderNotifications(sampleNotifications);

document.getElementById('markAllRead').addEventListener('click', () => {
  sampleNotifications.forEach(n => n.unread = false);
  renderNotifications(sampleNotifications);
});
</script>

<?php include 'templates/footer.php'; ?>
