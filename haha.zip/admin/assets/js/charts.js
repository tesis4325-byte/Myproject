// Charts Manager for Admin Dashboard
class ChartsManager {
    constructor() {
        this.charts = {};
        this.colors = {
            primary: '#0EA5E9',
            secondary: '#1E3A8A',
            success: '#10B981',
            warning: '#F59E0B',
            error: '#EF4444',
            info: '#3B82F6',
            gray: '#6B7280'
        };
        this.init();
    }

    init() {
        this.setupChartDefaults();
    }

    setupChartDefaults() {
        if (typeof Chart !== 'undefined') {
            Chart.defaults.font.family = 'Inter, sans-serif';
            Chart.defaults.color = this.colors.gray;
            Chart.defaults.plugins.legend.display = true;
            Chart.defaults.plugins.legend.position = 'bottom';
            Chart.defaults.responsive = true;
            Chart.defaults.maintainAspectRatio = false;
        }
    }

    createOrderTrendsChart(canvasId, data = null) {
        const ctx = document.getElementById(canvasId);
        if (!ctx) return null;

        const defaultData = {
            labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
            datasets: [{
                label: 'Orders',
                data: [12, 19, 15, 25, 22, 18, 30],
                borderColor: this.colors.primary,
                backgroundColor: this.colors.primary + '20',
                tension: 0.4,
                fill: true
            }]
        };

        this.charts[canvasId] = new Chart(ctx, {
            type: 'line',
            data: data || defaultData,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        mode: 'index',
                        intersect: false,
                        backgroundColor: 'rgba(0, 0, 0, 0.8)',
                        titleColor: 'white',
                        bodyColor: 'white',
                        borderColor: this.colors.primary,
                        borderWidth: 1
                    }
                },
                scales: {
                    x: {
                        grid: {
                            display: false
                        }
                    },
                    y: {
                        beginAtZero: true,
                        grid: {
                            color: 'rgba(0, 0, 0, 0.1)'
                        }
                    }
                },
                interaction: {
                    mode: 'nearest',
                    axis: 'x',
                    intersect: false
                }
            }
        });

        return this.charts[canvasId];
    }

    createRevenueChart(canvasId, data = null) {
        const ctx = document.getElementById(canvasId);
        if (!ctx) return null;

        const defaultData = {
            labels: ['Week 1', 'Week 2', 'Week 3', 'Week 4'],
            datasets: [{
                label: 'Revenue',
                data: [15000, 22000, 18000, 28000],
                backgroundColor: [
                    this.colors.success,
                    this.colors.success,
                    this.colors.success,
                    this.colors.success
                ],
                borderColor: this.colors.success,
                borderWidth: 1
            }]
        };

        this.charts[canvasId] = new Chart(ctx, {
            type: 'bar',
            data: data || defaultData,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        backgroundColor: 'rgba(0, 0, 0, 0.8)',
                        titleColor: 'white',
                        bodyColor: 'white',
                        callbacks: {
                            label: function(context) {
                                return 'Revenue: ₱' + context.parsed.y.toLocaleString();
                            }
                        }
                    }
                },
                scales: {
                    x: {
                        grid: {
                            display: false
                        }
                    },
                    y: {
                        beginAtZero: true,
                        grid: {
                            color: 'rgba(0, 0, 0, 0.1)'
                        },
                        ticks: {
                            callback: function(value) {
                                return '₱' + value.toLocaleString();
                            }
                        }
                    }
                }
            }
        });

        return this.charts[canvasId];
    }

    createServiceDistributionChart(canvasId, data = null) {
        const ctx = document.getElementById(canvasId);
        if (!ctx) return null;

        const defaultData = {
            labels: ['Food Delivery', 'Pickup & Deliver', 'Bill Payment', 'Custom Request'],
            datasets: [{
                data: [45, 30, 15, 10],
                backgroundColor: [
                    this.colors.primary,
                    this.colors.success,
                    this.colors.warning,
                    this.colors.info
                ],
                borderWidth: 2,
                borderColor: 'white'
            }]
        };

        this.charts[canvasId] = new Chart(ctx, {
            type: 'doughnut',
            data: data || defaultData,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            padding: 20,
                            usePointStyle: true
                        }
                    },
                    tooltip: {
                        backgroundColor: 'rgba(0, 0, 0, 0.8)',
                        titleColor: 'white',
                        bodyColor: 'white',
                        callbacks: {
                            label: function(context) {
                                const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                const percentage = ((context.parsed / total) * 100).toFixed(1);
                                return context.label + ': ' + percentage + '%';
                            }
                        }
                    }
                },
                cutout: '60%'
            }
        });

        return this.charts[canvasId];
    }

    createRiderPerformanceChart(canvasId, data = null) {
        const ctx = document.getElementById(canvasId);
        if (!ctx) return null;

        const defaultData = {
            labels: ['John Doe', 'Jane Smith', 'Mike Johnson', 'Sarah Wilson', 'Tom Brown'],
            datasets: [{
                label: 'Deliveries',
                data: [85, 72, 68, 59, 45],
                backgroundColor: this.colors.primary,
                borderColor: this.colors.primary,
                borderWidth: 1
            }]
        };

        this.charts[canvasId] = new Chart(ctx, {
            type: 'horizontalBar',
            data: data || defaultData,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                indexAxis: 'y',
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        backgroundColor: 'rgba(0, 0, 0, 0.8)',
                        titleColor: 'white',
                        bodyColor: 'white'
                    }
                },
                scales: {
                    x: {
                        beginAtZero: true,
                        grid: {
                            color: 'rgba(0, 0, 0, 0.1)'
                        }
                    },
                    y: {
                        grid: {
                            display: false
                        }
                    }
                }
            }
        });

        return this.charts[canvasId];
    }

    createSalesComparisonChart(canvasId, data = null) {
        const ctx = document.getElementById(canvasId);
        if (!ctx) return null;

        const defaultData = {
            labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
            datasets: [{
                label: 'This Year',
                data: [120000, 135000, 148000, 162000, 175000, 188000],
                borderColor: this.colors.primary,
                backgroundColor: this.colors.primary + '20',
                tension: 0.4
            }, {
                label: 'Last Year',
                data: [98000, 112000, 125000, 138000, 151000, 164000],
                borderColor: this.colors.gray,
                backgroundColor: this.colors.gray + '20',
                tension: 0.4
            }]
        };

        this.charts[canvasId] = new Chart(ctx, {
            type: 'line',
            data: data || defaultData,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'top'
                    },
                    tooltip: {
                        mode: 'index',
                        intersect: false,
                        backgroundColor: 'rgba(0, 0, 0, 0.8)',
                        titleColor: 'white',
                        bodyColor: 'white',
                        callbacks: {
                            label: function(context) {
                                return context.dataset.label + ': ₱' + context.parsed.y.toLocaleString();
                            }
                        }
                    }
                },
                scales: {
                    x: {
                        grid: {
                            display: false
                        }
                    },
                    y: {
                        beginAtZero: true,
                        grid: {
                            color: 'rgba(0, 0, 0, 0.1)'
                        },
                        ticks: {
                            callback: function(value) {
                                return '₱' + (value / 1000) + 'K';
                            }
                        }
                    }
                },
                interaction: {
                    mode: 'nearest',
                    axis: 'x',
                    intersect: false
                }
            }
        });

        return this.charts[canvasId];
    }

    createComplaintTrendsChart(canvasId, data = null) {
        const ctx = document.getElementById(canvasId);
        if (!ctx) return null;

        const defaultData = {
            labels: ['Week 1', 'Week 2', 'Week 3', 'Week 4'],
            datasets: [{
                label: 'New Complaints',
                data: [12, 8, 15, 6],
                backgroundColor: this.colors.error,
                borderColor: this.colors.error,
                borderWidth: 1
            }, {
                label: 'Resolved',
                data: [10, 12, 11, 14],
                backgroundColor: this.colors.success,
                borderColor: this.colors.success,
                borderWidth: 1
            }]
        };

        this.charts[canvasId] = new Chart(ctx, {
            type: 'bar',
            data: data || defaultData,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'top'
                    },
                    tooltip: {
                        backgroundColor: 'rgba(0, 0, 0, 0.8)',
                        titleColor: 'white',
                        bodyColor: 'white'
                    }
                },
                scales: {
                    x: {
                        grid: {
                            display: false
                        }
                    },
                    y: {
                        beginAtZero: true,
                        grid: {
                            color: 'rgba(0, 0, 0, 0.1)'
                        }
                    }
                }
            }
        });

        return this.charts[canvasId];
    }

    updateChart(chartId, newData) {
        if (this.charts[chartId]) {
            this.charts[chartId].data = newData;
            this.charts[chartId].update();
        }
    }

    updateChartData(chartId, datasetIndex, newData) {
        if (this.charts[chartId] && this.charts[chartId].data.datasets[datasetIndex]) {
            this.charts[chartId].data.datasets[datasetIndex].data = newData;
            this.charts[chartId].update();
        }
    }

    addDataPoint(chartId, label, data) {
        if (this.charts[chartId]) {
            this.charts[chartId].data.labels.push(label);
            this.charts[chartId].data.datasets.forEach((dataset, index) => {
                dataset.data.push(data[index] || 0);
            });
            this.charts[chartId].update();
        }
    }

    removeDataPoint(chartId, index = 0) {
        if (this.charts[chartId]) {
            this.charts[chartId].data.labels.splice(index, 1);
            this.charts[chartId].data.datasets.forEach(dataset => {
                dataset.data.splice(index, 1);
            });
            this.charts[chartId].update();
        }
    }

    destroyChart(chartId) {
        if (this.charts[chartId]) {
            this.charts[chartId].destroy();
            delete this.charts[chartId];
        }
    }

    destroyAllCharts() {
        Object.keys(this.charts).forEach(chartId => {
            this.destroyChart(chartId);
        });
    }

    resizeCharts() {
        Object.values(this.charts).forEach(chart => {
            chart.resize();
        });
    }

    // Utility methods for data formatting
    formatChartData(rawData, type = 'line') {
        switch (type) {
            case 'line':
                return {
                    labels: rawData.map(item => item.label || item.date),
                    datasets: [{
                        label: 'Value',
                        data: rawData.map(item => item.value || item.count),
                        borderColor: this.colors.primary,
                        backgroundColor: this.colors.primary + '20',
                        tension: 0.4
                    }]
                };
            case 'bar':
                return {
                    labels: rawData.map(item => item.label || item.name),
                    datasets: [{
                        label: 'Value',
                        data: rawData.map(item => item.value || item.count),
                        backgroundColor: this.colors.primary,
                        borderColor: this.colors.primary,
                        borderWidth: 1
                    }]
                };
            case 'doughnut':
                return {
                    labels: rawData.map(item => item.label || item.name),
                    datasets: [{
                        data: rawData.map(item => item.value || item.count),
                        backgroundColor: [
                            this.colors.primary,
                            this.colors.success,
                            this.colors.warning,
                            this.colors.info,
                            this.colors.error
                        ].slice(0, rawData.length)
                    }]
                };
            default:
                return rawData;
        }
    }

    // Animation helpers
    animateChart(chartId, duration = 1000) {
        if (this.charts[chartId]) {
            this.charts[chartId].update('active', {
                duration: duration,
                easing: 'easeInOutQuart'
            });
        }
    }

    // Export chart as image
    exportChart(chartId, filename = 'chart.png') {
        if (this.charts[chartId]) {
            const canvas = this.charts[chartId].canvas;
            const link = document.createElement('a');
            link.download = filename;
            link.href = canvas.toDataURL();
            link.click();
        }
    }

    // Real-time data updates
    startRealTimeUpdates(chartId, updateFunction, interval = 30000) {
        if (this.charts[chartId]) {
            const intervalId = setInterval(async () => {
                try {
                    const newData = await updateFunction();
                    this.updateChart(chartId, newData);
                } catch (error) {
                    console.error('Real-time update error:', error);
                }
            }, interval);

            // Store interval ID for cleanup
            this.charts[chartId]._updateInterval = intervalId;
        }
    }

    stopRealTimeUpdates(chartId) {
        if (this.charts[chartId] && this.charts[chartId]._updateInterval) {
            clearInterval(this.charts[chartId]._updateInterval);
            delete this.charts[chartId]._updateInterval;
        }
    }
}

// Global charts manager instance
let chartsManager;

// Initialize charts manager when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    chartsManager = new ChartsManager();
    
    // Auto-initialize charts based on canvas elements
    const chartCanvases = document.querySelectorAll('canvas[data-chart-type]');
    chartCanvases.forEach(canvas => {
        const chartType = canvas.getAttribute('data-chart-type');
        const chartId = canvas.id;
        
        switch (chartType) {
            case 'order-trends':
                chartsManager.createOrderTrendsChart(chartId);
                break;
            case 'revenue':
                chartsManager.createRevenueChart(chartId);
                break;
            case 'service-distribution':
                chartsManager.createServiceDistributionChart(chartId);
                break;
            case 'rider-performance':
                chartsManager.createRiderPerformanceChart(chartId);
                break;
            case 'sales-comparison':
                chartsManager.createSalesComparisonChart(chartId);
                break;
            case 'complaint-trends':
                chartsManager.createComplaintTrendsChart(chartId);
                break;
        }
    });
});

// Handle window resize
window.addEventListener('resize', function() {
    if (chartsManager) {
        chartsManager.resizeCharts();
    }
});

// Cleanup on page unload
window.addEventListener('beforeunload', function() {
    if (chartsManager) {
        chartsManager.destroyAllCharts();
    }
});

// Export for use in other scripts
if (typeof module !== 'undefined' && module.exports) {
    module.exports = ChartsManager;
}
