// Admin Dashboard JavaScript
class AdminManager {
    constructor() {
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.initializeComponents();
    }

    setupEventListeners() {
        // Global click handler for dropdowns
        document.addEventListener('click', this.handleGlobalClick.bind(this));
        
        // Form submission handlers
        document.addEventListener('submit', this.handleFormSubmit.bind(this));
        
        // Modal handlers
        document.addEventListener('click', this.handleModalActions.bind(this));
        
        // Search functionality
        this.setupSearchHandlers();
        
        // Filter handlers
        this.setupFilterHandlers();
    }

    handleGlobalClick(event) {
        // Close dropdowns when clicking outside
        // Generic dropdowns (if any) using .dropdown/.dropdown-menu structure
        document.querySelectorAll('.dropdown-menu').forEach(menu => {
            const container = menu.closest('.dropdown');
            if (!container || !container.contains(event.target)) {
                menu.classList.remove('show');
            }
        });

        // Notification dropdown respects .notification-dropdown container
        const notificationMenu = document.getElementById('notificationMenu');
        if (notificationMenu && !event.target.closest('.notification-dropdown')) {
            notificationMenu.classList.remove('show');
        }

        // User dropdown respects .user-dropdown container
        const userMenu = document.getElementById('userMenu');
        if (userMenu && !event.target.closest('.user-dropdown')) {
            userMenu.classList.remove('show');
        }
    }

    handleFormSubmit(event) {
        const form = event.target;
        if (form.classList.contains('ajax-form')) {
            event.preventDefault();
            this.submitAjaxForm(form);
        }
    }

    async submitAjaxForm(form) {
        const formData = new FormData(form);
        const action = form.getAttribute('data-action');
        const method = form.getAttribute('method') || 'POST';

        try {
            this.showLoading('Processing...');
            
            const response = await fetch(action, {
                method: method,
                body: formData
            });

            const result = await response.json();
            
            if (result.success) {
                this.showSuccess(result.message || 'Operation completed successfully');
                if (result.redirect) {
                    setTimeout(() => {
                        window.location.href = result.redirect;
                    }, 1500);
                }
                if (result.reload) {
                    setTimeout(() => {
                        window.location.reload();
                    }, 1500);
                }
            } else {
                this.showError(result.message || 'Operation failed');
            }
        } catch (error) {
            console.error('Form submission error:', error);
            this.showError('Network error occurred');
        }
    }

    handleModalActions(event) {
        const target = event.target;
        
        if (target.matches('[data-modal]')) {
            event.preventDefault();
            const modalId = target.getAttribute('data-modal');
            this.showModal(modalId);
        }
        
        if (target.matches('.modal-close, .modal-backdrop')) {
            this.hideModal();
        }
    }

    showModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.add('show');
            document.body.style.overflow = 'hidden';
        }
    }

    hideModal() {
        const modals = document.querySelectorAll('.modal.show');
        modals.forEach(modal => {
            modal.classList.remove('show');
        });
        document.body.style.overflow = '';
    }

    setupSearchHandlers() {
        const searchInputs = document.querySelectorAll('.search-input');
        searchInputs.forEach(input => {
            let timeout;
            input.addEventListener('input', (e) => {
                clearTimeout(timeout);
                timeout = setTimeout(() => {
                    this.performSearch(e.target);
                }, 300);
            });
        });
    }

    async performSearch(input) {
        const query = input.value.trim();
        const searchType = input.getAttribute('data-search-type');
        const resultsContainer = document.getElementById(input.getAttribute('data-results'));

        if (query.length < 2) {
            if (resultsContainer) {
                resultsContainer.innerHTML = '';
            }
            return;
        }

        try {
            const response = await fetch(`../api/${searchType}.php?action=search&q=${encodeURIComponent(query)}`);
            const result = await response.json();

            if (result.success && resultsContainer) {
                this.displaySearchResults(resultsContainer, result.data, searchType);
            }
        } catch (error) {
            console.error('Search error:', error);
        }
    }

    displaySearchResults(container, results, type) {
        if (results.length === 0) {
            container.innerHTML = '<div class="search-no-results">No results found</div>';
            return;
        }

        const html = results.map(item => {
            switch (type) {
                case 'customers':
                    return `
                        <div class="search-result-item" data-id="${item.id}">
                            <div class="result-info">
                                <h4>${item.name}</h4>
                                <p>${item.phone} • ${item.email || 'No email'}</p>
                            </div>
                            <div class="result-actions">
                                <button class="btn btn-sm btn-primary" onclick="viewCustomer(${item.id})">View</button>
                            </div>
                        </div>
                    `;
                case 'riders':
                    return `
                        <div class="search-result-item" data-id="${item.id}">
                            <div class="result-info">
                                <h4>${item.name}</h4>
                                <p>${item.phone} • Status: ${item.status}</p>
                            </div>
                            <div class="result-actions">
                                <button class="btn btn-sm btn-primary" onclick="viewRider(${item.id})">View</button>
                            </div>
                        </div>
                    `;
                case 'merchants':
                    return `
                        <div class="search-result-item" data-id="${item.id}">
                            <div class="result-info">
                                <h4>${item.name}</h4>
                                <p>${item.category} • ${item.address}</p>
                            </div>
                            <div class="result-actions">
                                <button class="btn btn-sm btn-primary" onclick="viewMerchant(${item.id})">View</button>
                            </div>
                        </div>
                    `;
                default:
                    return `
                        <div class="search-result-item" data-id="${item.id}">
                            <div class="result-info">
                                <h4>${item.name || item.title}</h4>
                                <p>${item.description || item.details}</p>
                            </div>
                        </div>
                    `;
            }
        }).join('');

        container.innerHTML = html;
    }

    setupFilterHandlers() {
        const filterSelects = document.querySelectorAll('.filter-select');
        filterSelects.forEach(select => {
            select.addEventListener('change', (e) => {
                this.applyFilters();
            });
        });

        const filterButtons = document.querySelectorAll('.filter-btn');
        filterButtons.forEach(button => {
            button.addEventListener('click', (e) => {
                e.preventDefault();
                button.classList.toggle('active');
                this.applyFilters();
            });
        });
    }

    applyFilters() {
        const filters = {};
        
        // Collect filter values
        document.querySelectorAll('.filter-select').forEach(select => {
            if (select.value) {
                filters[select.name] = select.value;
            }
        });

        document.querySelectorAll('.filter-btn.active').forEach(button => {
            const filterName = button.getAttribute('data-filter');
            const filterValue = button.getAttribute('data-value');
            if (filterName && filterValue) {
                filters[filterName] = filterValue;
            }
        });

        // Apply filters to current page
        this.loadFilteredData(filters);
    }

    async loadFilteredData(filters) {
        const currentPage = this.getCurrentPageType();
        const tableContainer = document.querySelector('.data-table-container');
        
        if (!tableContainer) return;

        try {
            this.showTableLoading(tableContainer);
            
            const queryString = new URLSearchParams(filters).toString();
            const response = await fetch(`../api/${currentPage}.php?action=list&${queryString}`);
            const result = await response.json();

            if (result.success) {
                this.updateTable(tableContainer, result.data);
            }
        } catch (error) {
            console.error('Filter error:', error);
            this.showError('Failed to apply filters');
        }
    }

    getCurrentPageType() {
        const path = window.location.pathname;
        if (path.includes('customers')) return 'customers';
        if (path.includes('riders')) return 'riders';
        if (path.includes('merchants')) return 'merchants';
        if (path.includes('bookings')) return 'bookings';
        if (path.includes('complaints')) return 'complaints';
        return 'bookings'; // default
    }

    showTableLoading(container) {
        const tbody = container.querySelector('tbody');
        if (tbody) {
            tbody.innerHTML = '<tr><td colspan="100%" class="text-center">Loading...</td></tr>';
        }
    }

    updateTable(container, data) {
        const tbody = container.querySelector('tbody');
        if (!tbody || !data.length) {
            if (tbody) {
                tbody.innerHTML = '<tr><td colspan="100%" class="text-center">No data found</td></tr>';
            }
            return;
        }

        // This would need to be customized based on the specific table structure
        // For now, just reload the page to show updated data
        window.location.reload();
    }

    initializeComponents() {
        // Initialize tooltips
        this.initializeTooltips();
        
        // Initialize data tables
        this.initializeDataTables();
        
        // Initialize charts if present
        if (typeof Chart !== 'undefined') {
            this.initializeCharts();
        }
        
        // Initialize date pickers
        this.initializeDatePickers();
    }

    initializeTooltips() {
        const tooltipElements = document.querySelectorAll('[data-tooltip]');
        tooltipElements.forEach(element => {
            element.addEventListener('mouseenter', this.showTooltip.bind(this));
            element.addEventListener('mouseleave', this.hideTooltip.bind(this));
        });
    }

    showTooltip(event) {
        const element = event.target;
        const text = element.getAttribute('data-tooltip');
        
        const tooltip = document.createElement('div');
        tooltip.className = 'tooltip';
        tooltip.textContent = text;
        document.body.appendChild(tooltip);
        
        const rect = element.getBoundingClientRect();
        tooltip.style.left = rect.left + (rect.width / 2) - (tooltip.offsetWidth / 2) + 'px';
        tooltip.style.top = rect.top - tooltip.offsetHeight - 5 + 'px';
        
        element._tooltip = tooltip;
    }

    hideTooltip(event) {
        const element = event.target;
        if (element._tooltip) {
            document.body.removeChild(element._tooltip);
            element._tooltip = null;
        }
    }

    initializeDataTables() {
        const tables = document.querySelectorAll('.data-table');
        tables.forEach(table => {
            this.enhanceTable(table);
        });
    }

    enhanceTable(table) {
        // Add sorting functionality
        const headers = table.querySelectorAll('th[data-sort]');
        headers.forEach(header => {
            header.style.cursor = 'pointer';
            header.addEventListener('click', () => {
                this.sortTable(table, header);
            });
        });

        // Add row selection
        const checkboxes = table.querySelectorAll('input[type="checkbox"]');
        checkboxes.forEach(checkbox => {
            checkbox.addEventListener('change', () => {
                this.updateSelectionCount();
            });
        });
    }

    sortTable(table, header) {
        const column = header.getAttribute('data-sort');
        const tbody = table.querySelector('tbody');
        const rows = Array.from(tbody.querySelectorAll('tr'));
        
        const isAscending = !header.classList.contains('sort-asc');
        
        // Remove sort classes from all headers
        table.querySelectorAll('th').forEach(th => {
            th.classList.remove('sort-asc', 'sort-desc');
        });
        
        // Add sort class to current header
        header.classList.add(isAscending ? 'sort-asc' : 'sort-desc');
        
        rows.sort((a, b) => {
            const aValue = a.querySelector(`[data-value="${column}"]`)?.textContent || '';
            const bValue = b.querySelector(`[data-value="${column}"]`)?.textContent || '';
            
            if (isAscending) {
                return aValue.localeCompare(bValue);
            } else {
                return bValue.localeCompare(aValue);
            }
        });
        
        rows.forEach(row => tbody.appendChild(row));
    }

    updateSelectionCount() {
        const checkboxes = document.querySelectorAll('.data-table input[type="checkbox"]:checked');
        const count = checkboxes.length;
        const selectionInfo = document.querySelector('.selection-info');
        
        if (selectionInfo) {
            if (count > 0) {
                selectionInfo.textContent = `${count} item(s) selected`;
                selectionInfo.style.display = 'block';
            } else {
                selectionInfo.style.display = 'none';
            }
        }
        
        // Show/hide bulk action buttons
        const bulkActions = document.querySelector('.bulk-actions');
        if (bulkActions) {
            bulkActions.style.display = count > 0 ? 'flex' : 'none';
        }
    }

    initializeDatePickers() {
        const dateInputs = document.querySelectorAll('input[type="date"]');
        dateInputs.forEach(input => {
            // Add any date picker enhancements here
            input.addEventListener('change', (e) => {
                // Validate date ranges if needed
                this.validateDateRange(e.target);
            });
        });
    }

    validateDateRange(input) {
        const startDate = document.querySelector('input[name="start_date"]');
        const endDate = document.querySelector('input[name="end_date"]');
        
        if (startDate && endDate && startDate.value && endDate.value) {
            if (new Date(startDate.value) > new Date(endDate.value)) {
                this.showWarning('Start date cannot be later than end date');
                input.value = '';
            }
        }
    }

    // Charts are handled by dedicated dashboard/charts scripts. Keep this as a no-op to avoid runtime errors
    initializeCharts() {
        // Intentionally left blank. Dashboard charts are initialized in `admin/dashboard.php` and `admin/assets/js/charts.js`.
    }

    // Notification methods
    showSuccess(message, title = 'Success') {
        Swal.fire({
            icon: 'success',
            title: title,
            text: message,
            timer: 3000,
            showConfirmButton: false
        });
    }

    showError(message, title = 'Error') {
        Swal.fire({
            icon: 'error',
            title: title,
            text: message
        });
    }

    showWarning(message, title = 'Warning') {
        Swal.fire({
            icon: 'warning',
            title: title,
            text: message
        });
    }

    showLoading(message = 'Loading...') {
        Swal.fire({
            title: message,
            allowOutsideClick: false,
            didOpen: () => {
                Swal.showLoading();
            }
        });
    }

    async showConfirm(message, title = 'Confirm Action') {
        const result = await Swal.fire({
            icon: 'question',
            title: title,
            text: message,
            showCancelButton: true,
            confirmButtonText: 'Yes, proceed',
            cancelButtonText: 'Cancel'
        });
        
        return result.isConfirmed;
    }

    // Utility methods
    formatCurrency(amount) {
        return new Intl.NumberFormat('en-PH', {
            style: 'currency',
            currency: 'PHP'
        }).format(amount);
    }

    formatDate(date) {
        return new Intl.DateTimeFormat('en-PH', {
            year: 'numeric',
            month: 'short',
            day: 'numeric'
        }).format(new Date(date));
    }

    formatDateTime(date) {
        return new Intl.DateTimeFormat('en-PH', {
            year: 'numeric',
            month: 'short',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        }).format(new Date(date));
    }

    debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }
}

// Global functions for common actions
async function deleteItem(type, id, name = '') {
    const admin = window.adminManager;
    const confirmed = await admin.showConfirm(
        `Are you sure you want to delete ${name ? `"${name}"` : 'this item'}? This action cannot be undone.`,
        'Delete Confirmation'
    );
    
    if (!confirmed) return;
    
    try {
        admin.showLoading('Deleting...');
        
        const response = await fetch(`../api/${type}.php?action=delete&id=${id}`, {
            method: 'DELETE'
        });
        
        const result = await response.json();
        
        if (result.success) {
            admin.showSuccess(result.message || 'Item deleted successfully');
            setTimeout(() => {
                window.location.reload();
            }, 1500);
        } else {
            admin.showError(result.message || 'Failed to delete item');
        }
    } catch (error) {
        console.error('Delete error:', error);
        admin.showError('Network error occurred');
    }
}

async function toggleStatus(type, id, currentStatus) {
    const admin = window.adminManager;
    const newStatus = currentStatus === 'active' ? 'inactive' : 'active';
    
    const confirmed = await admin.showConfirm(
        `Are you sure you want to ${newStatus === 'active' ? 'activate' : 'deactivate'} this item?`,
        'Status Change'
    );
    
    if (!confirmed) return;
    
    try {
        admin.showLoading('Updating status...');
        
        const response = await fetch(`../api/${type}.php?action=toggle_status&id=${id}`, {
            method: 'POST'
        });
        
        const result = await response.json();
        
        if (result.success) {
            admin.showSuccess(result.message || 'Status updated successfully');
            setTimeout(() => {
                window.location.reload();
            }, 1500);
        } else {
            admin.showError(result.message || 'Failed to update status');
        }
    } catch (error) {
        console.error('Status update error:', error);
        admin.showError('Network error occurred');
    }
}

// Initialize admin manager when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    window.adminManager = new AdminManager();
});

// Export for use in other scripts
if (typeof module !== 'undefined' && module.exports) {
    module.exports = AdminManager;
}
