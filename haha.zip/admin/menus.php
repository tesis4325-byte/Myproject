<?php
$pageTitle = 'Menu Management';
include 'templates/header.php';
?>

<!-- Page Header -->
<div class="dashboard-header">
    <div class="header-content">
        <div>
            <h1>Menu Management</h1>
            <p>Manage menu categories and items for all merchants</p>
        </div>
        <div class="header-actions">
            <button class="btn btn-secondary" onclick="exportMenus()">
                <i class="fas fa-download"></i> Export
            </button>
            <button class="btn btn-primary" onclick="addMenuItem()">
                <i class="fas fa-plus"></i> Add Item
            </button>
        </div>
    </div>
</div>

<!-- Menu Stats -->
<div class="stats-grid">
    <div class="stat-card primary">
        <div class="stat-icon">
            <i class="fas fa-utensils"></i>
        </div>
        <div class="stat-content">
            <h3 id="totalItems">0</h3>
            <p>Total Items</p>
        </div>
    </div>
    <div class="stat-card success">
        <div class="stat-icon">
            <i class="fas fa-check-circle"></i>
        </div>
        <div class="stat-content">
            <h3 id="availableItems">0</h3>
            <p>Available Items</p>
        </div>
    </div>
    <div class="stat-card warning">
        <div class="stat-icon">
            <i class="fas fa-tags"></i>
        </div>
        <div class="stat-content">
            <h3 id="totalCategories">0</h3>
            <p>Categories</p>
        </div>
    </div>
    <div class="stat-card info">
        <div class="stat-icon">
            <i class="fas fa-peso-sign"></i>
        </div>
        <div class="stat-content">
            <h3 id="avgPrice">₱0</h3>
            <p>Average Price</p>
        </div>
    </div>
</div>

<!-- Filters and Search -->
<div class="dashboard-card">
    <div class="card-header">
        <h3>Filter & Search</h3>
        <div class="card-actions">
            <button class="btn btn-sm btn-secondary" onclick="clearFilters()">Clear Filters</button>
        </div>
    </div>
    <div class="card-body">
        <div class="filters-grid">
            <div class="filter-group">
                <label class="form-label">Search</label>
                <input type="text" class="form-control search-input" placeholder="Search menu items...">
            </div>
            <div class="filter-group">
                <label class="form-label">Merchant</label>
                <select class="form-control filter-select" name="merchant_id" id="merchantFilter">
                    <option value="">All Merchants</option>
                    <!-- Options loaded dynamically -->
                </select>
            </div>
            <div class="filter-group">
                <label class="form-label">Category</label>
                <select class="form-control filter-select" name="category_id" id="categoryFilter">
                    <option value="">All Categories</option>
                    <!-- Options loaded dynamically -->
                </select>
            </div>
            <div class="filter-group">
                <label class="form-label">Status</label>
                <select class="form-control filter-select" name="status">
                    <option value="">All Status</option>
                    <option value="available">Available</option>
                    <option value="unavailable">Unavailable</option>
                </select>
            </div>
            <div class="filter-group">
                <label class="form-label">Price Range</label>
                <div class="price-range">
                    <input type="number" class="form-control" name="min_price" placeholder="Min">
                    <span>to</span>
                    <input type="number" class="form-control" name="max_price" placeholder="Max">
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Menu Items Table -->
<div class="dashboard-card">
    <div class="card-header">
        <h3>Menu Items</h3>
        <div class="card-actions">
            <div class="bulk-actions" style="display: none;">
                <button class="btn btn-sm btn-success" onclick="bulkSetAvailable()">
                    <i class="fas fa-check"></i> Set Available
                </button>
                <button class="btn btn-sm btn-warning" onclick="bulkSetUnavailable()">
                    <i class="fas fa-times"></i> Set Unavailable
                </button>
                <button class="btn btn-sm btn-danger" onclick="bulkDelete()">
                    <i class="fas fa-trash"></i> Delete
                </button>
            </div>
        </div>
    </div>
    <div class="card-body">
        <div class="selection-info" style="display: none;"></div>
        <div class="table-responsive data-table-container" id="menu-items-table">
            <table class="table data-table">
                <thead>
                    <tr>
                        <th><input type="checkbox" id="selectAll" onchange="toggleSelectAll()"></th>
                        <th>Item</th>
                        <th>Merchant</th>
                        <th>Category</th>
                        <th>Price</th>
                        <th>Status</th>
                        <th>Orders</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody id="menuItemsTableBody">
                    <tr>
                        <td colspan="8" class="text-center">Loading menu items...</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
class MenusManager {
    constructor() {
        this.selectedItems = new Set();
        this.itemsById = new Map();
        this.init();
    }

    async init() {
        await this.loadInitialData();
        this.setupEventListeners();
        this.loadMenuItems();
    }

    async loadInitialData() {
        try {
            // Load stats
            const statsResponse = await fetch('../api/menus.php?action=stats');
            const statsResult = await statsResponse.json();
            if (statsResult.success) {
                this.updateStats(statsResult.data);
            }

            // Load merchants for filter
            const merchantsResponse = await fetch('../api/merchants.php?action=list&status=active');
            const merchantsResult = await merchantsResponse.json();
            if (merchantsResult.success) {
                this.populateMerchantFilter(merchantsResult.data.merchants || []);
            }

            // Load categories for filter (all by default)
            const categoriesResponse = await fetch('../api/menus.php?action=categories');
            const categoriesResult = await categoriesResponse.json();
            if (categoriesResult.success) {
                this.populateCategoryFilter(categoriesResult.data || []);
            }

            // If a merchant is already selected, reload categories specific to that merchant
            const merchantFilter = document.getElementById('merchantFilter');
            const categoryFilter = document.getElementById('categoryFilter');
            if (merchantFilter && merchantFilter.value) {
                try {
                    const url = `../api/menus.php?action=categories&merchant_id=${encodeURIComponent(merchantFilter.value)}`;
                    const res = await fetch(url);
                    const json = await res.json();
                    if (json && json.success) {
                        // Reset options keeping the placeholder
                        categoryFilter.innerHTML = '<option value="">All Categories</option>';
                        (json.data || []).forEach(cat => {
                            const opt = document.createElement('option');
                            opt.value = cat.id;
                            opt.textContent = cat.name;
                            categoryFilter.appendChild(opt);
                        });
                    }
                } catch (e) {
                    console.error('Init category load failed:', e);
                }
            }
        } catch (error) {
            console.error('Error loading initial data:', error);
        }
    }

    updateStats(stats) {
        document.getElementById('totalItems').textContent = stats.total_items || 0;
        document.getElementById('availableItems').textContent = stats.available_items || 0;
        document.getElementById('totalCategories').textContent = stats.total_categories || 0;
        const avgNum = Number(stats.avg_price ?? 0);
        document.getElementById('avgPrice').textContent = '₱' + avgNum.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    }

    populateMerchantFilter(merchants) {
        const select = document.getElementById('merchantFilter');
        merchants.forEach(merchant => {
            const option = document.createElement('option');
            option.value = merchant.id;
            option.textContent = merchant.name;
            select.appendChild(option);
        });
    }

    populateCategoryFilter(categories) {
        const select = document.getElementById('categoryFilter');
        categories.forEach(category => {
            const option = document.createElement('option');
            option.value = category.id;
            option.textContent = category.name;
            select.appendChild(option);
        });
    }

    setupEventListeners() {
        document.querySelectorAll('.filter-select, input[name="min_price"], input[name="max_price"]').forEach(element => {
            element.addEventListener('change', () => {
                this.loadMenuItems();
            });
        });

        // When merchant filter changes, reload category options for that merchant
        const merchantFilter = document.getElementById('merchantFilter');
        const categoryFilter = document.getElementById('categoryFilter');
        if (merchantFilter && categoryFilter) {
            merchantFilter.addEventListener('change', async () => {
                const merchantId = merchantFilter.value;
                categoryFilter.innerHTML = '<option value="">All Categories</option>';
                try {
                    const url = merchantId ? `../api/menus.php?action=categories&merchant_id=${encodeURIComponent(merchantId)}` : `../api/menus.php?action=categories`;
                    const res = await fetch(url);
                    const json = await res.json();
                    if (json && json.success) {
                        const categories = json.data || [];
                        categories.forEach(cat => {
                            const opt = document.createElement('option');
                            opt.value = cat.id;
                            opt.textContent = cat.name;
                            categoryFilter.appendChild(opt);
                        });
                    }
                } catch (e) {
                    console.error('Failed to reload categories:', e);
                }
                // Trigger reload with new filter set
                this.loadMenuItems();
            });
        }

        const searchInput = document.querySelector('.search-input');
        if (searchInput) {
            let timeout;
            searchInput.addEventListener('input', (e) => {
                clearTimeout(timeout);
                timeout = setTimeout(() => {
                    this.loadMenuItems();
                }, 300);
            });
        }
    }

    async loadMenuItems() {
        try {
            const filters = this.getFilters();
            const queryString = new URLSearchParams(filters).toString();

            const response = await fetch(`../api/menus.php?action=list&${queryString}`);
            const result = await response.json();

            if (result.success) {
                this.displayMenuItems(result.data.items || []);
            } else {
                this.showError(result.message || 'Failed to load menu items');
            }
        } catch (error) {
            console.error('Error loading menu items:', error);
            this.showError('Network error occurred');
        }
    }

    getFilters() {
        const filters = {};
        
        const searchInput = document.querySelector('.search-input');
        if (searchInput && searchInput.value.trim()) {
            filters.search = searchInput.value.trim();
        }

        document.querySelectorAll('.filter-select').forEach(select => {
            if (select.value) {
                filters[select.name] = select.value;
            }
        });

        const minPrice = document.querySelector('input[name="min_price"]').value;
        const maxPrice = document.querySelector('input[name="max_price"]').value;
        if (minPrice) filters.min_price = minPrice;
        if (maxPrice) filters.max_price = maxPrice;

        return filters;
    }

    displayMenuItems(items) {
        const tbody = document.getElementById('menuItemsTableBody');
        
        if (items.length === 0) {
            tbody.innerHTML = '<tr><td colspan="8" class="text-center">No menu items found</td></tr>';
            return;
        }

        // cache items for view/edit
        this.itemsById.clear();
        items.forEach(it => this.itemsById.set(it.id, it));

        const toImgSrc = (path) => {
            if (!path) return '../assets/images/default-food.png';
            // Absolute path
            if (path.startsWith('/')) return path;
            // Ensure admin-relative path works
            return `../${path}`;
        };

        tbody.innerHTML = items.map(item => `
            <tr data-item-id="${item.id}">
                <td>
                    <input type="checkbox" class="item-checkbox" value="${item.id}" onchange="toggleItemSelection(${item.id})">
                </td>
                <td>
                    <div class="menu-item-info">
                        <div class="item-image">
                            <img src="${toImgSrc(item.image)}" alt="${item.name}">
                        </div>
                        <div class="item-details">
                            <strong>${item.name}</strong>
                            <br><small class="text-muted">${item.description || 'No description'}</small>
                        </div>
                    </div>
                </td>
                <td>
                    <div class="merchant-info">
                        <strong>${item.merchant_name}</strong>
                    </div>
                </td>
                <td>
                    <span class="badge badge-secondary">${item.category_name}</span>
                </td>
                <td>
                    <strong>₱${Number(item.price).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</strong>
                </td>
                <td>
                    <span class="badge badge-${this.getStatusColor(item.status)}">${item.status}</span>
                </td>
                <td>
                    <div class="order-stats">
                        <strong>${item.total_orders || 0}</strong> orders
                        <br><small class="text-muted">This month: ${item.monthly_orders || 0}</small>
                    </div>
                </td>
                <td>
                    <div class="action-buttons">
                        <button class="btn btn-sm btn-primary" onclick="viewMenuItem(${item.id})">
                            <i class="fas fa-eye"></i>
                        </button>
                        <button class="btn btn-sm btn-warning" onclick="editMenuItem(${item.id})">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button class="btn btn-sm ${item.status === 'available' ? 'btn-secondary' : 'btn-success'}" 
                                onclick="toggleItemStatus(${item.id}, '${item.status === 'available' ? 'unavailable' : 'available'}')">
                            <i class="fas fa-${item.status === 'available' ? 'times' : 'check'}"></i>
                        </button>
                        <button class="btn btn-sm btn-danger" onclick="deleteMenuItem(${item.id})">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </td>
            </tr>
        `).join('');
    }

    getStatusColor(status) {
        const colors = {
            'available': 'success',
            'unavailable': 'secondary'
        };
        return colors[status] || 'secondary';
    }

    showError(message) {
        if (window.adminManager) {
            window.adminManager.showError(message);
        } else {
            alert(message);
        }
    }

    showSuccess(message) {
        if (window.adminManager) {
            window.adminManager.showSuccess(message);
        } else {
            alert(message);
        }
    }
}

let menusManager;

document.addEventListener('DOMContentLoaded', function() {
    menusManager = new MenusManager();
});

function toggleSelectAll() {
    const selectAll = document.getElementById('selectAll');
    const checkboxes = document.querySelectorAll('.item-checkbox');
    
    checkboxes.forEach(checkbox => {
        checkbox.checked = selectAll.checked;
        const itemId = parseInt(checkbox.value);
        if (selectAll.checked) {
            menusManager.selectedItems.add(itemId);
        } else {
            menusManager.selectedItems.delete(itemId);
        }
    });
    
    updateBulkActions();
}

function toggleItemSelection(itemId) {
    const checkbox = document.querySelector(`input[value="${itemId}"]`);
    if (checkbox.checked) {
        menusManager.selectedItems.add(itemId);
    } else {
        menusManager.selectedItems.delete(itemId);
    }
    
    updateBulkActions();
}

function updateBulkActions() {
    const count = menusManager.selectedItems.size;
    const bulkActions = document.querySelector('.bulk-actions');
    const selectionInfo = document.querySelector('.selection-info');
    
    if (count > 0) {
        bulkActions.style.display = 'flex';
        selectionInfo.style.display = 'block';
        selectionInfo.textContent = `${count} item(s) selected`;
    } else {
        bulkActions.style.display = 'none';
        selectionInfo.style.display = 'none';
    }
}

function viewMenuItem(itemId) {
    const item = menusManager.itemsById.get(itemId);
    if (!item) { return menusManager.showError('Item not found'); }
    const formatPeso = (n) => '₱' + Number(n || 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    Swal.fire({
        title: item.name,
        html: `
            <div class="menu-item-info" style="margin-bottom:10px">
                <div class="item-image"><img src="${(function(){
                    const p=item.image; if(!p) return '../assets/images/default-food.png'; return p.startsWith('/')?p:`../${p}`;})()}" style="width:80px;height:80px;object-fit:cover;border-radius:8px"></div>
                <div class="item-details">
                    <strong>${item.name}</strong><br>
                    <small class="text-muted">${item.merchant_name} • ${item.category_name||'Uncategorized'}</small>
                </div>
            </div>
            <p>${item.description || 'No description'}</p>
            <p><strong>Price:</strong> ${formatPeso(item.price)}<br>
               <strong>Status:</strong> ${item.status}</p>
        `,
        showConfirmButton: true
    });
}

function addMenuItem() {
    // Build select options from already-loaded filters for convenience
    const merchantOptions = Array.from(document.querySelectorAll('#merchantFilter option'))
        .filter(opt => opt.value !== '')
        .map(opt => `<option value="${opt.value}">${opt.textContent}</option>`)
        .join('');

    Swal.fire({
        title: 'Add Menu Item',
        html: `
            <div class="form-grid">
                <div class="form-group">
                    <label class="form-label">Merchant</label>
                    <select id="swal-merchant" class="form-control">${merchantOptions}</select>
                </div>
                <div class="form-group">
                    <label class="form-label">Category</label>
                    <div style="display:flex; gap:0.5rem; align-items:center;">
                        <select id="swal-category" class="form-control"><option value="">Loading...</option></select>
                        <button id="seed-cats" type="button" class="btn btn-sm btn-secondary" title="Add common categories">Add defaults</button>
                    </div>
                    <small class="text-muted">If empty, click Add defaults to create common categories (Drinks, Rice Meals, etc.).</small>
                </div>
                <div class="form-group">
                    <label class="form-label">Name</label>
                    <input id="swal-name" class="form-control" placeholder="Item name">
                </div>
                <div class="form-group">
                    <label class="form-label">Description</label>
                    <textarea id="swal-description" class="form-control" rows="3" placeholder="Short description (optional)"></textarea>
                </div>
                <div class="form-group">
                    <label class="form-label">Price (₱)</label>
                    <input id="swal-price" type="number" min="0" step="0.01" class="form-control" placeholder="0.00">
                </div>
                <div class="form-group">
                    <label class="form-label">Preparation Time (mins)</label>
                    <input id="swal-prep" type="number" min="0" step="1" class="form-control" placeholder="e.g. 15">
                </div>
                <div class="form-group">
                    <label class="form-label">Image</label>
                    <input id="swal-image" type="file" accept="image/*" class="form-control">
                    <small class="text-muted">Max 5MB. Optional.</small>
                </div>
            </div>
        `,
        focusConfirm: false,
        didOpen: async () => {
            const merchSel = document.getElementById('swal-merchant');
            const catSel = document.getElementById('swal-category');
            async function loadCats(merchantId) {
                catSel.innerHTML = '<option value="">Loading...</option>';
                try {
                    const res = await fetch(`../api/menus.php?action=categories&merchant_id=${encodeURIComponent(merchantId)}`);
                    const json = await res.json();
                    const cats = (json && json.success) ? (json.data || []) : [];
                    if (!cats.length) {
                        catSel.innerHTML = '<option value="">Uncategorized</option>';
                    } else {
                        catSel.innerHTML = cats.map(c => `<option value="${c.id}">${c.name}</option>`).join('');
                    }
                } catch (e) {
                    catSel.innerHTML = '<option value="">Uncategorized</option>';
                }
            }
            if (merchSel && merchSel.value) { loadCats(merchSel.value); }
            merchSel?.addEventListener('change', () => loadCats(merchSel.value));

            // Seed default categories
            const seedBtn = document.getElementById('seed-cats');
            seedBtn?.addEventListener('click', async () => {
                const mid = merchSel?.value;
                if (!mid) { Swal.showValidationMessage('Please select a merchant first'); return; }
                seedBtn.disabled = true; seedBtn.textContent = 'Seeding...';
                try {
                    const res = await fetch('../api/menus.php?action=seed_default_categories', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ merchant_id: mid })
                    });
                    const json = await res.json();
                    if (!res.ok || !json.success) throw new Error(json.message || 'Failed');
                    await loadCats(mid);
                } catch (e) {
                    console.error(e);
                } finally {
                    seedBtn.disabled = false; seedBtn.textContent = 'Add defaults';
                }
            });
        },
        showCancelButton: true,
        confirmButtonText: 'Save',
        preConfirm: async () => {
            const merchant_id = document.getElementById('swal-merchant').value;
            const category_id = document.getElementById('swal-category').value;
            const name = document.getElementById('swal-name').value.trim();
            const description = document.getElementById('swal-description').value.trim();
            const priceVal = document.getElementById('swal-price').value;
            const preparation_time = document.getElementById('swal-prep').value;
            const imageFile = document.getElementById('swal-image').files[0];

            if (!merchant_id) {
                Swal.showValidationMessage('Please select a merchant');
                return false;
            }
            if (!name) {
                Swal.showValidationMessage('Name is required');
                return false;
            }
            const price = parseFloat(priceVal);
            if (isNaN(price) || price <= 0) {
                Swal.showValidationMessage('Enter a valid price');
                return false;
            }
            // Optional: 5MB client-side check
            if (imageFile && imageFile.size > 5 * 1024 * 1024) {
                Swal.showValidationMessage('Image must be 5MB or less');
                return false;
            }

            // Show loading while saving
            Swal.showLoading();

            let imagePath = '';
            if (imageFile) {
                try {
                    const fd = new FormData();
                    fd.append('menu_image', imageFile);
                    // optional: for existing item updates, we could pass menu_id
                    const upRes = await fetch('../api/uploads.php?action=menu_image', { method: 'POST', body: fd });
                    const upJson = await upRes.json();
                    if (!upRes.ok || !upJson.success) {
                        throw new Error(upJson.message || 'Upload failed');
                    }
                    imagePath = upJson.data?.path || '';
                } catch (e) {
                    Swal.showValidationMessage('Image upload error: ' + e.message);
                    return false;
                }
            }

            // Build payload for create
            const payload = {
                merchant_id: merchant_id,
                name: name,
                price: price,
                description: description || undefined,
                image: imagePath || undefined,
            };
            if (category_id) payload.category_id = parseInt(category_id);
            if (preparation_time) payload.preparation_time = parseInt(preparation_time);

            try {
                const res = await fetch('../api/menus.php?action=create', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(payload)
                });
                const json = await res.json();
                if (!res.ok || !json.success) {
                    throw new Error(json.message || 'Failed to save');
                }
                return json;
            } catch (err) {
                Swal.showValidationMessage('Save error: ' + err.message);
                return false;
            }
        }
    }).then((result) => {
        if (result.isConfirmed && result.value && result.value.success) {
            menusManager.showSuccess('Menu item created');
            menusManager.loadMenuItems();
        }
    });
}

function editMenuItem(itemId) {
    const item = menusManager.itemsById.get(itemId);
    if (!item) { return menusManager.showError('Item not found'); }
    const merchantOptions = Array.from(document.querySelectorAll('#merchantFilter option'))
        .map(opt => `<option value="${opt.value}" ${String(opt.value)===String(item.merchant_id)?'selected':''}>${opt.textContent}</option>`)
        .join('');
    const categoryOptions = Array.from(document.querySelectorAll('#categoryFilter option'))
        .map(opt => `<option value="${opt.value}" ${String(opt.value)===String(item.category_id)?'selected':''}>${opt.textContent}</option>`)
        .join('');

    Swal.fire({
        title: 'Edit Menu Item',
        html: `
            <div class="form-grid">
                <div class="form-group">
                    <label class="form-label">Merchant</label>
                    <select id="swal-merchant" class="form-control">${merchantOptions}</select>
                </div>
                <div class="form-group">
                    <label class="form-label">Category</label>
                    <select id="swal-category" class="form-control">${categoryOptions}</select>
                </div>
                <div class="form-group">
                    <label class="form-label">Name</label>
                    <input id="swal-name" class="form-control" value="${item.name||''}">
                </div>
                <div class="form-group">
                    <label class="form-label">Description</label>
                    <textarea id="swal-description" class="form-control" rows="3">${item.description||''}</textarea>
                </div>
                <div class="form-group">
                    <label class="form-label">Price (₱)</label>
                    <input id="swal-price" type="number" min="0" step="0.01" class="form-control" value="${item.price}">
                </div>
                <div class="form-group">
                    <label class="form-label">Preparation Time (mins)</label>
                    <input id="swal-prep" type="number" min="0" step="1" class="form-control" value="${item.preparation_time||''}">
                </div>
            </div>
        `,
        showCancelButton: true,
        confirmButtonText: 'Save',
        preConfirm: async () => {
            const name = document.getElementById('swal-name').value.trim();
            const priceVal = document.getElementById('swal-price').value;
            if (!name) { Swal.showValidationMessage('Name is required'); return false; }
            const price = parseFloat(priceVal);
            if (isNaN(price) || price <= 0) { Swal.showValidationMessage('Enter a valid price'); return false; }
            const payload = {
                item_id: itemId,
                name,
                description: document.getElementById('swal-description').value.trim(),
                price,
                preparation_time: document.getElementById('swal-prep').value ? parseInt(document.getElementById('swal-prep').value) : undefined,
                category_id: document.getElementById('swal-category').value ? parseInt(document.getElementById('swal-category').value) : undefined,
            };
            try {
                const res = await fetch('../api/menus.php?action=update', {
                    method: 'PUT',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(payload)
                });
                const json = await res.json();
                if (!res.ok || !json.success) throw new Error(json.message || 'Update failed');
                return json;
            } catch (e) {
                Swal.showValidationMessage(e.message);
                return false;
            }
        }
    }).then((r) => {
        if (r.isConfirmed && r.value && r.value.success) {
            menusManager.showSuccess('Menu item updated');
            menusManager.loadMenuItems();
        }
    });
}

function toggleItemStatus(itemId, newStatus) {
    const confirmed = confirm(`Set item to ${newStatus}?`);
    if (!confirmed) return;
    const isAvailable = newStatus === 'available';
    fetch('../api/menus.php?action=update_availability', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ item_id: itemId, is_available: isAvailable })
    })
    .then(r => r.json().then(j => ({ ok: r.ok, j })))
    .then(({ ok, j }) => {
        if (!ok || !j.success) throw new Error(j.message || 'Failed to update');
        menusManager.showSuccess('Status updated');
        menusManager.loadMenuItems();
    })
    .catch(err => menusManager.showError(err.message));
}

function deleteMenuItem(itemId) {
    const confirmed = confirm('Delete this menu item?');
    if (!confirmed) return;
    // Soft delete by marking unavailable (avoid DELETE method issues)
    fetch('../api/menus.php?action=update_availability', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ item_id: itemId, is_available: false })
    })
    .then(r => r.json().then(j => ({ ok: r.ok, j })))
    .then(({ ok, j }) => {
        if (!ok || !j.success) throw new Error(j.message || 'Failed to delete');
        menusManager.showSuccess('Menu item deleted');
        // Hide unavailable items so the deleted one disappears from the list
        const statusSelect = document.querySelector('select[name="status"]');
        if (statusSelect) statusSelect.value = 'available';
        menusManager.loadMenuItems();
    })
    .catch(err => menusManager.showError(err.message));
}

function clearFilters() {
    document.querySelectorAll('.filter-select').forEach(select => {
        select.value = '';
    });
    document.querySelector('input[name="min_price"]').value = '';
    document.querySelector('input[name="max_price"]').value = '';
    document.querySelector('.search-input').value = '';
    
    menusManager.loadMenuItems();
}

function exportMenus() {
    const filters = menusManager.getFilters();
    const queryString = new URLSearchParams(filters).toString();
    window.open(`../api/menus.php?action=export&${queryString}`, '_blank');
}

function bulkSetAvailable() {
    const selectedIds = Array.from(menusManager.selectedItems);
    if (selectedIds.length === 0) {
        menusManager.showError('Please select items to set available');
        return;
    }
    alert('Bulk set available - IDs: ' + selectedIds.join(', '));
}

function bulkSetUnavailable() {
    const selectedIds = Array.from(menusManager.selectedItems);
    if (selectedIds.length === 0) {
        menusManager.showError('Please select items to set unavailable');
        return;
    }
    alert('Bulk set unavailable - IDs: ' + selectedIds.join(', '));
}

function bulkDelete() {
    const selectedIds = Array.from(menusManager.selectedItems);
    if (selectedIds.length === 0) {
        menusManager.showError('Please select items to delete');
        return;
    }
    
    const confirmed = confirm(`Delete ${selectedIds.length} menu items?`);
    if (confirmed) {
        alert('Bulk delete - IDs: ' + selectedIds.join(', '));
    }
}
</script>

<style>
.dashboard-card { margin-top: 1rem; }
.card-header { display:flex; align-items:center; justify-content:space-between; padding: 0.75rem 1rem; border-bottom: 1px solid var(--gray-200); }
.card-header h3 { margin:0; font-size:1.05rem; color: var(--gray-800); }
.card-actions { display:flex; gap:0.5rem; }

/* Filters layout */
.filters-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
    gap: 1rem 1.25rem;
    padding: 1rem;
}
.filter-group { display:flex; flex-direction:column; }
.filter-group .form-label { font-weight:600; color: var(--gray-700); margin-bottom: 0.375rem; }
.form-control { width: 100%; }
.search-input { height: 36px; }
.filter-select { height: 36px; }
.price-range input.form-control { max-width: 120px; height: 36px; }
.price-range span { padding: 0 4px; }

/* Table spacing */
.data-table-container { padding: 0 1rem 1rem; }

.menu-item-info {
    display: flex;
    align-items: center;
    gap: 0.75rem;
}

.item-image {
    width: 40px;
    height: 40px;
    border-radius: 8px;
    overflow: hidden;
    flex-shrink: 0;
}

.item-image img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.item-details strong {
    color: var(--gray-800);
}

.price-range {
    display: flex;
    align-items: center;
    gap: 0.5rem;
}

.price-range span {
    color: var(--gray-600);
    font-size: 0.875rem;
}

.order-stats strong {
    color: var(--gray-800);
}
</style>

<?php include 'templates/footer.php'; ?>
