<?php
$pageTitle = 'Orders & Bookings';
include 'templates/header.php';
?>

<!-- Page Header -->
<div class="dashboard-header">
    <div class="header-content">
        <div>
            <h1>Orders & Bookings</h1>
            <p>Manage all customer orders and delivery bookings</p>
        </div>
        <div class="header-actions">
            <button class="btn btn-secondary" onclick="exportBookings()">
                <i class="fas fa-download"></i> Export
            </button>
            <button class="btn btn-primary" onclick="refreshBookings()">
                <i class="fas fa-sync-alt"></i> Refresh
            </button>
        </div>
    </div>
</div>

<!-- Filters and Search -->
<div class="dashboard-card">
    <div class="card-header">
        <h3>Filter & Search</h3>
        <div class="card-actions">
            <button class="btn btn-sm btn-secondary" onclick="clearFilters()">Clear Filters</button>
        </div>
    </div>
    <div class="card-body">
        <div class="filters-grid">
            <div class="filter-group">
                <label class="form-label">Search</label>
                <input type="text" class="form-control search-input" placeholder="Search bookings...">
            </div>
            <div class="filter-group">
                <label class="form-label">Status</label>
                <select class="form-control filter-select" name="status">
                    <option value="">All Statuses</option>
                    <option value="pending">Pending</option>
                    <option value="confirmed">Confirmed</option>
                    <option value="assigned">Assigned</option>
                    <option value="picked_up">Picked Up</option>
                    <option value="delivered">Delivered</option>
                    <option value="completed">Completed</option>
                    <option value="cancelled">Cancelled</option>
                </select>
            </div>
            <div class="filter-group">
                <label class="form-label">Service Type</label>
                <select class="form-control filter-select" name="service_type">
                    <option value="">All Services</option>
                    <option value="food_delivery">Food Delivery</option>
                    <option value="pickup_deliver">Pickup & Deliver</option>
                    <option value="bill_payment">Bill Payment</option>
                    <option value="custom_request">Custom Request</option>
                </select>
            </div>
            <div class="filter-group">
                <label class="form-label">Date Range</label>
                <div class="date-range">
                    <input type="date" class="form-control" name="start_date" id="startDate">
                    <span>to</span>
                    <input type="date" class="form-control" name="end_date" id="endDate">
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Quick Stats -->
<div class="stats-grid">
    <div class="stat-card primary">
        <div class="stat-icon">
            <i class="fas fa-clock"></i>
        </div>
        <div class="stat-content">
            <h3 id="pendingOrders">0</h3>
            <p>Pending Orders</p>
        </div>
    </div>
    <div class="stat-card warning">
        <div class="stat-icon">
            <i class="fas fa-motorcycle"></i>
        </div>
        <div class="stat-content">
            <h3 id="inTransitOrders">0</h3>
            <p>In Transit</p>
        </div>
    </div>
    <div class="stat-card success">
        <div class="stat-icon">
            <i class="fas fa-check-circle"></i>
        </div>
        <div class="stat-content">
            <h3 id="completedToday">0</h3>
            <p>Completed Today</p>
        </div>
    </div>
    <div class="stat-card info">
        <div class="stat-icon">
            <i class="fas fa-peso-sign"></i>
        </div>
        <div class="stat-content">
            <h3 id="todayRevenue">₱0</h3>
            <p>Today's Revenue</p>
        </div>
    </div>
</div>

<!-- Bookings Table -->
<div class="dashboard-card">
    <div class="card-header">
        <h3>All Bookings</h3>
        <div class="card-actions">
            <div class="bulk-actions" style="display: none;">
                <button class="btn btn-sm btn-warning" onclick="bulkAssignRider()">
                    <i class="fas fa-user-plus"></i> Assign Rider
                </button>
                <button class="btn btn-sm btn-danger" onclick="bulkCancel()">
                    <i class="fas fa-times"></i> Cancel Selected
                </button>
            </div>
        </div>
    </div>
    <div class="card-body">
        <div class="selection-info" style="display: none;"></div>
        <div class="table-responsive data-table-container" id="all-bookings-table">
            <table class="table data-table">
                <thead>
                    <tr>
                        <th><input type="checkbox" id="selectAll" onchange="toggleSelectAll()"></th>
                        <th>Booking #</th>
                        <th>Customer</th>
                        <th>Service</th>
                        <th>Amount</th>
                        <th>Status</th>
                        <th>Rider</th>
                        <th>Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody id="bookingsTableBody">
                    <tr>
                        <td colspan="9" class="text-center">Loading bookings...</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
class BookingsManager {
    constructor() {
        this.selectedBookings = new Set();
        this.init();
    }

    async init() {
        await this.loadInitialData();
        this.setupEventListeners();
        this.loadBookings();
    }

    async loadInitialData() {
        try {
            const statsResponse = await fetch('../api/bookings.php?action=stats');
            const statsData = await statsResponse.json();
            
            if (statsData.success) {
                this.updateStats(statsData.data);
            }
        } catch (error) {
            console.error('Error loading initial data:', error);
        }
    }

    updateStats(stats) {
        document.getElementById('pendingOrders').textContent = stats.pending_orders || 0;
        document.getElementById('inTransitOrders').textContent = stats.in_transit_orders || 0;
        document.getElementById('completedToday').textContent = stats.completed_today || 0;
        document.getElementById('todayRevenue').textContent = '₱' + (stats.today_revenue || 0).toLocaleString();
    }

    setupEventListeners() {
        document.querySelectorAll('.filter-select, input[name="start_date"], input[name="end_date"]').forEach(element => {
            element.addEventListener('change', () => {
                this.loadBookings();
            });
        });

        const searchInput = document.querySelector('.search-input');
        if (searchInput) {
            let timeout;
            searchInput.addEventListener('input', (e) => {
                clearTimeout(timeout);
                timeout = setTimeout(() => {
                    this.loadBookings();
                }, 300);
            });
        }
    }

    async loadBookings() {
        try {
            const filters = this.getFilters();
            const queryString = new URLSearchParams(filters).toString();

            const response = await fetch(`../api/bookings.php?action=list&${queryString}`);
            const result = await response.json();

            if (result.success) {
                this.displayBookings(result.data.bookings || []);
            } else {
                this.showError(result.message || 'Failed to load bookings');
            }
        } catch (error) {
            console.error('Error loading bookings:', error);
            this.showError('Network error occurred');
        }
    }

    getFilters() {
        const filters = {};
        
        const searchInput = document.querySelector('.search-input');
        if (searchInput && searchInput.value.trim()) {
            filters.search = searchInput.value.trim();
        }

        document.querySelectorAll('.filter-select').forEach(select => {
            if (select.value) {
                filters[select.name] = select.value;
            }
        });

        const startDate = document.getElementById('startDate').value;
        const endDate = document.getElementById('endDate').value;
        if (startDate) filters.start_date = startDate;
        if (endDate) filters.end_date = endDate;

        return filters;
    }

    displayBookings(bookings) {
        const tbody = document.getElementById('bookingsTableBody');
        
        if (bookings.length === 0) {
            tbody.innerHTML = '<tr><td colspan="9" class="text-center">No bookings found</td></tr>';
            return;
        }

        tbody.innerHTML = bookings.map(booking => `
            <tr data-booking-id="${booking.id}">
                <td>
                    <input type="checkbox" class="booking-checkbox" value="${booking.id}" onchange="toggleBookingSelection(${booking.id})">
                </td>
                <td>
                    <a href="#" onclick="viewBooking(${booking.id})" class="booking-link">
                        ${booking.booking_number}
                    </a>
                </td>
                <td>
                    <div class="customer-info">
                        <strong>${booking.customer_name}</strong>
                        <br><small>${booking.customer_phone}</small>
                    </div>
                </td>
                <td>
                    <span class="badge badge-info">${this.formatServiceType(booking.service_type)}</span>
                </td>
                <td>
                    <strong>₱${parseFloat(booking.total_amount).toLocaleString()}</strong>
                </td>
                <td>
                    <span class="badge badge-${this.getStatusColor(booking.status)}">${booking.status}</span>
                </td>
                <td>
                    ${booking.rider_name ? `
                        <div class="rider-info">
                            <strong>${booking.rider_name}</strong>
                            <br><small>${booking.rider_phone}</small>
                        </div>
                    ` : '<span class="text-muted">Not assigned</span>'}
                </td>
                <td>
                    ${this.formatDateTime(booking.created_at)}
                </td>
                <td>
                    <div class="action-buttons">
                        <button class="btn btn-sm btn-primary" onclick="viewBooking(${booking.id})">
                            <i class="fas fa-eye"></i>
                        </button>
                        ${booking.status !== 'completed' && booking.status !== 'cancelled' ? `
                            <button class="btn btn-sm btn-danger" onclick="cancelBooking(${booking.id})">
                                <i class="fas fa-times"></i>
                            </button>
                        ` : ''}
                    </div>
                </td>
            </tr>
        `).join('');
    }

    formatServiceType(type) {
        const types = {
            'food_delivery': 'Food Delivery',
            'pickup_deliver': 'Pickup & Deliver',
            'bill_payment': 'Bill Payment',
            'pay_bills': 'Bill Payment',
            'custom_request': 'Custom Request'
        };
        return types[type] || type;
    }

    getStatusColor(status) {
        const colors = {
            'pending': 'warning',
            'confirmed': 'info',
            'assigned': 'primary',
            'picked_up': 'primary',
            'delivered': 'success',
            'completed': 'success',
            'cancelled': 'danger'
        };
        return colors[status] || 'secondary';
    }

    formatDateTime(datetime) {
        const date = new Date(datetime);
        return date.toLocaleDateString('en-PH', {
            month: 'short',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    }

    showError(message) {
        if (window.Swal) {
            Swal.fire({ icon: 'error', title: 'Error', text: message || 'Something went wrong' });
        } else if (window.adminManager) {
            window.adminManager.showError(message);
        } else {
            alert(message);
        }
    }

    showSuccess(message) {
        if (window.Swal) {
            Swal.fire({ icon: 'success', title: 'Success', text: message || 'Operation completed' });
        } else if (window.adminManager) {
            window.adminManager.showSuccess(message);
        } else {
            alert(message);
        }
    }
}

let bookingsManager;

document.addEventListener('DOMContentLoaded', function() {
    bookingsManager = new BookingsManager();
});

function toggleSelectAll() {
    const selectAll = document.getElementById('selectAll');
    const checkboxes = document.querySelectorAll('.booking-checkbox');
    
    checkboxes.forEach(checkbox => {
        checkbox.checked = selectAll.checked;
        const bookingId = parseInt(checkbox.value);
        if (selectAll.checked) {
            bookingsManager.selectedBookings.add(bookingId);
        } else {
            bookingsManager.selectedBookings.delete(bookingId);
        }
    });
    
    updateBulkActions();
}

function toggleBookingSelection(bookingId) {
    const checkbox = document.querySelector(`input[value="${bookingId}"]`);
    if (checkbox.checked) {
        bookingsManager.selectedBookings.add(bookingId);
    } else {
        bookingsManager.selectedBookings.delete(bookingId);
    }
    
    updateBulkActions();
}

function updateBulkActions() {
    const count = bookingsManager.selectedBookings.size;
    const bulkActions = document.querySelector('.bulk-actions');
    const selectionInfo = document.querySelector('.selection-info');
    
    if (count > 0) {
        bulkActions.style.display = 'flex';
        selectionInfo.style.display = 'block';
        selectionInfo.textContent = `${count} booking(s) selected`;
    } else {
        bulkActions.style.display = 'none';
        selectionInfo.style.display = 'none';
    }
}

async function viewBooking(bookingId) {
    try {
        const response = await fetch(`../api/bookings.php?action=details&booking_id=${bookingId}`);
        const result = await response.json();
        
        if (result.success) {
            const b = (result.data && result.data.booking) ? result.data.booking : result.data;
            const items = (result.data && result.data.items) ? result.data.items : [];
            const serviceLabel = (bookingsManager && bookingsManager.formatServiceType) ? bookingsManager.formatServiceType(b.type || b.service_type) : (b.type || b.service_type || '');
            const amount = (b.total_amount !== undefined) ? parseFloat(b.total_amount).toLocaleString() : '0.00';
            const createdAt = b.created_at ? new Date(b.created_at).toLocaleString('en-PH') : '';

            let itemsHtml = '';
            if (items && items.length) {
                itemsHtml = '<div class="booking-items"><strong>Items</strong><ul style="margin:0; padding-left:1rem;">' + items.map(it => `<li>${(it.item_name || it.name || 'Item')} x${it.quantity || 1} - ₱${(it.total_price || it.price || 0).toLocaleString()}</li>`).join('') + '</ul></div>';
            }

            const html = `
                <div class="booking-detail-modal" style="text-align:left">
                    <div style="margin-bottom:.5rem"><strong>Service:</strong> ${serviceLabel}</div>
                    <div style="margin-bottom:.5rem"><strong>Status:</strong> <span class="badge">${b.status || ''}</span></div>
                    <div style="margin-bottom:.5rem"><strong>Amount:</strong> ₱${amount}</div>
                    <div style="margin-bottom:.5rem"><strong>Customer:</strong> ${b.customer_name || ''} <small>(${b.customer_phone || ''})</small></div>
                    ${b.pickup_address ? `<div style=\"margin-bottom:.5rem\"><strong>Pickup:</strong> ${b.pickup_address}</div>` : ''}
                    ${b.delivery_address ? `<div style=\"margin-bottom:.5rem\"><strong>Delivery:</strong> ${b.delivery_address}</div>` : ''}
                    ${b.delivery_notes ? `<div style=\"margin-bottom:.5rem\"><strong>Notes:</strong> ${b.delivery_notes}</div>` : ''}
                    ${b.rider_name ? `<div style=\"margin-bottom:.5rem\"><strong>Rider:</strong> ${b.rider_name} <small>(${b.rider_phone || ''})</small></div>` : ''}
                    <div style="margin-bottom:.5rem"><strong>Created:</strong> ${createdAt}</div>
                    ${itemsHtml}
                </div>
            `;

            if (window.Swal) {
                Swal.fire({
                    title: `Booking ${b.booking_number || ('#' + bookingId)}`,
                    html,
                    width: 700,
                    confirmButtonText: 'Close'
                });
            } else {
                alert('Booking details: ' + JSON.stringify(result.data, null, 2));
            }
        } else {
            bookingsManager.showError(result.message || 'Failed to load booking details');
        }
    } catch (error) {
        console.error('Error loading booking:', error);
        bookingsManager.showError('Network error occurred');
    }
}

async function cancelBooking(bookingId) {
    try {
        if (window.Swal) {
            const ask = await Swal.fire({
                title: 'Cancel this booking?',
                text: 'This action cannot be undone.',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Yes, cancel',
                cancelButtonText: 'No'
            });
            if (!ask.isConfirmed) return;

            await Swal.fire({
                title: 'Cancelling... ',
                allowOutsideClick: false,
                didOpen: () => { Swal.showLoading(); }
            });
        } else {
            const confirmed = confirm('Are you sure you want to cancel this booking?');
            if (!confirmed) return;
        }

        const response = await fetch(`../api/bookings.php?action=cancel&booking_id=${bookingId}`, { method: 'DELETE' });
        const result = await response.json();

        if (window.Swal) Swal.close();

        if (result.success) {
            bookingsManager.showSuccess('Booking cancelled successfully');
            bookingsManager.loadBookings();
        } else {
            bookingsManager.showError(result.message || 'Failed to cancel booking');
        }
    } catch (error) {
        console.error('Error cancelling booking:', error);
        if (window.Swal) Swal.close();
        bookingsManager.showError('Network error occurred');
    }
}

function clearFilters() {
    document.querySelectorAll('.filter-select').forEach(select => {
        select.value = '';
    });
    document.getElementById('startDate').value = '';
    document.getElementById('endDate').value = '';
    document.querySelector('.search-input').value = '';
    
    bookingsManager.loadBookings();
}

function refreshBookings() {
    bookingsManager.loadBookings();
    bookingsManager.loadInitialData();
}

function exportBookings() {
    const filters = bookingsManager.getFilters();
    const queryString = new URLSearchParams(filters).toString();
    window.open(`../api/bookings.php?action=export&${queryString}`, '_blank');
}

function bulkAssignRider() {
    const selectedIds = Array.from(bookingsManager.selectedBookings);
    if (selectedIds.length === 0) {
        bookingsManager.showError('Please select bookings to assign');
        return;
    }
    alert('Bulk assign rider feature - Selected IDs: ' + selectedIds.join(', '));
}

function bulkCancel() {
    const selectedIds = Array.from(bookingsManager.selectedBookings);
    if (selectedIds.length === 0) {
        bookingsManager.showError('Please select bookings to cancel');
        return;
    }
    
    const confirmed = confirm(`Cancel ${selectedIds.length} selected bookings?`);
    if (confirmed) {
        alert('Bulk cancel feature - Selected IDs: ' + selectedIds.join(', '));
    }
}
</script>

<style>
.filters-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 1rem;
}

.filter-group {
    display: flex;
    flex-direction: column;
}

.date-range {
    display: flex;
    align-items: center;
    gap: 0.5rem;
}

.date-range span {
    color: var(--gray-600);
    font-size: 0.875rem;
}

.booking-link {
    color: var(--primary-color);
    text-decoration: none;
    font-weight: 600;
}

.booking-link:hover {
    text-decoration: underline;
}

.customer-info strong {
    color: var(--gray-800);
}

.customer-info small {
    color: var(--gray-600);
}

.rider-info strong {
    color: var(--gray-800);
}

.rider-info small {
    color: var(--gray-600);
}

.action-buttons {
    display: flex;
    gap: 0.25rem;
}

.bulk-actions {
    display: flex;
    gap: 0.5rem;
    align-items: center;
}

.selection-info {
    padding: 0.5rem;
    background: var(--gray-100);
    border-radius: 0.375rem;
    font-size: 0.875rem;
    color: var(--gray-700);
    margin-bottom: 1rem;
}
</style>

<?php include 'templates/footer.php'; ?>
