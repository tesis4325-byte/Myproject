<?php
$pageTitle = 'Rider Management';
include 'templates/header.php';
?>

<!-- Page Header -->
<div class="dashboard-header">
    <div class="header-content">
        <div>
            <h1>Rider Management</h1>
            <p>Manage delivery riders and track their performance</p>
        </div>
        <div class="header-actions">
            <button class="btn btn-secondary" onclick="exportRiders()">
                <i class="fas fa-download"></i> Export
            </button>
            <button class="btn btn-primary" onclick="addRider()">
                <i class="fas fa-plus"></i> Add Rider
            </button>
        </div>
    </div>
</div>

<!-- Rider Stats -->
<div class="stats-grid">
    <div class="stat-card success">
        <div class="stat-icon">
            <i class="fas fa-motorcycle"></i>
        </div>
        <div class="stat-content">
            <h3 id="totalRiders">0</h3>
            <p>Total Riders</p>
        </div>
    </div>
    <div class="stat-card primary">
        <div class="stat-icon">
            <i class="fas fa-circle" style="color: #10B981;"></i>
        </div>
        <div class="stat-content">
            <h3 id="onlineRiders">0</h3>
            <p>Online Now</p>
        </div>
    </div>
    <div class="stat-card warning">
        <div class="stat-icon">
            <i class="fas fa-shipping-fast"></i>
        </div>
        <div class="stat-content">
            <h3 id="busyRiders">0</h3>
            <p>On Delivery</p>
        </div>
    </div>
    <div class="stat-card info">
        <div class="stat-icon">
            <i class="fas fa-star"></i>
        </div>
        <div class="stat-content">
            <h3 id="avgRating">0.0</h3>
            <p>Average Rating</p>
        </div>
    </div>
</div>

<!-- Filters and Search -->
<div class="dashboard-card">
    <div class="card-header">
        <h3>Filter & Search</h3>
        <div class="card-actions">
            <button class="btn btn-sm btn-secondary" onclick="clearFilters()">Clear Filters</button>
        </div>
    </div>
    <div class="card-body">
        <div class="filters-grid">
            <div class="filter-group">
                <label class="form-label">Search</label>
                <input type="text" class="form-control search-input" placeholder="Search by name, phone, vehicle...">
            </div>
            <div class="filter-group">
                <label class="form-label">Status</label>
                <select class="form-control filter-select" name="status">
                    <option value="">All Status</option>
                    <option value="online">Online</option>
                    <option value="offline">Offline</option>
                    <option value="busy">Busy</option>
                    <option value="inactive">Inactive</option>
                </select>
            </div>
            <div class="filter-group">
                <label class="form-label">Vehicle Type</label>
                <select class="form-control filter-select" name="vehicle_type">
                    <option value="">All Vehicles</option>
                    <option value="motorcycle">Motorcycle</option>
                    <option value="bicycle">Bicycle</option>
                    <option value="car">Car</option>
                    <option value="van">Van</option>
                </select>
            </div>
            <div class="filter-group">
                <label class="form-label">Rating</label>
                <select class="form-control filter-select" name="rating">
                    <option value="">All Ratings</option>
                    <option value="5">5 Stars</option>
                    <option value="4">4+ Stars</option>
                    <option value="3">3+ Stars</option>
                    <option value="2">2+ Stars</option>
                </select>
            </div>
        </div>
    </div>
</div>

<!-- Riders Table -->
<div class="dashboard-card">
    <div class="card-header">
        <h3>All Riders</h3>
        <div class="card-actions">
            <div class="bulk-actions" style="display: none;">
                <button class="btn btn-sm btn-success" onclick="bulkActivate()">
                    <i class="fas fa-check"></i> Activate
                </button>
                <button class="btn btn-sm btn-warning" onclick="bulkSuspend()">
                    <i class="fas fa-pause"></i> Suspend
                </button>
            </div>
        </div>
    </div>
    <div class="card-body">
        <div class="selection-info" style="display: none;"></div>
        <div class="table-responsive data-table-container" id="all-riders-table">
            <table class="table data-table">
                <thead>
                    <tr>
                        <th><input type="checkbox" id="selectAll" onchange="toggleSelectAll()"></th>
                        <th>Rider</th>
                        <th>Contact</th>
                        <th>Vehicle</th>
                        <th>Status</th>
                        <th>Rating</th>
                        <th>Deliveries</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody id="ridersTableBody">
                    <tr>
                        <td colspan="8" class="text-center">Loading riders...</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
class RidersManager {
    constructor() {
        this.selectedRiders = new Set();
        this.riders = [];
        this.riderMap = new Map();
        this.init();
    }

    async init() {
        await this.loadStats();
        this.setupEventListeners();
        this.loadRiders();
    }

    async loadStats() {
        try {
            const response = await fetch('../api/riders.php?action=stats');
            const result = await response.json();
            
            if (result.success) {
                this.updateStats(result.data);
            }
        } catch (error) {
            console.error('Error loading stats:', error);
        }
    }

    updateStats(stats) {
        document.getElementById('totalRiders').textContent = stats.total_riders || 0;
        document.getElementById('onlineRiders').textContent = stats.online_riders || 0;
        document.getElementById('busyRiders').textContent = stats.busy_riders || 0;
        document.getElementById('avgRating').textContent = (Number(stats.avg_rating) || 0).toFixed(1);
    }

    setupEventListeners() {
        document.querySelectorAll('.filter-select').forEach(element => {
            element.addEventListener('change', () => {
                this.loadRiders();
            });
        });

        const searchInput = document.querySelector('.search-input');
        if (searchInput) {
            let timeout;
            searchInput.addEventListener('input', (e) => {
                clearTimeout(timeout);
                timeout = setTimeout(() => {
                    this.loadRiders();
                }, 300);
            });
        }
    }

    async loadRiders() {
        try {
            const filters = this.getFilters();
            const queryString = new URLSearchParams(filters).toString();

            const response = await fetch(`../api/riders.php?action=list&${queryString}`);
            const result = await response.json();

            if (result.success) {
                this.displayRiders(result.data.riders || []);
            } else {
                this.showError(result.message || 'Failed to load riders');
            }
        } catch (error) {
            console.error('Error loading riders:', error);
            this.showError('Network error occurred');
        }
    }

    getFilters() {
        const filters = {};
        
        const searchInput = document.querySelector('.search-input');
        if (searchInput && searchInput.value.trim()) {
            filters.search = searchInput.value.trim();
        }

        document.querySelectorAll('.filter-select').forEach(select => {
            if (select.value) {
                filters[select.name] = select.value;
            }
        });

        return filters;
    }

    displayRiders(riders) {
        const tbody = document.getElementById('ridersTableBody');
        
        if (riders.length === 0) {
            tbody.innerHTML = '<tr><td colspan="8" class="text-center">No riders found</td></tr>';
            return;
        }

        // cache for quick lookup in actions
        this.riders = riders;
        this.riderMap.clear();
        riders.forEach(r => {
            const idNum = Number(r.id);
            this.riderMap.set(idNum, r);
            this.riderMap.set(String(r.id), r);
        });

        tbody.innerHTML = riders.map(rider => `
            <tr data-rider-id="${rider.id}">
                <td>
                    <input type="checkbox" class="rider-checkbox" value="${rider.id}" onchange="toggleRiderSelection(${rider.id})">
                </td>
                <td>
                    <div class="rider-info">
                        <div class="rider-avatar">
                            <img src="${rider.avatar || '../admin/assets/images/default-avatar.svg'}" alt="${rider.name}">
                            <div class="status-indicator ${rider.status}"></div>
                        </div>
                        <div class="rider-details">
                            <strong>${rider.name}</strong>
                            <br><small class="text-muted">ID: ${rider.id}</small>
                        </div>
                    </div>
                </td>
                <td>
                    <div class="contact-info">
                        <div><i class="fas fa-phone"></i> ${rider.phone}</div>
                        ${rider.email ? `<div><i class="fas fa-envelope"></i> ${rider.email}</div>` : ''}
                    </div>
                </td>
                <td>
                    <div class="vehicle-info">
                        <div class="vehicle-type">
                            <i class="fas fa-${this.getVehicleIcon(rider.vehicle_type)}"></i>
                            ${rider.vehicle_type}
                        </div>
                        ${rider.vehicle_plate ? `<small class="text-muted">${rider.vehicle_plate}</small>` : ''}
                    </div>
                </td>
                <td>
                    <span class="badge badge-${this.getStatusColor(rider.status)} status-badge">
                        <i class="fas fa-circle"></i> ${rider.status}
                    </span>
                </td>
                <td>
                    <div class="rating-display">
                        <div class="stars">
                            ${this.generateStars(Number(rider.rating) || 0)}
                        </div>
                        <small class="text-muted">${(Number(rider.rating) || 0).toFixed(1)} (${rider.total_reviews || 0})</small>
                    </div>
                </td>
                <td>
                    <div class="delivery-stats">
                        <strong>${rider.total_deliveries || 0}</strong> deliveries
                        <br><small class="text-muted">This month: ${rider.monthly_deliveries || 0}</small>
                    </div>
                </td>
                <td>
                    <div class="action-buttons">
                        <button class="btn btn-sm btn-primary" onclick="viewRider(${rider.id})">
                            <i class="fas fa-eye"></i>
                        </button>
                        <button class="btn btn-sm btn-warning" onclick="editRider(${rider.id})">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button class="btn btn-sm btn-danger" onclick="deleteRider(${rider.id})">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </td>
            </tr>
        `).join('');
    }

    getVehicleIcon(type) {
        const icons = {
            'motorcycle': 'motorcycle',
            'bicycle': 'bicycle',
            'car': 'car',
            'van': 'truck'
        };
        return icons[type] || 'motorcycle';
    }

    getStatusColor(status) {
        const colors = {
            'online': 'success',
            'offline': 'secondary',
            'busy': 'warning',
            'inactive': 'danger'
        };
        return colors[status] || 'secondary';
    }

    generateStars(rating) {
        const fullStars = Math.floor(rating);
        const hasHalfStar = rating % 1 >= 0.5;
        const emptyStars = 5 - fullStars - (hasHalfStar ? 1 : 0);
        
        let stars = '';
        
        for (let i = 0; i < fullStars; i++) {
            stars += '<i class="fas fa-star"></i>';
        }
        
        if (hasHalfStar) {
            stars += '<i class="fas fa-star-half-alt"></i>';
        }
        
        for (let i = 0; i < emptyStars; i++) {
            stars += '<i class="far fa-star"></i>';
        }
        
        return stars;
    }

    showError(message) {
        if (window.adminManager) {
            window.adminManager.showError(message);
        } else {
            alert(message);
        }
    }

    showSuccess(message) {
        if (window.adminManager) {
            window.adminManager.showSuccess(message);
        } else {
            alert(message);
        }
    }
}

let ridersManager;

document.addEventListener('DOMContentLoaded', function() {
    ridersManager = new RidersManager();
    window.ridersManager = ridersManager; // ensure global access for inline handlers
});

function toggleSelectAll() {
    const selectAll = document.getElementById('selectAll');
    const checkboxes = document.querySelectorAll('.rider-checkbox');
    
    checkboxes.forEach(checkbox => {
        checkbox.checked = selectAll.checked;
        const riderId = parseInt(checkbox.value);
        if (selectAll.checked) {
            ridersManager.selectedRiders.add(riderId);
        } else {
            ridersManager.selectedRiders.delete(riderId);
        }
    });
    
    updateBulkActions();
}

function toggleRiderSelection(riderId) {
    const checkbox = document.querySelector(`input[value="${riderId}"]`);
    if (checkbox.checked) {
        ridersManager.selectedRiders.add(riderId);
    } else {
        ridersManager.selectedRiders.delete(riderId);
    }
    
    updateBulkActions();
}

function updateBulkActions() {
    const count = ridersManager.selectedRiders.size;
    const bulkActions = document.querySelector('.bulk-actions');
    const selectionInfo = document.querySelector('.selection-info');
    
    if (count > 0) {
        bulkActions.style.display = 'flex';
        selectionInfo.style.display = 'block';
        selectionInfo.textContent = `${count} rider(s) selected`;
    } else {
        bulkActions.style.display = 'none';
        selectionInfo.style.display = 'none';
    }
}

function viewRider(riderId) {
    const rm = window.ridersManager;
    const idNum = Number(riderId);
    let r = rm?.riderMap?.get(idNum) || rm?.riderMap?.get(String(riderId));
    if (!r && Array.isArray(rm?.riders)) {
        r = rm.riders.find(x => String(x.id) === String(riderId));
    }
    if (!r) {
        if (window.adminManager) adminManager.showError('Rider not found in current list');
        else alert('Rider not found');
        return;
    }
    const html = `
        <div style="text-align:left">
            <div style="display:flex; gap:1rem; align-items:center; margin-bottom:1rem;">
                <div style="width:64px;height:64px;border-radius:50%;overflow:hidden;background:#f2f2f2">
                    <img src="${r.avatar || '../admin/assets/images/default-avatar.svg'}" alt="${r.name}" style="width:100%;height:100%;object-fit:cover;"/>
                </div>
                <div>
                    <h3 style="margin:0 0 .25rem 0">${r.name}</h3>
                    <div>
                        <span class="badge badge-${rm.getStatusColor(r.status)}">${r.status}</span>
                        <span class="badge badge-info" style="text-transform:capitalize">${r.vehicle_type}</span>
                    </div>
                    <small class="text-muted">Rider ID: ${r.id}</small>
                </div>
            </div>
            <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:1rem;">
                <div>
                    <h4 style="margin:0 0 .5rem 0">Contact</h4>
                    <div><label>Phone:</label> <span>${r.phone || ''}</span></div>
                    ${r.email ? `<div><label>Email:</label> <span>${r.email}</span></div>` : ''}
                </div>
                <div>
                    <h4 style="margin:0 0 .5rem 0">Vehicle</h4>
                    <div><label>Type:</label> <span>${r.vehicle_type || ''}</span></div>
                    ${r.vehicle_plate ? `<div><label>Plate:</label> <span>${r.vehicle_plate}</span></div>` : ''}
                </div>
                <div>
                    <h4 style="margin:0 0 .5rem 0">Performance</h4>
                    <div><label>Rating:</label> <span>${(Number(r.rating)||0).toFixed(1)} (${r.total_reviews||0})</span></div>
                    <div><label>Total Deliveries:</label> <span>${r.total_deliveries || 0}</span></div>
                    <div><label>This Month:</label> <span>${r.monthly_deliveries || 0}</span></div>
                </div>
            </div>
        </div>`;
    if (window.Swal) {
        Swal.fire({ html, width: 800, confirmButtonText: 'Close', showCloseButton: false });
    } else {
        alert(`${r.name} (ID: ${r.id})`);
    }
}

async function addRider() {
    if (!window.Swal) { alert('Add rider form (coming soon)'); return; }
    await Swal.fire({
        icon: 'info',
        title: 'Add Rider',
        text: 'Feature coming soon.'
    });
}

function editRider(riderId) {
    if (window.Swal) {
        Swal.fire({ icon: 'info', title: 'Edit Rider', text: `Feature coming soon. Rider ID: ${riderId}` });
    } else {
        alert('Edit rider - ID: ' + riderId);
    }
}

async function deleteRider(riderId) {
    if (window.Swal) {
        const ask = await Swal.fire({
            title: 'Delete this rider?',
            text: 'This action cannot be undone.',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete',
            cancelButtonText: 'No'
        });
        if (!ask.isConfirmed) return;
        await Swal.fire({ icon: 'info', title: 'Delete Rider', text: `Feature coming soon. Rider ID: ${riderId}` });
    } else {
        const confirmed = confirm('Delete this rider?');
        if (confirmed) alert('Delete rider - ID: ' + riderId);
    }
}

function clearFilters() {
    document.querySelectorAll('.filter-select').forEach(select => {
        select.value = '';
    });
    document.querySelector('.search-input').value = '';
    
    ridersManager.loadRiders();
}

function exportRiders() {
    const filters = ridersManager.getFilters();
    const queryString = new URLSearchParams(filters).toString();
    window.open(`../api/riders.php?action=export&${queryString}`, '_blank');
}

function bulkActivate() {
    const selectedIds = Array.from(ridersManager.selectedRiders);
    if (selectedIds.length === 0) {
        ridersManager.showError('Please select riders to activate');
        return;
    }
    if (window.Swal) {
        Swal.fire({ icon: 'info', title: 'Bulk Activate', text: `Feature coming soon. IDs: ${selectedIds.join(', ')}` });
    } else {
        alert('Bulk activate - IDs: ' + selectedIds.join(', '));
    }
}

function bulkSuspend() {
    const selectedIds = Array.from(ridersManager.selectedRiders);
    if (selectedIds.length === 0) {
        ridersManager.showError('Please select riders to suspend');
        return;
    }
    if (window.Swal) {
        Swal.fire({ icon: 'info', title: 'Bulk Suspend', text: `Feature coming soon. IDs: ${selectedIds.join(', ')}` });
    } else {
        alert('Bulk suspend - IDs: ' + selectedIds.join(', '));
    }
}
</script>

<style>
.dashboard-card { margin-top: 1rem; }
.card-header { display:flex; align-items:center; justify-content:space-between; padding: 0.75rem 1rem; border-bottom: 1px solid var(--gray-200); }
.card-header h3 { margin:0; font-size:1.05rem; color: var(--gray-800); }
.card-actions { display:flex; gap:0.5rem; }

/* Filters layout */
.filters-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
    gap: 1rem 1.25rem;
    padding: 1rem;
}
.filter-group { display:flex; flex-direction:column; }
.filter-group .form-label { font-weight:600; color: var(--gray-700); margin-bottom: 0.375rem; }
.form-control { width: 100%; }
.search-input { height: 36px; }
.filter-select { height: 36px; }

/* Table spacing */
.data-table-container { padding: 0 1rem 1rem; }

.rider-info {
    display: flex;
    align-items: center;
    gap: 0.75rem;
}

.rider-avatar {
    position: relative;
    width: 40px;
    height: 40px;
    border-radius: 50%;
    overflow: hidden;
    flex-shrink: 0;
}

.rider-avatar img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.status-indicator {
    position: absolute;
    bottom: 2px;
    right: 2px;
    width: 12px;
    height: 12px;
    border-radius: 50%;
    border: 2px solid white;
}

.status-indicator.online {
    background-color: #10B981;
}

.status-indicator.offline {
    background-color: #6B7280;
}

.status-indicator.busy {
    background-color: #F59E0B;
}

.status-indicator.inactive {
    background-color: #EF4444;
}

.vehicle-info {
    display: flex;
    flex-direction: column;
}

.vehicle-type {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    text-transform: capitalize;
}

.status-badge {
    display: flex;
    align-items: center;
    gap: 0.25rem;
    text-transform: capitalize;
}

.status-badge i {
    font-size: 0.5rem;
}

.rating-display .stars {
    color: #F59E0B;
    margin-bottom: 0.25rem;
}

.rating-display .stars i {
    margin-right: 0.125rem;
}

.delivery-stats strong {
    color: var(--gray-800);
}
</style>

<?php include 'templates/footer.php'; ?>
