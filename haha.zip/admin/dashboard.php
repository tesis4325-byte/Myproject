<?php
$pageTitle = 'Dashboard';
include 'templates/header.php';
?>

<!-- Dashboard Header -->
<div class="dashboard-header">
    <div class="header-content">
        <div>
            <h1>Dashboard</h1>
            <p>Welcome back, <?php echo $_SESSION['name'] ?? 'Admin'; ?>! Here's what's happening today.</p>
        </div>
        <div class="header-actions">
            <button class="btn btn-primary" onclick="refreshDashboard()">
                <i class="fas fa-sync-alt"></i> Refresh
            </button>
            <button class="btn btn-secondary" onclick="exportReport()">
                <i class="fas fa-download"></i> Export Report
            </button>
        </div>
    </div>
</div>

<!-- Stats Cards -->
<div class="stats-grid">
    <div class="stat-card primary">
        <div class="stat-icon">
            <i class="fas fa-shopping-cart"></i>
        </div>
        <div class="stat-content">
            <h3 id="totalOrders">0</h3>
            <p>Total Orders Today</p>
            <span id="orderGrowthText" class="stat-change neutral">--</span>
        </div>
    </div>
    
    <div class="stat-card success">
        <div class="stat-icon">
            <i class="fas fa-peso-sign"></i>
        </div>
        <div class="stat-content">
            <h3 id="totalRevenue">₱0</h3>
            <p>Revenue Today</p>
            <span id="revenueGrowthText" class="stat-change neutral">--</span>
        </div>
    </div>
    
    <div class="stat-card warning">
        <div class="stat-icon">
            <i class="fas fa-motorcycle"></i>
        </div>
        <div class="stat-content">
            <h3 id="activeRiders">0</h3>
            <p>Active Riders</p>
            <span id="onlineNowText" class="stat-change neutral">0 online now</span>
        </div>
    </div>
    
    <div class="stat-card info">
        <div class="stat-icon">
            <i class="fas fa-users"></i>
        </div>
        <div class="stat-content">
            <h3 id="newCustomers">0</h3>
            <p>New Customers</p>
            <span id="newCustomersSubText" class="stat-change neutral">Today</span>
        </div>
    </div>
</div>

<!-- Charts Section -->
<div class="dashboard-grid">
    <div class="dashboard-card">
        <div class="card-header">
            <h3>Order Trends</h3>
            <div class="card-actions">
                <select id="orderTrendPeriod" onchange="updateOrderTrends()">
                    <option value="7days">Last 7 Days</option>
                    <option value="30days">Last 30 Days</option>
                    <option value="3months">Last 3 Months</option>
                </select>
            </div>
        </div>
        <div class="card-body">
            <canvas id="orderTrendsChart" width="400" height="200"></canvas>
        </div>
    </div>
    
    <div class="dashboard-card">
        <div class="card-header">
            <h3>Revenue Analytics</h3>
            <div class="card-actions">
                <select id="revenuePeriod" onchange="updateRevenueChart()">
                    <option value="today">Today</option>
                    <option value="week">This Week</option>
                    <option value="month">This Month</option>
                </select>
            </div>
        </div>
        <div class="card-body">
            <canvas id="revenueChart" width="400" height="200"></canvas>
        </div>
    </div>
</div>

<div class="dashboard-grid">
    <div class="dashboard-card">
        <div class="card-header">
            <h3>Service Distribution</h3>
        </div>
        <div class="card-body">
            <canvas id="serviceChart" width="400" height="300"></canvas>
        </div>
    </div>
    
    <div class="dashboard-card">
        <div class="card-header">
            <h3>Recent Orders</h3>
            <div class="card-actions">
                <a href="bookings.php" class="btn btn-sm btn-primary">View All</a>
            </div>
        </div>
        <div class="card-body">
            <div class="table-responsive data-table-container" id="recent-orders-table">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Order ID</th>
                            <th>Customer</th>
                            <th>Service</th>
                            <th>Amount</th>
                            <th>Status</th>
                            <th>Time</th>
                        </tr>
                    </thead>
                    <tbody id="recentOrdersTable">
                        <tr>
                            <td colspan="6" class="text-center">Loading...</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Quick Actions -->
<div class="dashboard-card">
    <div class="card-header">
        <h3>Quick Actions</h3>
    </div>
    <div class="card-body">
        <div class="quick-actions">
            <button class="quick-action-btn" onclick="window.location.href='bookings.php?status=pending'">
                <i class="fas fa-clock"></i>
                <span>Pending Orders</span>
                <span class="badge" id="pendingCount">0</span>
            </button>
            <button class="quick-action-btn" onclick="window.location.href='complaints.php?status=open'">
                <i class="fas fa-exclamation-triangle"></i>
                <span>Open Complaints</span>
                <span class="badge badge-warning" id="complaintsCount">0</span>
            </button>
            <button class="quick-action-btn" onclick="window.location.href='riders.php?action=add'">
                <i class="fas fa-user-plus"></i>
                <span>Add Rider</span>
            </button>
            <button class="quick-action-btn" onclick="window.location.href='merchants.php?action=add'">
                <i class="fas fa-store"></i>
                <span>Add Merchant</span>
            </button>
            <button class="quick-action-btn" onclick="window.location.href='promotions.php?action=add'">
                <i class="fas fa-tags"></i>
                <span>Create Promotion</span>
            </button>
            <button class="quick-action-btn" onclick="window.location.href='reports.php'">
                <i class="fas fa-chart-line"></i>
                <span>Generate Report</span>
            </button>
        </div>
    </div>
</div>

<!-- System Status -->
<div class="dashboard-grid">
    <div class="dashboard-card">
        <div class="card-header">
            <h3>System Status</h3>
        </div>
        <div class="card-body">
            <div class="status-list">
                <div class="status-item">
                    <div class="status-indicator online"></div>
                    <div class="status-content">
                        <h4>API Services</h4>
                        <p>All systems operational</p>
                    </div>
                    <div class="status-value">99.9%</div>
                </div>
                <div class="status-item">
                    <div class="status-indicator online"></div>
                    <div class="status-content">
                        <h4>Payment Gateway</h4>
                        <p>Connected and processing</p>
                    </div>
                    <div class="status-value">100%</div>
                </div>
                <div class="status-item">
                    <div class="status-indicator warning"></div>
                    <div class="status-content">
                        <h4>SMS Service</h4>
                        <p>Minor delays reported</p>
                    </div>
                    <div class="status-value">95%</div>
                </div>
                <div class="status-item">
                    <div class="status-indicator online"></div>
                    <div class="status-content">
                        <h4>Map Services</h4>
                        <p>OpenStreetMap active</p>
                    </div>
                    <div class="status-value">100%</div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="dashboard-card">
        <div class="card-header">
            <h3>Top Performers</h3>
            <div class="card-actions">
                <select id="performerType" onchange="updateTopPerformers()">
                    <option value="riders">Top Riders</option>
                    <option value="merchants">Top Merchants</option>
                    <option value="customers">Top Customers</option>
                </select>
            </div>
        </div>
        <div class="card-body">
            <div id="topPerformersList">
                <div class="performer-item">
                    <div class="performer-avatar">
                        <i class="fas fa-motorcycle"></i>
                    </div>
                    <div class="performer-info">
                        <h4>Loading...</h4>
                        <p>Please wait</p>
                    </div>
                    <div class="performer-stats">
                        <span class="stat-value">-</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
class AdminDashboard {
    constructor() {
        this.charts = {};
        this.serviceDistribution = [];
        this.init();
    }

    async init() {
        await this.loadDashboardData();
        this.initializeCharts();
        this.startAutoRefresh();
        // Load top performers on first load
        updateTopPerformers();
    }

    async loadDashboardData() {
        try {
            const today = new Date().toISOString().slice(0,10);
            const response = await fetch(`../api/reports.php?action=dashboard_overview&date_from=${today}&date_to=${today}`);
            const data = await response.json();
            
            if (data.success) {
                const overview = data.data || {};
                this.updateStats(overview.overview || {});
                // Recent orders
                this.updateRecentOrders(overview.recent_orders || []);
                // Save service distribution for chart rendering
                this.serviceDistribution = overview.service_distribution || [];
                this.updateQuickActionCounts(overview);

                // If chart already exists (after first render), refresh its data
                if (this.charts.service) {
                    const svc = this.prepareServiceDistribution();
                    this.charts.service.data.labels = svc.labels;
                    this.charts.service.data.datasets[0].data = svc.values;
                    this.charts.service.update();
                }
            }
        } catch (error) {
            console.error('Error loading dashboard data:', error);
        }
    }

    updateStats(data) {
        document.getElementById('totalOrders').textContent = data.total_orders || 0;
        document.getElementById('totalRevenue').textContent = '₱' + (parseFloat(data.total_revenue || 0)).toLocaleString();
        document.getElementById('activeRiders').textContent = data.active_riders || 0;
        document.getElementById('newCustomers').textContent = data.new_customers || 0;

        // Growth texts
        const setGrowth = (elId, rate, suffix) => {
            const el = document.getElementById(elId);
            if (!el) return;
            const val = typeof rate === 'number' ? rate : parseFloat(rate || 0);
            el.classList.remove('positive', 'negative', 'neutral');
            if (val > 0) el.classList.add('positive');
            else if (val < 0) el.classList.add('negative');
            else el.classList.add('neutral');
            const sign = val > 0 ? '+' : '';
            el.textContent = `${sign}${isNaN(val) ? 0 : val}% ${suffix}`;
        };

        setGrowth('orderGrowthText', data.orders_growth_rate ?? 0, 'from yesterday');
        setGrowth('revenueGrowthText', data.revenue_growth_rate ?? 0, 'from yesterday');

        // Online riders subtext
        const onlineNow = parseInt(data.online_riders || 0, 10);
        const onlineEl = document.getElementById('onlineNowText');
        if (onlineEl) onlineEl.textContent = `${onlineNow} online now`;
    }

    updateRecentOrders(orders) {
        const tbody = document.getElementById('recentOrdersTable');
        if (orders.length === 0) {
            tbody.innerHTML = '<tr><td colspan="6" class="text-center">No recent orders</td></tr>';
            return;
        }

        tbody.innerHTML = orders.map(order => `
            <tr>
                <td><a href="bookings.php?id=${order.id}">#${order.booking_number}</a></td>
                <td>${order.customer_name}</td>
                <td><span class="badge badge-info">${order.service_type}</span></td>
                <td>₱${parseFloat(order.total_amount).toLocaleString()}</td>
                <td><span class="badge badge-${this.getStatusColor(order.status)}">${order.status}</span></td>
                <td>${this.formatTime(order.created_at)}</td>
            </tr>
        `).join('');
    }

    updateQuickActionCounts(data) {
        document.getElementById('pendingCount').textContent = data.pending_orders || 0;
        document.getElementById('complaintsCount').textContent = data.open_complaints || 0;
    }

    initializeCharts() {
        // Order Trends Chart
        const orderCtx = document.getElementById('orderTrendsChart').getContext('2d');
        this.charts.orderTrends = new Chart(orderCtx, {
            type: 'line',
            data: {
                labels: [],
                datasets: [{
                    label: 'Orders',
                    data: [],
                    borderColor: '#0EA5E9',
                    backgroundColor: 'rgba(14, 165, 233, 0.1)',
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                }
            }
        });

        // Revenue Chart
        const revenueCtx = document.getElementById('revenueChart').getContext('2d');
        this.charts.revenue = new Chart(revenueCtx, {
            type: 'bar',
            data: {
                labels: [],
                datasets: [{
                    label: 'Revenue',
                    data: [],
                    backgroundColor: '#10B981'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                }
            }
        });

        // Service Distribution Chart (from API)
        const serviceCtx = document.getElementById('serviceChart').getContext('2d');
        const svc = this.prepareServiceDistribution();
        this.charts.service = new Chart(serviceCtx, {
            type: 'doughnut',
            data: {
                labels: svc.labels,
                datasets: [{
                    data: svc.values,
                    backgroundColor: ['#0EA5E9', '#10B981', '#F59E0B', '#8B5CF6']
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false
            }
        });

        this.loadChartData();
    }

    prepareServiceDistribution() {
        if (!this.serviceDistribution || this.serviceDistribution.length === 0) {
            return {
                labels: ['Food Delivery', 'Pickup & Deliver', 'Bill Payment', 'Custom Request'],
                values: [0, 0, 0, 0]
            };
        }
        const labelMap = {
            'food_delivery': 'Food Delivery',
            'pickup_deliver': 'Pickup & Deliver',
            'pay_bills': 'Bill Payment',
            'custom_request': 'Custom Request'
        };
        const labels = [];
        const values = [];
        this.serviceDistribution.forEach(item => {
            const key = item.service_type || '';
            labels.push(labelMap[key] || key || 'Unknown');
            values.push(parseInt(item.orders || 0, 10));
        });
        return { labels, values };
    }

    async loadChartData() {
        try {
            // Respect current selectors for accuracy on first load
            const orderPeriod = document.getElementById('orderTrendPeriod').value || '7days';
            const { from: ordersFrom, to: ordersTo } = AdminDashboardHelpers.getRange(orderPeriod);
            const revenuePeriod = document.getElementById('revenuePeriod').value || 'today';
            const { from: revFrom, to: revTo, groupBy } = AdminDashboardHelpers.getRevenueRange(revenuePeriod);

            // Load order trends per selected range
            const trendsResponse = await fetch(`../api/reports.php?action=order_trends&date_from=${ordersFrom}&date_to=${ordersTo}`);
            const trendsData = await trendsResponse.json();
            
            if (trendsData.success) {
                const series = trendsData.data.order_trends || [];
                this.updateOrderTrendsChart(series);
            }

            // Load revenue data per selected range
            const revenueResponse = await fetch(`../api/reports.php?action=revenue_trends&group_by=${groupBy}&date_from=${revFrom}&date_to=${revTo}`);
            const revenueData = await revenueResponse.json();
            
            if (revenueData.success) {
                const series = revenueData.data.revenue_trends || [];
                this.updateRevenueChart(series);
            }
        } catch (error) {
            console.error('Error loading chart data:', error);
        }
    }

    updateOrderTrendsChart(data) {
        this.charts.orderTrends.data.labels = data.map(item => item.date);
        // API field is total_orders
        this.charts.orderTrends.data.datasets[0].data = data.map(item => parseInt(item.total_orders || 0, 10));
        this.charts.orderTrends.update();
    }

    updateRevenueChart(data) {
        // API returns 'period' as label for revenue_trends
        this.charts.revenue.data.labels = data.map(item => item.period);
        this.charts.revenue.data.datasets[0].data = data.map(item => parseFloat(item.total_revenue || 0));
        this.charts.revenue.update();
    }

    getStatusColor(status) {
        const colors = {
            'pending': 'warning',
            'confirmed': 'info',
            'picked_up': 'primary',
            'delivered': 'success',
            'completed': 'success',
            'cancelled': 'danger'
        };
        return colors[status] || 'secondary';
    }

    formatTime(timestamp) {
        const date = new Date(timestamp);
        return date.toLocaleTimeString('en-US', { 
            hour: '2-digit', 
            minute: '2-digit' 
        });
    }

    startAutoRefresh() {
        // Refresh dashboard data every 30 seconds
        setInterval(() => {
            this.loadDashboardData();
        }, 30000);
    }
}

// Global functions
async function refreshDashboard() {
    const dashboard = new AdminDashboard();
    Swal.fire({
        icon: 'success',
        title: 'Dashboard Refreshed',
        timer: 1500,
        showConfirmButton: false
    });
}

async function exportReport() {
    try {
        const response = await fetch('../api/reports.php?action=export_report', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ report_type: 'sales', format: 'csv' })
        });
        const result = await response.json();
        
        if (result.success) {
            window.open(result.data.download_url, '_blank');
        } else {
            Swal.fire('Error', 'Failed to export report', 'error');
        }
    } catch (error) {
        Swal.fire('Error', 'Failed to export report', 'error');
    }
}

async function updateOrderTrends() {
    const period = document.getElementById('orderTrendPeriod').value;
    const { from, to } = AdminDashboardHelpers.getRange(period);
    try {
        const res = await fetch(`../api/reports.php?action=order_trends&date_from=${from}&date_to=${to}`);
        const json = await res.json();
        if (json.success) {
            const series = json.data.order_trends || [];
            const dashboard = window.__dashboardInstance;
            if (dashboard) {
                dashboard.updateOrderTrendsChart(series);
            }
        }
    } catch (e) { console.error('Failed to update order trends', e); }
}

async function updateRevenueChart() {
    const period = document.getElementById('revenuePeriod').value;
    const { from, to, groupBy } = AdminDashboardHelpers.getRevenueRange(period);
    try {
        const res = await fetch(`../api/reports.php?action=revenue_trends&group_by=${groupBy}&date_from=${from}&date_to=${to}`);
        const json = await res.json();
        if (json.success) {
            const series = json.data.revenue_trends || [];
            const dashboard = window.__dashboardInstance;
            if (dashboard) {
                dashboard.updateRevenueChart(series);
            }
        }
    } catch (e) { console.error('Failed to update revenue chart', e); }
}

// Helpers for computing date ranges
const AdminDashboardHelpers = {
    format(d) { return d.toISOString().slice(0,10); },
    getRange(period) {
        const today = new Date();
        const to = this.format(today);
        let fromDate = new Date(today);
        switch (period) {
            case '30days':
                fromDate = new Date(today.getTime() - 29*24*60*60*1000); break;
            case '3months':
                fromDate = new Date(today.getTime() - 89*24*60*60*1000); break;
            case '7days':
            default:
                fromDate = new Date(today.getTime() - 6*24*60*60*1000);
        }
        return { from: this.format(fromDate), to };
    },
    getRevenueRange(period) {
        const today = new Date();
        const to = this.format(today);
        let fromDate = new Date(today);
        let groupBy = 'day';
        switch (period) {
            case 'week':
                fromDate = new Date(today.getTime() - 6*24*60*60*1000); break;
            case 'month':
                fromDate = new Date(today.getFullYear(), today.getMonth(), 1); break;
            case 'today':
            default:
                fromDate = new Date(today.getFullYear(), today.getMonth(), today.getDate());
        }
        return { from: this.format(fromDate), to, groupBy };
    }
};

async function updateTopPerformers() {
    const type = document.getElementById('performerType').value;
    const list = document.getElementById('topPerformersList');
    if (list) {
        list.innerHTML = `
            <div class="performer-item">
                <div class="performer-avatar"><i class="fas fa-spinner fa-spin"></i></div>
                <div class="performer-info">
                    <h4>Loading...</h4>
                    <p>Please wait</p>
                </div>
                <div class="performer-stats"><span class="stat-value">-</span></div>
            </div>`;
    }

    // Use last 30 days for meaningful ranking
    const today = new Date();
    const to = today.toISOString().slice(0,10);
    const from = new Date(today.getTime() - 29*24*60*60*1000).toISOString().slice(0,10);
    try {
        const res = await fetch(`../api/reports.php?action=top_performers&type=${encodeURIComponent(type)}&date_from=${from}&date_to=${to}&limit=5`);
        let json;
        try { json = await res.json(); } catch (_) { json = { success: false, message: `HTTP ${res.status}` }; }
        if (!res.ok || !json.success) {
            const msg = (json && json.message) ? json.message : `HTTP ${res.status}`;
            if (list) list.innerHTML = `<div class="text-center text-danger">${msg}</div>`;
            console.error('Top performers API error:', { status: res.status, body: json });
            return;
        }
        const items = json.data.items || [];
        if (!list) return;
        if (items.length === 0) {
            list.innerHTML = '<div class="text-center">No data for selected period</div>';
            return;
        }
        const currency = (n) => '₱' + Number(n || 0).toLocaleString();
        list.innerHTML = items.map(it => {
            const icon = type === 'riders' ? 'fa-motorcycle' : (type === 'merchants' ? 'fa-store' : 'fa-user');
            const metric = (it.metric_label === 'Revenue' || it.metric_label === 'Spent') ? currency(it.metric_value) : Number(it.metric_value || 0).toLocaleString();
            return `
                <div class="performer-item">
                    <div class="performer-avatar"><i class="fas ${icon}"></i></div>
                    <div class="performer-info">
                        <h4>${it.name}</h4>
                        <p>${it.subtitle || ''}</p>
                    </div>
                    <div class="performer-stats">
                        <span class="stat-value">${metric}</span>
                        <div class="stat-sub">${it.metric_label}${it.secondary ? ' • ' + it.secondary : ''}</div>
                    </div>
                </div>`;
        }).join('');
    } catch (e) {
        if (list) list.innerHTML = '<div class="text-center text-danger">Failed to load top performers</div>';
        console.error('Failed to load top performers', e);
    }
}

// Initialize dashboard
document.addEventListener('DOMContentLoaded', function() {
    const instance = new AdminDashboard();
    window.__dashboardInstance = instance;
});
</script>

<?php include 'templates/footer.php'; ?>
