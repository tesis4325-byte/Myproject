<?php
$pageTitle = 'Reports & Analytics';
include 'templates/header.php';
?>

<!-- Page Header -->
<div class="dashboard-header">
    <div class="header-content">
        <div>
            <h1>Reports & Analytics</h1>
            <p>Financial reports, sales analytics, and performance metrics</p>
        </div>
        <div class="header-actions">
            <button class="btn btn-secondary" onclick="scheduleReport()">
                <i class="fas fa-clock"></i> Schedule Report
            </button>
            <button class="btn btn-primary" onclick="generateReport()">
                <i class="fas fa-chart-bar"></i> Generate Report
            </button>
        </div>
    </div>
</div>

<!-- Report Categories -->
<div class="dashboard-card">
    <div class="card-header">
        <h3>Report Categories</h3>
    </div>
    <div class="card-body">
        <div class="report-categories">
            <div class="report-category active" data-category="sales" onclick="selectCategory('sales')">
                <div class="category-icon">
                    <i class="fas fa-chart-line"></i>
                </div>
                <div class="category-info">
                    <h4>Sales Reports</h4>
                    <p>Revenue, orders, trends</p>
                </div>
            </div>
            <div class="report-category" data-category="financial" onclick="selectCategory('financial')">
                <div class="category-icon">
                    <i class="fas fa-peso-sign"></i>
                </div>
                <div class="category-info">
                    <h4>Financial Reports</h4>
                    <p>Payouts, commissions, taxes</p>
                </div>
            </div>
            <div class="report-category" data-category="performance" onclick="selectCategory('performance')">
                <div class="category-icon">
                    <i class="fas fa-tachometer-alt"></i>
                </div>
                <div class="category-info">
                    <h4>Performance Reports</h4>
                    <p>Riders, merchants, efficiency</p>
                </div>
            </div>
            <div class="report-category" data-category="customer" onclick="selectCategory('customer')">
                <div class="category-icon">
                    <i class="fas fa-users"></i>
                </div>
                <div class="category-info">
                    <h4>Customer Reports</h4>
                    <p>Behavior, satisfaction, retention</p>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Report Filters -->
<div class="dashboard-card">
    <div class="card-header">
        <h3>Report Filters</h3>
        <div class="card-actions">
            <button class="btn btn-sm btn-secondary" onclick="clearReportFilters()">Clear Filters</button>
        </div>
    </div>
    <div class="card-body">
        <div class="filters-grid">
            <div class="filter-group">
                <label class="form-label">Report Type</label>
                <select class="form-control" id="reportType">
                    <option value="">Select Report Type</option>
                    <!-- Options loaded based on category -->
                </select>
            </div>
            <div class="filter-group">
                <label class="form-label">Date Range</label>
                <select class="form-control" id="dateRange" onchange="handleDateRangeChange()">
                    <option value="today">Today</option>
                    <option value="yesterday">Yesterday</option>
                    <option value="this_week">This Week</option>
                    <option value="last_week">Last Week</option>
                    <option value="this_month" selected>This Month</option>
                    <option value="last_month">Last Month</option>
                    <option value="this_year">This Year</option>
                    <option value="custom">Custom Range</option>
                </select>
            </div>
            <div class="filter-group custom-date-range" style="display: none;">
                <label class="form-label">Custom Date Range</label>
                <div class="date-range">
                    <input type="date" class="form-control" id="startDate">
                    <span>to</span>
                    <input type="date" class="form-control" id="endDate">
                </div>
            </div>
            <div class="filter-group">
                <label class="form-label">Format</label>
                <select class="form-control" id="reportFormat">
                    <option value="html">View Online</option>
                    <option value="pdf">PDF Download</option>
                    <option value="excel">Excel Download</option>
                    <option value="csv">CSV Download</option>
                </select>
            </div>
        </div>
    </div>
</div>

<!-- Report Content -->
<div class="dashboard-card" id="reportContent">
    <div class="card-header">
        <h3 id="reportTitle">Sales Report - This Month</h3>
        <div class="card-actions">
            <button class="btn btn-sm btn-secondary" onclick="exportReport()">
                <i class="fas fa-download"></i> Export
            </button>
            <button class="btn btn-sm btn-primary" onclick="refreshReport()">
                <i class="fas fa-sync-alt"></i> Refresh
            </button>
        </div>
    </div>
    <div class="card-body" id="reportBody">
        <!-- Sales Report Content -->
        <div class="report-section" id="salesReport">
            <div class="stats-grid">
                <div class="stat-card primary">
                    <div class="stat-icon">
                        <i class="fas fa-peso-sign"></i>
                    </div>
                    <div class="stat-content">
                        <h3 id="totalRevenue">₱0</h3>
                        <p>Total Revenue</p>
                    </div>
                </div>
                <div class="stat-card success">
                    <div class="stat-icon">
                        <i class="fas fa-shopping-cart"></i>
                    </div>
                    <div class="stat-content">
                        <h3 id="totalOrders">0</h3>
                        <p>Total Orders</p>
                    </div>
                </div>
                <div class="stat-card info">
                    <div class="stat-icon">
                        <i class="fas fa-chart-bar"></i>
                    </div>
                    <div class="stat-content">
                        <h3 id="avgOrderValue">₱0</h3>
                        <p>Avg Order Value</p>
                    </div>
                </div>
                <div class="stat-card warning">
                    <div class="stat-icon">
                        <i class="fas fa-percentage"></i>
                    </div>
                    <div class="stat-content">
                        <h3 id="growthRate">0%</h3>
                        <p>Growth Rate</p>
                    </div>
                </div>
            </div>

            <div class="charts-grid">
                <div class="chart-container">
                    <h4>Revenue Trend</h4>
                    <canvas id="revenueTrendChart" data-chart-type="sales-comparison"></canvas>
                </div>
                <div class="chart-container">
                    <h4>Service Distribution</h4>
                    <canvas id="serviceDistributionChart" data-chart-type="service-distribution"></canvas>
                </div>
            </div>

            <div class="table-section">
                <h4>Top Performing Merchants</h4>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Merchant</th>
                                <th>Orders</th>
                                <th>Revenue</th>
                                <th>Growth</th>
                            </tr>
                        </thead>
                        <tbody id="topMerchantsTable">
                            <tr>
                                <td colspan="4" class="text-center">Loading...</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Other report sections will be loaded dynamically -->
        <div class="report-section" id="financialReport" style="display: none;">
            <div class="stats-grid">
                <div class="stat-card primary">
                    <div class="stat-icon">
                        <i class="fas fa-hand-holding-usd"></i>
                    </div>
                    <div class="stat-content">
                        <h3 id="totalPayouts">₱0</h3>
                        <p>Total Payouts</p>
                    </div>
                </div>
                <div class="stat-card success">
                    <div class="stat-icon">
                        <i class="fas fa-coins"></i>
                    </div>
                    <div class="stat-content">
                        <h3 id="totalCommissions">₱0</h3>
                        <p>Total Commissions</p>
                    </div>
                </div>
                <div class="stat-card warning">
                    <div class="stat-icon">
                        <i class="fas fa-receipt"></i>
                    </div>
                    <div class="stat-content">
                        <h3 id="pendingPayouts">₱0</h3>
                        <p>Pending Payouts</p>
                    </div>
                </div>
                <div class="stat-card info">
                    <div class="stat-icon">
                        <i class="fas fa-chart-pie"></i>
                    </div>
                    <div class="stat-content">
                        <h3 id="profitMargin">0%</h3>
                        <p>Profit Margin</p>
                    </div>
                </div>
            </div>
        </div>

        <div class="report-section" id="performanceReport" style="display: none;">
            <div class="stats-grid">
                <div class="stat-card primary">
                    <div class="stat-icon">
                        <i class="fas fa-motorcycle"></i>
                    </div>
                    <div class="stat-content">
                        <h3 id="avgDeliveryTime">0 min</h3>
                        <p>Avg Delivery Time</p>
                    </div>
                </div>
                <div class="stat-card success">
                    <div class="stat-icon">
                        <i class="fas fa-check-circle"></i>
                    </div>
                    <div class="stat-content">
                        <h3 id="successRate">0%</h3>
                        <p>Success Rate</p>
                    </div>
                </div>
                <div class="stat-card warning">
                    <div class="stat-icon">
                        <i class="fas fa-star"></i>
                    </div>
                    <div class="stat-content">
                        <h3 id="avgRating">0.0</h3>
                        <p>Average Rating</p>
                    </div>
                </div>
                <div class="stat-card info">
                    <div class="stat-icon">
                        <i class="fas fa-users"></i>
                    </div>
                    <div class="stat-content">
                        <h3 id="activeRiders">0</h3>
                        <p>Active Riders</p>
                    </div>
                </div>
            </div>
        </div>

        <div class="report-section" id="customerReport" style="display: none;">
            <div class="stats-grid">
                <div class="stat-card primary">
                    <div class="stat-icon">
                        <i class="fas fa-users"></i>
                    </div>
                    <div class="stat-content">
                        <h3 id="totalCustomers">0</h3>
                        <p>Total Customers</p>
                    </div>
                </div>
                <div class="stat-card success">
                    <div class="stat-icon">
                        <i class="fas fa-user-plus"></i>
                    </div>
                    <div class="stat-content">
                        <h3 id="newCustomers">0</h3>
                        <p>New Customers</p>
                    </div>
                </div>
                <div class="stat-card warning">
                    <div class="stat-icon">
                        <i class="fas fa-redo"></i>
                    </div>
                    <div class="stat-content">
                        <h3 id="repeatRate">0%</h3>
                        <p>Repeat Rate</p>
                    </div>
                </div>
                <div class="stat-card info">
                    <div class="stat-icon">
                        <i class="fas fa-heart"></i>
                    </div>
                    <div class="stat-content">
                        <h3 id="satisfactionScore">0.0</h3>
                        <p>Satisfaction Score</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
class ReportsManager {
    constructor() {
        this.currentCategory = 'sales';
        this.reportTypes = {
            sales: [
                { value: 'daily_sales', text: 'Daily Sales Report' },
                { value: 'monthly_sales', text: 'Monthly Sales Report' },
                { value: 'service_breakdown', text: 'Service Breakdown' },
                { value: 'merchant_performance', text: 'Merchant Performance' }
            ],
            financial: [
                { value: 'payout_summary', text: 'Payout Summary' },
                { value: 'commission_report', text: 'Commission Report' },
                { value: 'tax_report', text: 'Tax Report' },
                { value: 'profit_loss', text: 'Profit & Loss' }
            ],
            performance: [
                { value: 'rider_performance', text: 'Rider Performance' },
                { value: 'delivery_metrics', text: 'Delivery Metrics' },
                { value: 'efficiency_report', text: 'Efficiency Report' },
                { value: 'quality_metrics', text: 'Quality Metrics' }
            ],
            customer: [
                { value: 'customer_behavior', text: 'Customer Behavior' },
                { value: 'satisfaction_report', text: 'Satisfaction Report' },
                { value: 'retention_analysis', text: 'Retention Analysis' },
                { value: 'demographic_report', text: 'Demographic Report' }
            ]
        };
        this.init();
    }

    init() {
        this.updateReportTypes();
        this.loadReportData();
    }

    updateReportTypes() {
        const reportTypeSelect = document.getElementById('reportType');
        const types = this.reportTypes[this.currentCategory];
        
        reportTypeSelect.innerHTML = '<option value="">Select Report Type</option>';
        types.forEach(type => {
            const option = document.createElement('option');
            option.value = type.value;
            option.textContent = type.text;
            reportTypeSelect.appendChild(option);
        });
        
        // Select first option by default
        if (types.length > 0) {
            reportTypeSelect.value = types[0].value;
        }
    }

    async loadReportData() {
        try {
            const filters = this.getReportFilters();
            const response = await fetch(`../api/reports.php?action=generate&category=${this.currentCategory}&${new URLSearchParams(filters).toString()}`);
            const result = await response.json();

            if (result.success) {
                this.displayReportData(result.data);
            } else {
                this.showError(result.message || 'Failed to load report data');
            }
        } catch (error) {
            console.error('Error loading report data:', error);
            this.showError('Network error occurred');
        }
    }

    getReportFilters() {
        const filters = {};
        
        const reportType = document.getElementById('reportType').value;
        const dateRange = document.getElementById('dateRange').value;
        
        if (reportType) filters.type = reportType;
        if (dateRange) filters.date_range = dateRange;
        
        if (dateRange === 'custom') {
            const startDate = document.getElementById('startDate').value;
            const endDate = document.getElementById('endDate').value;
            if (startDate) filters.start_date = startDate;
            if (endDate) filters.end_date = endDate;
        }
        
        return filters;
    }

    displayReportData(data) {
        // Hide all report sections
        document.querySelectorAll('.report-section').forEach(section => {
            section.style.display = 'none';
        });
        
        // Show current category section
        const currentSection = document.getElementById(`${this.currentCategory}Report`);
        if (currentSection) {
            currentSection.style.display = 'block';
        }
        
        // Update report title
        const categoryNames = {
            sales: 'Sales Report',
            financial: 'Financial Report',
            performance: 'Performance Report',
            customer: 'Customer Report'
        };
        
        const dateRange = document.getElementById('dateRange').value;
        const dateRangeText = dateRange.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase());
        
        document.getElementById('reportTitle').textContent = `${categoryNames[this.currentCategory]} - ${dateRangeText}`;
        
        // Update stats based on category
        this.updateCategoryStats(data);
    }

    updateCategoryStats(data) {
        switch (this.currentCategory) {
            case 'sales':
                if (data.stats) {
                    document.getElementById('totalRevenue').textContent = '₱' + (data.stats.total_revenue || 0).toLocaleString();
                    document.getElementById('totalOrders').textContent = data.stats.total_orders || 0;
                    document.getElementById('avgOrderValue').textContent = '₱' + (data.stats.avg_order_value || 0).toLocaleString();
                    document.getElementById('growthRate').textContent = (data.stats.growth_rate || 0) + '%';
                }
                this.updateTopMerchantsTable(data.top_merchants || []);
                break;
                
            case 'financial':
                if (data.stats) {
                    document.getElementById('totalPayouts').textContent = '₱' + (data.stats.total_payouts || 0).toLocaleString();
                    document.getElementById('totalCommissions').textContent = '₱' + (data.stats.total_commissions || 0).toLocaleString();
                    document.getElementById('pendingPayouts').textContent = '₱' + (data.stats.pending_payouts || 0).toLocaleString();
                    document.getElementById('profitMargin').textContent = (data.stats.profit_margin || 0) + '%';
                }
                break;
                
            case 'performance':
                if (data.stats) {
                    document.getElementById('avgDeliveryTime').textContent = (data.stats.avg_delivery_time || 0) + ' min';
                    document.getElementById('successRate').textContent = (data.stats.success_rate || 0) + '%';
                    document.getElementById('avgRating').textContent = (data.stats.avg_rating || 0).toFixed(1);
                    document.getElementById('activeRiders').textContent = data.stats.active_riders || 0;
                }
                break;
                
            case 'customer':
                if (data.stats) {
                    document.getElementById('totalCustomers').textContent = data.stats.total_customers || 0;
                    document.getElementById('newCustomers').textContent = data.stats.new_customers || 0;
                    document.getElementById('repeatRate').textContent = (data.stats.repeat_rate || 0) + '%';
                    document.getElementById('satisfactionScore').textContent = (data.stats.satisfaction_score || 0).toFixed(1);
                }
                break;
        }
    }

    updateTopMerchantsTable(merchants) {
        const tbody = document.getElementById('topMerchantsTable');
        
        if (merchants.length === 0) {
            tbody.innerHTML = '<tr><td colspan="4" class="text-center">No data available</td></tr>';
            return;
        }
        
        tbody.innerHTML = merchants.map(merchant => `
            <tr>
                <td><strong>${merchant.name}</strong></td>
                <td>${merchant.orders || 0}</td>
                <td>₱${parseFloat(merchant.revenue || 0).toLocaleString()}</td>
                <td>
                    <span class="badge badge-${merchant.growth >= 0 ? 'success' : 'danger'}">
                        ${merchant.growth >= 0 ? '+' : ''}${merchant.growth || 0}%
                    </span>
                </td>
            </tr>
        `).join('');
    }

    showError(message) {
        if (window.adminManager) {
            window.adminManager.showError(message);
        } else {
            alert(message);
        }
    }

    showSuccess(message) {
        if (window.adminManager) {
            window.adminManager.showSuccess(message);
        } else {
            alert(message);
        }
    }
}

let reportsManager;

document.addEventListener('DOMContentLoaded', function() {
    reportsManager = new ReportsManager();
});

function selectCategory(category) {
    // Update active category
    document.querySelectorAll('.report-category').forEach(cat => {
        cat.classList.remove('active');
    });
    document.querySelector(`[data-category="${category}"]`).classList.add('active');
    
    // Update manager
    reportsManager.currentCategory = category;
    reportsManager.updateReportTypes();
    reportsManager.loadReportData();
}

function handleDateRangeChange() {
    const dateRange = document.getElementById('dateRange').value;
    const customDateRange = document.querySelector('.custom-date-range');
    
    if (dateRange === 'custom') {
        customDateRange.style.display = 'block';
    } else {
        customDateRange.style.display = 'none';
        reportsManager.loadReportData();
    }
}

function generateReport() {
    reportsManager.loadReportData();
}

function refreshReport() {
    reportsManager.loadReportData();
}

function exportReport() {
    const format = document.getElementById('reportFormat').value;
    const filters = reportsManager.getReportFilters();
    const queryString = new URLSearchParams({
        ...filters,
        category: reportsManager.currentCategory,
        format: format
    }).toString();
    
    if (format === 'html') {
        window.open(`../api/reports.php?action=export&${queryString}`, '_blank');
    } else {
        // For PDF, Excel, CSV downloads
        const link = document.createElement('a');
        link.href = `../api/reports.php?action=export&${queryString}`;
        link.download = `${reportsManager.currentCategory}_report.${format}`;
        link.click();
    }
}

function scheduleReport() {
    alert('Schedule report feature - coming soon');
}

function clearReportFilters() {
    document.getElementById('reportType').value = '';
    document.getElementById('dateRange').value = 'this_month';
    document.getElementById('startDate').value = '';
    document.getElementById('endDate').value = '';
    document.getElementById('reportFormat').value = 'html';
    
    handleDateRangeChange();
    reportsManager.loadReportData();
}
</script>

<style>
.dashboard-card { margin-top: 1rem; }
.card-header { display:flex; align-items:center; justify-content:space-between; padding: 0.75rem 1rem; border-bottom: 1px solid var(--gray-200); }
.card-header h3 { margin:0; font-size:1.05rem; color: var(--gray-800); }
.card-actions { display:flex; gap:0.5rem; }

/* Filters layout */
.filters-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
    gap: 1rem 1.25rem;
    padding: 1rem;
}
.filter-group { display:flex; flex-direction:column; }
.filter-group .form-label { font-weight:600; color: var(--gray-700); margin-bottom: 0.375rem; }
.form-control { width: 100%; height: 36px; }
.search-input { height: 36px; }
.filter-select { height: 36px; }

/* Table spacing (if any tables below) */
.data-table-container { padding: 0 1rem 1rem; }
.report-categories {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 1rem;
}

.report-category {
    display: flex;
    align-items: center;
    gap: 1rem;
    padding: 1rem;
    border: 2px solid var(--gray-200);
    border-radius: 0.5rem;
    cursor: pointer;
    transition: all 0.3s ease;
}

.report-category:hover {
    border-color: var(--primary-color);
    background-color: var(--gray-50);
}

.report-category.active {
    border-color: var(--primary-color);
    background-color: var(--primary-color);
    color: white;
}

.category-icon {
    font-size: 1.5rem;
    color: var(--primary-color);
}

.report-category.active .category-icon {
    color: white;
}

.category-info h4 {
    margin: 0 0 0.25rem 0;
    font-size: 1rem;
}

.category-info p {
    margin: 0;
    font-size: 0.875rem;
    opacity: 0.8;
}

.charts-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
    gap: 2rem;
    margin: 2rem 0;
}

.chart-container {
    background: white;
    padding: 1rem;
    border-radius: 0.5rem;
    border: 1px solid var(--gray-200);
}

.chart-container h4 {
    margin: 0 0 1rem 0;
    color: var(--gray-800);
}

.chart-container canvas {
    max-height: 300px;
}

/* Mobile adjustments to prevent chart cut-off */
@media (max-width: 768px) {
    .charts-grid {
        grid-template-columns: 1fr;
        gap: 1rem;
        margin: 1rem 0;
    }
    .chart-container {
        padding: 0.75rem;
    }
    /* Ensure canvases scale to container width on small screens */
    .chart-container canvas {
        width: 100% !important;
        height: 260px !important;
        max-height: none;
        display: block;
    }
}

.table-section {
    margin-top: 2rem;
}

.table-section h4 {
    margin-bottom: 1rem;
    color: var(--gray-800);
}

.date-range {
    display: flex;
    align-items: center;
    gap: 0.5rem;
}

.date-range span {
    color: var(--gray-600);
    font-size: 0.875rem;
}
</style>

<?php include 'templates/footer.php'; ?>
