<?php
// Debug authentication issue
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'config/Database.php';

try {
    $db = Database::getInstance()->getConnection();
    
    echo "<h2>Database Debug</h2>";
    
    // Check if users table exists and has data
    echo "<h3>Users Table:</h3>";
    $stmt = $db->query("SELECT * FROM users");
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo "<pre>" . print_r($users, true) . "</pre>";
    
    // Test specific admin login
    echo "<h3>Admin Login Test:</h3>";
    $phone = '09123456789';
    $password = 'password123';
    
    $stmt = $db->prepare("SELECT * FROM users WHERE phone = ? AND role = 'admin' AND status = 'active'");
    $stmt->execute([$phone]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($user) {
        echo "User found: <pre>" . print_r($user, true) . "</pre>";
        
        $passwordCheck = password_verify($password, $user['password']);
        echo "Password verification: " . ($passwordCheck ? "SUCCESS" : "FAILED") . "<br>";
        
        // Test the actual hash
        echo "Stored hash: " . $user['password'] . "<br>";
        echo "Test hash: " . password_hash($password, PASSWORD_DEFAULT) . "<br>";
        
    } else {
        echo "No user found with phone $phone and role 'admin'<br>";
        
        // Check all users with this phone
        $stmt2 = $db->prepare("SELECT * FROM users WHERE phone = ?");
        $stmt2->execute([$phone]);
        $allUsers = $stmt2->fetchAll(PDO::FETCH_ASSOC);
        echo "All users with this phone: <pre>" . print_r($allUsers, true) . "</pre>";
    }
    
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}
?>
