<?php
require_once __DIR__ . '/../models/Booking.php';
require_once __DIR__ . '/../models/Customer.php';
require_once __DIR__ . '/../models/Rider.php';
require_once __DIR__ . '/../models/Merchant.php';
require_once __DIR__ . '/../config/AppConfig.php';

class BookingController {
    private $booking_model;
    private $customer_model;
    private $rider_model;
    private $merchant_model;
    
    public function __construct() {
        $this->booking_model = new Booking();
        $this->customer_model = new Customer();
        $this->rider_model = new Rider();
        $this->merchant_model = new Merchant();
    }
    
    public function createBooking($data) {
        try {
            // Create or get customer
            $customer_id = $this->customer_model->getOrCreate(
                $data['customer_phone'],
                $data['customer_name'],
                $data['customer_email'] ?? null,
                $data['delivery_address'] ?? null,
                $data['delivery_lat'] ?? null,
                $data['delivery_lng'] ?? null
            );
            
            if (!$customer_id) {
                return [
                    'success' => false,
                    'message' => 'Failed to create customer record'
                ];
            }
            
            // Calculate delivery fee if coordinates provided
            $delivery_fee = $data['delivery_fee'] ?? AppConfig::DELIVERY_FEE_BASE;
            if (isset($data['pickup_lat']) && isset($data['pickup_lng']) && 
                isset($data['delivery_lat']) && isset($data['delivery_lng'])) {
                $fee_calc = $this->booking_model->calculateDeliveryFee(
                    $data['pickup_lat'], $data['pickup_lng'],
                    $data['delivery_lat'], $data['delivery_lng']
                );
                $delivery_fee = $fee_calc['fee'];
            }
            
            // Calculate service fee
            $service_fee = 0;
            if (isset($data['merchant_id']) && $data['merchant_id']) {
                $this->merchant_model->getById($data['merchant_id']);
                $service_fee = ($data['subtotal'] ?? 0) * ($this->merchant_model->commission_rate / 100);
            }
            
            // Set booking data
            $this->booking_model->customer_id = $customer_id;
            $this->booking_model->merchant_id = $data['merchant_id'] ?? null;
            $this->booking_model->type = $data['type'];
            $this->booking_model->customer_name = $data['customer_name'];
            $this->booking_model->customer_phone = $data['customer_phone'];
            $this->booking_model->pickup_address = $data['pickup_address'] ?? null;
            $this->booking_model->pickup_lat = $data['pickup_lat'] ?? null;
            $this->booking_model->pickup_lng = $data['pickup_lng'] ?? null;
            $this->booking_model->pickup_notes = $data['pickup_notes'] ?? null;
            $this->booking_model->delivery_address = $data['delivery_address'];
            $this->booking_model->delivery_lat = $data['delivery_lat'];
            $this->booking_model->delivery_lng = $data['delivery_lng'];
            $this->booking_model->delivery_notes = $data['delivery_notes'] ?? null;
            $this->booking_model->items = json_encode($data['items'] ?? []);
            $this->booking_model->subtotal = $data['subtotal'] ?? 0;
            $this->booking_model->delivery_fee = $delivery_fee;
            $this->booking_model->service_fee = $service_fee;
            $this->booking_model->total_amount = ($data['subtotal'] ?? 0) + $delivery_fee + $service_fee;
            $this->booking_model->payment_method = $data['payment_method'] ?? 'cod';
            
            if ($this->booking_model->create()) {
                // Auto-assign rider if enabled
                $auto_assign = true; // This could be a system setting
                if ($auto_assign) {
                    $this->booking_model->autoAssignRider();
                }
                
                // Increment customer order count
                $this->customer_model->id = $customer_id;
                $this->customer_model->incrementOrderCount();
                
                return [
                    'success' => true,
                    'message' => 'Booking created successfully',
                    'booking_id' => $this->booking_model->id,
                    'booking_number' => $this->booking_model->booking_number,
                    'total_amount' => $this->booking_model->total_amount
                ];
            } else {
                return [
                    'success' => false,
                    'message' => 'Failed to create booking'
                ];
            }
        } catch (Exception $e) {
            AppConfig::logError($e->getMessage(), __FILE__, __LINE__);
            return [
                'success' => false,
                'message' => 'Booking creation failed'
            ];
        }
    }
    
    public function updateBookingStatus($booking_id, $new_status, $notes = '', $user_id = null) {
        try {
            $booking = $this->booking_model->getById($booking_id);
            if (!$booking) {
                return [
                    'success' => false,
                    'message' => 'Booking not found'
                ];
            }
            
            $this->booking_model->id = $booking_id;
            $this->booking_model->status = $booking['status'];
            $this->booking_model->rider_id = $booking['rider_id'];
            
            if ($this->booking_model->updateStatus($new_status, $notes, $user_id)) {
                return [
                    'success' => true,
                    'message' => 'Booking status updated successfully'
                ];
            } else {
                return [
                    'success' => false,
                    'message' => 'Failed to update booking status'
                ];
            }
        } catch (Exception $e) {
            AppConfig::logError($e->getMessage(), __FILE__, __LINE__);
            return [
                'success' => false,
                'message' => 'Status update failed'
            ];
        }
    }
    
    public function assignRider($booking_id, $rider_id, $user_id = null) {
        try {
            $booking = $this->booking_model->getById($booking_id);
            if (!$booking) {
                return [
                    'success' => false,
                    'message' => 'Booking not found'
                ];
            }
            
            // Check if rider is available
            $rider = $this->rider_model->getById($rider_id);
            if (!$rider || !$rider['is_online']) {
                return [
                    'success' => false,
                    'message' => 'Rider is not available'
                ];
            }
            
            $this->booking_model->id = $booking_id;
            if ($this->booking_model->assignRider($rider_id, $user_id)) {
                // Update booking status to accepted if it's pending
                if ($booking['status'] === 'pending') {
                    $this->booking_model->updateStatus('accepted', 'Rider assigned', $user_id);
                }
                
                return [
                    'success' => true,
                    'message' => 'Rider assigned successfully'
                ];
            } else {
                return [
                    'success' => false,
                    'message' => 'Failed to assign rider'
                ];
            }
        } catch (Exception $e) {
            AppConfig::logError($e->getMessage(), __FILE__, __LINE__);
            return [
                'success' => false,
                'message' => 'Rider assignment failed'
            ];
        }
    }
    
    public function getBookings($filters = []) {
        try {
            $status = $filters['status'] ?? null;
            $type = $filters['type'] ?? null;
            $rider_id = $filters['rider_id'] ?? null;
            $merchant_id = $filters['merchant_id'] ?? null;
            $limit = $filters['limit'] ?? AppConfig::PAGINATION_LIMIT;
            $offset = $filters['offset'] ?? 0;
            
            $bookings = $this->booking_model->getAll($status, $type, $rider_id, $merchant_id, $limit, $offset);
            
            return [
                'success' => true,
                'data' => $bookings
            ];
        } catch (Exception $e) {
            AppConfig::logError($e->getMessage(), __FILE__, __LINE__);
            return [
                'success' => false,
                'message' => 'Failed to retrieve bookings'
            ];
        }
    }
    
    public function getBookingDetails($booking_id) {
        try {
            $booking = $this->booking_model->getById($booking_id);
            if (!$booking) {
                return [
                    'success' => false,
                    'message' => 'Booking not found'
                ];
            }
            
            // Get status history
            $status_history = $this->booking_model->getStatusHistory($booking_id);
            
            return [
                'success' => true,
                'data' => [
                    'booking' => $booking,
                    'status_history' => $status_history
                ]
            ];
        } catch (Exception $e) {
            AppConfig::logError($e->getMessage(), __FILE__, __LINE__);
            return [
                'success' => false,
                'message' => 'Failed to retrieve booking details'
            ];
        }
    }
    
    public function getDashboardStats($days = 30) {
        try {
            $stats = $this->booking_model->getDashboardStats($days);
            $today_stats = $this->booking_model->getTodayStats();
            
            return [
                'success' => true,
                'data' => [
                    'period_stats' => $stats,
                    'today_stats' => $today_stats
                ]
            ];
        } catch (Exception $e) {
            AppConfig::logError($e->getMessage(), __FILE__, __LINE__);
            return [
                'success' => false,
                'message' => 'Failed to retrieve dashboard stats'
            ];
        }
    }
    
    public function acceptBooking($booking_id, $rider_id) {
        try {
            $booking = $this->booking_model->getById($booking_id);
            if (!$booking) {
                return [
                    'success' => false,
                    'message' => 'Booking not found'
                ];
            }
            
            if ($booking['status'] !== 'pending') {
                return [
                    'success' => false,
                    'message' => 'Booking is no longer available'
                ];
            }
            
            // Check if rider has an active booking
            $active_booking = $this->rider_model->getActiveBooking($rider_id);
            if ($active_booking) {
                return [
                    'success' => false,
                    'message' => 'You already have an active booking'
                ];
            }
            
            $this->booking_model->id = $booking_id;
            if ($this->booking_model->assignRider($rider_id)) {
                $this->booking_model->updateStatus('accepted', 'Booking accepted by rider');
                
                // Update rider acceptance rate
                $this->rider_model->id = $rider_id;
                $this->rider_model->updateAcceptanceRate(true);
                
                return [
                    'success' => true,
                    'message' => 'Booking accepted successfully'
                ];
            } else {
                return [
                    'success' => false,
                    'message' => 'Failed to accept booking'
                ];
            }
        } catch (Exception $e) {
            AppConfig::logError($e->getMessage(), __FILE__, __LINE__);
            return [
                'success' => false,
                'message' => 'Booking acceptance failed'
            ];
        }
    }
    
    public function declineBooking($booking_id, $rider_id, $reason = '') {
        try {
            // Update rider acceptance rate
            $this->rider_model->id = $rider_id;
            $this->rider_model->updateAcceptanceRate(false);
            
            AppConfig::logActivity($rider_id, 'decline_booking', "Booking {$booking_id} declined. Reason: {$reason}");
            
            return [
                'success' => true,
                'message' => 'Booking declined'
            ];
        } catch (Exception $e) {
            AppConfig::logError($e->getMessage(), __FILE__, __LINE__);
            return [
                'success' => false,
                'message' => 'Failed to decline booking'
            ];
        }
    }
    
    public function updateDeliveryProof($booking_id, $photo_path, $signature_data) {
        try {
            $this->booking_model->id = $booking_id;
            if ($this->booking_model->updateDeliveryProof($photo_path, $signature_data)) {
                return [
                    'success' => true,
                    'message' => 'Delivery proof updated successfully'
                ];
            } else {
                return [
                    'success' => false,
                    'message' => 'Failed to update delivery proof'
                ];
            }
        } catch (Exception $e) {
            AppConfig::logError($e->getMessage(), __FILE__, __LINE__);
            return [
                'success' => false,
                'message' => 'Delivery proof update failed'
            ];
        }
    }
    
    public function addRating($booking_id, $rating, $review = '', $type = 'customer') {
        try {
            $this->booking_model->id = $booking_id;
            
            if ($type === 'customer') {
                $result = $this->booking_model->addCustomerRating($rating, $review);
            } else {
                $result = $this->booking_model->addRiderRating($rating, $review);
            }
            
            if ($result) {
                return [
                    'success' => true,
                    'message' => 'Rating added successfully'
                ];
            } else {
                return [
                    'success' => false,
                    'message' => 'Failed to add rating'
                ];
            }
        } catch (Exception $e) {
            AppConfig::logError($e->getMessage(), __FILE__, __LINE__);
            return [
                'success' => false,
                'message' => 'Rating submission failed'
            ];
        }
    }
    
    public function getAvailableBookings($rider_lat = null, $rider_lng = null) {
        try {
            $bookings = $this->booking_model->getAvailableForAssignment();
            
            // Calculate distance if rider location provided
            if ($rider_lat && $rider_lng) {
                foreach ($bookings as &$booking) {
                    if ($booking['pickup_lat'] && $booking['pickup_lng']) {
                        $distance_calc = $this->booking_model->calculateDeliveryFee(
                            $rider_lat, $rider_lng,
                            $booking['pickup_lat'], $booking['pickup_lng']
                        );
                        $booking['distance_to_pickup'] = $distance_calc['distance'];
                    }
                }
                
                // Sort by distance
                usort($bookings, function($a, $b) {
                    return ($a['distance_to_pickup'] ?? 999) <=> ($b['distance_to_pickup'] ?? 999);
                });
            }
            
            return [
                'success' => true,
                'data' => $bookings
            ];
        } catch (Exception $e) {
            AppConfig::logError($e->getMessage(), __FILE__, __LINE__);
            return [
                'success' => false,
                'message' => 'Failed to retrieve available bookings'
            ];
        }
    }
}
?>
