<?php
require_once '../config/Database.php';
require_once '../models/Merchant.php';
require_once '../models/Menu.php';

class MerchantController {
    private $db;
    private $merchant;
    private $menu;

    public function __construct() {
        $database = new Database();
        $this->db = $database->getConnection();
        $this->merchant = new Merchant($this->db);
        $this->menu = new Menu($this->db);
    }

    public function getAllMerchants($filters = []) {
        try {
            $merchants = $this->merchant->getAll($filters);
            return [
                'success' => true,
                'data' => $merchants
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Failed to fetch merchants: ' . $e->getMessage()
            ];
        }
    }

    public function getMerchantById($id) {
        try {
            $merchant = $this->merchant->getById($id);
            if ($merchant) {
                return [
                    'success' => true,
                    'data' => $merchant
                ];
            }
            return [
                'success' => false,
                'message' => 'Merchant not found'
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Failed to fetch merchant: ' . $e->getMessage()
            ];
        }
    }

    public function createMerchant($data) {
        try {
            // Validate required fields
            $required = ['name', 'address', 'phone', 'category'];
            foreach ($required as $field) {
                if (empty($data[$field])) {
                    return [
                        'success' => false,
                        'message' => ucfirst($field) . ' is required'
                    ];
                }
            }

            $merchantId = $this->merchant->create($data);
            if ($merchantId) {
                return [
                    'success' => true,
                    'message' => 'Merchant created successfully',
                    'data' => ['id' => $merchantId]
                ];
            }
            return [
                'success' => false,
                'message' => 'Failed to create merchant'
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Failed to create merchant: ' . $e->getMessage()
            ];
        }
    }

    public function updateMerchant($id, $data) {
        try {
            $success = $this->merchant->update($id, $data);
            if ($success) {
                return [
                    'success' => true,
                    'message' => 'Merchant updated successfully'
                ];
            }
            return [
                'success' => false,
                'message' => 'Failed to update merchant'
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Failed to update merchant: ' . $e->getMessage()
            ];
        }
    }

    public function deleteMerchant($id) {
        try {
            $success = $this->merchant->delete($id);
            if ($success) {
                return [
                    'success' => true,
                    'message' => 'Merchant deleted successfully'
                ];
            }
            return [
                'success' => false,
                'message' => 'Failed to delete merchant'
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Failed to delete merchant: ' . $e->getMessage()
            ];
        }
    }

    public function toggleMerchantStatus($id) {
        try {
            $success = $this->merchant->toggleStatus($id);
            if ($success) {
                return [
                    'success' => true,
                    'message' => 'Merchant status updated successfully'
                ];
            }
            return [
                'success' => false,
                'message' => 'Failed to update merchant status'
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Failed to update status: ' . $e->getMessage()
            ];
        }
    }

    public function getMerchantStats($id) {
        try {
            $stats = $this->merchant->getStats($id);
            return [
                'success' => true,
                'data' => $stats
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Failed to fetch merchant stats: ' . $e->getMessage()
            ];
        }
    }

    public function getMerchantSalesReport($id, $startDate = null, $endDate = null) {
        try {
            $report = $this->merchant->getSalesReport($id, $startDate, $endDate);
            return [
                'success' => true,
                'data' => $report
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Failed to generate sales report: ' . $e->getMessage()
            ];
        }
    }

    public function getMerchantMenu($merchantId) {
        try {
            $categories = $this->menu->getCategoriesByMerchant($merchantId);
            $items = $this->menu->getItemsByMerchant($merchantId);
            
            return [
                'success' => true,
                'data' => [
                    'categories' => $categories,
                    'items' => $items
                ]
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Failed to fetch merchant menu: ' . $e->getMessage()
            ];
        }
    }

    public function updateMerchantHours($id, $hours) {
        try {
            $success = $this->merchant->updateOpeningHours($id, $hours);
            if ($success) {
                return [
                    'success' => true,
                    'message' => 'Opening hours updated successfully'
                ];
            }
            return [
                'success' => false,
                'message' => 'Failed to update opening hours'
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Failed to update hours: ' . $e->getMessage()
            ];
        }
    }

    public function getMerchantsByCategory($category) {
        try {
            $merchants = $this->merchant->getByCategory($category);
            return [
                'success' => true,
                'data' => $merchants
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Failed to fetch merchants by category: ' . $e->getMessage()
            ];
        }
    }

    public function searchMerchants($query) {
        try {
            $merchants = $this->merchant->search($query);
            return [
                'success' => true,
                'data' => $merchants
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Failed to search merchants: ' . $e->getMessage()
            ];
        }
    }

    public function getMerchantDashboardData($merchantId) {
        try {
            $stats = $this->merchant->getStats($merchantId);
            $recentOrders = $this->merchant->getRecentOrders($merchantId, 10);
            $salesData = $this->merchant->getSalesReport($merchantId, date('Y-m-01'), date('Y-m-d'));
            
            return [
                'success' => true,
                'data' => [
                    'stats' => $stats,
                    'recent_orders' => $recentOrders,
                    'sales_data' => $salesData
                ]
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Failed to fetch dashboard data: ' . $e->getMessage()
            ];
        }
    }

    public function updateMerchantRating($id, $rating, $review = null) {
        try {
            $success = $this->merchant->updateRating($id, $rating, $review);
            if ($success) {
                return [
                    'success' => true,
                    'message' => 'Rating updated successfully'
                ];
            }
            return [
                'success' => false,
                'message' => 'Failed to update rating'
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Failed to update rating: ' . $e->getMessage()
            ];
        }
    }
}
?>
