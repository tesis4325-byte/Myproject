<?php
session_start();
require_once __DIR__ . '/../models/User.php';
require_once __DIR__ . '/../models/Rider.php';
require_once __DIR__ . '/../config/AppConfig.php';

class AuthController {
    private $user_model;
    private $rider_model;
    
    public function __construct() {
        $this->user_model = new User();
        $this->rider_model = new Rider();
    }
    
    public function login($username, $password, $role = null) {
        try {
            if ($this->user_model->login($username, $password)) {
                // Check role if specified
                if ($role && $this->user_model->role !== $role) {
                    return [
                        'success' => false,
                        'message' => 'Access denied for this role'
                    ];
                }
                
                // Set session variables
                $_SESSION['user_id'] = $this->user_model->id;
                $_SESSION['username'] = $this->user_model->username;
                $_SESSION['role'] = $this->user_model->role;
                $_SESSION['full_name'] = $this->user_model->full_name;
                $_SESSION['logged_in'] = true;
                $_SESSION['login_time'] = time();
                
                // For riders, also get rider info
                if ($this->user_model->role === 'rider') {
                    $rider_info = $this->rider_model->getByUserId($this->user_model->id);
                    if ($rider_info) {
                        $_SESSION['rider_id'] = $rider_info['id'];
                    }
                }
                
                return [
                    'success' => true,
                    'message' => 'Login successful',
                    'user' => [
                        'id' => $this->user_model->id,
                        'username' => $this->user_model->username,
                        'role' => $this->user_model->role,
                        'full_name' => $this->user_model->full_name
                    ]
                ];
            } else {
                return [
                    'success' => false,
                    'message' => 'Invalid username or password'
                ];
            }
        } catch (Exception $e) {
            AppConfig::logError($e->getMessage(), __FILE__, __LINE__);
            return [
                'success' => false,
                'message' => 'Login failed. Please try again.'
            ];
        }
    }
    
    public function logout() {
        if (isset($_SESSION['user_id'])) {
            AppConfig::logActivity($_SESSION['user_id'], 'logout', 'User logged out');
        }
        
        session_destroy();
        return [
            'success' => true,
            'message' => 'Logged out successfully'
        ];
    }
    
    public function isLoggedIn() {
        return isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true;
    }
    
    public function hasRole($required_role) {
        if (!$this->isLoggedIn()) {
            return false;
        }
        
        $user_role = $_SESSION['role'];
        
        // Super admin can access everything
        if ($user_role === 'super_admin') {
            return true;
        }
        
        // Check specific role permissions
        switch ($required_role) {
            case 'admin':
                return in_array($user_role, ['admin', 'super_admin']);
            case 'dispatcher':
                return in_array($user_role, ['dispatcher', 'admin', 'super_admin']);
            case 'finance':
                return in_array($user_role, ['finance', 'admin', 'super_admin']);
            case 'rider':
                return $user_role === 'rider';
            default:
                return $user_role === $required_role;
        }
    }
    
    public function requireLogin($redirect_url = null) {
        if (!$this->isLoggedIn()) {
            if ($redirect_url) {
                header("Location: $redirect_url");
            } else {
                http_response_code(401);
                echo json_encode(['success' => false, 'message' => 'Authentication required']);
            }
            exit;
        }
        
        // Check session timeout
        if (isset($_SESSION['login_time']) && 
            (time() - $_SESSION['login_time']) > AppConfig::SESSION_TIMEOUT) {
            $this->logout();
            if ($redirect_url) {
                header("Location: $redirect_url");
            } else {
                http_response_code(401);
                echo json_encode(['success' => false, 'message' => 'Session expired']);
            }
            exit;
        }
    }
    
    public function requireRole($required_role, $redirect_url = null) {
        $this->requireLogin($redirect_url);
        
        if (!$this->hasRole($required_role)) {
            if ($redirect_url) {
                header("Location: $redirect_url");
            } else {
                http_response_code(403);
                echo json_encode(['success' => false, 'message' => 'Access denied']);
            }
            exit;
        }
    }
    
    public function getCurrentUser() {
        if (!$this->isLoggedIn()) {
            return null;
        }
        
        return [
            'id' => $_SESSION['user_id'],
            'username' => $_SESSION['username'],
            'role' => $_SESSION['role'],
            'full_name' => $_SESSION['full_name'],
            'rider_id' => $_SESSION['rider_id'] ?? null
        ];
    }
    
    public function changePassword($current_password, $new_password) {
        if (!$this->isLoggedIn()) {
            return [
                'success' => false,
                'message' => 'Authentication required'
            ];
        }
        
        try {
            // Verify current password
            if (!$this->user_model->login($_SESSION['username'], $current_password)) {
                return [
                    'success' => false,
                    'message' => 'Current password is incorrect'
                ];
            }
            
            // Update password
            $this->user_model->id = $_SESSION['user_id'];
            if ($this->user_model->updatePassword($new_password)) {
                return [
                    'success' => true,
                    'message' => 'Password updated successfully'
                ];
            } else {
                return [
                    'success' => false,
                    'message' => 'Failed to update password'
                ];
            }
        } catch (Exception $e) {
            AppConfig::logError($e->getMessage(), __FILE__, __LINE__);
            return [
                'success' => false,
                'message' => 'Password update failed'
            ];
        }
    }
    
    public function createUser($username, $email, $password, $role, $full_name, $phone, $rider_details = null) {
        try {
            // Check if username or email already exists
            if ($this->user_model->usernameExists($username)) {
                return [
                    'success' => false,
                    'message' => 'Username already exists'
                ];
            }
            
            if ($this->user_model->emailExists($email)) {
                return [
                    'success' => false,
                    'message' => 'Email already exists'
                ];
            }
            
            // Create user
            $this->user_model->username = $username;
            $this->user_model->email = $email;
            $this->user_model->password = $password;
            $this->user_model->role = $role;
            $this->user_model->full_name = $full_name;
            $this->user_model->phone = $phone;
            $this->user_model->status = 'active';
            
            if ($this->user_model->create()) {
                // If creating a rider, also create rider details
                if ($role === 'rider' && $rider_details) {
                    $this->rider_model->user_id = $this->user_model->id;
                    $this->rider_model->license_number = $rider_details['license_number'] ?? '';
                    $this->rider_model->vehicle_type = $rider_details['vehicle_type'] ?? 'motorcycle';
                    $this->rider_model->vehicle_plate = $rider_details['vehicle_plate'] ?? '';
                    $this->rider_model->vehicle_model = $rider_details['vehicle_model'] ?? '';
                    $this->rider_model->emergency_contact = $rider_details['emergency_contact'] ?? '';
                    $this->rider_model->emergency_name = $rider_details['emergency_name'] ?? '';
                    
                    $this->rider_model->create();
                }
                
                return [
                    'success' => true,
                    'message' => 'User created successfully',
                    'user_id' => $this->user_model->id
                ];
            } else {
                return [
                    'success' => false,
                    'message' => 'Failed to create user'
                ];
            }
        } catch (Exception $e) {
            AppConfig::logError($e->getMessage(), __FILE__, __LINE__);
            return [
                'success' => false,
                'message' => 'User creation failed'
            ];
        }
    }
    
    public function generateCSRFToken() {
        if (!isset($_SESSION['csrf_token']) || 
            !isset($_SESSION['csrf_token_time']) ||
            (time() - $_SESSION['csrf_token_time']) > AppConfig::CSRF_TOKEN_EXPIRY) {
            
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
            $_SESSION['csrf_token_time'] = time();
        }
        
        return $_SESSION['csrf_token'];
    }
    
    public function validateCSRFToken($token) {
        return isset($_SESSION['csrf_token']) && 
               isset($_SESSION['csrf_token_time']) &&
               hash_equals($_SESSION['csrf_token'], $token) &&
               (time() - $_SESSION['csrf_token_time']) <= AppConfig::CSRF_TOKEN_EXPIRY;
    }
}
?>
