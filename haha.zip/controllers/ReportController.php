<?php
require_once '../config/Database.php';
require_once '../models/Report.php';
require_once '../models/Booking.php';
require_once '../models/Rider.php';
require_once '../models/Merchant.php';

class ReportController {
    private $db;
    private $report;
    private $booking;
    private $rider;
    private $merchant;

    public function __construct() {
        $database = new Database();
        $this->db = $database->getConnection();
        $this->report = new Report($this->db);
        $this->booking = new Booking($this->db);
        $this->rider = new Rider($this->db);
        $this->merchant = new Merchant($this->db);
    }

    public function getSalesReport($startDate = null, $endDate = null, $filters = []) {
        try {
            $report = $this->report->getSalesReport($startDate, $endDate, $filters);
            return [
                'success' => true,
                'data' => $report
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Failed to generate sales report: ' . $e->getMessage()
            ];
        }
    }

    public function getRiderPerformanceReport($riderId = null, $startDate = null, $endDate = null) {
        try {
            $report = $this->report->getRiderPerformanceReport($riderId, $startDate, $endDate);
            return [
                'success' => true,
                'data' => $report
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Failed to generate rider performance report: ' . $e->getMessage()
            ];
        }
    }

    public function getMerchantReport($merchantId = null, $startDate = null, $endDate = null) {
        try {
            $report = $this->report->getMerchantReport($merchantId, $startDate, $endDate);
            return [
                'success' => true,
                'data' => $report
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Failed to generate merchant report: ' . $e->getMessage()
            ];
        }
    }

    public function getFinancialReport($startDate = null, $endDate = null) {
        try {
            $report = $this->report->getFinancialReport($startDate, $endDate);
            return [
                'success' => true,
                'data' => $report
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Failed to generate financial report: ' . $e->getMessage()
            ];
        }
    }

    public function getCustomerReport($startDate = null, $endDate = null) {
        try {
            $report = $this->report->getCustomerReport($startDate, $endDate);
            return [
                'success' => true,
                'data' => $report
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Failed to generate customer report: ' . $e->getMessage()
            ];
        }
    }

    public function getDashboardStats($period = 'today') {
        try {
            $stats = $this->report->getDashboardStats($period);
            return [
                'success' => true,
                'data' => $stats
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Failed to fetch dashboard stats: ' . $e->getMessage()
            ];
        }
    }

    public function getOrderTrends($period = '30days') {
        try {
            $trends = $this->report->getOrderTrends($period);
            return [
                'success' => true,
                'data' => $trends
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Failed to fetch order trends: ' . $e->getMessage()
            ];
        }
    }

    public function getRevenueTrends($period = '30days') {
        try {
            $trends = $this->report->getRevenueTrends($period);
            return [
                'success' => true,
                'data' => $trends
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Failed to fetch revenue trends: ' . $e->getMessage()
            ];
        }
    }

    public function getTopPerformers($type = 'riders', $limit = 10, $period = '30days') {
        try {
            $performers = $this->report->getTopPerformers($type, $limit, $period);
            return [
                'success' => true,
                'data' => $performers
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Failed to fetch top performers: ' . $e->getMessage()
            ];
        }
    }

    public function getServiceTypeReport($startDate = null, $endDate = null) {
        try {
            $report = $this->report->getServiceTypeReport($startDate, $endDate);
            return [
                'success' => true,
                'data' => $report
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Failed to generate service type report: ' . $e->getMessage()
            ];
        }
    }

    public function getGeographicReport($startDate = null, $endDate = null) {
        try {
            $report = $this->report->getGeographicReport($startDate, $endDate);
            return [
                'success' => true,
                'data' => $report
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Failed to generate geographic report: ' . $e->getMessage()
            ];
        }
    }

    public function getPayoutReport($riderId = null, $startDate = null, $endDate = null) {
        try {
            $report = $this->report->getPayoutReport($riderId, $startDate, $endDate);
            return [
                'success' => true,
                'data' => $report
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Failed to generate payout report: ' . $e->getMessage()
            ];
        }
    }

    public function getComplaintReport($startDate = null, $endDate = null) {
        try {
            $report = $this->report->getComplaintReport($startDate, $endDate);
            return [
                'success' => true,
                'data' => $report
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Failed to generate complaint report: ' . $e->getMessage()
            ];
        }
    }

    public function exportReport($type, $format = 'csv', $params = []) {
        try {
            $data = null;
            
            switch ($type) {
                case 'sales':
                    $result = $this->getSalesReport($params['start_date'] ?? null, $params['end_date'] ?? null, $params['filters'] ?? []);
                    break;
                case 'riders':
                    $result = $this->getRiderPerformanceReport($params['rider_id'] ?? null, $params['start_date'] ?? null, $params['end_date'] ?? null);
                    break;
                case 'merchants':
                    $result = $this->getMerchantReport($params['merchant_id'] ?? null, $params['start_date'] ?? null, $params['end_date'] ?? null);
                    break;
                case 'financial':
                    $result = $this->getFinancialReport($params['start_date'] ?? null, $params['end_date'] ?? null);
                    break;
                case 'customers':
                    $result = $this->getCustomerReport($params['start_date'] ?? null, $params['end_date'] ?? null);
                    break;
                default:
                    return [
                        'success' => false,
                        'message' => 'Invalid report type'
                    ];
            }

            if (!$result['success']) {
                return $result;
            }

            $filename = $this->generateExportFile($result['data'], $type, $format);
            
            return [
                'success' => true,
                'message' => 'Report exported successfully',
                'data' => [
                    'filename' => $filename,
                    'download_url' => '/downloads/' . $filename
                ]
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Failed to export report: ' . $e->getMessage()
            ];
        }
    }

    private function generateExportFile($data, $type, $format) {
        $timestamp = date('Y-m-d_H-i-s');
        $filename = "{$type}_report_{$timestamp}.{$format}";
        $filepath = "../public/downloads/{$filename}";

        // Ensure downloads directory exists
        if (!file_exists('../public/downloads')) {
            mkdir('../public/downloads', 0755, true);
        }

        switch ($format) {
            case 'csv':
                $this->exportToCsv($data, $filepath);
                break;
            case 'json':
                $this->exportToJson($data, $filepath);
                break;
            case 'excel':
                $this->exportToExcel($data, $filepath);
                break;
            default:
                throw new Exception('Unsupported export format');
        }

        return $filename;
    }

    private function exportToCsv($data, $filepath) {
        $file = fopen($filepath, 'w');
        
        if (!empty($data)) {
            // Write headers
            fputcsv($file, array_keys($data[0]));
            
            // Write data
            foreach ($data as $row) {
                fputcsv($file, $row);
            }
        }
        
        fclose($file);
    }

    private function exportToJson($data, $filepath) {
        file_put_contents($filepath, json_encode($data, JSON_PRETTY_PRINT));
    }

    private function exportToExcel($data, $filepath) {
        // Basic Excel export (would need PHPSpreadsheet for full functionality)
        $this->exportToCsv($data, $filepath);
    }

    public function getReportSchedules() {
        try {
            $schedules = $this->report->getScheduledReports();
            return [
                'success' => true,
                'data' => $schedules
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Failed to fetch report schedules: ' . $e->getMessage()
            ];
        }
    }

    public function createReportSchedule($data) {
        try {
            $required = ['name', 'report_type', 'frequency', 'recipients'];
            foreach ($required as $field) {
                if (empty($data[$field])) {
                    return [
                        'success' => false,
                        'message' => ucfirst($field) . ' is required'
                    ];
                }
            }

            $scheduleId = $this->report->createScheduledReport($data);
            if ($scheduleId) {
                return [
                    'success' => true,
                    'message' => 'Report schedule created successfully',
                    'data' => ['id' => $scheduleId]
                ];
            }
            return [
                'success' => false,
                'message' => 'Failed to create report schedule'
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Failed to create schedule: ' . $e->getMessage()
            ];
        }
    }

    public function updateReportSchedule($id, $data) {
        try {
            $success = $this->report->updateScheduledReport($id, $data);
            if ($success) {
                return [
                    'success' => true,
                    'message' => 'Report schedule updated successfully'
                ];
            }
            return [
                'success' => false,
                'message' => 'Failed to update report schedule'
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Failed to update schedule: ' . $e->getMessage()
            ];
        }
    }

    public function deleteReportSchedule($id) {
        try {
            $success = $this->report->deleteScheduledReport($id);
            if ($success) {
                return [
                    'success' => true,
                    'message' => 'Report schedule deleted successfully'
                ];
            }
            return [
                'success' => false,
                'message' => 'Failed to delete report schedule'
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Failed to delete schedule: ' . $e->getMessage()
            ];
        }
    }
}
?>
