<?php
require_once __DIR__ . '/../models/Rider.php';
require_once __DIR__ . '/../models/Booking.php';
require_once __DIR__ . '/../config/AppConfig.php';

class RiderController {
    private $rider_model;
    private $booking_model;
    
    public function __construct() {
        $this->rider_model = new Rider();
        $this->booking_model = new Booking();
    }
    
    public function getRiderDashboard($rider_id) {
        try {
            $rider_info = $this->rider_model->getById($rider_id);
            if (!$rider_info) {
                return [
                    'success' => false,
                    'message' => 'Rider not found'
                ];
            }
            
            // Get performance stats
            $performance = $this->rider_model->getPerformanceStats($rider_id, 30);
            $today_performance = $this->rider_model->getPerformanceStats($rider_id, 1);
            
            // Get earnings
            $earnings = $this->rider_model->getEarnings($rider_id);
            $today_earnings = $this->rider_model->getEarnings($rider_id, date('Y-m-d'), date('Y-m-d'));
            
            // Get active booking
            $active_booking = $this->rider_model->getActiveBooking($rider_id);
            
            // Get recent bookings
            $recent_bookings = $this->booking_model->getAll(null, null, $rider_id, null, 10, 0);
            
            return [
                'success' => true,
                'data' => [
                    'rider_info' => $rider_info,
                    'performance' => [
                        'monthly' => $performance,
                        'today' => $today_performance
                    ],
                    'earnings' => [
                        'total' => $earnings,
                        'today' => $today_earnings
                    ],
                    'active_booking' => $active_booking,
                    'recent_bookings' => $recent_bookings
                ]
            ];
        } catch (Exception $e) {
            AppConfig::logError($e->getMessage(), __FILE__, __LINE__);
            return [
                'success' => false,
                'message' => 'Failed to retrieve rider dashboard'
            ];
        }
    }
    
    public function updateLocation($rider_id, $lat, $lng) {
        try {
            $this->rider_model->id = $rider_id;
            if ($this->rider_model->updateLocation($lat, $lng)) {
                return [
                    'success' => true,
                    'message' => 'Location updated successfully'
                ];
            } else {
                return [
                    'success' => false,
                    'message' => 'Failed to update location'
                ];
            }
        } catch (Exception $e) {
            AppConfig::logError($e->getMessage(), __FILE__, __LINE__);
            return [
                'success' => false,
                'message' => 'Location update failed'
            ];
        }
    }
    
    public function toggleOnlineStatus($rider_id, $is_online) {
        try {
            $this->rider_model->id = $rider_id;
            if ($this->rider_model->setOnlineStatus($is_online)) {
                $status = $is_online ? 'online' : 'offline';
                return [
                    'success' => true,
                    'message' => "Status changed to {$status}"
                ];
            } else {
                return [
                    'success' => false,
                    'message' => 'Failed to update status'
                ];
            }
        } catch (Exception $e) {
            AppConfig::logError($e->getMessage(), __FILE__, __LINE__);
            return [
                'success' => false,
                'message' => 'Status update failed'
            ];
        }
    }
    
    public function getAvailableBookings($rider_id) {
        try {
            $rider_info = $this->rider_model->getById($rider_id);
            if (!$rider_info || !$rider_info['is_online']) {
                return [
                    'success' => false,
                    'message' => 'Rider must be online to view bookings'
                ];
            }
            
            // Get available bookings near rider
            $bookings = $this->booking_model->getAvailableForAssignment();
            
            // Calculate distance to each booking
            if ($rider_info['current_lat'] && $rider_info['current_lng']) {
                foreach ($bookings as &$booking) {
                    if ($booking['pickup_lat'] && $booking['pickup_lng']) {
                        $distance_calc = $this->booking_model->calculateDeliveryFee(
                            $rider_info['current_lat'], $rider_info['current_lng'],
                            $booking['pickup_lat'], $booking['pickup_lng']
                        );
                        $booking['distance_to_pickup'] = $distance_calc['distance'];
                        $booking['estimated_earning'] = $booking['delivery_fee'] * (AppConfig::RIDER_COMMISSION_PERCENTAGE);
                    }
                }
                
                // Sort by distance
                usort($bookings, function($a, $b) {
                    return ($a['distance_to_pickup'] ?? 999) <=> ($b['distance_to_pickup'] ?? 999);
                });
            }
            
            return [
                'success' => true,
                'data' => $bookings
            ];
        } catch (Exception $e) {
            AppConfig::logError($e->getMessage(), __FILE__, __LINE__);
            return [
                'success' => false,
                'message' => 'Failed to retrieve available bookings'
            ];
        }
    }
    
    public function acceptBooking($rider_id, $booking_id) {
        try {
            // Check if rider is online and available
            $rider_info = $this->rider_model->getById($rider_id);
            if (!$rider_info || !$rider_info['is_online']) {
                return [
                    'success' => false,
                    'message' => 'You must be online to accept bookings'
                ];
            }
            
            // Check if rider already has an active booking
            $active_booking = $this->rider_model->getActiveBooking($rider_id);
            if ($active_booking) {
                return [
                    'success' => false,
                    'message' => 'You already have an active booking'
                ];
            }
            
            // Get booking details
            $booking = $this->booking_model->getById($booking_id);
            if (!$booking || $booking['status'] !== 'pending') {
                return [
                    'success' => false,
                    'message' => 'Booking is no longer available'
                ];
            }
            
            // Accept the booking
            $this->booking_model->id = $booking_id;
            if ($this->booking_model->assignRider($rider_id)) {
                $this->booking_model->updateStatus('accepted', 'Booking accepted by rider');
                
                // Update rider acceptance rate
                $this->rider_model->id = $rider_id;
                $this->rider_model->updateAcceptanceRate(true);
                
                return [
                    'success' => true,
                    'message' => 'Booking accepted successfully',
                    'booking' => $booking
                ];
            } else {
                return [
                    'success' => false,
                    'message' => 'Failed to accept booking'
                ];
            }
        } catch (Exception $e) {
            AppConfig::logError($e->getMessage(), __FILE__, __LINE__);
            return [
                'success' => false,
                'message' => 'Booking acceptance failed'
            ];
        }
    }
    
    public function updateBookingStatus($rider_id, $booking_id, $status, $notes = '') {
        try {
            // Verify booking belongs to rider
            $booking = $this->booking_model->getById($booking_id);
            if (!$booking || $booking['rider_id'] != $rider_id) {
                return [
                    'success' => false,
                    'message' => 'Booking not found or access denied'
                ];
            }
            
            // Validate status transition
            $valid_transitions = [
                'accepted' => ['preparing', 'cancelled'],
                'preparing' => ['ready', 'cancelled'],
                'ready' => ['picked_up', 'cancelled'],
                'picked_up' => ['on_the_way', 'cancelled'],
                'on_the_way' => ['delivered', 'cancelled']
            ];
            
            $current_status = $booking['status'];
            if (!isset($valid_transitions[$current_status]) || 
                !in_array($status, $valid_transitions[$current_status])) {
                return [
                    'success' => false,
                    'message' => 'Invalid status transition'
                ];
            }
            
            $this->booking_model->id = $booking_id;
            if ($this->booking_model->updateStatus($status, $notes, $rider_id)) {
                return [
                    'success' => true,
                    'message' => 'Booking status updated successfully'
                ];
            } else {
                return [
                    'success' => false,
                    'message' => 'Failed to update booking status'
                ];
            }
        } catch (Exception $e) {
            AppConfig::logError($e->getMessage(), __FILE__, __LINE__);
            return [
                'success' => false,
                'message' => 'Status update failed'
            ];
        }
    }
    
    public function uploadDeliveryProof($rider_id, $booking_id, $photo_path, $signature_data) {
        try {
            // Verify booking belongs to rider
            $booking = $this->booking_model->getById($booking_id);
            if (!$booking || $booking['rider_id'] != $rider_id) {
                return [
                    'success' => false,
                    'message' => 'Booking not found or access denied'
                ];
            }
            
            if ($booking['status'] !== 'on_the_way') {
                return [
                    'success' => false,
                    'message' => 'Delivery proof can only be uploaded when on the way'
                ];
            }
            
            $this->booking_model->id = $booking_id;
            if ($this->booking_model->updateDeliveryProof($photo_path, $signature_data)) {
                // Update status to delivered
                $this->booking_model->updateStatus('delivered', 'Delivery completed with proof', $rider_id);
                
                return [
                    'success' => true,
                    'message' => 'Delivery proof uploaded successfully'
                ];
            } else {
                return [
                    'success' => false,
                    'message' => 'Failed to upload delivery proof'
                ];
            }
        } catch (Exception $e) {
            AppConfig::logError($e->getMessage(), __FILE__, __LINE__);
            return [
                'success' => false,
                'message' => 'Delivery proof upload failed'
            ];
        }
    }
    
    public function getBookingHistory($rider_id, $page = 1, $status = null) {
        try {
            $limit = AppConfig::PAGINATION_LIMIT;
            $offset = ($page - 1) * $limit;
            
            $bookings = $this->booking_model->getAll($status, null, $rider_id, null, $limit, $offset);
            
            return [
                'success' => true,
                'data' => [
                    'bookings' => $bookings,
                    'pagination' => [
                        'current_page' => $page,
                        'per_page' => $limit
                    ]
                ]
            ];
        } catch (Exception $e) {
            AppConfig::logError($e->getMessage(), __FILE__, __LINE__);
            return [
                'success' => false,
                'message' => 'Failed to retrieve booking history'
            ];
        }
    }
    
    public function getEarnings($rider_id, $period = 'month') {
        try {
            $start_date = null;
            $end_date = null;
            
            switch ($period) {
                case 'today':
                    $start_date = date('Y-m-d');
                    $end_date = date('Y-m-d');
                    break;
                case 'week':
                    $start_date = date('Y-m-d', strtotime('-7 days'));
                    $end_date = date('Y-m-d');
                    break;
                case 'month':
                    $start_date = date('Y-m-01');
                    $end_date = date('Y-m-t');
                    break;
            }
            
            $earnings = $this->rider_model->getEarnings($rider_id, $start_date, $end_date);
            
            return [
                'success' => true,
                'data' => $earnings
            ];
        } catch (Exception $e) {
            AppConfig::logError($e->getMessage(), __FILE__, __LINE__);
            return [
                'success' => false,
                'message' => 'Failed to retrieve earnings'
            ];
        }
    }
    
    public function sendPanicAlert($rider_id, $message = '') {
        try {
            $this->rider_model->id = $rider_id;
            if ($this->rider_model->sendPanicAlert($rider_id, $message)) {
                return [
                    'success' => true,
                    'message' => 'Panic alert sent successfully'
                ];
            } else {
                return [
                    'success' => false,
                    'message' => 'Failed to send panic alert'
                ];
            }
        } catch (Exception $e) {
            AppConfig::logError($e->getMessage(), __FILE__, __LINE__);
            return [
                'success' => false,
                'message' => 'Panic alert failed'
            ];
        }
    }
    
    public function rateCustomer($rider_id, $booking_id, $rating, $review = '') {
        try {
            // Verify booking belongs to rider and is completed
            $booking = $this->booking_model->getById($booking_id);
            if (!$booking || $booking['rider_id'] != $rider_id || $booking['status'] !== 'delivered') {
                return [
                    'success' => false,
                    'message' => 'Cannot rate this booking'
                ];
            }
            
            $this->booking_model->id = $booking_id;
            if ($this->booking_model->addRiderRating($rating, $review)) {
                return [
                    'success' => true,
                    'message' => 'Customer rating submitted successfully'
                ];
            } else {
                return [
                    'success' => false,
                    'message' => 'Failed to submit rating'
                ];
            }
        } catch (Exception $e) {
            AppConfig::logError($e->getMessage(), __FILE__, __LINE__);
            return [
                'success' => false,
                'message' => 'Rating submission failed'
            ];
        }
    }
    
    public function updateProfile($rider_id, $data) {
        try {
            $rider_info = $this->rider_model->getByUserId($data['user_id']);
            if (!$rider_info || $rider_info['id'] != $rider_id) {
                return [
                    'success' => false,
                    'message' => 'Rider not found'
                ];
            }
            
            // Update rider details
            $this->rider_model->id = $rider_id;
            $this->rider_model->license_number = $data['license_number'];
            $this->rider_model->vehicle_type = $data['vehicle_type'];
            $this->rider_model->vehicle_plate = $data['vehicle_plate'];
            $this->rider_model->vehicle_model = $data['vehicle_model'];
            $this->rider_model->emergency_contact = $data['emergency_contact'];
            $this->rider_model->emergency_name = $data['emergency_name'];
            
            if ($this->rider_model->update()) {
                return [
                    'success' => true,
                    'message' => 'Profile updated successfully'
                ];
            } else {
                return [
                    'success' => false,
                    'message' => 'Failed to update profile'
                ];
            }
        } catch (Exception $e) {
            AppConfig::logError($e->getMessage(), __FILE__, __LINE__);
            return [
                'success' => false,
                'message' => 'Profile update failed'
            ];
        }
    }
}
?>
