<?php
require_once '../config/Database.php';
require_once '../models/Menu.php';

class MenuController {
    private $db;
    private $menu;

    public function __construct() {
        $database = new Database();
        $this->db = $database->getConnection();
        $this->menu = new Menu($this->db);
    }

    public function getAllCategories($merchantId = null) {
        try {
            if ($merchantId) {
                $categories = $this->menu->getCategoriesByMerchant($merchantId);
            } else {
                $categories = $this->menu->getAllCategories();
            }
            return [
                'success' => true,
                'data' => $categories
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Failed to fetch categories: ' . $e->getMessage()
            ];
        }
    }

    public function createCategory($data) {
        try {
            $required = ['merchant_id', 'name'];
            foreach ($required as $field) {
                if (empty($data[$field])) {
                    return [
                        'success' => false,
                        'message' => ucfirst($field) . ' is required'
                    ];
                }
            }

            $categoryId = $this->menu->createCategory($data);
            if ($categoryId) {
                return [
                    'success' => true,
                    'message' => 'Category created successfully',
                    'data' => ['id' => $categoryId]
                ];
            }
            return [
                'success' => false,
                'message' => 'Failed to create category'
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Failed to create category: ' . $e->getMessage()
            ];
        }
    }

    public function updateCategory($id, $data) {
        try {
            $success = $this->menu->updateCategory($id, $data);
            if ($success) {
                return [
                    'success' => true,
                    'message' => 'Category updated successfully'
                ];
            }
            return [
                'success' => false,
                'message' => 'Failed to update category'
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Failed to update category: ' . $e->getMessage()
            ];
        }
    }

    public function deleteCategory($id) {
        try {
            $success = $this->menu->deleteCategory($id);
            if ($success) {
                return [
                    'success' => true,
                    'message' => 'Category deleted successfully'
                ];
            }
            return [
                'success' => false,
                'message' => 'Failed to delete category'
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Failed to delete category: ' . $e->getMessage()
            ];
        }
    }

    public function getAllItems($filters = []) {
        try {
            $items = $this->menu->getAllItems($filters);
            return [
                'success' => true,
                'data' => $items
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Failed to fetch items: ' . $e->getMessage()
            ];
        }
    }

    public function getItemsByMerchant($merchantId, $categoryId = null) {
        try {
            if ($categoryId) {
                $items = $this->menu->getItemsByCategory($categoryId);
            } else {
                $items = $this->menu->getItemsByMerchant($merchantId);
            }
            return [
                'success' => true,
                'data' => $items
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Failed to fetch items: ' . $e->getMessage()
            ];
        }
    }

    public function getItemById($id) {
        try {
            $item = $this->menu->getItemById($id);
            if ($item) {
                return [
                    'success' => true,
                    'data' => $item
                ];
            }
            return [
                'success' => false,
                'message' => 'Item not found'
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Failed to fetch item: ' . $e->getMessage()
            ];
        }
    }

    public function createItem($data) {
        try {
            $required = ['merchant_id', 'category_id', 'name', 'price'];
            foreach ($required as $field) {
                if (empty($data[$field])) {
                    return [
                        'success' => false,
                        'message' => ucfirst($field) . ' is required'
                    ];
                }
            }

            if (!is_numeric($data['price']) || $data['price'] < 0) {
                return [
                    'success' => false,
                    'message' => 'Price must be a valid positive number'
                ];
            }

            $itemId = $this->menu->createItem($data);
            if ($itemId) {
                return [
                    'success' => true,
                    'message' => 'Item created successfully',
                    'data' => ['id' => $itemId]
                ];
            }
            return [
                'success' => false,
                'message' => 'Failed to create item'
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Failed to create item: ' . $e->getMessage()
            ];
        }
    }

    public function updateItem($id, $data) {
        try {
            if (isset($data['price']) && (!is_numeric($data['price']) || $data['price'] < 0)) {
                return [
                    'success' => false,
                    'message' => 'Price must be a valid positive number'
                ];
            }

            $success = $this->menu->updateItem($id, $data);
            if ($success) {
                return [
                    'success' => true,
                    'message' => 'Item updated successfully'
                ];
            }
            return [
                'success' => false,
                'message' => 'Failed to update item'
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Failed to update item: ' . $e->getMessage()
            ];
        }
    }

    public function deleteItem($id) {
        try {
            $success = $this->menu->deleteItem($id);
            if ($success) {
                return [
                    'success' => true,
                    'message' => 'Item deleted successfully'
                ];
            }
            return [
                'success' => false,
                'message' => 'Failed to delete item'
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Failed to delete item: ' . $e->getMessage()
            ];
        }
    }

    public function toggleItemAvailability($id) {
        try {
            $success = $this->menu->toggleItemAvailability($id);
            if ($success) {
                return [
                    'success' => true,
                    'message' => 'Item availability updated successfully'
                ];
            }
            return [
                'success' => false,
                'message' => 'Failed to update item availability'
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Failed to update availability: ' . $e->getMessage()
            ];
        }
    }

    public function searchItems($query, $merchantId = null) {
        try {
            $items = $this->menu->searchItems($query, $merchantId);
            return [
                'success' => true,
                'data' => $items
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Failed to search items: ' . $e->getMessage()
            ];
        }
    }

    public function getPopularItems($merchantId = null, $limit = 10) {
        try {
            $items = $this->menu->getPopularItems($merchantId, $limit);
            return [
                'success' => true,
                'data' => $items
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Failed to fetch popular items: ' . $e->getMessage()
            ];
        }
    }

    public function getMenuStats($merchantId = null) {
        try {
            $stats = $this->menu->getMenuStats($merchantId);
            return [
                'success' => true,
                'data' => $stats
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Failed to fetch menu stats: ' . $e->getMessage()
            ];
        }
    }

    public function bulkUpdateItems($items) {
        try {
            $results = [];
            $successCount = 0;
            $errorCount = 0;

            foreach ($items as $item) {
                if (!isset($item['id'])) {
                    $results[] = ['id' => null, 'success' => false, 'message' => 'Item ID is required'];
                    $errorCount++;
                    continue;
                }

                $success = $this->menu->updateItem($item['id'], $item);
                if ($success) {
                    $results[] = ['id' => $item['id'], 'success' => true, 'message' => 'Updated successfully'];
                    $successCount++;
                } else {
                    $results[] = ['id' => $item['id'], 'success' => false, 'message' => 'Failed to update'];
                    $errorCount++;
                }
            }

            return [
                'success' => $errorCount === 0,
                'message' => "Bulk update completed: {$successCount} successful, {$errorCount} failed",
                'data' => [
                    'results' => $results,
                    'summary' => [
                        'total' => count($items),
                        'successful' => $successCount,
                        'failed' => $errorCount
                    ]
                ]
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Bulk update failed: ' . $e->getMessage()
            ];
        }
    }

    public function importMenu($merchantId, $menuData) {
        try {
            $this->db->beginTransaction();

            $importResults = [
                'categories' => ['created' => 0, 'errors' => []],
                'items' => ['created' => 0, 'errors' => []]
            ];

            // Import categories first
            if (isset($menuData['categories'])) {
                foreach ($menuData['categories'] as $categoryData) {
                    $categoryData['merchant_id'] = $merchantId;
                    $categoryId = $this->menu->createCategory($categoryData);
                    if ($categoryId) {
                        $importResults['categories']['created']++;
                        $categoryData['id'] = $categoryId;
                    } else {
                        $importResults['categories']['errors'][] = "Failed to create category: " . $categoryData['name'];
                    }
                }
            }

            // Import items
            if (isset($menuData['items'])) {
                foreach ($menuData['items'] as $itemData) {
                    $itemData['merchant_id'] = $merchantId;
                    $itemId = $this->menu->createItem($itemData);
                    if ($itemId) {
                        $importResults['items']['created']++;
                    } else {
                        $importResults['items']['errors'][] = "Failed to create item: " . $itemData['name'];
                    }
                }
            }

            $this->db->commit();

            return [
                'success' => true,
                'message' => 'Menu imported successfully',
                'data' => $importResults
            ];
        } catch (Exception $e) {
            $this->db->rollback();
            return [
                'success' => false,
                'message' => 'Menu import failed: ' . $e->getMessage()
            ];
        }
    }
}
?>
