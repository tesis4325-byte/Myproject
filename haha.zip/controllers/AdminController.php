<?php
require_once __DIR__ . '/../models/User.php';
require_once __DIR__ . '/../models/Customer.php';
require_once __DIR__ . '/../models/Rider.php';
require_once __DIR__ . '/../models/Merchant.php';
require_once __DIR__ . '/../models/Booking.php';
require_once __DIR__ . '/../models/Menu.php';
require_once __DIR__ . '/../config/AppConfig.php';

class AdminController {
    private $user_model;
    private $customer_model;
    private $rider_model;
    private $merchant_model;
    private $booking_model;
    private $menu_model;
    
    public function __construct() {
        $this->user_model = new User();
        $this->customer_model = new Customer();
        $this->rider_model = new Rider();
        $this->merchant_model = new Merchant();
        $this->booking_model = new Booking();
        $this->menu_model = new Menu();
    }
    
    public function getDashboardData() {
        try {
            // Get booking stats
            $booking_stats = $this->booking_model->getDashboardStats(30);
            $today_stats = $this->booking_model->getTodayStats();
            
            // Get rider stats
            $total_riders = count($this->rider_model->getAll('active'));
            $online_riders = count($this->rider_model->getAll('active', true));
            
            // Get customer stats
            $total_customers = $this->customer_model->getTotalCount();
            $top_customers = $this->customer_model->getTopCustomers(5);
            
            // Get merchant stats
            $total_merchants = count($this->merchant_model->getAll(true));
            $top_merchants = $this->merchant_model->getTopMerchants(5);
            
            // Get recent bookings
            $recent_bookings = $this->booking_model->getAll(null, null, null, null, 10, 0);
            
            return [
                'success' => true,
                'data' => [
                    'booking_stats' => $booking_stats,
                    'today_stats' => $today_stats,
                    'rider_stats' => [
                        'total' => $total_riders,
                        'online' => $online_riders,
                        'offline' => $total_riders - $online_riders
                    ],
                    'customer_stats' => [
                        'total' => $total_customers,
                        'top_customers' => $top_customers
                    ],
                    'merchant_stats' => [
                        'total' => $total_merchants,
                        'top_merchants' => $top_merchants
                    ],
                    'recent_bookings' => $recent_bookings
                ]
            ];
        } catch (Exception $e) {
            AppConfig::logError($e->getMessage(), __FILE__, __LINE__);
            return [
                'success' => false,
                'message' => 'Failed to retrieve dashboard data'
            ];
        }
    }
    
    public function getCustomers($page = 1, $search = '', $blocked_only = false) {
        try {
            $limit = AppConfig::PAGINATION_LIMIT;
            $offset = ($page - 1) * $limit;
            
            $customers = $this->customer_model->getAll($limit, $offset, $search, $blocked_only);
            $total = $this->customer_model->getTotalCount($search, $blocked_only);
            
            return [
                'success' => true,
                'data' => [
                    'customers' => $customers,
                    'pagination' => [
                        'current_page' => $page,
                        'total_pages' => ceil($total / $limit),
                        'total_records' => $total,
                        'per_page' => $limit
                    ]
                ]
            ];
        } catch (Exception $e) {
            AppConfig::logError($e->getMessage(), __FILE__, __LINE__);
            return [
                'success' => false,
                'message' => 'Failed to retrieve customers'
            ];
        }
    }
    
    public function blockCustomer($customer_id, $reason = '') {
        try {
            if ($this->customer_model->blockCustomer($customer_id, $reason)) {
                return [
                    'success' => true,
                    'message' => 'Customer blocked successfully'
                ];
            } else {
                return [
                    'success' => false,
                    'message' => 'Failed to block customer'
                ];
            }
        } catch (Exception $e) {
            AppConfig::logError($e->getMessage(), __FILE__, __LINE__);
            return [
                'success' => false,
                'message' => 'Customer blocking failed'
            ];
        }
    }
    
    public function unblockCustomer($customer_id) {
        try {
            if ($this->customer_model->unblockCustomer($customer_id)) {
                return [
                    'success' => true,
                    'message' => 'Customer unblocked successfully'
                ];
            } else {
                return [
                    'success' => false,
                    'message' => 'Failed to unblock customer'
                ];
            }
        } catch (Exception $e) {
            AppConfig::logError($e->getMessage(), __FILE__, __LINE__);
            return [
                'success' => false,
                'message' => 'Customer unblocking failed'
            ];
        }
    }
    
    public function getRiders($status = null) {
        try {
            $riders = $this->rider_model->getAll($status);
            
            // Get performance stats for each rider
            foreach ($riders as &$rider) {
                $stats = $this->rider_model->getPerformanceStats($rider['id'], 30);
                $rider['performance'] = $stats;
            }
            
            return [
                'success' => true,
                'data' => $riders
            ];
        } catch (Exception $e) {
            AppConfig::logError($e->getMessage(), __FILE__, __LINE__);
            return [
                'success' => false,
                'message' => 'Failed to retrieve riders'
            ];
        }
    }
    
    public function createRider($user_data, $rider_data) {
        try {
            // Create user account first
            $this->user_model->username = $user_data['username'];
            $this->user_model->email = $user_data['email'];
            $this->user_model->password = $user_data['password'];
            $this->user_model->role = 'rider';
            $this->user_model->full_name = $user_data['full_name'];
            $this->user_model->phone = $user_data['phone'];
            $this->user_model->status = 'active';
            
            if ($this->user_model->create()) {
                // Create rider details
                $this->rider_model->user_id = $this->user_model->id;
                $this->rider_model->license_number = $rider_data['license_number'];
                $this->rider_model->vehicle_type = $rider_data['vehicle_type'];
                $this->rider_model->vehicle_plate = $rider_data['vehicle_plate'];
                $this->rider_model->vehicle_model = $rider_data['vehicle_model'];
                $this->rider_model->emergency_contact = $rider_data['emergency_contact'];
                $this->rider_model->emergency_name = $rider_data['emergency_name'];
                
                if ($this->rider_model->create()) {
                    return [
                        'success' => true,
                        'message' => 'Rider created successfully',
                        'rider_id' => $this->rider_model->id
                    ];
                } else {
                    // Rollback user creation if rider creation fails
                    $this->user_model->delete($this->user_model->id);
                    return [
                        'success' => false,
                        'message' => 'Failed to create rider details'
                    ];
                }
            } else {
                return [
                    'success' => false,
                    'message' => 'Failed to create user account'
                ];
            }
        } catch (Exception $e) {
            AppConfig::logError($e->getMessage(), __FILE__, __LINE__);
            return [
                'success' => false,
                'message' => 'Rider creation failed'
            ];
        }
    }
    
    public function updateRiderStatus($user_id, $status) {
        try {
            $this->user_model->getById($user_id);
            $this->user_model->status = $status;
            
            if ($this->user_model->update()) {
                return [
                    'success' => true,
                    'message' => 'Rider status updated successfully'
                ];
            } else {
                return [
                    'success' => false,
                    'message' => 'Failed to update rider status'
                ];
            }
        } catch (Exception $e) {
            AppConfig::logError($e->getMessage(), __FILE__, __LINE__);
            return [
                'success' => false,
                'message' => 'Rider status update failed'
            ];
        }
    }
    
    public function getMerchants($active_only = false) {
        try {
            $merchants = $this->merchant_model->getAll($active_only);
            
            return [
                'success' => true,
                'data' => $merchants
            ];
        } catch (Exception $e) {
            AppConfig::logError($e->getMessage(), __FILE__, __LINE__);
            return [
                'success' => false,
                'message' => 'Failed to retrieve merchants'
            ];
        }
    }
    
    public function createMerchant($data) {
        try {
            $this->merchant_model->name = $data['name'];
            $this->merchant_model->slug = $this->merchant_model->generateSlug($data['name']);
            $this->merchant_model->logo = $data['logo'] ?? '';
            $this->merchant_model->description = $data['description'] ?? '';
            $this->merchant_model->phone = $data['phone'];
            $this->merchant_model->email = $data['email'] ?? '';
            $this->merchant_model->address = $data['address'];
            $this->merchant_model->lat = $data['lat'];
            $this->merchant_model->lng = $data['lng'];
            $this->merchant_model->opening_hours = json_encode($data['opening_hours'] ?? []);
            $this->merchant_model->commission_rate = $data['commission_rate'] ?? 5.00;
            $this->merchant_model->service_fee = $data['service_fee'] ?? 0.00;
            
            if ($this->merchant_model->create()) {
                return [
                    'success' => true,
                    'message' => 'Merchant created successfully',
                    'merchant_id' => $this->merchant_model->id,
                    'slug' => $this->merchant_model->slug
                ];
            } else {
                return [
                    'success' => false,
                    'message' => 'Failed to create merchant'
                ];
            }
        } catch (Exception $e) {
            AppConfig::logError($e->getMessage(), __FILE__, __LINE__);
            return [
                'success' => false,
                'message' => 'Merchant creation failed'
            ];
        }
    }
    
    public function updateMerchant($id, $data) {
        try {
            if (!$this->merchant_model->getById($id)) {
                return [
                    'success' => false,
                    'message' => 'Merchant not found'
                ];
            }
            
            $this->merchant_model->name = $data['name'];
            $this->merchant_model->slug = $data['slug'] ?? $this->merchant_model->generateSlug($data['name']);
            $this->merchant_model->logo = $data['logo'] ?? $this->merchant_model->logo;
            $this->merchant_model->description = $data['description'] ?? '';
            $this->merchant_model->phone = $data['phone'];
            $this->merchant_model->email = $data['email'] ?? '';
            $this->merchant_model->address = $data['address'];
            $this->merchant_model->lat = $data['lat'];
            $this->merchant_model->lng = $data['lng'];
            $this->merchant_model->opening_hours = json_encode($data['opening_hours'] ?? []);
            $this->merchant_model->is_active = $data['is_active'] ?? true;
            $this->merchant_model->commission_rate = $data['commission_rate'] ?? 5.00;
            $this->merchant_model->service_fee = $data['service_fee'] ?? 0.00;
            
            if ($this->merchant_model->update()) {
                return [
                    'success' => true,
                    'message' => 'Merchant updated successfully'
                ];
            } else {
                return [
                    'success' => false,
                    'message' => 'Failed to update merchant'
                ];
            }
        } catch (Exception $e) {
            AppConfig::logError($e->getMessage(), __FILE__, __LINE__);
            return [
                'success' => false,
                'message' => 'Merchant update failed'
            ];
        }
    }
    
    public function deleteMerchant($id) {
        try {
            if ($this->merchant_model->delete($id)) {
                return [
                    'success' => true,
                    'message' => 'Merchant deleted successfully'
                ];
            } else {
                return [
                    'success' => false,
                    'message' => 'Failed to delete merchant'
                ];
            }
        } catch (Exception $e) {
            AppConfig::logError($e->getMessage(), __FILE__, __LINE__);
            return [
                'success' => false,
                'message' => 'Merchant deletion failed'
            ];
        }
    }
    
    public function getReports($type, $start_date, $end_date, $merchant_id = null) {
        try {
            switch ($type) {
                case 'sales':
                    return $this->getSalesReport($start_date, $end_date, $merchant_id);
                case 'riders':
                    return $this->getRiderReport($start_date, $end_date);
                case 'customers':
                    return $this->getCustomerReport($start_date, $end_date);
                default:
                    return [
                        'success' => false,
                        'message' => 'Invalid report type'
                    ];
            }
        } catch (Exception $e) {
            AppConfig::logError($e->getMessage(), __FILE__, __LINE__);
            return [
                'success' => false,
                'message' => 'Report generation failed'
            ];
        }
    }
    
    private function getSalesReport($start_date, $end_date, $merchant_id = null) {
        // Implementation for sales report
        $query = "SELECT 
                    DATE(created_at) as date,
                    COUNT(*) as total_orders,
                    COUNT(CASE WHEN status = 'delivered' THEN 1 END) as completed_orders,
                    SUM(CASE WHEN status = 'delivered' THEN total_amount ELSE 0 END) as total_revenue,
                    SUM(CASE WHEN status = 'delivered' THEN service_fee ELSE 0 END) as total_commission
                  FROM bookings 
                  WHERE created_at BETWEEN :start_date AND :end_date";
        
        if ($merchant_id) {
            $query .= " AND merchant_id = :merchant_id";
        }
        
        $query .= " GROUP BY DATE(created_at) ORDER BY date DESC";
        
        // This would be implemented with proper database connection
        return [
            'success' => true,
            'data' => []
        ];
    }
    
    private function getRiderReport($start_date, $end_date) {
        // Implementation for rider performance report
        return [
            'success' => true,
            'data' => []
        ];
    }
    
    private function getCustomerReport($start_date, $end_date) {
        // Implementation for customer activity report
        return [
            'success' => true,
            'data' => []
        ];
    }
    
    public function broadcastNotification($title, $message, $type = 'system', $target_role = null) {
        try {
            // Get target users
            $users = $this->user_model->getAll($target_role, 'active');
            
            $success_count = 0;
            foreach ($users as $user) {
                // Insert notification for each user
                $query = "INSERT INTO notifications (user_id, type, title, message) 
                          VALUES (:user_id, :type, :title, :message)";
                
                // This would be implemented with proper database connection
                $success_count++;
            }
            
            return [
                'success' => true,
                'message' => "Notification sent to {$success_count} users"
            ];
        } catch (Exception $e) {
            AppConfig::logError($e->getMessage(), __FILE__, __LINE__);
            return [
                'success' => false,
                'message' => 'Notification broadcast failed'
            ];
        }
    }
}
?>
