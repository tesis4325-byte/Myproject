# RM Delivery Management System

A comprehensive web-based delivery management system built with PHP, MySQL, and modern web technologies. The system provides complete management interfaces for administrators, riders, customers, and merchants with real-time tracking capabilities focused on the Mindanao region of the Philippines.

## Features

### 🔧 Admin Dashboard
- **Complete Management Interface**: Manage bookings, customers, riders, merchants, menus, reports, promotions, complaints, and system settings
- **Real-time Analytics**: Interactive charts and statistics with Chart.js integration
- **Advanced Filtering**: Search, sort, and filter data across all management pages
- **Bulk Operations**: Perform actions on multiple records simultaneously
- **Data Export**: Export data to CSV format for reporting
- **User Management**: Role-based access control and security settings

### 🚴 Rider Interface
- **Mobile-Optimized Dashboard**: Clean, responsive interface for riders on the go
- **Booking Management**: View available bookings, accept orders, and update delivery status
- **Real-time Tracking**: GPS location tracking with OpenStreetMap integration
- **Delivery History**: Complete history with earnings, ratings, and performance metrics
- **Profile Management**: Update personal info, vehicle details, and documents
- **Panic Alert System**: Emergency alert system with location sharing

### 👥 Customer Features
- **User-Friendly Interface**: Browse restaurants, view menus, and place orders
- **Order Tracking**: Real-time order status updates and delivery tracking
- **Rating System**: Rate deliveries and provide feedback
- **Order History**: View past orders and reorder favorites

### 🏪 Merchant Support
- **Menu Management**: Add, edit, and manage menu items with images
- **Order Processing**: Receive and process incoming orders
- **Analytics**: View sales performance and customer feedback

## Technology Stack

### Backend
- **PHP 7.4+**: Server-side scripting
- **MySQL 8.0+**: Database management
- **RESTful APIs**: JSON-based API endpoints for AJAX functionality

### Frontend
- **HTML5/CSS3**: Modern web standards
- **JavaScript (ES6+)**: Interactive functionality
- **Bootstrap 5**: Responsive UI framework
- **Chart.js**: Data visualization and analytics
- **SweetAlert2**: Beautiful alerts and notifications
- **FontAwesome**: Icon library

### Mapping & Location
- **Leaflet.js**: Interactive maps
- **OpenStreetMap**: Map tiles and data
- **Leaflet Routing Machine**: Route calculation and navigation
- **Geolocation API**: GPS location tracking

## Installation

### Prerequisites
- **XAMPP/WAMP/LAMP**: Local development environment
- **PHP 7.4+**: With PDO MySQL extension
- **MySQL 8.0+**: Database server
- **Web Browser**: Modern browser with JavaScript enabled

### Setup Instructions

1. **Clone/Download the Project**
   ```bash
   git clone <repository-url>
   # OR download and extract to your web server directory
   ```

2. **Database Setup**
   ```bash
   # Import the database schema
   mysql -u root -p < sql/schema.sql
   
   # Import sample data (optional)
   mysql -u root -p < sql/seed.sql
   ```

3. **Configuration**
   ```php
   // Update config/Database.php with your database credentials
   private $host = "localhost";
   private $db_name = "rmdelivery";
   private $username = "root";
   private $password = "your_password";
   ```

4. **File Permissions**
   ```bash
   # Set proper permissions for upload directories
   chmod 755 uploads/
   chmod 755 logs/
   ```

5. **Access the Application**
   - **Customer Interface**: `http://localhost/rmdelivery/public/`
   - **Admin Dashboard**: `http://localhost/rmdelivery/admin/`
   - **Rider Interface**: `http://localhost/rmdelivery/rider/`

## Default Login Credentials

### Admin Access
- **URL**: `/admin/`
- **Username**: admin@rmdelivery.com
- **Password**: admin123

### Rider Access
- **URL**: `/rider/`
- **Phone**: 09123456789
- **Password**: rider123

### Customer Access
- **URL**: `/public/`
- **Phone**: 09987654321
- **Password**: customer123

## API Endpoints

### Authentication
- `POST /api/auth.php?action=login` - User login
- `POST /api/auth.php?action=register` - User registration
- `GET /api/auth.php?action=logout` - User logout
- `GET /api/auth.php?action=check_session` - Session validation

### Bookings Management
- `GET /api/bookings.php?action=list` - Get bookings list
- `GET /api/bookings.php?action=stats` - Get booking statistics
- `POST /api/bookings.php?action=create` - Create new booking
- `PUT /api/bookings.php?action=update_status` - Update booking status
- `POST /api/bookings.php?action=assign_rider` - Assign rider to booking

### Rider Operations
- `GET /api/riders.php?action=dashboard_stats` - Get rider dashboard stats
- `GET /api/riders.php?action=available_bookings` - Get available bookings
- `POST /api/riders.php?action=accept_booking` - Accept booking
- `PUT /api/riders.php?action=update_booking_status` - Update delivery status
- `POST /api/riders.php?action=update_location` - Update GPS location
- `POST /api/riders.php?action=send_panic_alert` - Send emergency alert

### File Uploads
- `POST /api/uploads.php?action=profile_image` - Upload profile image
- `POST /api/uploads.php?action=document` - Upload document
- `POST /api/uploads.php?action=menu_image` - Upload menu item image

## Directory Structure

```
rmdelivery/
├── admin/                  # Admin dashboard
│   ├── assets/            # Admin CSS, JS, images
│   ├── templates/         # Header, footer, sidebar templates
│   └── *.php             # Admin management pages
├── api/                   # RESTful API endpoints
│   ├── auth.php          # Authentication API
│   ├── bookings.php      # Bookings management API
│   ├── customers.php     # Customer management API
│   ├── riders.php        # Rider operations API
│   └── uploads.php       # File upload API
├── config/               # Configuration files
│   ├── Database.php      # Database connection
│   └── AppConfig.php     # Application settings
├── controllers/          # Business logic controllers
├── models/              # Data models
├── public/              # Customer-facing pages
│   ├── assets/          # Public CSS, JS, images
│   └── *.php           # Customer pages
├── rider/               # Rider interface
│   ├── assets/          # Rider CSS, JS, images
│   └── *.php           # Rider pages
├── logs/                # System and error logs
├── uploads/             # User uploaded files
├── sql/                 # Database schema and seed data
└── README.md           # This file
```

## Key Features Explained

### Real-time Tracking
- GPS location updates every 30 seconds for active riders
- Live map display with pickup and delivery markers
- Route optimization using OSRM routing service
- Geofencing for delivery confirmation

### Security Features
- Session-based authentication
- Password hashing with PHP's password_hash()
- SQL injection prevention with prepared statements
- File upload validation and sanitization
- CSRF protection on forms

### Mobile Responsiveness
- Bootstrap 5 responsive grid system
- Touch-friendly interface for riders
- Optimized for mobile devices and tablets
- Progressive Web App (PWA) capabilities

### Performance Optimization
- Database indexing for fast queries
- AJAX-based page updates without refresh
- Image optimization and lazy loading
- Efficient API endpoints with pagination

## Customization

### Styling
- Modify CSS files in respective `assets/css/` directories
- Sky Blue (#87CEEB) and Dark Blue (#1e3a8a) color scheme
- Bootstrap 5 utility classes for rapid customization

### Configuration
- Update `config/AppConfig.php` for application settings
- Modify database schema in `sql/schema.sql` as needed
- Adjust API rate limits and security settings

### Maps and Location
- Mindanao region focused with custom map bounds
- OpenStreetMap tiles (can be changed to other providers)
- Routing service can be switched to different providers

## Troubleshooting

### Common Issues

1. **Database Connection Failed**
   - Check database credentials in `config/Database.php`
   - Ensure MySQL service is running
   - Verify database exists and is accessible

2. **File Upload Errors**
   - Check upload directory permissions (755)
   - Verify PHP upload settings (upload_max_filesize, post_max_size)
   - Ensure uploads/ directory exists

3. **Map Not Loading**
   - Check internet connection for OpenStreetMap tiles
   - Verify Leaflet.js library is loaded
   - Check browser console for JavaScript errors

4. **Session Issues**
   - Ensure PHP sessions are enabled
   - Check session directory permissions
   - Verify session configuration in php.ini

### Performance Issues
- Enable PHP OPcache for better performance
- Optimize database queries with proper indexing
- Use CDN for static assets in production
- Enable gzip compression on web server

## Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/new-feature`)
3. Commit your changes (`git commit -am 'Add new feature'`)
4. Push to the branch (`git push origin feature/new-feature`)
5. Create a Pull Request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Support

For support and questions:
- **Email**: support@rmdelivery.com
- **Documentation**: Check this README and inline code comments
- **Issues**: Report bugs and feature requests via GitHub issues

## Changelog

### Version 1.0.0 (Current)
- Complete admin dashboard with all management features
- Full rider interface with real-time tracking
- Customer ordering system
- RESTful API endpoints
- OpenStreetMap integration for Mindanao region
- File upload system
- Comprehensive logging system
- Mobile-responsive design
- Security features and authentication

---

**RM Delivery Management System** - Efficient delivery management for the modern world.
