<?php
class AppConfig {
    // Site Configuration
    const SITE_NAME = 'RM Delivery';
    const SITE_URL = 'http://localhost/rmdelivery';
    const SITE_EMAIL = 'admin@rmdelivery.com';
    
    // Theme Colors
    const PRIMARY_COLOR = '#0EA5E9'; // Sky Blue
    const SECONDARY_COLOR = '#1E3A8A'; // Dark Blue
    const SUCCESS_COLOR = '#10B981';
    const WARNING_COLOR = '#F59E0B';
    const DANGER_COLOR = '#EF4444';
    
    // File Upload Settings
    const MAX_FILE_SIZE = 5242880; // 5MB
    const ALLOWED_IMAGE_TYPES = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
    const UPLOAD_PATH = '/uploads/';
    
    // Map Configuration (Mindanao, Philippines)
    const MAP_CENTER_LAT = 7.8731;
    const MAP_CENTER_LNG = 125.0000;
    const MAP_ZOOM_LEVEL = 8;
    
    // Business Settings
    const DELIVERY_FEE_BASE = 50.00;
    const DELIVERY_FEE_PER_KM = 10.00;
    const SERVICE_FEE_PERCENTAGE = 0.05; // 5%
    const RIDER_COMMISSION_PERCENTAGE = 0.15; // 15%
    
    // System Settings
    const PAGINATION_LIMIT = 20;
    const SESSION_TIMEOUT = 3600; // 1 hour
    const LOG_RETENTION_DAYS = 30;
    
    // Notification Settings
    const ENABLE_SMS = true;
    const ENABLE_EMAIL = true;
    const ENABLE_PUSH = true;
    
    // Security Settings
    const BCRYPT_COST = 12;
    const CSRF_TOKEN_EXPIRY = 1800; // 30 minutes
    
    public static function getTimezone() {
        return 'Asia/Manila';
    }
    
    public static function formatCurrency($amount) {
        return '₱' . number_format($amount, 2);
    }
    
    public static function logActivity($user_id, $action, $details = '') {
        $log_file = __DIR__ . '/../logs/activity.log';
        $timestamp = date('Y-m-d H:i:s');
        $log_entry = "[{$timestamp}] User ID: {$user_id} | Action: {$action} | Details: {$details}" . PHP_EOL;
        file_put_contents($log_file, $log_entry, FILE_APPEND | LOCK_EX);
    }
    
    public static function logError($error_message, $file = '', $line = '') {
        $log_file = __DIR__ . '/../logs/errors.log';
        $timestamp = date('Y-m-d H:i:s');
        $log_entry = "[{$timestamp}] Error: {$error_message}";
        if ($file) $log_entry .= " | File: {$file}";
        if ($line) $log_entry .= " | Line: {$line}";
        $log_entry .= PHP_EOL;
        file_put_contents($log_file, $log_entry, FILE_APPEND | LOCK_EX);
    }
}
?>
