<?php
// Generate correct password hash
$password = 'password123';
$hash = password_hash($password, PASSWORD_DEFAULT);

echo "<h2>Password Hash Generator</h2>";
echo "Password: $password<br>";
echo "Generated Hash: $hash<br><br>";

// Verify it works
$verify = password_verify($password, $hash);
echo "Verification Test: " . ($verify ? "✅ SUCCESS" : "❌ FAILED") . "<br><br>";

if ($verify) {
    echo "<h3>Updating Database...</h3>";
    
    require_once 'config/Database.php';
    
    try {
        $db = Database::getInstance()->getConnection();
        
        // Update admin password
        $stmt = $db->prepare("UPDATE users SET password = ? WHERE username = 'admin'");
        $result1 = $stmt->execute([$hash]);
        echo "Admin password updated: " . ($result1 ? "✅ SUCCESS" : "❌ FAILED") . "<br>";
        
        // Update rider password
        $stmt = $db->prepare("UPDATE users SET password = ? WHERE username = 'rider001'");
        $result2 = $stmt->execute([$hash]);
        echo "Rider password updated: " . ($result2 ? "✅ SUCCESS" : "❌ FAILED") . "<br><br>";
        
        // Final verification
        echo "<h3>Final Verification:</h3>";
        
        // Test admin
        $stmt = $db->prepare("SELECT password FROM users WHERE username = 'admin'");
        $stmt->execute();
        $adminHash = $stmt->fetchColumn();
        $adminValid = password_verify($password, $adminHash);
        echo "Admin login test: " . ($adminValid ? "✅ SUCCESS" : "❌ FAILED") . "<br>";
        
        // Test rider
        $stmt = $db->prepare("SELECT password FROM users WHERE username = 'rider001'");
        $stmt->execute();
        $riderHash = $stmt->fetchColumn();
        $riderValid = password_verify($password, $riderHash);
        echo "Rider login test: " . ($riderValid ? "✅ SUCCESS" : "❌ FAILED") . "<br><br>";
        
        if ($adminValid && $riderValid) {
            echo "<h3>🎉 Authentication Fixed!</h3>";
            echo "<p><a href='admin/index.php'>Test Admin Login</a> | <a href='rider/index.php'>Test Rider Login</a></p>";
        }
        
    } catch (Exception $e) {
        echo "❌ Database Error: " . $e->getMessage();
    }
}
?>
