<?php
// Debug the actual login process
require_once 'config/Database.php';

echo "<h2>Login Debug Tool</h2>";

// Test the exact same process as the API
$phone = '09123456789';
$password = 'password123';
$userType = 'admin';

try {
    $db = Database::getInstance()->getConnection();
    
    echo "<h3>Step 1: Database Connection</h3>";
    echo "✅ Connected to database<br><br>";
    
    echo "<h3>Step 2: Query Users Table</h3>";
    $stmt = $db->prepare("SELECT * FROM users WHERE phone = ? AND role = ? AND status = 'active'");
    $stmt->execute([$phone, $userType]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($user) {
        echo "✅ User found:<br>";
        echo "- ID: " . $user['id'] . "<br>";
        echo "- Username: " . $user['username'] . "<br>";
        echo "- Phone: " . $user['phone'] . "<br>";
        echo "- Role: " . $user['role'] . "<br>";
        echo "- Status: " . $user['status'] . "<br>";
        echo "- Password Hash: " . substr($user['password'], 0, 20) . "...<br><br>";
        
        echo "<h3>Step 3: Password Verification</h3>";
        $passwordValid = password_verify($password, $user['password']);
        echo "Password verification: " . ($passwordValid ? "✅ SUCCESS" : "❌ FAILED") . "<br><br>";
        
        if ($passwordValid) {
            echo "<h3>Step 4: Simulate API Response</h3>";
            echo "✅ Login should succeed<br>";
            echo "Expected response: 200 OK with user data<br><br>";
            
            echo "<h3>🔍 API Debug Test</h3>";
            echo "<p>Let's test the actual API endpoint:</p>";
            
            $postData = json_encode([
                'phone' => $phone,
                'password' => $password,
                'user_type' => $userType
            ]);
            
            echo "<strong>POST Data:</strong><br>";
            echo "<pre>" . htmlspecialchars($postData) . "</pre>";
            
            // Test with cURL
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, 'http://localhost/rmdelivery/api/auth.php?action=login');
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
            curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HEADER, true);
            
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            
            echo "<strong>API Response (HTTP $httpCode):</strong><br>";
            echo "<pre>" . htmlspecialchars($response) . "</pre>";
            
        } else {
            echo "❌ Password verification failed - this is the issue!<br>";
        }
        
    } else {
        echo "❌ No user found with phone: $phone, role: $userType, status: active<br>";
        
        // Check what users exist
        echo "<h3>Available Users:</h3>";
        $stmt = $db->prepare("SELECT id, username, phone, role, status FROM users");
        $stmt->execute();
        $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        foreach ($users as $u) {
            echo "- ID: {$u['id']}, Username: {$u['username']}, Phone: {$u['phone']}, Role: {$u['role']}, Status: {$u['status']}<br>";
        }
    }
    
} catch (Exception $e) {
    echo "❌ Error: " . $e->getMessage();
}
?>
