<?php
// Fix password hashes in database
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'config/Database.php';

try {
    $db = Database::getInstance()->getConnection();
    
    // Correct password hash for 'password123'
    $correctHash = '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi';
    
    echo "<h2>Fixing Password Hashes</h2>";
    
    // Update admin password
    $stmt = $db->prepare("UPDATE users SET password = ? WHERE username = 'admin'");
    $result1 = $stmt->execute([$correctHash]);
    echo "Admin password updated: " . ($result1 ? "✅ SUCCESS" : "❌ FAILED") . "<br>";
    
    // Update rider password
    $stmt = $db->prepare("UPDATE users SET password = ? WHERE username = 'rider001'");
    $result2 = $stmt->execute([$correctHash]);
    echo "Rider password updated: " . ($result2 ? "✅ SUCCESS" : "❌ FAILED") . "<br><br>";
    
    // Verify the fix
    echo "<h3>Verification:</h3>";
    $testPassword = 'password123';
    
    // Test admin
    $stmt = $db->prepare("SELECT password FROM users WHERE username = 'admin'");
    $stmt->execute();
    $adminHash = $stmt->fetchColumn();
    $adminValid = password_verify($testPassword, $adminHash);
    echo "Admin password verification: " . ($adminValid ? "✅ SUCCESS" : "❌ FAILED") . "<br>";
    
    // Test rider
    $stmt = $db->prepare("SELECT password FROM users WHERE username = 'rider001'");
    $stmt->execute();
    $riderHash = $stmt->fetchColumn();
    $riderValid = password_verify($testPassword, $riderHash);
    echo "Rider password verification: " . ($riderValid ? "✅ SUCCESS" : "❌ FAILED") . "<br><br>";
    
    if ($adminValid && $riderValid) {
        echo "<h3>🎉 Password Fix Complete!</h3>";
        echo "<p>You can now login with:</p>";
        echo "<ul>";
        echo "<li><strong>Admin:</strong> 09123456789 / password123</li>";
        echo "<li><strong>Rider:</strong> 09987654321 / password123</li>";
        echo "</ul>";
        echo "<p><a href='admin/index.php'>Try Admin Login</a> | <a href='rider/index.php'>Try Rider Login</a></p>";
    }
    
} catch (Exception $e) {
    echo "❌ Error: " . $e->getMessage();
}
?>
