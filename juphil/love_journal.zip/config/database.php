<?php
define('DB_SERVER', 'sql107.infinityfree.com'); // from your panel
define('DB_USERNAME', 'if0_39491840');          // your InfinityFree DB username
define('DB_PASSWORD', 'ONKHZhcnfDh');           // your vPanel password
define('DB_NAME', 'if0_39491840_love_journal'); // full DB name with prefix

$mysqli = new mysqli(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);

// Check connection
if ($mysqli->connect_error) {
    die("ERROR: Could not connect. " . $mysqli->connect_error);
}
?>